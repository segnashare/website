import * as react from "react";
import { CSSProperties, Component, ComponentProps, ComponentType, Dispatch, ElementType, ErrorInfo, FC, FocusEvent, FocusEventHandler, FormEvent, FormEventHandler, HTMLAttributes, HTMLProps, KeyboardEvent, MutableRefObject, PropsWithChildren, PureComponent, ReactElement, ReactNode, Ref, RefAttributes, RefObject, SVGProps, SetStateAction } from "react";
import * as _sanity_types0 from "@sanity/types";
import { ArraySchemaType, AssetMetadataType, AssetSource, AssetSourceSpec, BlockDecoratorDefinition, BlockListDefinition, BlockStyleDefinition, BooleanSchemaType, ConditionalProperty, CrossDatasetReferenceSchemaType, CrossDatasetReferenceValue, CrossDatasetType, CurrentUser, DeprecatedProperty, FieldGroup, File as File$1, FileAsset, FileSchemaType, FileValue, FormNodeValidation, GeopointValue, GlobalDocumentReferenceType, I18nTextRecord, Image, ImageAsset, ImageSchemaType, ImageUrlFitMode, ImageValue, IndexTuple, InitialValueProperty, InitialValueResolverContext, IntrinsicTypeName, KeyedObject, KeyedSegment, MendozaEffectPair, NumberSchemaType, ObjectField, ObjectFieldType, ObjectSchemaType, PatchOperations, Path, PathSegment, PortableTextBlock, PortableTextObject, PortableTextTextBlock, PrepareViewOptions, PreviewValue, Reference, ReferenceSchemaType, ReferenceValue, Role, RuleClass, SanityDocument, SanityDocumentLike, Schema, SchemaType, SchemaTypeDefinition, SearchStrategy, SlugSchemaType, SlugValue, SortOrdering, StrictVersionLayeringOptions, StringSchemaType, TextSchemaType, TransactionLogEventWithEffects, TransactionLogEventWithMutations, UploadState, User, ValidationMarker } from "@sanity/types";
import { BifurClient } from "@sanity/bifur-client";
import * as _sanity_client0 from "@sanity/client";
import { ClientConfig, ClientPerspective, QueryParams, ReconnectEvent, ReleaseDocument, ReleaseDocument as ReleaseDocument$1, ReleaseType, ResetEvent, SanityClient, SanityDocument as SanityDocument$1, SingleActionResult, SingleMutationResult, StackablePerspective, WelcomeBackEvent, WelcomeEvent } from "@sanity/client";
import * as _sanity_ui0 from "@sanity/ui";
import { AvatarPosition, AvatarProps, AvatarSize, AvatarStatus, BadgeProps, BadgeTone, BoxProps, ButtonProps, ButtonTone, CardProps, DialogProps, HotkeysProps, MenuButtonProps, MenuItem, Placement, PopoverProps, ResponsivePaddingProps, ResponsiveWidthProps, Text, TextProps, ThemeColorSchemeKey, ToastParams, TooltipProps } from "@sanity/ui";
import { FlatNamespace, KeyPrefix, Namespace, TFunction, TFunction as TFunction$1, i18n as i18n$1 } from "i18next";
import { MonoTypeOperatorFunction, Observable, OperatorFunction, Subject } from "rxjs";
import { IntentLinkProps, IntentParameters, Router, RouterState, SearchParam } from "sanity/router";
import { ScrollToOptions } from "@tanstack/react-virtual";
import * as _sanity_telemetry0 from "@sanity/telemetry";
import { DRAFTS_FOLDER, DraftId, PublishedId, VERSION_FOLDER, getDraftId, getPublishedId, getVersionFromId, getVersionId, isDraftId, isPublishedId, isVersionId } from "@sanity/client/csm";
import * as sanity__singletons0 from "sanity/_singletons";
import { DocumentLimitUpsellContextValue, FieldActionsContextValue, HoveredFieldContextValue, LocaleContextValue, SchedulesContext, SingleDocReleaseContextValue } from "sanity/_singletons";
import { Mutation } from "@sanity/mutator";
import { CanvasResource, FrameMessages, MediaResource, StudioResource, WindowMessages } from "@sanity/message-protocol";
import { DocumentHandle } from "@sanity/sdk";
import { FallbackNs } from "react-i18next";
import { BrowserHistory, HashHistory, History, MemoryHistory } from "history";
import { RootTheme, ThemeColorSchemeKey as ThemeColorSchemeKey$1 } from "@sanity/ui/theme";
import { EditorSelection, HotkeyOptions, InvalidValueResolution, OnCopyFn, OnPasteResultOrPromise, PasteData, Patch, PortableTextEditor, RangeDecoration, RangeDecorationOnMovedDetails, RenderBlockFunction } from "@portabletext/editor";
import { ColorHueKey, ColorTintKey, ColorTints } from "@sanity/color";
import { Subscriber } from "nano-pubsub";
import { ArrayDiff, BooleanDiff, Diff, ItemDiff, NullDiff, NumberDiff, ObjectDiff, StringDiff, StringSegmentChanged, StringSegmentUnchanged, TypeChangeDiff } from "@sanity/diff";
import * as styled_components0 from "styled-components";
import { ExecutionProps } from "styled-components";
import * as date_fns_formatRelative0 from "date-fns/formatRelative";
import { ResizeObserverEntry } from "@juggle/resize-observer";
import { ThrottleSettings } from "lodash-es/throttle.js";
import { DEFAULT_ANNOTATIONS, DEFAULT_DECORATORS } from "@sanity/schema";
import * as styled_components_dist_types0 from "/home/runner/work/sanity/sanity/node_modules/.pnpm/@sanity+styled-components@6.1.24_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@sanity/styled-components/dist/types.js";
import { PortableTextMemberSchemaTypes } from "@portabletext/sanity-bridge";
import { ImageUrlBuilder, ImageUrlBuilder as ImageUrlBuilder$1 } from "@sanity/image-url";
import { MarkdownShortcutsPluginProps } from "@portabletext/plugin-markdown-shortcuts";
import { PasteLinkPluginProps } from "@portabletext/plugin-paste-link";
import { TypographyPluginProps } from "@portabletext/plugin-typography";
import { Node } from "@sanity/comlink";
interface CreateSanityMediaLibrarySourceProps {
  i18nKey?: string;
  icon?: React.ComponentType;
  libraryId: string | null;
  name?: string;
}
/**
 * Create a new image asset source for the Media Library
 *
 * @beta
 */
declare function createSanityMediaLibraryImageSource(props: CreateSanityMediaLibrarySourceProps): AssetSource;
/**
 * Create a new file asset source for the Media Library
 *
 * @beta
 */
declare function createSanityMediaLibraryFileSource(props: CreateSanityMediaLibrarySourceProps): AssetSource;
interface SharedProps$1 {
  children?: ReactNode;
  header: string;
  width: ResponsiveWidthProps['width'];
}
interface DialogProps$2 extends SharedProps$1 {
  type: 'dialog';
  id?: string;
  autofocus?: boolean;
  onClose?: () => void;
}
interface PopoverProps$3 extends SharedProps$1 {
  type: 'popover';
  legacy_referenceElement: HTMLElement | null;
  onClose: () => void;
}
/**
 * @beta
 * Creates a dialog or a popover for editing content.
 * Handles presence and virtual scrolling.
 */
declare function EditPortal(props: PopoverProps$3 | DialogProps$2): React.JSX.Element;
interface SharedProps {
  children?: ReactNode;
  header: string;
  width: ResponsiveWidthProps['width'];
}
interface DialogProps$1 extends SharedProps {
  type: 'dialog';
  id?: string;
  autofocus?: boolean;
  onClose?: () => void;
}
interface PopoverProps$2 extends SharedProps {
  type: 'popover';
  id?: string;
  legacy_referenceElement: HTMLElement | null;
  onClose: () => void;
}
/**
 * @beta
 * Creates a dialog or a popover for editing content.
 * Handles presence and virtual scrolling.
 *
 * When multiple dialogs are open, only the top-most dialog is visible.
 * Non-top dialogs are hidden via CSS while preserving their state.
 */
declare function EnhancedObjectDialog(props: PopoverProps$2 | DialogProps$1): React.JSX.Element;
type JsonObject = { [Key in string]: KeyValueStoreValue } & { [Key in string]?: KeyValueStoreValue | undefined };
type JsonArray = KeyValueStoreValue[] | readonly KeyValueStoreValue[];
type JsonPrimitive = string | number | boolean | null;
/** @internal */
type KeyValueStoreValue = JsonPrimitive | JsonObject | JsonArray;
/** @internal */
interface KeyValueStore {
  getKey(key: string): Observable<KeyValueStoreValue | null>;
  setKey(key: string, value: KeyValueStoreValue): Promise<KeyValueStoreValue>;
}
/** @internal */
declare function createKeyValueStore(options: {
  client: SanityClient;
}): KeyValueStore;
/**
 * The interface used by the Studio that produces a `SanityClient` and
 * `CurrentUser` that gets passed to the resulting `Workspace`s and `Source`s.
 *
 * NOTE: This interface is primarily for internal use. Refer to
 * `createAuthStore` instead.
 *
 * @beta
 * @hidden
 */
interface AuthStore {
  /**
   * Emits `AuthState`s. This should update when the user's auth state changes.
   * E.g. After a login, a new `AuthState` could be emitted with a non-null
   * `currentUser` and `authenticated: true`
   *
   * NOTE: all auth store implementations should emit on subscribe using
   * something like shareReplay(1) to ensure all new subscribers get an
   * `AuthState` value on subscribe
   */
  state: Observable<AuthState>;
  /**
   * Emits auth tokens, or `null` if not configured to use them or they do not exist
   */
  token?: Observable<string | null>;
  /**
   * Custom auth stores are expected to implement a UI that initiates the user's
   * authentication. For the typical case in `createAuthStore`, this means
   * loading the providers and showing them as options to the user.
   */
  LoginComponent?: ComponentType<LoginComponentProps>;
  /**
   * Custom auth stores can implement a function that runs when the user logs
   * out. The implementation is expected to remove all credentials both locally
   * and on the server.
   */
  logout?: () => void;
  /**
   * Custom auth stores can implement a function that is designated to run when
   * the Studio loads (e.g. to trade a session ID for a token in cookie-less
   * mode). Within the Studio, this is called within the `AuthBoundary`.
   */
  handleCallbackUrl?: () => Promise<void>;
}
/**
 * The unit an `AuthStore` emits to determine the user's authentication state.
 *
 * @beta
 * @hidden
 */
interface AuthState {
  /**
   * Similar to a logged-in flag. This state is used in places like the
   * `AuthBoundary` to determine whether or not it should render the
   * `NotAuthenticatedComponent`. Implementers may choose to set this to `true`
   * while also also emitting a `currentUser` of `null` if a `null` user is
   * accepted (e.g. a project that doesn't require a login)
   */
  authenticated: boolean;
  /**
   * The value of the user logged in or `null` if none is provided
   */
  currentUser: CurrentUser | null;
  /**
   * A client that is expected to be pre-configured to allow for any downstream
   * requests in the Studio
   */
  client: SanityClient;
}
/**
 * @beta
 * @hidden
 */
type LoginComponentProps = {
  projectId: string; /** @deprecated use redirectPath instead */
  basePath: string;
  redirectPath?: string;
} | {
  projectId: string;
  redirectPath: string; /** @deprecated use redirectPath instead */
  basePath?: string;
};
/** @internal */
interface AuthStoreOptions extends AuthConfig {
  clientFactory?: (options: ClientConfig) => SanityClient;
  projectId: string;
  dataset: string;
}
/**
 * @internal
 */
declare function _createAuthStore({
  clientFactory: clientFactoryOption,
  projectId,
  dataset,
  apiHost,
  loginMethod,
  ...providerOptions
}: AuthStoreOptions): AuthStore;
/**
 * @internal
 */
declare const createAuthStore: typeof _createAuthStore;
/** @internal */
interface MockAuthStoreOptions {
  currentUser: CurrentUser | null;
  client: SanityClient;
}
/**
 * Creates a mock `AuthStore` (for testing) that emits an `AuthState` derived
 * from the `client` and `currentUser` given.
 *
 * @internal
 */
declare function createMockAuthStore({
  client,
  currentUser
}: MockAuthStoreOptions): AuthStore;
/** @internal */
declare function getProviderTitle(provider?: string): string | undefined;
/**
 * Duck-type check for whether or not this looks like an auth store
 *
 * @param maybeStore - Item to check if matches the AuthStore interface
 * @returns True if auth store, false otherwise
 * @internal
 */
declare function isAuthStore(maybeStore: unknown): maybeStore is AuthStore;
/**
 * Check whether the provided login method is compatible with cookieless auth, e.g. whether any
 * authentication token found in localStorage should be acknowledged.
 *
 * @internal
 */
declare function isCookielessCompatibleLoginMethod(loginMethod: LoginMethod): loginMethod is CookielessCompatibleLoginMethod;
/** @internal */
interface ConnectionStatusStore {
  connectionStatus$: Observable<ConnectionStatus>;
}
/** @internal */
type ConnectingStatus = {
  type: 'connecting';
};
/** @internal */
type ErrorStatus = {
  type: 'error';
  error: Error;
  attemptNo: number;
  isOffline: boolean;
  retryAt: Date;
};
/** @internal */
type RetryingStatus = {
  type: 'retrying';
};
/** @internal */
type ConnectedStatus = {
  type: 'connected';
  lastHeartbeat: Date;
};
/** @internal */
declare const CONNECTING: ConnectingStatus;
/** @internal */
type ConnectionStatus = ConnectingStatus | ErrorStatus | ConnectedStatus | RetryingStatus;
/** @internal */
declare const onRetry: () => void;
/** @internal */
interface ConnectionStatusStoreOptions {
  bifur: BifurClient;
}
/**
 * This is the beginning of what should be the data store tracking connection status in the Sanity studio.
 *
 * @internal
 */
declare function createConnectionStatusStore({
  bifur
}: ConnectionStatusStoreOptions): ConnectionStatusStore;
/** @internal */
interface CorsOriginErrorOptions {
  projectId?: string;
  isStaging: boolean;
}
/** @internal */
declare class CorsOriginError extends Error {
  projectId?: string;
  isStaging: boolean;
  constructor({
    projectId,
    isStaging
  }: CorsOriginErrorOptions);
}
/** @internal */
type BetaBadgeProps = Omit<BadgeProps, 'mode' | 'tone'>;
/** @internal */
declare function BetaBadge(props: BetaBadgeProps & Omit<HTMLProps<HTMLDivElement>, 'ref'>): react.JSX.Element;
/** @internal */
type CommandListElementType = 'input' | 'list';
/** @internal */
type CommandListGetItemDisabledCallback = (virtualIndex: number) => boolean;
/** @internal */
type CommandListGetItemKeyCallback = (virtualIndex: number) => number | string;
/** @internal */
type CommandListGetItemSelectedCallback = (virtualIndex: number) => boolean;
/** @internal */
type CommandListItemContext = {
  activeIndex: number | null;
  disabled?: boolean;
  selected?: boolean;
  virtualIndex: number;
};
/** @internal */
type CommandListRenderItemCallback<T> = (item: T, context: CommandListItemContext) => ReactNode;
/** @internal */
interface CommandListHandle {
  focusInputElement: () => void;
  focusListElement: () => void;
  getTopIndex: () => number;
  scrollToIndex: (index: number) => void;
}
/** @internal */
interface CommandListProps<T = any> extends ResponsivePaddingProps {
  /** The data attribute to apply to any active virtual list items */
  activeItemDataAttr?: string;
  /** `aria-label` to apply to the virtual list container element */
  ariaLabel: string;
  /** Whether `aria-multiselectable` is enabled on the virtual list container element */
  ariaMultiselectable?: boolean;
  /** Automatically focus the input or virtual list */
  autoFocus?: CommandListElementType;
  /** Whether the virtual list can receive focus */
  canReceiveFocus?: boolean;
  /** Pixel offset of the virtual list focus ring. Negative values will cause the focus ring to appear inset */
  focusRingOffset?: number;
  /** Force a fixed height for all virtual list children and skip measurement (faster). */
  fixedHeight?: boolean;
  /** Custom function to map disabled items */
  getItemDisabled?: CommandListGetItemDisabledCallback;
  /** Custom function to map virtual list items to custom keys */
  getItemKey?: CommandListGetItemKeyCallback;
  /** Custom function to map selected items */
  getItemSelected?: CommandListGetItemSelectedCallback;
  /** Scroll alignment of the initial active index */
  initialScrollAlign?: ScrollToOptions['align'];
  /** Initial active index on mount */
  initialIndex?: number;
  /** Input element to associate with this virtual list. Associated inputs will receive focus and handle key events */
  inputElement?: HTMLInputElement | null;
  /** Estimated height for each list item */
  itemHeight: number;
  /** Virtual list item values, accessible to all rendered item components */
  items: T[];
  /** Callback fired when the virtual list is within `onEndReachedIndexThreshold` of rendered content */
  onEndReached?: () => void;
  /** Number of items from the end of the virtual list before which `onEndReached` is triggered */
  onEndReachedIndexOffset?: number;
  /** Only show selection state when the virtual list is active (is hovered or has focus) */
  onlyShowSelectionWhenActive?: boolean;
  /** Number of items to render above and below the visible area*/
  overscan?: number;
  /** Rendered component in virtual lists */
  renderItem: CommandListRenderItemCallback<T>;
  /** `data-testid` to apply to outermost container */
  testId?: string;
  /** Allow wraparound keyboard navigation between first and last items */
  wrapAround?: boolean;
}
/**
 * Renders a Command List with support for the following:
 *
 * - Keyboard navigation (↑ / ↓ / ENTER) to children with a specified container (`childContainerRef`)
 * - Focus redirection when clicking child elements
 * - Pointer blocking when navigating with arrow keys (to ensure that only one active state is visible at any given time)
 * - ARIA attributes to define a `combobox` input that controls a separate `listbox`
 *
 * @internal
 */
declare const CommandList: react.NamedExoticComponent<CommandListProps<any> & react.RefAttributes<CommandListHandle>>;
type BaseButtonProps = Pick<ButtonProps, 'as' | 'icon' | 'iconRight' | 'justify' | 'loading' | 'mode' | 'paddingY' | 'paddingLeft' | 'selected' | 'tone' | 'type' | 'width'> & {
  size?: 'default' | 'large';
  radius?: 'full';
};
type ButtonWithText = {
  text: string;
  tooltipProps?: TooltipProps$1 | null;
  icon?: ButtonProps['icon'];
};
type IconButton = {
  text?: undefined;
  icon?: ButtonProps['icon'];
  /**
   * When using a button with an icon, tooltipProps are required to enforce consistency in UI.
   */
  tooltipProps: TooltipProps$1 | null;
};
/** @internal */
type ButtonProps$1 = BaseButtonProps & (ButtonWithText | IconButton);
/**
 * Customized Sanity UI <Button> with pre-defined layout options.
 *
 * @internal
 */
declare const Button: react.ForwardRefExoticComponent<(Omit<Pick<ButtonProps, "as" | "icon" | "iconRight" | "justify" | "loading" | "mode" | "paddingLeft" | "paddingY" | "selected" | "tone" | "type" | "width"> & {
  size?: "default" | "large" | undefined;
  radius?: "full" | undefined;
} & ButtonWithText & Omit<HTMLProps<HTMLButtonElement>, "as" | "size" | "title">, "ref"> | Omit<Pick<ButtonProps, "as" | "icon" | "iconRight" | "justify" | "loading" | "mode" | "paddingLeft" | "paddingY" | "selected" | "tone" | "type" | "width"> & {
  size?: "default" | "large" | undefined;
  radius?: "full" | undefined;
} & IconButton & Omit<HTMLProps<HTMLButtonElement>, "as" | "size" | "title">, "ref">) & react.RefAttributes<HTMLButtonElement>>;
/** @internal */
type MenuButtonProps$1 = Omit<MenuButtonProps, 'popover'> & {
  popover?: Omit<PopoverProps, 'animate' | 'content' | 'open'>;
};
/** @internal */
type TooltipProps$1 = Omit<TooltipProps, 'arrow' | 'padding' | 'shadow'> & {
  hotkeys?: HotkeysProps['keys'];
};
/** @internal */
type PopoverProps$1 = PopoverProps;
type ContextMenuButtonProps = Pick<ButtonProps$1, 'mode' | 'selected' | 'size' | 'tone' | 'tooltipProps' | 'loading'>;
/**
 * Simple context menu button (with horizontal ellipsis icon) with shared localization.
 *
 * @internal
 */
declare const ContextMenuButton: react.ForwardRefExoticComponent<ContextMenuButtonProps & Pick<HTMLProps<HTMLButtonElement>, "disabled" | "hidden" | "onClick"> & react.RefAttributes<HTMLButtonElement>>;
/**
 * Indicates the type of document variant, either `draft`, `version` or `published`.
 * Draft documents are prefixed with `drafts.`.
 * Version documents are prefixed with `versions.<versionName>`
 * The rest are considered published documents.
 * @public
 */
type DocumentVariantType = 'draft' | 'version' | 'published';
/**
 * Takes a document id and returns the variant type for that document
 * If it's a document that starts with `version.` it's a `version` document.
 * If it's a document that starts with `drafts.` it's a `draft` document.
 * Otherwise, it's a `published` document.
 * @public
 * */
declare function getDocumentVariantType(documentId: string): DocumentVariantType;
/**
 * @internal
 */
declare const Chip: react.ForwardRefExoticComponent<Omit<Omit<_sanity_ui0.ButtonProps & Omit<react.HTMLProps<HTMLButtonElement>, "as" | "width">, "ref"> & react.RefAttributes<HTMLButtonElement>, "ref"> & react.RefAttributes<unknown>>;
/**
 *
 * Checks if the document ID `documentId` has the same ID as `equalsDocumentId`,
 * ignoring the draft prefix.
 *
 * @public
 *
 * @param documentId - The document ID to check
 * @param equalsDocumentId - The document ID to check against
 *
 * @example
 * Draft vs published document ID, but representing the same document:
 * ```
 * // Prints "true":
 * console.log(documentIdEquals('drafts.agot', 'agot'));
 * ```
 * @example
 * Different documents:
 * ```
 * // Prints "false":
 * console.log(documentIdEquals('hp-tcos', 'hp-hbp'));
 * ```
 *
 * @returns `true` if the document IDs are equal, `false` otherwise
 */
declare function documentIdEquals(documentId: string, equalsDocumentId: string): boolean;
/** @internal */
declare function isDraft(document: SanityDocumentLike): boolean;
/**
 * TODO: Improve return type based on presence of `version` option.
 *
 * @internal
 */
declare function getIdPair(id: string, {
  version
}?: {
  version?: string;
}): {
  draftId: DraftId;
  publishedId: PublishedId;
  versionId?: string;
};
/**
 * System bundles are sets of documents owned by the system.
 *
 * - Draft documents contain data that has not yet been published. These documents all exist in the "drafts" path.
 * - Published documents contain data that has been published. These documents all exist in the root path.
 *
 * These differ to user bundles, which are created when a user establishes a custom set of documents
 * (e.g. by creating a release).
 *
 * @public
 */
declare const systemBundles: readonly ["drafts", "published"];
/**
 * System bundles are sets of documents owned by the system.
 *
 * - Draft documents contain data that has not yet been published. These documents all exist in the "drafts" path.
 * - Published documents contain data that has been published. These documents all exist in the root path.
 *
 * These differ to user bundles, which are created when a user establishes a custom set of documents
 * (e.g. by creating a release).
 *
 * @public
 */
type SystemBundle = 'drafts' | 'published';
/** @internal */
declare function isSystemBundle(maybeSystemBundle: unknown): maybeSystemBundle is SystemBundle;
/** @internal */
type SystemBundleName = 'draft' | 'published';
/**
 * `isSystemBundle` should be preferred, but some parts of the codebase currently use the singular
 * "draft" name instead of the plural "drafts".
 *
 * @internal
 */
declare function isSystemBundleName(maybeSystemBundleName: unknown): maybeSystemBundleName is SystemBundleName;
/**
 *  @internal
 *  Given a perspective stack and a document id, returns true if the document id matches any of the provided perspectives
 *  e.g. `idMatchesPerspective('['summer'], 'versions.summer.foo') === true`
 *  e.g. `idMatchesPerspective('['drafts', 'summer'], 'versions.summer.foo') === true`
 *  e.g. `idMatchesPerspective('['drafts'], 'versions.summer.foo') === false`
 *  e.g. `idMatchesPerspective('['drafts', 'summer'], 'versions.winter.foo') === false`
 *
 * Note: a published id will match any perspective
 *   e.g. `idMatchesPerspective('['drafts', 'summer'], 'foo') === true`
 */
declare function idMatchesPerspective(perspectiveStack: StackablePerspective[], documentId: string): boolean;
/** @internal */
declare function createDraftFrom(document: SanityDocument): SanityDocument;
/** @internal */
declare function newDraftFrom(document: SanityDocument): SanityDocument;
/** @internal */
declare function createPublishedFrom(document: SanityDocument): SanityDocument;
/**
 * Takes a list of documents and collates draft/published pairs into single entries
 * `{id: <published id>, draft?: <draft document>, published?: <published document>}`
 *
 * Note: because Map is ordered by insertion key the resulting array will be ordered by whichever
 * version appeared first
 *
 * @internal
 */
interface CollatedHit<T extends {
  _id: string;
} = {
  _id: string;
}> {
  id: string;
  type: string;
  draft?: T;
  published?: T;
  versions: T[];
}
/** @internal */
declare function collate<T extends {
  _id: string;
  _type: string;
}>(documents: T[]): CollatedHit<T>[];
/** @internal */
declare function removeDupes(documents: SanityDocumentLike[]): SanityDocumentLike[];
/**
 * @beta
 */
type ReleaseId = string;
/**
 * A value representing a perspective, including the data describing it. This is either the name of a
 * system bundle, or a document describing a release.
 *
 * @public
 */
type TargetPerspective = ReleaseDocument | SystemBundle | string;
/**
 * @beta
 * @deprecated Use `TargetPerspective` instead.
 */
type SelectedPerspective = TargetPerspective;
/**
 * @beta
 */
type PerspectiveStack = ExtractArray<ClientPerspective>;
/**
 * @beta
 */
interface PerspectiveContextValue {
  selectedPerspectiveName: 'published' | ReleaseId | undefined;
  /**
   * The releaseId as `r<string>`; it will be undefined if the selected perspective is `published` or `drafts`
   */
  selectedReleaseId: ReleaseId | undefined;
  selectedPerspective: TargetPerspective;
  /**
   * The stacked array of perspectives ids ordered chronologically to represent the state of documents at the given point in time.
   * It can be used as the perspective param in the client to get the correct view of the documents.
   * @returns ["published"] | ["drafts"] | ["releaseId2", "releaseId1", "drafts"]
   */
  perspectiveStack: PerspectiveStack;
  excludedPerspectives: string[];
}
/**
 * @internal
 */
type ExtractArray<Union> = Union extends unknown[] ? Union : never;
/**
 * @internal
 */
type ReleasesNavMenuItemPropsGetter = (content: {
  perspective: TargetPerspective;
}) => Partial<ComponentProps<typeof MenuItem>>;
/**
 * @internal
 */
declare const VersionChip: react.NamedExoticComponent<{
  disabled?: boolean | undefined;
  selected: boolean;
  tooltipContent?: ReactNode;
  onClick: () => void;
  text: string;
  contextMenuPortal?: boolean | undefined;
  tone: "caution" | "critical" | "default" | "neutral" | "positive" | "primary" | "suggest";
  locked?: boolean | undefined;
  onCopyToDraftsNavigate: () => void;
  contextValues: {
    documentId: string;
    documentType: string;
    releases: ReleaseDocument[];
    releasesLoading: boolean;
    bundleId: string;
    isVersion: boolean;
    disabled?: boolean | undefined;
    isGoingToUnpublish?: boolean | undefined;
    release?: ReleaseDocument | undefined;
  };
}>;
/** @internal */
type ReleaseAvatarIconProps = {
  release: TargetPerspective;
  tone?: never;
  releaseType?: never;
} | {
  releaseType: ReleaseType;
  tone?: never;
  release?: never;
} | {
  /**
   * @deprecated - Prefer `release` or `releaseType`.
   */
  tone: BadgeTone;
  release?: never;
  releaseType?: never;
};
declare const ReleaseAvatarIcon: ({
  tone,
  release,
  releaseType
}: ReleaseAvatarIconProps) => react.JSX.Element;
declare function ReleaseAvatar({
  fontSize,
  padding,
  ...iconProps
}: ReleaseAvatarIconProps & {
  fontSize?: number;
  padding?: number;
}): React.JSX.Element;
/** @internal */
interface ReleaseTitleDetails {
  displayTitle: string;
  fullTitle: string;
  isTruncated: boolean;
}
/** @internal */
interface ReleaseTitleProps {
  title: string | undefined;
  fallback: string;
  enableTooltip?: boolean;
  tooltipMaxWidth?: string;
  children?: (details: ReleaseTitleDetails) => ReactElement;
  textProps?: Omit<TextProps, 'children'> & {
    style?: CSSProperties;
  };
}
/** @internal */
declare function ReleaseTitle(props: ReleaseTitleProps): ReactNode;
/**
 * @internal
 */
declare const VersionInlineBadge: ({
  children,
  $tone
}: PropsWithChildren<{
  $tone?: "caution" | "critical" | "default" | "neutral" | "positive" | "primary" | "suggest" | undefined;
}>) => react.JSX.Element;
/**
 * @internal
 */
declare const getVersionInlineBadge: (release?: TargetPerspective | undefined) => FC<{
  children?: react.ReactNode;
}>;
interface ObserveDocumentAPIConfig {
  dataset?: string;
  projectId?: string;
  apiVersion?: string;
}
type DocumentIdSetObserverState = {
  status: 'reconnecting' | 'connected';
  documentIds: string[];
};
/** @internal */
type Id = string;
/**
 * @hidden
 * @beta */
type Previewable = ({
  _id: string;
} | {
  _type: string;
} | {
  _system?: {
    delete: boolean;
  };
} | {
  _ref: string;
  _dataset?: string;
  _projectId?: string;
}) & {
  /**
   * optional object used to attach meta data to the prepared result.
   * currently used to add a flag for the invalid preview error fallback and
   * insufficient permissions fallback
   * @internal
   */
  _internalMeta?: {
    type?: string;
  };
};
/**
 * TODO: unify with content path from `@sanity/types`
 *
 *
 * @hidden
 * @beta
 */
type PreviewPath = FieldName[];
/** @internal */
type Selection = [id: Id, fields: FieldName[]];
/**
 * @hidden
 * @beta */
type FieldName = string;
/** @internal */
interface AvailabilityResponse {
  omitted: {
    id: string;
    reason: 'existence' | 'permission';
  }[];
}
/** @internal */
type AvailabilityReason = 'READABLE' | 'PERMISSION_DENIED' | 'NOT_FOUND';
/**
 * @hidden
 * @beta */
type PreviewableType = SchemaType | CrossDatasetType | GlobalDocumentReferenceType;
/**
 * @hidden
 * @beta */
interface ApiConfig {
  projectId: string;
  dataset: string;
}
/**
 * @hidden
 * @beta */
type DocumentAvailability = {
  available: true;
  reason: 'READABLE';
} | {
  available: false;
  reason: 'PERMISSION_DENIED' | 'NOT_FOUND' | 'VERSION_DELETED';
};
/**
 * @hidden
 * @beta */
interface DraftsModelDocumentAvailability {
  /**
   * document readability for the published document
   */
  published: DocumentAvailability;
  /**
   * document readability for the draft document
   */
  draft: DocumentAvailability;
  /**
   * document readability for the version document
   */
  version?: DocumentAvailability;
}
/**
 * @hidden
 * @beta */
interface DocumentStackAvailability {
  /**
   * Document id
   */
  id: string;
  /**
   * Availability for the document in this stack
   */
  availability: DocumentAvailability;
}
/**
 * @hidden
 * @beta */
interface DraftsModelDocument<T extends SanityDocumentLike = SanityDocumentLike> {
  id: string;
  type: string | null;
  draft: {
    availability: DocumentAvailability;
    snapshot: T | undefined;
  };
  published: {
    availability: DocumentAvailability;
    snapshot: T | undefined;
  };
  version?: {
    availability: DocumentAvailability;
    snapshot: T | undefined;
  };
}
/**
 * Event emitted to notify preview subscribers when they need to refetch a document being previewed
 * - 'connected' will happen when the store is connected to the invalidation channel, both initially and after a reconnect after a connection loss
 * - 'mutation' will happen when a document has been mutated and the store needs to refetch a document
 * @hidden
 * @beta
 */
type InvalidationChannelEvent = {
  type: 'connected';
} | {
  type: 'mutation';
  documentId: string;
  visibility: string;
};
/**
 * @hidden
 * @beta */
interface PreparedSnapshot {
  type?: PreviewableType;
  snapshot: PreviewValue | null | undefined;
}
/** @internal */
type ObserveDocumentTypeFromIdFn = (id: string, apiConfig?: ApiConfig, perspective?: StackablePerspective[]) => Observable<string | undefined>;
/**
 * @hidden
 * @beta */
interface ObservePathsFn {
  (value: Previewable, paths: (string | PreviewPath)[], apiConfig?: ApiConfig, perspective?: StackablePerspective[]): Observable<PreviewValue | SanityDocumentLike | Reference | string | null>;
}
/**
 * @hidden
 * @beta */
interface ObserveDocumentAvailabilityFn {
  (id: string, options?: {
    version?: string;
  }): Observable<{
    draft: DocumentAvailability;
    published: DocumentAvailability;
    version?: DocumentAvailability;
  }>;
}
/**
 * @hidden
 * @beta */
type ObserveForPreviewFn = (value: Previewable, type: PreviewableType, options?: {
  viewOptions?: PrepareViewOptions;
  perspective?: StackablePerspective[];
  apiConfig?: ApiConfig;
}) => Observable<PreparedSnapshot>;
/**
 * The document preview store supports subscribing to content for previewing purposes.
 * Documents observed by this store will be kept in sync and receive real-time updates from all collaborators,
 * but has no support for optimistic updates, so any local edits will require a server round-trip before becoming visible,
 * which means this store is less suitable for real-time editing scenarios.
 *
 * @hidden
 * @beta */
interface DocumentPreviewStore {
  observePaths: ObservePathsFn;
  observeForPreview: ObserveForPreviewFn;
  observeDocumentTypeFromId: (id: string, apiConfig?: ApiConfig, perspective?: StackablePerspective[]) => Observable<string | undefined>;
  /**
   *
   * @hidden
   * @beta
   */
  unstable_observeDocumentPairAvailability: (id: string, options?: {
    version?: string;
  }) => Observable<DraftsModelDocumentAvailability>;
  /**
   *
   * @hidden
   * @beta
   */
  unstable_observeDocumentStackAvailability: (id: string, perspectiveStack: StackablePerspective[]) => Observable<DocumentStackAvailability[]>;
  unstable_observePathsDocumentPair: <T extends SanityDocument = SanityDocument>(id: string, paths: PreviewPath[], options?: {
    version?: string;
  }) => Observable<DraftsModelDocument<T>>;
  /**
   * Observes a set of document IDs that matches the given groq-filter. The document ids are returned in ascending order and will update in real-time
   * Whenever a document appears or disappears from the set, a new array with the updated set of IDs will be pushed to subscribers.
   * The query is performed once, initially, and thereafter the set of ids are patched based on the `appear` and `disappear`
   * transitions on the received listener events.
   * This provides a lightweight way of subscribing to a list of ids for simple cases where you just want to subscribe to a set of documents ids
   * that matches a particular filter.
   * @hidden
   * @beta
   * @param filter - A groq filter to use for the document set
   * @param params - Parameters to use with the groq filter
   * @param options - Options for the observer
   * @param apiVersion - Specify the API version to use for the query
   */
  unstable_observeDocumentIdSet: (filter: string, params?: QueryParams, options?: {
    /**
     * Where to insert new items into the set. Defaults to 'sorted' which is based on the lexicographic order of the id
     */
    insert?: 'sorted' | 'prepend' | 'append';
    apiVersion?: string;
  }) => Observable<DocumentIdSetObserverState>;
  /**
   * Observe a complete document with the given ID
   * @hidden
   * @beta
   */
  unstable_observeDocument: (id: string, clientConfig?: ObserveDocumentAPIConfig) => Observable<SanityDocument | undefined>;
  /**
   * Observe a list of complete documents with the given IDs
   * @hidden
   * @beta
   */
  unstable_observeDocuments: (ids: string[], clientConfig?: ObserveDocumentAPIConfig) => Observable<(SanityDocument | undefined)[]>;
}
/** @internal */
interface DocumentPreviewStoreOptions {
  client: SanityClient;
}
/** @internal */
declare function createDocumentPreviewStore({
  client
}: DocumentPreviewStoreOptions): DocumentPreviewStore;
interface DocumentPerspectiveProps {
  documentId: string;
}
interface DocumentPerspectiveState {
  data: string[];
  error?: unknown;
  loading: boolean;
}
/**
 * Fetches the document versions for a given document
 * @param props - document Id of the document (might include release id)
 * @returns - data: document versions, loading, errors
 * @hidden
 * @beta
 */
declare function useDocumentVersions(props: DocumentPerspectiveProps): DocumentPerspectiveState;
interface useDocumentVersionTypeSortedListState {
  sortedDocumentList: ReleaseDocument[];
}
/**
 * Fetches the document versions for a given document and sorts them by release type
 *
 * @param documentId - document id related to the document version list
 * @returns object with sortedDocumentList
 *
 * @beta
 */
declare const useDocumentVersionTypeSortedList: ({
  documentId
}: {
  documentId: string;
}) => useDocumentVersionTypeSortedListState;
/** @internal */
declare const useIsReleaseActive: () => boolean;
/**
 * Returns a boolean if the document has only versions
 *
 * @param documentId - document id related to the document version list
 * @returns if the document has only versions
 *
 * @beta
 */
declare const useOnlyHasVersions: ({
  documentId
}: {
  documentId: string;
}) => boolean;
interface VersionOperationsValue {
  createVersion: (releaseId: ReleaseId, documentId: string) => Promise<void>;
  discardVersion: (releaseId: string, documentId: string) => Promise<SingleActionResult>;
  unpublishVersion: (documentId: string) => Promise<SingleActionResult>;
  revertUnpublishVersion: (documentId: string) => Promise<SingleActionResult>;
}
/** @internal */
declare function useVersionOperations(): VersionOperationsValue;
/**
 * Sorts releases by their release type and created date.
 * @internal
 */
declare function sortReleases(releases?: ReleaseDocument[]): ReleaseDocument[];
/**
 * This is used to draw the bar that wraps the diff components in the changes panel
 *
 * @internal
 */
declare const ChangeFieldWrapper: (props: {
  path: Path;
  children: ReactNode;
  hasRevertHover: boolean;
}) => react.JSX.Element;
/** @internal */
interface ChangeIndicatorProps {
  path: Path;
  hasFocus: boolean;
  isChanged: boolean;
  withHoverEffect?: boolean;
}
/** @internal */
declare function ChangeIndicator(props: ChangeIndicatorProps & Omit<HTMLProps<HTMLDivElement>, 'as'>): react.JSX.Element;
/** @internal */
interface ConnectorContextValue {
  isReviewChangesOpen: boolean;
  onOpenReviewChanges: () => void | undefined;
  onSetFocus: (nextPath: Path) => void | undefined;
  isInteractive?: boolean;
}
/** @internal */
interface ChangeConnectorRootProps {
  children: ReactNode;
  className?: string;
  isReviewChangesOpen: boolean;
  onOpenReviewChanges: () => void;
  onSetFocus: (path: Path) => void;
}
/** @internal */
declare function ChangeConnectorRoot({
  children,
  className,
  isReviewChangesOpen,
  onOpenReviewChanges,
  onSetFocus,
  ...restProps
}: ChangeConnectorRootProps): react.JSX.Element;
/** @internal */
type Reported<Value> = [string, Value];
/** @internal */
type ReporterHook<Payload> = (id: string | null, value: () => Payload, isEqual?: IsEqualFunction<Payload>) => void;
/** @internal */
type IsEqualFunction<Value> = (a: Value | null, b: Value | null) => boolean;
/** @internal */
interface TrackerContextStore<Value> {
  add: (id: string, value: Value) => void;
  update: (id: string, value: Value) => void;
  remove: (id: string) => void;
}
/** @internal */
type TrackerContextGetSnapshot<Value> = [string, Value][];
/** @internal */
declare function useTrackerStore<Value>(): {
  store: TrackerContextStore<Value>;
  snapshot: TrackerContextGetSnapshot<Value>;
};
/** @internal */
declare function useTrackerStoreReporter<Value>(store: TrackerContextStore<Value> | null, id: string | null, value: () => Value, isEqual?: IsEqualFunction<Value>): void;
/** @internal */
interface TrackedChange {
  element: HTMLElement | null;
  path: Path;
  isChanged: boolean;
  hasFocus: boolean;
  hasHover: boolean;
  hasRevertHover: boolean;
  zIndex: number;
}
/** @internal */
interface TrackedArea {
  element: HTMLElement | null;
}
/** @internal */
type ChangeIndicatorTrackerContextValue = TrackedChange;
declare function ChangeIndicatorsTrackerComponent(props: {
  children: React.ReactNode;
}): react.JSX.Element;
/**
 * @internal
 */
declare const ChangeIndicatorsTracker: react.MemoExoticComponent<typeof ChangeIndicatorsTrackerComponent>;
/**
 * @internal
 */
declare function useChangeIndicatorsReportedValues(): TrackerContextGetSnapshot<ChangeIndicatorTrackerContextValue>;
/**
 * @internal
 */
declare const useChangeIndicatorsReporter: ReporterHook<ChangeIndicatorTrackerContextValue>;
/**
 * @beta
 * @hidden
 */
interface CommentDeleteDialogProps {
  commentId: string;
  error: Error | null;
  isParent: boolean;
  loading: boolean;
  onClose: () => void;
  onConfirm: (id: string) => void;
}
/**
 * @beta
 * @hidden
 */
declare function CommentDeleteDialog(props: CommentDeleteDialogProps): react.JSX.Element;
/**
 * @internal
 */
declare const CommentDisabledIcon: react.ForwardRefExoticComponent<Omit<SVGProps<SVGSVGElement>, "ref"> & react.RefAttributes<SVGSVGElement>>;
/**
 *
 * @deprecated Calling `useClient()` without specifying an API version is deprecated - specify a date to prevent breaking changes, e.g. `useClient({apiVersion: "2025-02-07"})`.
 *
 * React hook that returns a configured Sanity client instance based on the given configuration.
 * Automatically uses the correct project and dataset based on the current active workspace.
 *
 * @public
 * @returns A configured Sanity client instance
 * @remarks The client instance is automatically memoized based on API version
 * @remarks The client will fallback to `v2025-02-07` of the API
 * @example Instantiating a client
 * ```ts
 * function MyComponent() {
 *   const client = useClient({apiVersion: '2021-06-07'})
 *   // ... do something with client instance ...
 * }
 * ```
 */
declare function useClient(): SanityClient;
/**
 * React hook that returns a configured Sanity client instance based on the given configuration.
 * Automatically uses the correct project and dataset based on the current active workspace.
 *
 * @public
 * @param clientOptions - Options for the client. Specifying
 *   {@link https://www.sanity.io/docs/api-versioning | apiVersion} is required in order to
 *   prevent breaking changes if studio changes the API version used in other places.
 *   See {@link SourceClientOptions}
 * @returns A configured Sanity client instance
 * @remarks The client instance is automatically memoized based on API version
 * @example Instantiating a client
 * ```ts
 * function MyComponent() {
 *   const client = useClient({apiVersion: '2021-06-07'})
 *   // ... do something with client instance ...
 * }
 * ```
 */
declare function useClient(clientOptions: SourceClientOptions): SanityClient;
/**
 * Workaround to support conditional toast (e.g. a toast that is visible as long as a condition holds true)
 * @hidden
 * @internal
 */
declare function useConditionalToast(params: ToastParams & {
  id: string;
  enabled?: boolean;
  delay?: number;
}): void;
/** @internal */
type ConnectionState = 'connecting' | 'reconnecting' | 'connected';
/** @internal */
declare function useConnectionState(publishedDocId: string, docTypeName: string, version?: string): ConnectionState;
/**
 * React hook that returns the name of the current dataset
 *
 * @public
 * @returns The name of the current dataset
 * @example Using the `useDataset` hook
 * ```ts
 * function MyComponent() {
 *   const dataset = useDataset()
 *   // ... do something with the dataset name ...
 * }
 * ```
 */
declare function useDataset(): string;
/**
 * Options for the `useDateTimeFormat` hook
 *
 * @public
 */
type UseDateTimeFormatOptions = Omit<Intl.DateTimeFormatOptions, 'fractionalSecondDigits'>;
/**
 * Returns an instance of `Intl.DateTimeFormat` that uses the currently selected locale,
 * and enables locale and culture-sensitive date formatting.
 *
 * @param options - Optional options for the date/time formatter
 * @returns Instance of `Intl.DateTimeFormat`
 * @public
 */
declare function useDateTimeFormat(options?: UseDateTimeFormatOptions): Intl.DateTimeFormat;
/**
 * Hook to register a dialog in the stack and check if it's the top-most one.
 *
 * @beta
 */
declare function useDialogStack({
  path
}?: {
  path?: Path;
}): {
  /** Unique ID for this dialog instance */dialogId: string; /** The current top dialog entry */
  topEntry: sanity__singletons0.DialogStackEntry | null; /** The full stack of dialog entries (each has id and path) */
  stack: sanity__singletons0.DialogStackEntry[]; /** Check if this dialog is on top */
  isTop: boolean; /** Close dialogs */
  close: (options?: {
    toParent?: boolean | undefined;
  } | undefined) => void; /** Navigate to a specific path, updating the form path and cleaning up the stack */
  navigateTo: (path: Path) => void;
};
/** @internal */
type CommitFunction = (mutation: Mutation['params']) => Promise<unknown>;
/**
 * @hidden
 * @beta */
interface DocumentRebaseEvent {
  type: 'rebase';
  document: SanityDocument;
  remoteMutations: MutationPayload[];
  localMutations: MutationPayload[];
}
/**
 * @hidden
 * @beta */
interface DocumentMutationEvent {
  type: 'mutation';
  document: SanityDocument;
  mutations: MutationPayload[];
  origin: 'local' | 'remote';
}
/**
 * @hidden
 * @beta */
interface SnapshotEvent {
  type: 'snapshot';
  document: SanityDocument;
}
/**
 * @hidden
 * @beta */
interface CommittedEvent {
  type: 'committed';
}
/**
 * @hidden
 * @beta */
interface DocumentRemoteMutationEvent {
  type: 'remoteMutation';
  head: SanityDocument;
  transactionId: string;
  author: string;
  timestamp: Date;
  effects: {
    apply: unknown;
    revert: unknown;
  };
}
/**
 * @hidden
 * @beta */
type RemoteSnapshotEvent = DocumentRemoteMutationEvent | SnapshotEvent;
/**
 * @hidden
 * @beta */
interface MutationPayload {
  create?: any;
  createIfNotExists?: any;
  createOrReplace?: any;
  delete?: any;
  patch?: any;
}
/** @internal */
interface MutationEvent {
  type: 'mutation';
  documentId: string;
  transactionId: string;
  mutations: MutationPayload[];
  effects: {
    apply: unknown;
    revert: unknown;
  };
  previousRev: string;
  resultRev: string;
  transactionTotalEvents: number;
  transactionCurrentEvent: number;
  messageReceivedAt: string;
  visibility: 'transaction' | 'query';
  transition: 'update' | 'appear' | 'disappear';
}
/** @internal */
interface PendingMutationsEvent {
  type: 'pending';
  phase: 'begin' | 'end';
}
/** @internal */
interface IdPair {
  draftId: string;
  publishedId: string;
  versionId?: string;
}
interface ListenerSequenceState {
  /**
   * Tracks the latest revision from the server that can be applied locally
   * Once we receive a mutation event that has a `previousRev` that equals `base.revision`
   * we will move `base.revision` to the event's `resultRev`
   * `base.revision` will be undefined if document doesn't exist.
   * `base` is `undefined` until the snapshot event is received
   */
  base: {
    revision: string | undefined;
  } | undefined;
  /**
   * Array of events to pass on to the stream, e.g. when mutation applies to current head revision, or a chain is complete
   */
  emitEvents: ListenerEvent[];
  /**
   * Buffer to keep track of events that doesn't line up in a [previousRev, resultRev] -- [previousRev, resultRev] sequence
   * This can happen if events arrive out of order, or if an event in the middle for some reason gets lost
   */
  buffer: MutationEvent[];
}
/**
 * Takes an input observable of listener events that might arrive out of order, and emits them in sequence
 * If we receive mutation events that doesn't line up in [previousRev, resultRev] pairs we'll put them in a buffer and
 * check if we have an unbroken chain every time we receive a new event
 *
 * If the buffer grows beyond `maxBufferSize`, or if `resolveChainDeadline` milliseconds passes before the chain resolves
 * an OutOfSyncError will be thrown on the stream
 *
 * @internal
 */
declare class OutOfSyncError extends Error {
  /**
   * Attach state to the error for debugging/reporting
   */
  state: ListenerSequenceState;
  constructor(message: string, state: ListenerSequenceState);
}
/** @internal */
interface InitialSnapshotEvent {
  type: 'snapshot';
  documentId: string;
  document: SanityDocument | null;
}
/**
 * @internal
 */
interface LatencyReportEvent {
  shard?: string;
  latencyMs: number;
  transactionId: string;
}
/** @internal */
interface DocumentPairLoadedEvent {
  durationMs: number;
  fromCache: boolean;
  hasPublished: boolean;
  hasDraft: boolean;
  hasVersion: boolean;
}
/** @internal */
interface DocumentStoreExtraOptions {
  tag?: string;
  /**
   * Called when we recover from sync error
   * Meant for error tracking / telemetry purposes
   * @param error - the {@link OutOfSyncError} recovered from
   */
  onSyncErrorRecovery?(error: OutOfSyncError): void;
  onReportLatency?: (event: LatencyReportEvent) => void;
  onSlowCommit?: () => void;
  onDocumentPairLoaded?: (event: DocumentPairLoadedEvent) => void;
}
/** @internal */
type ListenerEvent = MutationEvent | ReconnectEvent | InitialSnapshotEvent | PendingMutationsEvent | WelcomeEvent | WelcomeBackEvent | ResetEvent;
/** @internal */
declare function getPairListener(_client: SanityClient, idPair: IdPair, options?: DocumentStoreExtraOptions): Observable<ListenerEvent>;
interface TransactionSyncLockState {
  enabled: boolean;
}
/**
 * @hidden
 * @beta */
interface EditStateFor {
  id: string;
  type: string;
  transactionSyncLock: TransactionSyncLockState | null;
  draft: SanityDocument | null;
  published: SanityDocument | null;
  version: SanityDocument | null;
  /**
   * Whether live edit is enabled. This may be true for various reasons:
   *
   * - The schema type has live edit enabled.
   * - A version of the document is checked out.
   */
  liveEdit: boolean;
  /**
   * Whether the schema type has live edit enabled.
   */
  liveEditSchemaType: boolean;
  ready: boolean;
  /**
   * When editing a version, the name of the release the document belongs to.
   */
  release: string | undefined;
}
/** @internal */
declare const editState$1: (ctx: {
  client: SanityClient;
  schema: Schema;
  serverActionsEnabled: Observable<boolean>;
  extraOptions?: DocumentStoreExtraOptions | undefined;
}, idPair: IdPair, typeName: string) => Observable<EditStateFor>;
interface Options$2 extends StrictVersionLayeringOptions {
  displayed: Partial<SanityDocument> | null;
  documentId: string;
  editState: EditStateFor | null;
}
/**
 * @internal
 */
interface DocumentIdStack {
  /**
   * The position of the displayed document within the stack.
   */
  position: number;
  /**
   * The id of the previous document in the stack.
   */
  previousId?: string;
  /**
   * The id of the next document in the stack.
   */
  nextId?: string;
  /**
   * An array of document ids comprising the stack the displayed document is a member of, ordered per
   * release layering.
   */
  stack: string[];
}
/**
 * Get a stack of document ids representing existing versions of the provided document with release
 * layering applied.
 *
 * @internal
 */
declare function useDocumentIdStack({
  displayed,
  documentId,
  editState,
  strict
}: Options$2): DocumentIdStack;
/** @internal */
declare function useDocumentOperation(publishedDocId: string, docTypeName: string, version?: string): OperationsAPI;
/** @internal */
declare function useDocumentOperationEvent(publishedDocId: string, docTypeName: string): OperationError | OperationSuccess | undefined;
/** @internal */
declare function useEditState(publishedDocId: string, docTypeName: string, priority?: 'default' | 'low', version?: string): EditStateFor;
interface Features {
  enabled: boolean;
  error: Error | null;
  features: string[];
  isLoading: boolean;
}
declare const FEATURES: Record<string, string>;
/** @internal */
declare function useFeatureEnabled(featureKey: keyof typeof FEATURES): Features;
type FilterReleases = {
  notCurrentReleases: ReleaseDocument[];
  currentReleases: ReleaseDocument[];
  inCreation: ReleaseDocument | null;
};
interface Options$1 extends StrictVersionLayeringOptions {
  displayed: Partial<SanityDocument> | null;
  documentId: string;
  historyVersion?: string;
}
/**
 * @internal
 */
declare function useFilteredReleases({
  displayed,
  documentId,
  strict,
  historyVersion
}: Options$1): FilterReleases;
/**
 * Options for the duration formatter
 *
 * @public
 */
interface UseFormattedDurationOptions {
  /**
   * The formatting style to use in unit and list formatting. The default is "short".
   */
  style?: 'short' | 'long' | 'narrow';
  /**
   * The resolution of the duration. The default is "seconds".
   */
  resolution?: 'seconds' | 'milliseconds';
}
/**
 * The result of the duration formatter
 *
 * @public
 */
interface FormattedDuration {
  /** The human-readable, formatted duration as a string, eg "2 days, 3 hr, and 20 sec" */
  formatted: string;
  /** The machine-readable, formatted ISO-8601 duration string, eg "P2DT3H20S" */
  iso8601: string;
}
/**
 * Formats a duration (in milliseconds) to a more user friendly string eg `1h 30m` or `1t 29m 15s`.
 * Can be configured to output full units, eg `1 hour 30 minutes` or `1 hour 3 minutes 15 seconds`.
 * Uses the current locale, which also applies to the division of units.
 *
 * @example English (en-US) locale formatting
 * ```ts
 * useFormattedDuration(5589000)
 * // {"formatted": "1 hour, 33 minutes, and 9 seconds", "iso8601": "PT1H33M9S"}
 * ```
 *
 * @example Norwegian (no-NB) locale formatting
 * ```ts
 * useFormattedDuration(5589000)
 * // {"formatted": "1 time, 33 minutter og 9 sekunder", "iso8601": "PT1H33M9S"}
 * ```
 *
 * @param options - Optional options for the number formatter
 * @returns An object with `formatted` and `iso8601` properties
 * @public
 */
declare function useFormattedDuration(durationMs: number, options?: UseFormattedDurationOptions): FormattedDuration;
/**
 * This represents the shape of the root value sanity forms expect
 * @hidden
 * @public
 */
interface FormDocumentValue {
  _type: string;
  _id: string;
  [key: string]: unknown;
}
/** @internal */
interface GlobalCopyPasteElementHandler {
  value: FormDocumentValue | undefined;
  element: HTMLElement | null;
  focusPath?: Path;
}
/** @internal */
declare function useGlobalCopyPasteElementHandler({
  value,
  element,
  focusPath
}: GlobalCopyPasteElementHandler): void;
/**
 * Options for the `useListFormat` hook
 *
 * @public
 */
interface UseListFormatOptions {
  /**
   * The format of output message.
   * - `conjunction` (read: "and") - default
   * - `disjunction` (read: "or")
   * - `unit` (just a list)
   */
  type?: Intl.ListFormatType | undefined;
  /**
   * The length of the internationalized message.
   * This obviously varies based on language, but in US English this maps to:
   * - `long`: "a, b and c" - default
   * - `short`: "a, b & c"
   * - `narrow`: `a, b, c`
   */
  style?: Intl.ListFormatStyle | undefined;
}
/**
 * Returns an instance of `Intl.ListFormat` that uses the currently selected locale,
 * and enables language-sensitive list formatting.
 *
 * @param options - Optional options for the list formatter
 * @returns Instance of `Intl.ListFormat`
 * @public
 */
declare function useListFormat(options?: UseListFormatOptions): Intl.ListFormat;
interface ManageFavorite {
  favorite: () => void;
  unfavorite: () => void;
  isFavorited: boolean | undefined;
  /**
   * Whether the initial remote read task has succeeded.
   */
  isReady: boolean;
}
/**
 * @internal
 */
interface UseManageFavoriteProps extends DocumentHandle {
  resourceId?: string;
  resourceType: StudioResource['type'] | MediaResource['type'] | CanvasResource['type'];
  /**
   * The name of the schema collection this document belongs to.
   * Typically is the name of the workspace when used in the context of a studio.
   */
  schemaName?: string;
}
/**
 * IMPORTANT!
 *
 * Loosely based on the `useManageFavorite.ts` from `@sanity/sdk`.
 * This version has been modified to use Studio's Comlink Store.
 *
 * TODO: Adopt `@sanity/sdk`.
 *
 * ---
 *
 * This hook provides functionality to add and remove documents from favorites,
 * and tracks the current favorite status of the document.
 *
 * @internal
 */
declare function useManageFavorite({
  documentId,
  documentType,
  projectId,
  dataset,
  resourceId: paramResourceId,
  resourceType,
  schemaName
}: UseManageFavoriteProps): ManageFavorite;
/**
 * Options for the `useNumberFormat` hook
 *
 * @public
 */
type UseNumberFormatOptions = Intl.NumberFormatOptions;
/**
 * Returns an instance of `Intl.NumberFormat` that uses the currently selected locale,
 * and enables locale/language-sensitive number formatting.
 *
 * @param options - Optional options for the number formatter
 * @returns Instance of `Intl.NumberFormat`
 * @public
 */
declare function useNumberFormat(options?: UseNumberFormatOptions): Intl.NumberFormat;
/**
 * React hook that returns the current project id
 *
 * @public
 * @returns The current project id
 * @example Using the `useProjectId` hook
 * ```ts
 * function MyComponent() {
 *   const projectId = useProjectId()
 *   // ... do something with the project id ...
 * }
 * ```
 */
declare function useProjectId(): string;
/**
 * Will show a toast telling the user that the Studio is offline and currently reconnecting
 * @internal
 * @hidden
 * @param isReconnecting -
 */
declare const useReconnectingToast: (isReconnecting: boolean) => void;
interface ReferringDocumentsState<Doc> {
  isLoading: boolean;
  referringDocuments: Doc[];
}
/** @beta */
type DocumentField = Exclude<keyof SanityDocument, number>;
/**
 * @beta
 * Subscribe to a live-updating list document referring to the document of the passed ID
 * A new list of document will be emitted every time a document refers or no longer refers to the document of the given ID
 *
 * ## Gotcha
 * The returned list of referring documents is not extensive, will only return the 101 first documents.
 *
 * ## Gotcha
 * For every component that calls this hook, a new listener connection will be made to the backend.
 *
 * Make sure call this hook sparingly
 * @param id - id of document to search for referring documents for
 * @param fields - which root level fields to return for each document (defaults to _id and _type). Pass an empty array to return full documents
 */
declare function useReferringDocuments<DocumentType extends SanityDocument>(id: string, fields?: DocumentField[]): ReferringDocumentsState<never> | ReferringDocumentsState<DocumentType>;
/** @internal */
interface RelativeTimeOptions {
  minimal?: boolean;
  useTemporalPhrase?: boolean;
  relativeTo?: Date;
  timeZone?: string;
}
/** @internal */
declare function useRelativeTime(time: Date | string, options?: RelativeTimeOptions): string;
interface ReviewChangesContextValue extends ConnectorContextValue {
  /**
   * @deprecated use `isReviewChangesOpen` instead, this will be removed in the next major version
   */
  changesOpen?: boolean;
}
/**
 * @internal
 */
declare function useReviewChanges(): ReviewChangesContextValue;
/**
 * React hook that returns the schema registry for the current project
 *
 * @public
 * @returns The schema registry for the current project
 * @example Using the `useSchema` hook
 * ```ts
 * function MyComponent() {
 *   const schema = useSchema()
 *   // ... do something with the schema ...
 * }
 * ```
 */
declare function useSchema(): Schema;
type StudioUrlBuilder = (url: string) => string;
type StudioUrlModifier = {
  coreUi?: StudioUrlBuilder;
  studio?: StudioUrlBuilder;
} & ({
  coreUi: StudioUrlBuilder;
} | {
  studio: StudioUrlBuilder;
});
interface UseStudioUrlReturnType {
  studioUrl: string;
  buildStudioUrl: (modifiers: StudioUrlModifier) => string;
  buildIntentUrl: (intentLink: string) => string;
}
/**
 * @internal
 */
declare const useStudioUrl: (defaultUrl?: string | undefined) => UseStudioUrlReturnType;
/** @internal */
interface SyncState {
  isSyncing: boolean;
}
/** @internal */
declare function useSyncState(publishedDocId: string, documentType: string, version?: string): SyncState;
/**
 * An initial value template is a template that can be used to create a new documents.
 *
 * This allows a document type to have multiple different starting values while having the same
 * shared schema definition. Using parameters allows for dynamic template values.
 *
 * As the name implies, these are _initial_ values, not _default_ values. The distinction is that
 * the initial value is only set when the document is created - it is not "merged" into existing
 * documents that may lack values for fields.
 *
 * All document types will by default (automatically, behind the scenes) have an initial value
 * template generated for them, which will have the same ID as the schema type name. The value of
 * this template will be the value of the `initialValue` property on the schema type definition,
 * or an empty object if none is set.
 *
 * @public
 */
interface Template<Params = any, Value = any> {
  /**
   * Template ID. Automatically generated templates will have the same ID as the schema type name.
   */
  id: string;
  /**
   * Template title.
   */
  title: string;
  i18n?: I18nTextRecord<'title'>;
  /**
   * Schema type name the template belongs to. For the automatically generated templates,
   * this will be equal to the `id` property.
   */
  schemaType: string;
  /**
   * Template icon. Rendered in places such as the "new document" dialog. Optional.
   * Inferred from the schema type icon if not set.
   */
  icon?: SchemaType['icon'];
  /**
   * Value to use as initial value. Can either be a static object value, or a function that
   * resolves _to_ an object value. If using a function, it can be given a set of parameters,
   * which can then determine the value that is returned.
   */
  value: InitialValueProperty<Params, Value>;
  /**
   * Array of parameters the template accepts. Currently not used (any parameters are accepted),
   * but by defining parameters, the templates that require parameters can be identified and
   * excluded from UIs that do not provide them.
   */
  parameters?: TemplateParameter[];
  /**
   * Template description. Rendered in places such as the "new document" dialog. Optional.
   *
   * @deprecated No longer used
   */
  description?: string;
}
/**
 * Parameter for a template. Closely resembles API used to define fields for object schema types.
 * See {@link TemplateFieldDefinition} and {@link TemplateArrayFieldDefinition}
 * @public
 */
type TemplateParameter = TemplateFieldDefinition | TemplateArrayFieldDefinition;
/**
 * @public
 */
interface TypeTarget {
  type: string;
}
/** @public */
interface TemplateReferenceTarget {
  type: 'reference';
  /** Type to reference. See {@link TypeTarget} */
  to: TypeTarget | TypeTarget[];
}
/**
 * Field definition for a template parameter.
 * Closely resembles API used to define fields for object schema types.
 *
 * @public
 */
interface TemplateFieldDefinition {
  /**
   * Parameter name. Must be unique within the template.
   */
  name: string;
  /**
   * Parameter type, eg `string`, `number`, `boolean` etc.
   */
  type: string;
  /**
   * Parameter type. Will be attempted to be automatically set if not given,
   * by title-casing the `name` property.
   */
  title?: string;
  /**
   * Description for the parameter. Optional.
   * May be used in the future to explain the parameter in UIs.
   */
  description?: string;
  /**
   * Optional bag of options for the parameter. Currently unused.
   */
  options?: {
    [key: string]: any;
  };
}
/** @public */
type TemplateArrayFieldDefinition = TemplateFieldDefinition & {
  type: 'array'; /** Defines items that are definition of. See {@link TemplateReferenceTarget} and {@link TypeTarget} */
  of: (TemplateReferenceTarget | TypeTarget)[];
};
/**
 * Representation of an initial value template _item_
 * Used by the {@link structure.StructureBuilder} class to determine which initial value templates
 * should be available for a structure node, such as a list pane.
 *
 * @public
 */
interface InitialValueTemplateItem extends TemplateItem {
  type: 'initialValueTemplateItem';
  /** ID for this template item */
  id: string;
  /** Initial value template schema type */
  schemaType: string;
}
/**
 * Represents the items that can appear in different parts of the Sanity studio when creating
 * new documents - examples being the "New document" button in the navigation bar,
 * the corresponding button in panes, as well as the "Create new" button on references.
 *
 * Differs from an actual _template_ in that a single template can be pointed at by multiple
 * different items. This is useful when the template can create different values based on
 * passed parameters.
 *
 * @public
 */
interface TemplateItem {
  /**
   * ID for the template. Must be unique within the set of templates.
   */
  templateId: string;
  /**
   * Title for the item.
   * Defaults to the title of the associated template.
   */
  title?: string;
  i18n?: I18nTextRecord<'title'>;
  /**
   * Parameters for the template - an object of any JSON-serializable values
   */
  parameters?: {
    [key: string]: any;
  };
  /**
   * React icon for the item, if any.
   * Defaults to the icon for the associated template.
   */
  icon?: React.ElementType | React.JSX.Element;
  /**
   * Experimental: not fully supported yet
   * Hints at what the document ID for the new document should be.
   * Leave undefined to let the system decide.
   *
   * @experimental
   * @beta
   * @hidden
   */
  initialDocumentId?: string;
  /**
   * @deprecated No longer used anywhere
   * @hidden
   */
  subtitle?: string;
  /**
   * @deprecated No longer used anywhere
   * @hidden
   */
  description?: string;
}
/** @internal */
declare function prepareTemplates(schema: Schema, initialValueTemplates: Template[]): Template[];
/** @internal */
declare function defaultTemplateForType(schemaType: SchemaType): Template;
/** @internal */
declare function defaultTemplatesForSchema(schema: Schema): Template[];
/** @internal */
type Serializeable<T> = {
  serialize(): T;
};
interface Options {
  useCache?: boolean;
}
/** @internal */
declare function isBuilder(template: unknown): template is Serializeable<Template>;
/** @internal */
declare function resolveInitialValue(schema: Schema, template: Template, params: {
  [key: string]: any;
} | undefined, context: InitialValueResolverContext, options?: Options): Promise<{
  [key: string]: any;
}>;
/** @internal */
declare const DEFAULT_MAX_RECURSION_DEPTH = 10;
type ResolveInitialValueForType = <TParams extends Record<string, unknown>>(
/**
 * This is the name of the document.
 */

type: SchemaType,
/**
 * Params is a sanity context object passed to every initial value function.
 */

params: TParams,
/**
 * Maximum recursion depth (default 9).
 */

maxDepth: number, context: InitialValueResolverContext, options?: Options) => Promise<any>;
/**
 * Resolve initial value for the given schema type (recursively)
 *
 * @internal
 */
declare const resolveInitialValueForType: ResolveInitialValueForType;
/** @internal */
declare function resolveInitialObjectValue<Params extends Record<string, unknown>>(type: ObjectSchemaType, params: Params, maxDepth: number, context: InitialValueResolverContext, options?: Options): Promise<any>;
/**
 *
 * @hidden
 * @beta
 */
declare function useTemplates(): Template[];
/** @internal */
interface TimeAgoOpts {
  minimal?: boolean;
  agoSuffix?: boolean;
}
/**
 * @deprecated - Use {@link useRelativeTime} instead
 * @internal
 */
declare function useTimeAgo(time: Date | string, options?: TimeAgoOpts): string;
/**
 *
 * @hidden
 * @beta
 */
declare function useTools(): Tool[];
/**
 * Options for the `useUnitFormatter` hook
 *
 * @public
 */
type UseUnitFormatterOptions = Pick<Intl.NumberFormatOptions, 'notation' | 'signDisplay' | 'unitDisplay' | 'maximumFractionDigits' | 'minimumFractionDigits'>;
/**
 * Available measurement units
 *
 * @public
 */
type FormattableMeasurementUnit = 'acre' | 'bit' | 'byte' | 'celsius' | 'centimeter' | 'day' | 'degree' | 'fahrenheit' | 'fluid-ounce' | 'foot' | 'gallon' | 'gigabit' | 'gigabyte' | 'gram' | 'hectare' | 'hour' | 'inch' | 'kilobit' | 'kilobyte' | 'kilogram' | 'kilometer' | 'liter' | 'megabit' | 'megabyte' | 'meter' | 'mile' | 'mile-scandinavian' | 'milliliter' | 'millimeter' | 'millisecond' | 'minute' | 'month' | 'ounce' | 'percent' | 'petabyte' | 'pound' | 'second' | 'stone' | 'terabit' | 'terabyte' | 'week' | 'yard' | 'year';
/**
 * Formats a number using the specified unit, using the currently active locale.
 *
 * @param value - The number to format
 * @param unit - The unit to format the number as
 * @returns The formatted number
 * @public
 */
type UnitFormatter = (value: number, unit: FormattableMeasurementUnit) => string;
/**
 * Returns a formatter with the given options. Function takes a number and the unit to format as
 * the second argument. The formatter will yield localized output, based on the users' selected
 * locale.
 *
 * This differs from regular `Intl.NumberFormat` in two ways:
 * 1. You do not need to instantiate a new formatter for each unit you want to format
 *    (still happens behind the scenes, but is memoized)
 * 2. The default unit display style (`unitDisplay`) is `long`
 *
 * @example
 * ```ts
 * function MyComponent() {
 *   const format = useUnitFormatter()
 *   return <div>{format(2313, 'meter')}</div>
 *   // en-US -> 2,313 meters
 *   // fr-FR -> 2 313 mètres
 * }
 * ```
 *
 * @param options - Optional options for the unit formatter
 * @returns Formatter function
 * @public
 */
declare function useUnitFormatter(options?: UseUnitFormatterOptions): UnitFormatter;
type Loadable$1<T> = {
  data: T | null;
  error: Error | null;
  loading: boolean;
};
/**
 * @beta
 * @hidden
 */
type UserListWithPermissionsHookValue = Loadable$1<UserWithPermission[]> & {
  /** when true, comments has mention feature disabled
   * @internal
   * */
  disabled?: boolean;
};
/**
 * @beta
 * @hidden
 */
interface UserWithPermission extends User {
  granted: boolean;
}
/**
 * @beta
 */
interface UserListWithPermissionsOptions {
  documentValue: SanityDocument$1 | null;
  permission: DocumentValuePermission;
}
/**
 * @beta
 * Returns a list of users with the specified permission on the document.
 * If no document is provided it will return all as `granted: true`
 */
declare function useUserListWithPermissions(opts: UserListWithPermissionsOptions): UserListWithPermissionsHookValue;
/**
 * Concrete Rule implementation with validation logic.
 * This extends the base Rule class from `@sanity/schema` and adds the validate method.
 *
 * Note: `RuleClass` and `Rule` are split to fit the current `@sanity/types`
 * setup. Classes are a bit weird in the `@sanity/types` package because classes
 * create an actual javascript class while simultaneously creating a type
 * definition.
 *
 * This implicitly creates two types:
 * 1. the instance type — `Rule` and
 * 2. the static/class type - `RuleClass`
 *
 * The `RuleClass` type contains the static methods and the `Rule` instance
 * contains the instance methods.
 *
 * This package exports the RuleClass as a value without implicitly exporting
 * an instance definition. This should help reminder downstream users to import
 * from the `@sanity/types` package.
 *
 * @internal
 */
declare const Rule: RuleClass;
/**
 * The string resources for the studio core.
 *
 * @internal
 * @hidden
 */
declare const studioLocaleStrings: {
  /** "Configuration issue" header */'about-dialog.configuration-issue.header': string; /** Message shown if sanity.cli.ts is missing deployment.appId */
  'about-dialog.configuration-issue.missing-appid': string; /** "View documentation" link for auto-updating studios */
  'about-dialog.configuration-issue.missing-appid.view-documentation': string; /** "Disabled" status for auto-updates in About-dialog */
  'about-dialog.version-info.auto-updates.disabled': string; /** "Enabled" status for auto-updates in About-dialog */
  'about-dialog.version-info.auto-updates.enabled': string; /** @deprecated "Auto Updates" status header in About-dialog */
  'about-dialog.version-info.auto-updates.header': string; /** "How to enable" next to Disabled state for Auto updates in version info dialog */
  'about-dialog.version-info.auto-updates.how-to-enable': string; /** "Manage version" link text */
  'about-dialog.version-info.auto-updates.manage-version': string; /** Text displayed on the "Copy to clipboard"-button after clicked */
  'about-dialog.version-info.copy-to-clipboard-button.copied-text': string; /** "Copy to Clipboard" button text for copying version details from About-dialog */
  'about-dialog.version-info.copy-to-clipboard-button.text': string; /** "Current version" header in version info dialog  */
  'about-dialog.version-info.current-version.header': string; /** @deprecated "How to upgrade" link text */
  'about-dialog.version-info.how-to-upgrade': string; /** "Latest version" header in version info dialog */
  'about-dialog.version-info.latest-version.header': string; /** Info text when auto updates is enabled and a new version is available */
  'about-dialog.version-info.new-auto-update-version-available': string;
  /** "New version" header in version info dialog - Note that this is not necessary a *higher* version compared to current:
   *  It's a new version configured for auto updates which in some cases could even be a version below current  */
  'about-dialog.version-info.new-version.text': string; /** "Reload"-button when auto updates is enabled and a new version is available */
  'about-dialog.version-info.reload': string; /** "Reload to update"-tooltip when auto updates is enabled and a new version is available */
  'about-dialog.version-info.reload-to-update': string; /** "Development" tooltip in About-dialog */
  'about-dialog.version-info.tooltip.development': string; /** "New version available" tooltip in About-dialog */
  'about-dialog.version-info.tooltip.new-version-available': string; /** "Prerelease" tooltip in About-dialog */
  'about-dialog.version-info.tooltip.prerelease': string; /** "Up to date" tooltip in About-dialog */
  'about-dialog.version-info.tooltip.up-to-date': string; /** @deprecated "Up to date" status in About-dialog */
  'about-dialog.version-info.up-to-date': string; /** "Upgrade"-button text */
  'about-dialog.version-info.update-button.text': string; /** "Upgrade"-button tooltip text */
  'about-dialog.version-info.update-button.tooltip': string; /** "User agent" header in About-dialog */
  'about-dialog.version-info.user-agent.header': string; /** "View on GitHub" link from version info dialog */
  'about-dialog.version-info.view-on-github': string; /** The text used in the tooltip shown in the dialog close button */
  'announcement.dialog.close': string; /** Aria label to be used in the dialog close button */
  'announcement.dialog.close-label': string; /**Text to be used in the tooltip in the button in the studio announcement card */
  'announcement.floating-button.dismiss': string; /**Aria label to be used in the floating button in the studio announcement card, to dismiss the card */
  'announcement.floating-button.dismiss-label': string; /**Aria label to be used in the floating button in the studio announcement card */
  'announcement.floating-button.open-label': string; /** Menu item for deleting the asset */
  'asset-source.asset-list.menu.delete': string; /** Menu item for showing where a particular asset is used */
  'asset-source.asset-list.menu.show-usage': string; /** Header in usage dialog for file assets */
  'asset-source.asset-usage-dialog.header_file': string; /** Header in usage dialog for image assets */
  'asset-source.asset-usage-dialog.header_image': string; /** Text shown in usage dialog when loading documents using the selected asset */
  'asset-source.asset-usage-dialog.loading': string; /** Browse button text */
  'asset-source.browse-button.text': string; /** Text for cancel action in delete-asset dialog */
  'asset-source.delete-dialog.action.cancel': string; /** Text for "confirm delete" action in delete-asset dialog */
  'asset-source.delete-dialog.action.delete': string; /** Dialog header for delete-asset dialog when deleting a file */
  'asset-source.delete-dialog.header_file': string; /** Dialog header for delete-asset dialog when deleting an image */
  'asset-source.delete-dialog.header_image': string; /** Text shown in delete dialog when loading documents using the selected asset */
  'asset-source.delete-dialog.loading': string; /** Message confirming to delete *named* file */
  'asset-source.delete-dialog.usage-list.confirm-delete-file_named': string; /** Message confirming to delete *unnamed* file */
  'asset-source.delete-dialog.usage-list.confirm-delete-file_unnamed': string; /** Message confirming to delete *named* image */
  'asset-source.delete-dialog.usage-list.confirm-delete-image_named': string; /** Message confirming to delete *unnamed* image */
  'asset-source.delete-dialog.usage-list.confirm-delete-image_unnamed': string; /** Alt text showing on image preview in delete asset dialog  */
  'asset-source.delete-dialog.usage-list.image-preview-alt': string; /** Warning message showing when *named* file can't be deleted because it is in use */
  'asset-source.delete-dialog.usage-list.warning-file-is-in-use_named': string; /** Warning message showing when *unnamed* file can't be deleted because it is in use */
  'asset-source.delete-dialog.usage-list.warning-file-is-in-use_unnamed': string; /** Warning message showing when *named* image can't be deleted because it is in use */
  'asset-source.delete-dialog.usage-list.warning-image-is-in-use_named': string; /** Warning message showing when *unnamed* image can't be deleted because it is in use */
  'asset-source.delete-dialog.usage-list.warning-image-is-in-use_unnamed': string; /** Text shown when the list of assets only include a specific set of types */
  'asset-source.dialog.accept-message': string; /** Select asset dialog cancel-button */
  'asset-source.dialog.button.cancel': string; /** Select asset dialog select-button */
  'asset-source.dialog.button.select': string;
  /** Keys shared between both image asset source and file asset source */
  /** Insert asset error */
  'asset-source.dialog.insert-asset-error': string; /** Select asset dialog load more items */
  'asset-source.dialog.load-more': string;
  /** Text shown when selecting a file but there's no files to select from
   * @deprecated no longer in use
   */
  'asset-source.dialog.no-assets_file': string;
  /** Text shown when selecting an image but there's no images to select from
   * @deprecated no longer in use
   */
  'asset-source.dialog.no-assets_image': string;
  'asset-source.file.asset-list.action.delete.disabled-cannot-delete-current-file': string;
  'asset-source.file.asset-list.action.delete.text': string;
  'asset-source.file.asset-list.action.delete.title': string;
  'asset-source.file.asset-list.action.select-file.title': string;
  'asset-source.file.asset-list.action.show-usage.title': string;
  'asset-source.file.asset-list.delete-failed': string;
  'asset-source.file.asset-list.delete-successful': string;
  'asset-source.file.asset-list.header.date-added': string; /** File asset source */
  'asset-source.file.asset-list.header.filename': string;
  'asset-source.file.asset-list.header.size': string;
  'asset-source.file.asset-list.header.type': string; /** Text displayed on button or menu invoking the file asset source */
  'asset-source.file.title': string;
  'asset-source.image.asset-list.delete-failed': string; /** Image asset source */
  'asset-source.image.asset-list.delete-successful': string; /** Text displayed on button or menu invoking the image asset source */
  'asset-source.image.title': string; /** Built in asset source usage texts */
  'asset-source.usage-list.documents-using-file_named_one': string;
  'asset-source.usage-list.documents-using-file_named_other': string; /** Text shown in usage dialog for a file asset when there are zero, one or more documents using the *named* file **/
  'asset-source.usage-list.documents-using-file_named_zero': string;
  'asset-source.usage-list.documents-using-file_unnamed_one': string;
  'asset-source.usage-list.documents-using-file_unnamed_other': string; /** Text shown in usage dialog for a file asset when there are zero, one or more documents using the *unnamed* file **/
  'asset-source.usage-list.documents-using-file_unnamed_zero': string;
  'asset-source.usage-list.documents-using-image_named_one': string;
  'asset-source.usage-list.documents-using-image_named_other': string; /** Text shown in usage dialog for an image asset when there are zero, one or more documents using the *named* image **/
  'asset-source.usage-list.documents-using-image_named_zero': string;
  'asset-source.usage-list.documents-using-image_unnamed_one': string;
  'asset-source.usage-list.documents-using-image_unnamed_other': string; /** Text shown in usage dialog for an image asset when there are zero, one or more documents using the *unnamed* image **/
  'asset-source.usage-list.documents-using-image_unnamed_zero': string; /** Common (all) Asset Source texts. Note that all translation keys starting with 'asset-source.' is for the built in asset source. */
  'asset-sources.common.uploader.upload-failed.description': string;
  'asset-sources.common.uploader.upload-failed.title': string; /** Menu Items for Dataset Asset Source (will be replaced with workspace name by default) */
  'asset-sources.dataset.file.title': string;
  'asset-sources.dataset.image.title': string; /** Error messages for the Media Library Asset Source  */
  'asset-sources.media-library.error.library-could-not-be-resolved': string; /** Error message shown when no media library has been provisioned for the current organization */
  'asset-sources.media-library.error.no-media-library-provisioned': string; /** Menu Items for Media Library Asset Source */
  'asset-sources.media-library.file.title': string;
  'asset-sources.media-library.image.title': string; /** Done button text */
  'asset-sources.media-library.open-in-source-dialog.button.done': string; /** Select new asset button text with target title */
  'asset-sources.media-library.open-in-source-dialog.button.select-new-asset': string;
  'asset-sources.media-library.open-in-source-dialog.button.select-new-asset-fallback': string; /** Title for the open in source dialog */
  'asset-sources.media-library.open-in-source-dialog.title': string; /** Title for the upload dialog (component mode) */
  'asset-sources.media-library.upload-dialog.title': string; /** Warning message shown when uploading already existing files to the Media Library Asset Source */
  'asset-sources.media-library.warning.file-already-exist.description': string;
  'asset-sources.media-library.warning.file-already-exist.title': string; /** Label when a release has been deleted by a different user */
  'banners.deleted-bundle-banner.text': string; /** Action message for navigating to next month */
  'calendar.action.go-to-next-month': string; /** Action message for navigating to next year */
  'calendar.action.go-to-next-year': string; /** Action message for navigating to previous month */
  'calendar.action.go-to-previous-month': string; /** Action message for navigating to previous year */
  'calendar.action.go-to-previous-year': string;
  'calendar.action.go-to-today': string;
  'calendar.action.go-to-today-aria-label': string;
  'calendar.action.go-to-tomorrow': string;
  'calendar.action.go-to-yesterday': string; /** Label for switch that controls whether or not to include time in given timestamp */
  'calendar.action.include-time-label': string; /** Action message for selecting the time */
  'calendar.action.select-time': string; /** Action message for setting to the current time */
  'calendar.action.set-to-current-time': string; /** Label for selecting an hour preset. Receives a `time` param as a string on hh:mm format and a `date` param as a Date instance denoting the preset date */
  'calendar.action.set-to-time-preset': string; /** Aria label for button to open date picker */
  'calendar.button.aria-label': string; /** Tooltip content for button to open datetime input */
  'calendar.button.tooltip-text': string; /** Error message displayed in calendar when entered date is not the correct format */
  'calendar.error.must-be-in-format': string; /** Month name for April */
  'calendar.month-names.april': string; /** Month name for August */
  'calendar.month-names.august': string; /** Month name for December */
  'calendar.month-names.december': string; /** Month name for February */
  'calendar.month-names.february': string; /** Month name for January */
  'calendar.month-names.january': string; /** Month name for July */
  'calendar.month-names.july': string; /** Month name for June */
  'calendar.month-names.june': string; /** Month name for March */
  'calendar.month-names.march': string; /** Month name for May */
  'calendar.month-names.may': string; /** Month name for November */
  'calendar.month-names.november': string; /** Month name for October */
  'calendar.month-names.october': string; /** Month name for September */
  'calendar.month-names.september': string; /** Short weekday name for Friday */
  'calendar.weekday-names.short.friday': string; /** Short weekday name for Monday */
  'calendar.weekday-names.short.monday': string; /** Short weekday name for Saturdayday */
  'calendar.weekday-names.short.saturday': string; /** Short weekday name for Sunday */
  'calendar.weekday-names.short.sunday': string; /** Short weekday name for Thursday */
  'calendar.weekday-names.short.thursday': string; /** Short weekday name for Tuesday */
  'calendar.weekday-names.short.tuesday': string; /** Short weekday name for Wednesday */
  'calendar.weekday-names.short.wednesday': string; /** Label for the close button label in Review Changes pane */
  'changes.action.close-label': string; /** Cancel label for revert button prompt action */
  'changes.action.revert-all-cancel': string; /** Revert all confirm label for revert button action - used on prompt button + review changes pane */
  'changes.action.revert-all-confirm': string; /** Prompt for reverting all changes in document in Review Changes pane. Includes a count of changes. */
  'changes.action.revert-all-description': string; /** Prompt for confirming revert change (singular) label for field change action */
  'changes.action.revert-changes-confirm-change_one': string; /** Revert for confirming revert (plural) label for field change action */
  'changes.action.revert-changes-confirm-change_other': string; /** Prompt for reverting changes for a field change */
  'changes.action.revert-changes-description': string; /** Prompt for reverting changes for a group change, eg multiple changes */
  'changes.action.revert-changes-description_one': string; /** Label for when the action of the change was to set something that was previously empty, eg a field was given a value, an array item was added, an asset was selected or similar */
  'changes.added-label': string; /** Array diff: An item was added in a given position (`{{position}}`) */
  'changes.array.item-added-in-position': string;
  'changes.array.item-moved_down_one': string;
  'changes.array.item-moved_down_other': string;
  /**
   * Array diff: An item was moved within the array.
   * Receives `{{count}}` representing number of positions it moved.
   * Context is the direction of the move, either `up` or `down`.
   */
  'changes.array.item-moved_up_one': string;
  'changes.array.item-moved_up_other': string; /** Array diff: An item was removed from a given position (`{{position}}`) */
  'changes.array.item-removed-from-position': string; /** Accessibility label for the "change bar" shown when there are edits on a field-level */
  'changes.change-bar.aria-label': string; /** Label for when the action of the change was _not_ an add/remove, eg a text field changed value, an image was changed from one asset to another or similar */
  'changes.changed-label': string; /** Label and text for tooltip that indicates the authors of the changes */
  'changes.changes-by-author': string; /** Additional text shown in development mode when a diff component crashes during rendering */
  'changes.error-boundary.developer-info': string; /** Text shown when a diff component crashes during rendering, triggering the error boundary */
  'changes.error-boundary.title': string;
  'changes.error-description': string; /** Error title when changes could not be loaded */
  'changes.error-title': string; /** Error message shown when the value of a field is not the expected one */
  'changes.error.incorrect-type-message': string; /** File diff: Fallback title for the meta info section when there is no original filename to use  */
  'changes.file.meta-info-fallback-title': string; /** Image diff: Text shown in tooltip when hovering hotspot that has changed in diff view */
  'changes.image.crop-changed': string; /** Image diff: Text shown if the previous image asset was deleted (shouldn't theoretically happen) */
  'changes.image.deleted': string; /** Image diff: Text shown if the image failed to be loaded when previewing it */
  'changes.image.error-loading-image': string; /** Image diff: Text shown in tooltip when hovering hotspot that has changed in diff view */
  'changes.image.hotspot-changed': string; /** Image diff: Fallback title for the meta info section when there is no original filename to use  */
  'changes.image.meta-info-fallback-title': string; /** Image diff: Text shown if no asset has been set for the field (but has metadata changes) */
  'changes.image.no-asset-set': string; /** Image diff: Text shown when the from/to state has/had no image */
  'changes.image.no-image-placeholder': string; /** Label for the "from" value in the change inspector */
  'changes.inspector.from-label': string; /** Label for the "meta" (field path, action etc) information in the change inspector */
  'changes.inspector.meta-label': string; /** Label for the "to" value in the change inspector */
  'changes.inspector.to-label': string; /** Loading author of change in the differences tooltip in the review changes pane */
  'changes.loading-author': string; /** Loading changes in Review Changes Pane */
  'changes.loading-changes': string; /** Error message shown when the document revision could not be found */
  'changes.missing-since-document-error': string; /** No Changes description in the Review Changes pane */
  'changes.no-changes-description': string; /** No Changes title in the Review Changes pane */
  'changes.no-changes-title': string;
  'changes.not-selectable': string; /** Portable Text diff: An annotation was added */
  'changes.portable-text.annotation_added': string; /** Portable Text diff: An annotation was changed */
  'changes.portable-text.annotation_changed': string; /** Portable Text diff: An annotation was removed */
  'changes.portable-text.annotation_removed': string; /** Portable Text diff: An annotation was left unchanged */
  'changes.portable-text.annotation_unchanged': string; /** Portable Text diff: A block changed from one style to another (eg `normal` to `h1` or similar) */
  'changes.portable-text.block-style-changed': string; /** Portable Text diff: Change formatting of text (setting/unsetting marks, eg bold/italic etc) */
  'changes.portable-text.changed-formatting': string; /** Portable Text diff: An empty inline object is part of a change */
  'changes.portable-text.empty-inline-object': string; /** Portable Text diff: An empty object is the result of adding/removing an annotation */
  'changes.portable-text.empty-object-annotation': string; /** Portable Text diff: Added a block containing no text (eg empty block) */
  'changes.portable-text.empty-text_added': string; /** Portable Text diff: Changed a block that contained no text (eg empty block) */
  'changes.portable-text.empty-text_changed': string; /** Portable Text diff: Removed a block containing no text (eg empty block) */
  'changes.portable-text.empty-text_removed': string; /** Portable Text diff: An inline object was added */
  'changes.portable-text.inline-object_added': string; /** Portable Text diff: An inline object was changed */
  'changes.portable-text.inline-object_changed': string; /** Portable Text diff: An inline object was removed */
  'changes.portable-text.inline-object_removed': string; /** Portable Text diff: An inline object was left unchanged */
  'changes.portable-text.inline-object_unchanged': string; /** Portable Text diff: Added a chunk of text */
  'changes.portable-text.text_added': string; /** Portable Text diff: Removed a chunk of text */
  'changes.portable-text.text_removed': string; /** Portable Text diff: Annotation has an unknown schema type */
  'changes.portable-text.unknown-annotation-schema-type': string; /** Portable Text diff: Inline object has an unknown schema type */
  'changes.portable-text.unknown-inline-object-schema-type': string; /** Label for when the action of the change was a removal, eg a field was cleared, an array item was removed, an asset was deselected or similar */
  'changes.removed-label': string; /** Same Revision Selected description in the Review Changes pane */
  'changes.same-revision-selected-description': string; /** Same Revision Selected title in the Review Changes pane */
  'changes.same-revision-selected-title': string; /** Title for the Review Changes pane */
  'changes.title': string; /**The title that will be shown in the badge inside the events when the item is a draft */
  'changes.versions.draft': string;
  /** --- Common components --- */
  /** Tooltip text for context menu buttons */
  'common.context-menu-button.tooltip': string; /** Default text for dialog cancel button */
  'common.dialog.cancel-button.text': string; /** Default text for dialog confirm button */
  'common.dialog.confirm-button.text': string; /** Default text in shared loader text / spinner lockup */
  'common.loading': string; /** The title of the reconnecting toast */
  'common.reconnecting.toast.title': string;
  /** --- Configuration issues --- */
  /** Default label text on configuration issues button */
  'configuration-issues.button.label': string; /** Tooltip displayed on configuration issues button */
  'configuration-issues.button.tooltip': string; /** The fallback title for an ordering menu item if no localized titles are provided. */
  'default-menu-item.fallback-title': string; /** Title for the default ordering/SortOrder if no orderings are provided and the caption field is found */
  'default-orderings.caption': string; /** Title for the default ordering/SortOrder if no orderings are provided and the description field is found */
  'default-orderings.description': string; /** Title for the default ordering/SortOrder if no orderings are provided and the header field is found */
  'default-orderings.header': string; /** Title for the default ordering/SortOrder if no orderings are provided and the heading field is found */
  'default-orderings.heading': string; /** Title for the default ordering/SortOrder if no orderings are provided and the label field is found */
  'default-orderings.label': string; /** Title for the default ordering/SortOrder if no orderings are provided and the name field is found */
  'default-orderings.name': string; /** Title for the default ordering/SortOrder if no orderings are provided and the title field is found */
  'default-orderings.title': string; /** Label to show in the document footer indicating the creation date of the document */
  'document-status.created': string; /** Label to show in the document status indicating the date of the status */
  'document-status.date': string; /** Label to show in the document footer indicating the last edited date of the document */
  'document-status.edited': string; /** Label to show in the document footer status line when a document was last published */
  'document-status.last-published': string; /** Label to show in the document footer indicating the document is not published*/
  'document-status.not-published': string; /** Label to show in the document footer indicating the published date of the document */
  'document-status.published': string; /** Label to show in the document footer indicating the revision from date of the document */
  'document-status.revision-from': string; /** Label to show in the document footer indicating that the revision was not found */
  'document-status.revision-not-found': string; /** Toast description shown when saving changes is taking longer than expected */
  'document-store.slow-commit.description': string; /** Toast title shown when saving changes is taking longer than expected */
  'document-store.slow-commit.title': string; /** Label to indicate that a document type was not found */
  'document.type.not-found': string; /** Error message shown when an action cannot be performed */
  'errors.unable-to-perform-action': string; /** The value of the <code>_key</code> property must be a unique string. */
  'form.error.duplicate-keys-alert.details.additional-description': string; /** This usually happens when items are created using an API client, and the <code>_key</code> property of each elements has been generated non-uniquely. */
  'form.error.duplicate-keys-alert.details.description': string; /** Developer info */
  'form.error.duplicate-keys-alert.details.title': string; /** Generate unique keys */
  'form.error.duplicate-keys-alert.generate-button.text': string; /** Several items in this list share the same identifier (key). Every item must have an unique identifier. */
  'form.error.duplicate-keys-alert.summary': string; /** Non-unique keys */
  'form.error.duplicate-keys-alert.title': string; /** Error text shown when a field with a given name cannot be found in the schema or is conditionally hidden but explicitly told to render  */
  'form.error.field-not-found': string; /** Add missing keys */
  'form.error.missing-keys-alert.add-button.text': string; /** The value of the <code>_key</code> property must be a unique string. */
  'form.error.missing-keys-alert.details.additional-description': string; /** This usually happens when items are created using an API client, and the <code>_key</code> property has not been included. */
  'form.error.missing-keys-alert.details.description': string; /** Developer info */
  'form.error.missing-keys-alert.details.title': string; /** Some items in the list are missing their keys. This must be fixed in order to edit the list. */
  'form.error.missing-keys-alert.summary': string; /** Missing keys */
  'form.error.missing-keys-alert.title': string; /** This usually happens when items are created using an API client, or when a custom input component has added invalid data to the list. */
  'form.error.mixed-array-alert.details.description': string; /** Developer info */
  'form.error.mixed-array-alert.details.title': string; /**  Remove non-object values */
  'form.error.mixed-array-alert.remove-button.text': string; /** Some items in this list are not objects. This must be fixed in order to edit the list. */
  'form.error.mixed-array-alert.summary': string; /** Invalid list values */
  'form.error.mixed-array-alert.title': string; /** Error text shown when form is unable to find an array item at a given indexed path */
  'form.error.no-array-item-at-index': string; /** Error text shown when form is unable to find an array item at a given keyed path */
  'form.error.no-array-item-at-key': string; /** The title above the error call stack output related to the crash */
  'form.error.unhandled-runtime-error.call-stack.title': string; /** The title above the error component stack provided by React's underlying ErrorBoundary component */
  'form.error.unhandled-runtime-error.component-stack.title': string; /** The error message for the unhandled error that crashed the Input component during render */
  'form.error.unhandled-runtime-error.error-message': string; /** The title for the error card rendered inside a field in place of a crashing input */
  'form.error.unhandled-runtime-error.title': string; /** Form field deprecated label */
  'form.field.deprecated-label': string; /** Fallback title shown above field if it has no defined title */
  'form.field.untitled-field-label': string; /** Accessibility label for the icon that indicates the field has a validation error */
  'form.validation.has-error-aria-label': string; /** Accessibility label for the icon that indicates the field has validation information */
  'form.validation.has-info-aria-label': string; /** Accessibility label for the icon that indicates the field has a validation warning */
  'form.validation.has-warning-aria-label': string; /** Text shown when summarizing validation information, when the field has one or more errors */
  'form.validation.summary.errors-count_one': string;
  'form.validation.summary.errors-count_other': string; /** Text shown when summarizing validation information, when the field has one or more warnings */
  'form.validation.summary.warnings-count_one': string;
  'form.validation.summary.warnings-count_other': string; /** Tooltip for free trial navbar button indicating remaining days */
  'free-trial.tooltip.days-count_one': string;
  'free-trial.tooltip.days-count_other': string; /** Tooltip for free trial navbar button, once trial has ended */
  'free-trial.tooltip.trial-finished': string;
  /**
   * Label for "contact sales" call to action
   * These are titles for fallback links in the event the help & resources endpoint isn't able to be fetched
   */
  'help-resources.action.contact-sales': string;
  /**
   * Label for "help and support" call to action
   * These are titles for fallback links in the event the help & resources endpoint isn't able to be fetched
   */
  'help-resources.action.help-and-support': string;
  /**
   * Label for "join our community" call to action
   * These are titles for fallback links in the event the help & resources endpoint isn't able to be fetched
   */
  'help-resources.action.join-our-community': string; /** Information for what the latest sanity version is */
  'help-resources.latest-sanity-version': string; /** Text for link to register a studio */
  'help-resources.register-studio': string; /** Name of the sanity studio */
  'help-resources.studio': string; /** Menu item for registered studios (i.e. copies app id) */
  'help-resources.studio-app-id': string; /** Menu item for reloading Studio to update */
  'help-resources.studio-auto-update-now': string; /** Information for what studio version the current studio is running */
  'help-resources.studio-version': string; /** Title for help and resources menus */
  'help-resources.title': string; /** Label for studio's which are up to date */
  'help-resources.up-to-date': string; /** Version text */
  'help-resources.version': string; /**Incoming references inspector title */
  'incoming-references.title': string; /** Text for button to cancel an ongoing upload */
  'input.files.common.cancel-upload': string; /** Text for menuitem upload button default asset source */
  'input.files.common.upload-placeholder.file-input-button.default-source.badge': string; /** Text for file input button in upload placeholder */
  'input.files.common.upload-placeholder.file-input-button.text': string; /** Uploading <FileName/> */
  'input.files.common.upload-progress': string; /** The referenced document cannot be opened, because the URL failed to be resolved */
  'input.reference.document-cannot-be-opened.failed-to-resolve-url': string; /** Label for adding item after a specific array item */
  'inputs.array.action.add-after': string; /** Label for adding item before a specific array item */
  'inputs.array.action.add-before': string; /** Label for adding array item action when the schema allows for only one schema type */
  'inputs.array.action.add-item': string;
  /**
   * Label for adding one array item action when the schema allows for multiple schema types,
   * eg. will prompt the user to select a type once triggered
   */
  'inputs.array.action.add-item-select-type': string; /** Label for copying an array item  */
  'inputs.array.action.copy': string; /** Array drag handle button tooltip */
  'inputs.array.action.drag.tooltip': string; /** Label for duplicating an array item  */
  'inputs.array.action.duplicate': string; /** Label for editing the item of a specific type, eg "Edit Person" */
  'inputs.array.action.edit': string; /** Tooltip text explaining why adding items is disabled when array max is reached */
  'inputs.array.action.max-reached': string; /** Label for removing an array item action  */
  'inputs.array.action.remove': string; /** Label for removing action when an array item has an error  */
  'inputs.array.action.remove-invalid-item': string; /** Label for viewing the item of a specific type, eg "View Person" */
  'inputs.array.action.view': string; /** Error description for the array item tooltip that explains that the current item can still be moved or deleted but not edited since the schema definition is not found */
  'inputs.array.error.can-delete-but-no-edit-description': string; /** Error label for toast when array could not resolve the initial value */
  'inputs.array.error.cannot-resolve-initial-value-title': string; /** Error label for toast when trying to upload one array item of a type that cannot be converted to array */
  'inputs.array.error.cannot-upload-unable-to-convert_one': string; /** Error label for toast when trying to upload multiple array items of a type that cannot be converted to array */
  'inputs.array.error.cannot-upload-unable-to-convert_other': string; /** Error description for the array item tooltip that explains that the current type item is not valid for the list  */
  'inputs.array.error.current-schema-not-declare-description': string; /** Error description to show how the item is being represented in the json format */
  'inputs.array.error.json-representation-description': string; /** Error description for the array item tooltip that explains what the error means with more context */
  'inputs.array.error.type-is-incompatible-prompt': string; /** Error title for when an item type within an array input is incompatible, used in the tooltip */
  'inputs.array.error.type-is-incompatible-title': string; /** Error label for unexpected errors in the Array Input */
  'inputs.array.error.unexpected-error': string; /** Label for the array insert menu all items filter  */
  'inputs.array.insert-menu.filter.all-items': string; /** Label for when the array insert menu search shows no items */
  'inputs.array.insert-menu.search.no-results': string; /** Placeholder for the array insert menu search field */
  'inputs.array.insert-menu.search.placeholder': string; /** Tooltip for the array insert menu grid view toggle */
  'inputs.array.insert-menu.toggle-grid-view.tooltip': string; /** Tooltip for the array insert menu list view toggle */
  'inputs.array.insert-menu.toggle-list-view.tooltip': string; /** Label for when the array input doesn't have any items */
  'inputs.array.no-items-label': string; /** Label for read only array fields */
  'inputs.array.read-only-label': string; /** Label for when the array input is resolving the initial value for the item */
  'inputs.array.resolving-initial-value': string; /** Tooltip content when boolean input is disabled */
  'inputs.boolean.disabled': string; /** Warning label when selected datetime is in the past */
  'inputs.dateTime.past-date-warning': string; /** Placeholder value for datetime input */
  'inputs.datetime.placeholder': string; /** Acessibility label for button to open file options menu */
  'inputs.file.actions-menu.file-options.aria-label': string; /** Unknown member kind: `{{kind}}` */
  'inputs.file.error.unknown-member-kind': string; /** The value of this field is not a valid file. Resetting this field will let you choose a new file. */
  'inputs.file.invalid-file-warning.description': string; /** Reset value */
  'inputs.file.invalid-file-warning.reset-button.text': string; /** Invalid file value */
  'inputs.file.invalid-file-warning.title': string; /** The upload could not be completed at this time. */
  'inputs.file.upload-failed.description': string; /** Upload failed */
  'inputs.file.upload-failed.title': string; /** Private access policy badge label */
  'inputs.files.common.access-policy.private.label': string; /** Private access policy badge tooltip */
  'inputs.files.common.access-policy.private.tooltip': string; /** Clear field */
  'inputs.files.common.actions-menu.clear-field.label': string; /** Copy URL */
  'inputs.files.common.actions-menu.copy-url.label': string; /** Download */
  'inputs.files.common.actions-menu.download.label': string; /** The URL is copied to the clipboard */
  'inputs.files.common.actions-menu.notification.url-copied': string; /** Open in source */
  'inputs.files.common.actions-menu.open-in-source.label': string; /** Replace */
  'inputs.files.common.actions-menu.replace.label': string; /** Upload */
  'inputs.files.common.actions-menu.upload.label': string; /** Drop to upload */
  'inputs.files.common.drop-message.drop-to-upload': string; /** Drop to upload `{{count}}` file */
  'inputs.files.common.drop-message.drop-to-upload-multi_one': string; /** Drop to upload `{{count}}` files */
  'inputs.files.common.drop-message.drop-to-upload-multi_other': string; /** Can't upload this file here */
  'inputs.files.common.drop-message.drop-to-upload.no-accepted-file-message_one': string; /** Can't upload any of these files here */
  'inputs.files.common.drop-message.drop-to-upload.no-accepted-file-message_other': string; /** `{{count}}` file can't be uploaded here */
  'inputs.files.common.drop-message.drop-to-upload.rejected-file-message_one': string; /** `{{count}}` files can't be uploaded here */
  'inputs.files.common.drop-message.drop-to-upload.rejected-file-message_other': string; /** Cannot upload `{{count}}` files */
  'inputs.files.common.placeholder.cannot-upload-some-files_one': string;
  'inputs.files.common.placeholder.cannot-upload-some-files_other': string; /** Drag or paste type here */
  'inputs.files.common.placeholder.drag-or-paste-to-upload_file': string; /** Drag or paste image here */
  'inputs.files.common.placeholder.drag-or-paste-to-upload_image': string; /** Drop to upload file */
  'inputs.files.common.placeholder.drop-to-upload_file': string; /** Drop to upload image */
  'inputs.files.common.placeholder.drop-to-upload_image': string; /** Read only */
  'inputs.files.common.placeholder.read-only': string; /** Select asset source destination for files to upload */
  'inputs.files.common.placeholder.select-asset-source-upload-destination': string; /** Can't upload files here */
  'inputs.files.common.placeholder.upload-not-supported': string; /** Clear upload */
  'inputs.files.common.stale-upload-warning.clear': string; /** An upload has made no progress for at least `{{staleThresholdMinutes}}` minutes and likely got interrupted. You can safely clear the incomplete upload and try uploading again. */
  'inputs.files.common.stale-upload-warning.description': string; /** Incomplete upload */
  'inputs.files.common.stale-upload-warning.title': string; /** Select file */
  'inputs.files.select-dialog.title': string; /** Tooltip text for action to crop image */
  'inputs.image.actions-menu.crop-image-tooltip': string; /** Accessibility label for button to open image edit dialog */
  'inputs.image.actions-menu.edit-details.aria-label': string; /** Accessibility label for button to open image options menu */
  'inputs.image.actions-menu.options.aria-label': string; /** Cannot upload this file here */
  'inputs.image.drag-overlay.cannot-upload-here': string; /** Drop image to upload */
  'inputs.image.drag-overlay.drop-to-upload-image': string; /** This field is read only */
  'inputs.image.drag-overlay.this-field-is-read-only': string; /** Image could not be loaded due to possible access restrictions */
  'inputs.image.error.possible-access-restriction': string; /** Unknown member kind: `{{kind}}` */
  'inputs.image.error.unknown-member-kind': string; /** Edit hotspot and crop */
  'inputs.image.hotspot-dialog.title': string; /** The value of this field is not a valid image. Resetting this field will let you choose a new image. */
  'inputs.image.invalid-image-warning.description': string; /** Reset value */
  'inputs.image.invalid-image-warning.reset-button.text': string; /** Invalid image value */
  'inputs.image.invalid-image-warning.title': string; /** Preview of uploaded image */
  'inputs.image.preview-uploaded-image': string; /** Select image */
  'inputs.image.select-dialog.title': string; /** The upload could not be completed at this time. */
  'inputs.image.upload-error.description': string; /** Upload failed */
  'inputs.image.upload-error.title': string; /** Adjust the rectangle to crop image. Adjust the circle to specify the area that should always be visible. */
  'inputs.imagetool.description': string; /** Error: `{{errorMessage}}` */
  'inputs.imagetool.load-error': string; /** Hotspot & Crop */
  'inputs.imagetool.title': string; /** Warnings displayed to developers when using the crop/hotspot tool on vector images, notifying them that crops/hotspot are not respected when serving the image in vector format. For the crop/hotspot to apply, images must be served in a raster format such as JPG or PNG, by appending eg `fm=jpg` to the image url, or calling `format('jpg')` if using `@sanity/image-url` */
  'inputs.imagetool.vector-warning.developer-info': string; /** See developer info */
  'inputs.imagetool.vector-warning.expand-developer-info': string; /** Gotcha: Serving vector images with hotspot and crop from the Sanity Image API */
  'inputs.imagetool.vector-warning.title': string; /** Convert to `{{targetType}}` */
  'inputs.invalid-value.convert-button.text': string; /** The current value (<code>`{{actualType}}`</code>) */
  'inputs.invalid-value.current-type': string; /** The property value is stored as a value type that does not match the expected type. */
  'inputs.invalid-value.description': string; /** The value of this property must be of type <code>`{{validType}}`</code> according to the schema. */
  'inputs.invalid-value.details.description': string; /** Only the following types are valid here according to schema: */
  'inputs.invalid-value.details.multi-type-description': string; /** Mismatching value types typically occur when the schema has recently been changed. */
  'inputs.invalid-value.details.possible-reason': string; /** Developer info */
  'inputs.invalid-value.details.title': string;
  /** -- Invalid Value Input -- */
  /** Reset value */
  'inputs.invalid-value.reset-button.text': string; /** Invalid property value */
  'inputs.invalid-value.title': string; /** Title for the "All fields" field group */
  'inputs.object.field-group-tabs.all-fields-title': string; /** Aria label for the "Field groups" select control on smaller screens */
  'inputs.object.field-group-tabs.aria-label': string; /** Text shown in field group select for a group with error validation */
  'inputs.object.field-group-tabs.validation-error': string; /** Text shown in field group select for a group with info validation */
  'inputs.object.field-group-tabs.validation-info': string; /** Text shown in field group select for a group with warning validation */
  'inputs.object.field-group-tabs.validation-warning': string; /** Read-only field description */
  'inputs.object.unknown-fields.read-only.description': string; /** Fallback description shown when the unknown reference preview cannot be loaded */
  'inputs.object.unknown-fields.reference.preview.unavailable': string; /** Remove field */
  'inputs.object.unknown-fields.remove-field-button.text': string; /** Encountered `{{count}}` fields that are not defined in the schema. */
  'inputs.object.unknown-fields.warning.description_one': string;
  'inputs.object.unknown-fields.warning.description_other': string; /** Detailed description of unknown field warning */
  'inputs.object.unknown-fields.warning.details.description_one': string;
  'inputs.object.unknown-fields.warning.details.description_other': string; /** Developer info */
  'inputs.object.unknown-fields.warning.details.title': string; /** Unknown field found */
  'inputs.object.unknown-fields.warning.title_one': string;
  'inputs.object.unknown-fields.warning.title_other': string; /** Collapse the editor to save screen space  */
  'inputs.portable-text.action.collapse-editor': string; /** Aria label for action to edit an existing annotation */
  'inputs.portable-text.action.edit-annotation-aria-label': string; /** Expand the editor to give more editing space */
  'inputs.portable-text.action.expand-editor': string; /** Label label for action to insert a block of a given type (`{{typeName}}`) */
  'inputs.portable-text.action.insert-block': string; /** Accessibility label for action to insert a block of a given type (`{{typeName}}`) */
  'inputs.portable-text.action.insert-block-aria-label': string; /** Label for action to insert an inline object of a given type (`{{typeName}}`) */
  'inputs.portable-text.action.insert-inline-object': string; /** Accessibility label for action to insert an inline object of a given type (`{{typeName}}`) */
  'inputs.portable-text.action.insert-inline-object-aria-label': string; /** Aria label for action to remove an annotation */
  'inputs.portable-text.action.remove-annotation-aria-label': string; /** Label for activate on focus with context of click and not focused */
  'inputs.portable-text.activate-on-focus-message_click': string; /** Label for activate on focus with context of click and focused */
  'inputs.portable-text.activate-on-focus-message_click-focused': string; /** Label for activate on focus with context of tap and not focused */
  'inputs.portable-text.activate-on-focus-message_tap': string; /** Aria label for the annotation object */
  'inputs.portable-text.annotation-aria-label': string; /** Title for dialog that allows editing an annotation */
  'inputs.portable-text.annotation-editor.title': string; /** Title of the default "link" annotation */
  'inputs.portable-text.annotation.link': string; /** Aria label for the block object */
  'inputs.portable-text.block.aria-label': string; /** Label for action to edit a block item, in the case where it is editable */
  'inputs.portable-text.block.edit': string; /** Accessibility label for the button that opens the actions menu on blocks */
  'inputs.portable-text.block.open-menu-aria-label': string; /** Label for action to open a reference, in the case of block-level reference types */
  'inputs.portable-text.block.open-reference': string; /** Label for action to remove a block item */
  'inputs.portable-text.block.remove': string; /** Label for action to view a block item, in the case where it is read-only and thus cannot be edited */
  'inputs.portable-text.block.view': string; /** Title of the "code" decorator */
  'inputs.portable-text.decorator.code': string; /** Title of the "em" (emphasis) decorator */
  'inputs.portable-text.decorator.emphasis': string; /** Title of the "strike-through" decorator */
  'inputs.portable-text.decorator.strike-through': string; /** Title of the "strong" decorator */
  'inputs.portable-text.decorator.strong': string; /** Title of the "underline" decorator */
  'inputs.portable-text.decorator.underline': string; /** Placeholder text for when the editor is empty */
  'inputs.portable-text.empty-placeholder': string; /** Aria label for the block object */
  'inputs.portable-text.inline-block.aria-label': string; /** Label for action to edit an inline object item */
  'inputs.portable-text.inline-object.edit': string; /** Aria label for icon for action to edit an inline object item */
  'inputs.portable-text.inline-object.edit-aria-label': string; /** Label for action to remove an inline object item */
  'inputs.portable-text.inline-object.remove': string; /** Aria label for icon for action to remove an inline object item */
  'inputs.portable-text.inline-object.remove-aria-label': string; /** Disclaimer text shown on invalid Portable Text value, when an action is available to unblock the user, but it is not guaranteed to be safe */
  'inputs.portable-text.invalid-value.action-disclaimer': string; /** Action presented when the Portable Text field value is invalid, when block with key `{{key}}` has a child with key `{{childKey}}` of type `{{childType}}` which is not allowed by the schema definition */
  'inputs.portable-text.invalid-value.disallowed-child-type.action': string; /** Text explaining that the Portable Text field value is invalid, when block with key `{{key}}` has a child with key `{{childKey}}` of type `{{childType}}` which is not allowed by the schema definition */
  'inputs.portable-text.invalid-value.disallowed-child-type.description': string; /** Action presented when the Portable Text field value is invalid, when child with key `{{key}}` has a type (`{{typeName}}`) that is not an allowed block type for this field */
  'inputs.portable-text.invalid-value.disallowed-type.action': string; /** Text explaining that the Portable Text field value is invalid, when child with key `{{key}}` has a type (`{{typeName}}`) that is not an allowed block type for this field */
  'inputs.portable-text.invalid-value.disallowed-type.description': string; /** Action presented when the Portable Text field value is invalid, when block with key `{{key}}` contains no children */
  'inputs.portable-text.invalid-value.empty-children.action': string; /** Text explaining that the Portable Text field value is invalid, when block with key `{{key}}` contains no children */
  'inputs.portable-text.invalid-value.empty-children.description': string; /** Label for the button to ignore invalid values in the Portable Text editor */
  'inputs.portable-text.invalid-value.ignore-button.text': string; /** Action presented when the Portable Text field value is invalid, when child with key `{{key}}` has a `_type` property that is set to `block`, but the block type defined in schema has a different name (`{{expectedTypeName}}`) */
  'inputs.portable-text.invalid-value.incorrect-block-type.action': string; /** Text explaining that the Portable Text field value is invalid, when child with key `{{key}}` has a `_type` property that is set to `block`, but the block type defined in schema has a different name (`{{expectedTypeName}}`) */
  'inputs.portable-text.invalid-value.incorrect-block-type.description': string; /** Action presented when the Portable Text field value is invalid, when block with key `{{key}}` has a span with key `{{childKey}}` that has a missing or invalid `text` property */
  'inputs.portable-text.invalid-value.invalid-span-text.action': string; /** Text explaining that the Portable Text field value is invalid, when block with key `{{key}}` has a span with key `{{childKey}}` that has a missing or invalid `text` property */
  'inputs.portable-text.invalid-value.invalid-span-text.description': string; /** Action presented when the Portable Text field value is invalid, when child with key `{{key}}` is missing a `_type` property, but seems to be a block of type `{{expectedTypeName}}` */
  'inputs.portable-text.invalid-value.missing-block-type.action': string; /** Text explaining that the Portable Text field value is invalid, when child with key `{{key}}` is missing a `_type` property, but seems to be a block of type `{{expectedTypeName}}` */
  'inputs.portable-text.invalid-value.missing-block-type.description': string; /** Action presented when the Portable Text field value is invalid, when block with key `{{key}}` has a child at `{{index}}` which is missing `_key` property */
  'inputs.portable-text.invalid-value.missing-child-key.action': string; /** Text explaining that the Portable Text field value is invalid, when block with key `{{key}}` has a child at `{{index}}` which is missing `_key` property */
  'inputs.portable-text.invalid-value.missing-child-key.description': string; /** Action presented when the Portable Text field value is invalid, when block with key `{{key}}` has a child with key `{{childKey}}` which is missing a `_type` property */
  'inputs.portable-text.invalid-value.missing-child-type.action': string; /** Text explaining that the Portable Text field value is invalid, when block with key `{{key}}` has a child with key `{{childKey}}` which is missing a `_type` property */
  'inputs.portable-text.invalid-value.missing-child-type.description': string; /** Action presented when the Portable Text field value is invalid, when child at `{{index}}` is missing the required `_key` property */
  'inputs.portable-text.invalid-value.missing-key.action': string; /** Text explaining that the Portable Text field value is invalid, when child at `{{index}}` is missing the required `_key` property */
  'inputs.portable-text.invalid-value.missing-key.description': string; /** Action presented when the Portable Text field value is invalid, when child with key `{{key}}` has a missing or invalid `children` property */
  'inputs.portable-text.invalid-value.missing-or-invalid-children.action': string; /** Text explaining that the Portable Text field value is invalid, when child with key `{{key}}` has a missing or invalid `children` property */
  'inputs.portable-text.invalid-value.missing-or-invalid-children.description': string; /** Action presented when the Portable Text field value is invalid, when child with key `{{key}}` has a missing or invalid `markDefs` property */
  'inputs.portable-text.invalid-value.missing-or-invalid-markdefs.action': string; /** Text explaining that the Portable Text field value is invalid, when child with key `{{key}}` has a missing or invalid `markDefs` property */
  'inputs.portable-text.invalid-value.missing-or-invalid-markdefs.description': string; /** Action presented when the Portable Text field value is invalid, when child with key `{{key}}` is missing a `_type` property  */
  'inputs.portable-text.invalid-value.missing-type.action': string; /** Text explaining that the Portable Text field value is invalid, when child with key `{{key}}` is missing a `_type` property  */
  'inputs.portable-text.invalid-value.missing-type.description': string; /** Action presented when the Portable Text field value is invalid, when block with key `{{key}}` contains a non-object child at index `{{index}}` */
  'inputs.portable-text.invalid-value.non-object-child.action': string; /** Text explaining that the Portable Text field value is invalid, when block with key `{{key}}` contains a non-object child at index `{{index}}` */
  'inputs.portable-text.invalid-value.non-object-child.description': string; /** Action presented when the Portable Text field value is invalid, when the Portable Text field is not an array, or the array is empty */
  'inputs.portable-text.invalid-value.not-an-array.action': string; /** Text explaining that the Portable Text field value is invalid, when the Portable Text field is not an array, or the array is empty */
  'inputs.portable-text.invalid-value.not-an-array.description': string; /** Action presented when the Portable Text field value is invalid, when child at `{{index}}` is not an object */
  'inputs.portable-text.invalid-value.not-an-object.action': string; /** Text explaining that the Portable Text field value is invalid, when child at `{{index}}` is not an object */
  'inputs.portable-text.invalid-value.not-an-object.description': string; /** Action presented when the Portable Text field value is invalid, when block with key `{{key}}` contains marks (`{{orphanedMarks}}`) that are not supported by the current schema */
  'inputs.portable-text.invalid-value.orphaned-marks.action': string; /** Text explaining that the Portable Text field value is invalid, when block with key `{{key}}` contains marks (`{{orphanedMarks}}`) that are not supported by the current schema */
  'inputs.portable-text.invalid-value.orphaned-marks.description': string; /** Title for the alert indicating that the Portable Text field has an invalid value */
  'inputs.portable-text.invalid-value.title': string; /** Title of "bulleted" list type */
  'inputs.portable-text.list-type.bullet': string; /** Title of numbered list type */
  'inputs.portable-text.list-type.number': string; /** Title of the "h1" block style */
  'inputs.portable-text.style.h1': string; /** Title of the "h2" block style */
  'inputs.portable-text.style.h2': string; /** Title of the "h3" block style */
  'inputs.portable-text.style.h3': string; /** Title of the "h4" block style */
  'inputs.portable-text.style.h4': string; /** Title of the "h5" block style */
  'inputs.portable-text.style.h5': string; /** Title of the "h6" block style */
  'inputs.portable-text.style.h6': string; /** Title shown when multiple blocks of varying styles is selected */
  'inputs.portable-text.style.multiple': string; /** Title of fallback when no style is given for a block */
  'inputs.portable-text.style.none': string; /** Title of the "normal" block style */
  'inputs.portable-text.style.normal': string; /** Title of the "quote" block style */
  'inputs.portable-text.style.quote': string; /** Label for action to clear the current value of the reference field */
  'inputs.reference.action.clear': string; /** Label for action to copy the current item (used within arrays) */
  'inputs.reference.action.copy': string; /** Label for action to create a new document from the reference input */
  'inputs.reference.action.create-new-document': string; /** Label for action to create a new document from the reference input, when there are multiple templates or document types to choose from */
  'inputs.reference.action.create-new-document-select': string; /** Label for action to duplicate the current item to a new item (used within arrays) */
  'inputs.reference.action.duplicate': string; /** Label for action that opens the referenced document in a new tab */
  'inputs.reference.action.open-in-new-tab': string; /** Label for action to remove the reference from an array */
  'inputs.reference.action.remove': string; /** Label for action to replace the current value of the field */
  'inputs.reference.action.replace': string; /** Label for action to cancel a previously initiated replace action  */
  'inputs.reference.action.replace-cancel': string; /** The cross-dataset reference field currently has a reference, but the feature has been disabled since it was created. This explains what can/cannot be done in its current state. */
  'inputs.reference.cross-dataset.feature-disabled-actions': string; /** A cross-dataset reference field exists but the feature has been disabled. A <DocumentationLink> component is available. */
  'inputs.reference.cross-dataset.feature-disabled-description': string; /** Title for a warning telling the user that the current project does not have the "cross dataset references" feature */
  'inputs.reference.cross-dataset.feature-unavailable-title': string; /** The cross-dataset reference points to a document with an invalid type  */
  'inputs.reference.cross-dataset.invalid-type': string; /** The referenced document will open in a new tab (due to external studio) */
  'inputs.reference.document-opens-in-new-tab': string; /** Error title for when the document is unavailable (for any possible reason) */
  'inputs.reference.error.document-unavailable-title': string; /** Error title for when the referenced document failed to be loaded */
  'inputs.reference.error.failed-to-load-document-title': string; /** Error title for when the reference search returned a document that is not an allowed type for the field */
  'inputs.reference.error.invalid-search-result-type-title': string; /** Error description for when the document referenced is not one of the types declared as allowed target types in schema */
  'inputs.reference.error.invalid-type-description': string; /** Error title for when the document referenced is not one of the types declared as allowed target types in schema */
  'inputs.reference.error.invalid-type-title': string; /** Error description for when the user does not have permissions to read the referenced document */
  'inputs.reference.error.missing-read-permissions-description': string; /** Error title for when the user does not have permissions to read the referenced document */
  'inputs.reference.error.missing-read-permissions-title': string; /** Error description for when the current reference value points to a document that does not exist (on weak references) */
  'inputs.reference.error.nonexistent-document-description': string; /** Error title for when the current reference value points to a document that does not exist (on weak references) */
  'inputs.reference.error.nonexistent-document-title': string; /** Label for button that clears the reference when it points to a document that does not exist (on weak references) */
  'inputs.reference.error.nonexistent-document.clear-button-label': string; /** Error title for when the search for a reference failed. Note that the message sent by the backend may not be localized. */
  'inputs.reference.error.search-failed-title': string; /** Label for when the GDR points to an invalid type  */
  'inputs.reference.global.invalid-type': string; /** Alternative text for the image shown in cross-dataset reference input */
  'inputs.reference.image-preview-alt-text': string; /** Description for alert shown when a reference in a live-edit document is marked as being weak, the referenced document exists, AND the reference is supposed to be have been strengthened on publish */
  'inputs.reference.incomplete-reference.finalize-action-description': string; /** Title for alert shown when a reference in a live-edit document is marked as being weak, the referenced document exists, AND the reference is supposed to be have been strengthened on publish */
  'inputs.reference.incomplete-reference.finalize-action-title': string; /** Description for alert shown when a reference in a live-edit document points to a document that exists and has been published, but the reference is still marked as weak */
  'inputs.reference.incomplete-reference.strengthen-action-description': string; /** Title for alert shown when a reference in a live-edit document points to a document that exists and has been published, but the reference is still marked as weak */
  'inputs.reference.incomplete-reference.strengthen-action-title': string; /** Label for button that triggers the action that strengthen a reference */
  'inputs.reference.incomplete-reference.strengthen-button-label': string; /** Label for button that triggers a retry attempt for reference metadata  */
  'inputs.reference.metadata-error.retry-button-label': string; /** Title for alert shown when reference metadata fails to be loaded */
  'inputs.reference.metadata-error.title': string; /** Message shown when no documents were found that matched the given search string */
  'inputs.reference.no-results-for-query': string; /** Text for tooltip showing when a document was edited, using relative time (eg "how long ago was it edited?") */
  'inputs.reference.preview.edited-at-time': string; /** Accessibility label for icon indicating that document does _not_ have any unpublished changes */
  'inputs.reference.preview.has-no-unpublished-changes-aria-label': string; /** Accessibility label for icon indicating that document has unpublished changes */
  'inputs.reference.preview.has-unpublished-changes-aria-label': string; /** Accessibility label for icon indicating that document does _not_ have a published version */
  'inputs.reference.preview.is-not-published-aria-label': string; /** Accessibility label for icon indicating that document has a published version */
  'inputs.reference.preview.is-published-aria-label': string; /** Text for tooltip indicating that a document has no unpublished edits */
  'inputs.reference.preview.no-unpublished-edits': string; /** Text for tooltip indicating that a document has not yet been published */
  'inputs.reference.preview.not-published': string; /** Text for tooltip showing when a document was published, using relative time (eg "how long ago was it published?") */
  'inputs.reference.preview.published-at-time': string; /** The referenced document no longer exist and might have been deleted (for weak references) */
  'inputs.reference.referenced-document-does-not-exist': string; /** The referenced document could not be displayed to the user because of insufficient permissions */
  'inputs.reference.referenced-document-insufficient-permissions': string; /** Label for when the reference input is resolving the initial value for an item */
  'inputs.reference.resolving-initial-value': string; /** Placeholder shown in a reference input with no current value */
  'inputs.reference.search-placeholder': string; /** Explanation of the consequences of leaving the reference as strong instead of weak */
  'inputs.reference.strength-mismatch.is-strong-consquences': string; /** Description for alert shown when a reference is supposed to be weak, but the actual value is strong */
  'inputs.reference.strength-mismatch.is-strong-description': string; /** Explanation of the consequences of leaving the reference as weak instead of strong */
  'inputs.reference.strength-mismatch.is-weak-consquences': string; /** Description for alert shown when a reference is supposed to be strong, but the actual value is weak */
  'inputs.reference.strength-mismatch.is-weak-description': string; /** Label for button that triggers the action that strengthens a reference on strength mismatch */
  'inputs.reference.strength-mismatch.strengthen-button-label': string; /** Title for alert shown when a reference is supposed to be weak/strong, but the actual value is the opposite of what it is supposed to be */
  'inputs.reference.strength-mismatch.title': string; /** Label for button that triggers the action that weakens a reference on strength mismatch */
  'inputs.reference.strength-mismatch.weaken-button-label': string; /** Label for action to clear the current value of the select field */
  'inputs.select.action.clear': string; /** Action message for generating the slug */
  'inputs.slug.action.generate': string; /** Loading message for when the input is actively generating a slug */
  'inputs.slug.action.generating': string; /** Error message for when the source to generate a slug from is missing */
  'inputs.slug.error.missing-source': string; /** Placeholder for an empty tag input */
  'inputs.tags.placeholder': string; /** Placeholder for an empty tag input on touch devices */
  'inputs.tags.placeholder_touch': string; /** Convert to `{{targetType}}` */
  'inputs.untyped-value.convert-button.text': string; /** Encountered an object value without a <code>_type</code> property. */
  'inputs.untyped-value.description': string; /** Either remove the <code>name</code> property of the object declaration, or set <code>_type</code> property on items. */
  'inputs.untyped-value.details.description': string; /** Current value (<code>object</code>): */
  'inputs.untyped-value.details.json-dump-prefix': string; /** The following types are valid here according to schema: */
  'inputs.untyped-value.details.multi-type-description': string; /** Developer info */
  'inputs.untyped-value.details.title': string; /** Property value missing <code>_type</code> */
  'inputs.untyped-value.title': string; /** Unset value */
  'inputs.untyped-value.unset-item-button.text': string; /** Select video */
  'inputs.video.select-dialog.title': string; /** The fallback explanation if no context is provided */
  'insufficient-permissions-message.not-authorized-explanation': string; /** The explanation when unable to create any document at all */
  'insufficient-permissions-message.not-authorized-explanation_create-any-document': string; /** The explanation when unable to create a particular document */
  'insufficient-permissions-message.not-authorized-explanation_create-document': string; /** The explanation when unable to create a particular type of document */
  'insufficient-permissions-message.not-authorized-explanation_create-document-type': string; /** The explanation when unable to create a new reference in a document */
  'insufficient-permissions-message.not-authorized-explanation_create-new-reference': string; /** The explanation when unable to delete a particular document */
  'insufficient-permissions-message.not-authorized-explanation_delete-document': string; /** The explanation when unable to delete a schedule on scheduled publishing */
  'insufficient-permissions-message.not-authorized-explanation_delete-schedules': string; /** The explanation when unable to discard changes in a particular document */
  'insufficient-permissions-message.not-authorized-explanation_discard-changes': string; /** The explanation when unable to duplicate a particular document */
  'insufficient-permissions-message.not-authorized-explanation_duplicate-document': string; /** The explanation when unable to edit a schedule on scheduled publishing */
  'insufficient-permissions-message.not-authorized-explanation_edit-schedules': string; /** The explanation when unable to execute a schedule on scheduled publishing */
  'insufficient-permissions-message.not-authorized-explanation_execute-schedules': string; /** The explanation when unable to publish a particular document */
  'insufficient-permissions-message.not-authorized-explanation_publish-document': string; /** The explanation when unable to unpublish a particular document */
  'insufficient-permissions-message.not-authorized-explanation_unpublish-document': string; /** Appears after the not-authorized message. Lists the current roles. */
  'insufficient-permissions-message.roles': string; /** The title for the insufficient permissions message component */
  'insufficient-permissions-message.title': string; /** Unexpected error: `{{error}}` */
  'member-field-error.unexpected-error': string; /** Text shown in warning when browser is using HTTP1 to communicate with the Sanity API */
  'network-check.slow-protocol-warning.description': string; /** Text for link that takes the user to the Sanity documentation to learn more about the HTTP1 issue */
  'network-check.slow-protocol-warning.learn-more-button.text': string; /** Text for link that takes the user to the Sanity documentation to learn more about the HTTP1 issue */
  'network-check.slow-protocol-warning.snooze-button.text': string; /** Title text for the warning dialog when browser is using HTTP1 to communicate with the Sanity API */
  'network-check.slow-protocol-warning.title': string; /** Button label for "Create new document" button */
  'new-document.button': string;
  /**
   * Tooltip message displayed when hovering/activating the "Create new document" action,
   * when there are templates/types available for creation
   */
  'new-document.create-new-document-label': string; /** Placeholder for the "filter" input within the new document menu */
  'new-document.filter-placeholder': string; /** Loading indicator text within the new document menu */
  'new-document.loading': string; /** Accessibility label for the list displaying options in the new document menu */
  'new-document.new-document-aria-label': string; /** Message for when there are no document type options in the new document menu */
  'new-document.no-document-types-found': string;
  /**
   * Tooltip message displayed when hovering/activating the "Create new document" action,
   * when there are no templates/types to create from
   */
  'new-document.no-document-types-label': string; /** Message for when no results are found for a specific search query in the new document menu */
  'new-document.no-results': string; /** Aria label for the button that opens the "Create new document" popover/dialog */
  'new-document.open-dialog-aria-label': string; /** Title for "Create new document" dialog */
  'new-document.title': string; /** @deprecated Label for button that will make the browser reload when users' studio version is out-of-date */
  'package-version.new-package-available.reload-button': string; /** @deprecated Title of the alert for studio users when packages in their studio are out-of-date */
  'package-version.new-package-available.title': string; /** Label for action to invite members to the current studio project */
  'presence.action.manage-members': string; /** Accessibility label for presence menu button */
  'presence.aria-label': string; /** Message description for when no one else is currently present */
  'presence.no-one-else-description': string; /** Message title for when no one else is currently present */
  'presence.no-one-else-title': string; /** Message for when a user is not in a document (displayed in the global presence menu) */
  'presence.not-in-a-document': string; /** Tooltip content text for presence menu button */
  'presence.tooltip-content': string; /** Fallback title shown when a preview does not provide a title */
  'preview.default.title-fallback': string; /** Fallback preview value for types that have "no value" (eg null, undefined) */
  'preview.fallback.no-value': string; /** Alternative text for image being shown while image is being uploaded, in previews */
  'preview.image.file-is-being-uploaded.alt-text': string;
  'relative-time.just-now': string; /** Action message to add document to new release */
  'release.action.add-to-new-release': string; /** Action message to add document to release */
  'release.action.add-to-release': string; /** Tooltip message for document that is already added to release */
  'release.action.already-exists-in-release': string; /** Action message for when document is already in release  */
  'release.action.already-in-release': string; /** Action message for when you click to view all versions you can copy the current document to */
  'release.action.copy-to': string; /** Action message for creating new releases */
  'release.action.create-new': string; /** Description for toast when version creation failed */
  'release.action.create-version.failure': string; /** Action message for deleting a scheduled publish */
  'release.action.delete-schedule': string; /** Action message for when document is already in release  */
  'release.action.discard-version': string; /** Description for toast when version discarding failed */
  'release.action.discard-version.failure': string; /** Action message for editing the schedule of a scheduled publish */
  'release.action.edit-schedule': string; /** Action message for when a new release is created off an existing version, draft or published document */
  'release.action.new-release': string; /** Explanation provided when releases can't be created because the workspace release limit has been reached */
  'release.action.new-release.limit-reached': string;
  'release.action.new-release.limit-reached_other': string; /** Tooltip message for not having permissions for creating new releases */
  'release.action.permission.error': string; /** Action message for running a scheduled draft immediately */
  'release.action.publish-now': string; /** Error message description for when a version is reverted from being unpublished */
  'release.action.revert-unpublish-version.failure.description': string; /** Error message title for when a version is reverted from being unpublished */
  'release.action.revert-unpublish-version.failure.title': string; /** Action message description for when a version is reverted from being unpublished */
  'release.action.revert-unpublish-version.success.description': string; /** Action message title for when a version is reverted from being unpublished */
  'release.action.revert-unpublish-version.success.title': string; /** Action message for scheduling a paused draft */
  'release.action.schedule-publish': string; /** Error message for when a version is set to be unpublished */
  'release.action.unpublish-version.failure': string; /** Action message for when a version is set to be unpublished successfully */
  'release.action.unpublish-version.success': string; /** Action message for when the view release is pressed */
  'release.action.view-release': string; /** Action message for when the view scheduled drafts is pressed */
  'release.action.view-scheduled-drafts': string; /** Label for banner when release is scheduled */
  'release.banner.scheduled-for-publishing-on': string;
  'release.chip.button.other-versions_one': string;
  'release.chip.button.other-versions_other': string; /** Label for Draft chip in document header */
  'release.chip.draft': string; /** Label for Draft chip in global header */
  'release.chip.global.drafts': string; /** Label for Published chip in document header */
  'release.chip.published': string; /** Label for tooltip in chip when document is in an archived release */
  'release.chip.tooltip.archived': string; /** Label for tooltip in chip with the created date */
  'release.chip.tooltip.created-date': string; /** Label for tooltip in draft chip when it's a live edit document */
  'release.chip.tooltip.draft-disabled.live-edit': string; /** Label for tooltip in chip with the lasted edited date */
  'release.chip.tooltip.edited-date': string; /** Label for tooltip in chip when document is intended for a future release that hasn't been scheduled */
  'release.chip.tooltip.intended-for-date': string; /** Label for tooltip in chip when there is no recent draft edits */
  'release.chip.tooltip.no-edits': string; /** Label for tooltip in chip when document isn't published */
  'release.chip.tooltip.not-published': string;
  'release.chip.tooltip.other-versions_one': string;
  'release.chip.tooltip.other-versions_other': string; /** Label for tooltip in chip with the published date */
  'release.chip.tooltip.published-date': string; /** Label for tooltip in chip when document is in a release that has been scheduled */
  'release.chip.tooltip.scheduled-for-date': string; /** Label for tooltip in scheduled chip without a known date */
  'release.chip.tooltip.unknown-date': string; /** Label for tooltip on deleted release */
  'release.deleted-tooltip': string; /** Title for copying version to a new release dialog */
  'release.dialog.copy-to-release.title': string; /** Title for action create a release */
  'release.dialog.create.confirm': string; /** Title for creating releases dialog */
  'release.dialog.create.title': string; /** Body text when deleting scheduled draft and draft is already up to date */
  'release.dialog.delete-schedule-draft.body-already-current': string; /** Body text when deleting scheduled draft and changes will be saved to draft */
  'release.dialog.delete-schedule-draft.body-will-save-to-draft': string; /** Body text when deleting scheduled draft with checkbox shown for user choice */
  'release.dialog.delete-schedule-draft.body-with-choice': string; /** Confirm button text for deleting a scheduled draft */
  'release.dialog.delete-schedule-draft.confirm': string; /** Checkbox label for copying scheduled draft to draft before deletion */
  'release.dialog.delete-schedule-draft.copy-checkbox': string; /** Explanation text shown when scheduled draft has different changes than current draft */
  'release.dialog.delete-schedule-draft.different-changes-explanation': string; /** Header for the dialog confirming deletion of a scheduled draft */
  'release.dialog.delete-schedule-draft.header': string; /** Body text for change schedule dialog */
  'release.dialog.edit-schedule.body': string; /** Confirm button text for change schedule dialog */
  'release.dialog.edit-schedule.confirm': string; /** Header for change schedule dialog */
  'release.dialog.edit-schedule.header': string; /** Body text for the dialog confirming running a scheduled draft immediately */
  'release.dialog.publish-scheduled-draft.body': string; /** Confirm button text for running a scheduled draft immediately */
  'release.dialog.publish-scheduled-draft.confirm': string; /** Header for the dialog confirming running a scheduled draft immediately */
  'release.dialog.publish-scheduled-draft.header': string; /** Label for description in tooltip to explain release types */
  'release.dialog.tooltip.description': string; /** Label for noting that a release time is not final */
  'release.dialog.tooltip.note': string; /** Title for tooltip to explain release time */
  'release.dialog.tooltip.title': string; /** The placeholder text when the release doesn't have a description */
  'release.form.placeholder-describe-release': string; /** Tooltip for button to hide release visibility */
  'release.layer.hide': string; /** Label for the release menu */
  'release.menu.label': string; /** Menu item label for scheduled drafts */
  'release.menu.scheduled-drafts': string; /** Tooltip for the release menu */
  'release.menu.tooltip': string; /** Menu item label for viewing content releases */
  'release.menu.view-releases': string; /** Label for draft perspective in navbar */
  'release.navbar.drafts': string; /** Label for published releases in navbar */
  'release.navbar.published': string; /** Tooltip for releases navigation in navbar */
  'release.navbar.tooltip': string; /** The placeholder text when the release doesn't have a title */
  'release.placeholder-untitled-release': string; /** Description for warning that the published schedule time is in the past */
  'release.schedule-dialog.publish-date-in-past-warning': string; /** Label for date picker when scheduling a release */
  'release.schedule-dialog.select-publish-date-label': string;
  /** The toast description that will be shown when the user has a release perspective which is now archived
   * @deprecated – no longer needed
   * */
  'release.toast.archived-release.description': string;
  /** The toast title that will be shown when the user has a release perspective which is now archived
   * @deprecated – no longer needed
   * */
  'release.toast.archived-release.title': string; /** The toast title that will be shown the creating a release fails */
  'release.toast.create-release-error.title': string; /** Error toast for deleting a scheduled draft */
  'release.toast.delete-schedule-draft.error': string; /** Success toast for deleting a scheduled draft */
  'release.toast.delete-schedule-draft.success': string;
  /** The toast title that will be shown when the user has a release perspective which is now deleted
   * @deprecated – no longer needed
   * */
  'release.toast.not-found-release.title': string; /** Error toast for pausing a scheduled draft */
  'release.toast.pause-scheduled-draft.error': string; /** Error toast for running a scheduled publish immediately */
  'release.toast.publish-scheduled-draft.error': string; /** Success toast for running a scheduled publish immediately */
  'release.toast.publish-scheduled-draft.success': string;
  /** The toast description that will be shown when the user has a release perspective which is now published
   * @deprecated – no longer needed
   **/
  'release.toast.published-release.description': string;
  /** The toast title that will be shown when the user has a release perspective which is now deleted
   * @deprecated – no longer needed
   **/
  'release.toast.published-release.title': string; /** Error toast for rescheduling a draft */
  'release.toast.reschedule-scheduled-draft.error': string; /** Success toast for rescheduling a draft */
  'release.toast.reschedule-scheduled-draft.success': string; /** Error toast for scheduling a paused draft */
  'release.toast.schedule-publish.error': string; /** Success toast for scheduling a paused draft */
  'release.toast.schedule-publish.success': string;
  /** The toast title that will be shown when the user has a scheduled draft perspective which is now published
   * @deprecated – no longer needed
   * */
  'release.toast.scheduled-draft-published.title': string; /** Label for when a version of a document has already been added to the release */
  'release.tooltip.already-added': string; /** Label for when a release is scheduled / scheduling and a user can't add a document version to it */
  'release.tooltip.locked': string; /** Label for the release type 'as soon as possible' */
  'release.type.asap': string; /** Label for the release type 'at time', meaning it's a release with a scheduled date */
  'release.type.scheduled': string; /** Label for the release type 'undecided' */
  'release.type.undecided': string; /** Tooltip for the dropdown to show all versions of document */
  'release.version-list.tooltip': string; /** Button text for contacting support in the releases misconfiguration dialog */
  'releases.upsell.misconfiguration.contact-support': string; /** Header for the releases misconfiguration dialog */
  'releases.upsell.misconfiguration.header': string; /** Message shown in the releases misconfiguration dialog */
  'releases.upsell.misconfiguration.message': string; /** Confirm button text for the schedule publish dialog */
  'schedule-publish-dialog.confirm': string; /** Description for the schedule publish dialog */
  'schedule-publish-dialog.description': string; /** Header for the schedule publish dialog */
  'schedule-publish-dialog.header': string; /** Title for a scheduled draft release */
  'scheduled-drafts.release.title': string; /** Accessibility label to open search action when the search would go fullscreen (eg on narrower screens) */
  'search.action-open-aria-label': string; /** Action label for adding a search filter */
  'search.action.add-filter': string; /** Action label for clearing search filters */
  'search.action.clear-filters': string; /** Label for action to clear recent searches */
  'search.action.clear-recent-searches': string; /** Accessibility label for action to clear all currently applied document type filters */
  'search.action.clear-type-filters-aria-label': string; /** Label for action to clear all currently applied document type filters */
  'search.action.clear-type-filters-label': string; /** Accessibility label for when the search is full screen (on narrow screens) and you want to close the search */
  'search.action.close-search-aria-label': string; /** Accessibility label for filtering by document type */
  'search.action.filter-by-document-type-aria-label': string; /** Accessibility action label for removing an already applied search filter */
  'search.action.remove-filter-aria-label': string;
  /**
   * Text displayed when either no document type(s) have been selected, or we need a fallback,
   * eg "Search for all types".
   */
  'search.action.search-all-types': string;
  /**
   * Text displayed when we are able to determine one or more document types that will be used for
   * searching, and can fit within the space assigned by the design.
   */
  'search.action.search-specific-types': string;
  /**
   * Text displayed when we are able to determine one or more document types that will be used for
   * searching, but cannot list them all within the space assigned by the design, so we need an
   * additional "and X more" suffix. Allows using pluralization suffixes, eg `_one`, `_other` etc.
   */
  'search.action.search-specific-types-truncated': string; /** Dialog title for action to select an asset of unknown type */
  'search.action.select-asset': string; /** Dialog title for action to select a file asset */
  'search.action.select-asset_file': string; /** Dialog title for action to select an image asset */
  'search.action.select-asset_image': string; /** Accessibility label for when the search is full screen (on narrow screens) and you want to hide filters */
  'search.action.toggle-filters-aria-label_hide': string; /** Accessibility label for when the search is full screen (on narrow screens) and you want to show filters */
  'search.action.toggle-filters-aria-label_show': string; /** Label for when the search is full screen (on narrow screens) and you want to hide filters */
  'search.action.toggle-filters-label_hide': string; /** Label for when the search is full screen (on narrow screens) and you want to show filters */
  'search.action.toggle-filters-label_show': string; /** Tooltip text for the global search button */
  'search.button.tooltip': string;
  /**
   * A list of provided types (use `list` formatter preferably).
   */
  'search.document-type-list': string;
  /**
   * In the context of a list of document types - no filtering selection has been done,
   * thus the default is "all types".
   */
  'search.document-type-list-all-types': string;
  /**
   * A list of provided types that has been truncated - more types are included but not displayed,
   * thus we need to indicate that there are more. Allows using pluralization suffixes,
   * eg `_one`, `_other` etc.
   */
  'search.document-type-list-truncated': string; /** Accessibility label for list displaying the available document types */
  'search.document-types-aria-label': string; /** Label for when no document types matching the filter are found */
  'search.document-types-no-matches-found': string; /** Description for error when a filter cannot be displayed, describes that you should check the schema */
  'search.error.display-filter-description': string; /** Title for error when a filter cannot be displayed (mainly a developer-oriented error) */
  'search.error.display-filter-title': string; /** Description for error when no valid asset source is found, describes that you should check the the current studio config */
  'search.error.no-valid-asset-source-check-config-description': string; /** Description for error when no valid asset source is found, describes that only the default asset is supported */
  'search.error.no-valid-asset-source-only-default-description': string; /** Title for error when no valid asset sources found */
  'search.error.no-valid-asset-source-title': string; /** Helpful description for when search returned an error that we are not able to describe in detail */
  'search.error.unspecified-error-help-description': string; /** Title label for when search returned an error that we are not able to describe in detail */
  'search.error.unspecified-error-title': string;
  /**
   * Label for "All fields", a label that appears above the list of available fields when filtering.
   * If one or more document type has been chosen as filter, this label is replaced with a group of
   * fields per selected document type
   */
  'search.filter-all-fields-header': string; /** Label for the action of changing from one file to a different file in asset search filter */
  'search.filter-asset-change_file': string; /** Label for the action of changing from one image to a different image in asset search filter */
  'search.filter-asset-change_image': string; /** Label for the action of clearing the currently selected asset in an image/file filter */
  'search.filter-asset-clear': string; /** Label for the action of selecting a file in asset search filter */
  'search.filter-asset-select_file': string; /** Label for the action of selecting an image in asset search filter */
  'search.filter-asset-select_image': string; /** Label for boolean filter - false */
  'search.filter-boolean-false': string; /** Label for boolean filter - true */
  'search.filter-boolean-true': string; /** Accessibility label for list that lets you filter fields by title, when adding a new filter in search */
  'search.filter-by-title-aria-label': string; /** Accessibility label for date filter input */
  'search.filter-date-aria-label': string; /** Accessibility label for selecting end date on the date range search filter */
  'search.filter-date-range-end-date-aria-label': string; /** Accessibility label for selecting start date on the date range search filter */
  'search.filter-date-range-start-date-aria-label': string; /** Accessibility label for selecting the unit (day/month/year) when adding "X days ago" search filter */
  'search.filter-date-unit-aria-label': string;
  /**
   * Label for "Days"/"Months"/"Years" when selecting it as unit in "X days ago" search filter.
   * Capitalized, as it would be listed in a dropdown.
   */
  'search.filter-date-unit_days': string;
  'search.filter-date-unit_months': string;
  'search.filter-date-unit_years': string; /** Accessibility label for the input value (days/months/years) when adding "X days ago" search filter */
  'search.filter-date-value-aria-label': string; /** Label for "field description" shown in tooltip when navigating list of possible fields to filter */
  'search.filter-field-tooltip-description': string; /** Label for "field name" shown in tooltip when navigating list of possible fields to filter */
  'search.filter-field-tooltip-name': string; /** Label for "Used in document types", a list of the document types a field appears in. Shown in tooltip when navigating list of possible fields to filter */
  'search.filter-field-tooltip-used-in-document-types': string; /** Label for when no fields/filters are found for the given term */
  'search.filter-no-matches-found': string; /** Placeholder value for maximum numeric value filter */
  'search.filter-number-max-value-placeholder': string; /** Placeholder value for minimum numeric value filter */
  'search.filter-number-min-value-placeholder': string; /** Placeholder value for the number filter */
  'search.filter-number-value-placeholder': string; /** Placeholder for the "Filter" input, when narrowing possible fields/filters */
  'search.filter-placeholder': string; /** Label for the action of clearing the currently selected document in a reference filter */
  'search.filter-reference-clear': string;
  /**
   * Label for "shared fields", a label that appears above a list of fields that all filtered types
   * have in common, when adding a new filter. For instance, if "book" and "employee" both have a
   * "title" field, this field would be listed under "shared fields".
   * */
  'search.filter-shared-fields-header': string; /** Placeholder value for the string filter */
  'search.filter-string-value-placeholder': string; /** Label/placeholder prompting user to select one of the predefined, allowed values for a string field */
  'search.filter-string-value-select-predefined-value': string; /** Accessibility label for the "Filters" list, that is shown when using "Add filter" in search (singular) */
  'search.filters-aria-label_one': string; /** Accessibility label for the "Filters" list, that is shown when using "Add filter" in search (plural) */
  'search.filters-aria-label_other': string; /** Label for instructions on how to use the search - displayed when no recent searches are available */
  'search.instructions': string; /** Helpful description for when no search results are found */
  'search.no-results-help-description': string; /** Title label for when no search results are found */
  'search.no-results-title': string;
  /**
   * Individual search operators.
   *
   * The `name` variant is the form we use when the user is building a query, and selecting from a
   * list of available operators for a field. Keep in mind that since the user knows what the field
   * represents, we do not need to contextualize too much, and that the user may not be a developer
   * eg prefer "quantity is" over "array has length". Additionally, (if applicable in language) use
   * lowercased names.
   *
   * The `description` variant is the form shown once the filter has enough information to apply,
   * and is shown in the list of applied filters. It is passed components that _should_ be used to
   * compose the filter string, and to format them correctly:
   *
   * `<Field/>` - eg "Bird species", "Category", "Date of birth"
   * `<Operator>operator text</Operator>` - eg "has ≤", "includes", "is"
   * `<Value>{{value}}</Value>` - eg "Hawk", "Sparrow", "Eagle"
   *
   * Where applicable, a `count` is passed, allowing you to pluralize where needed, by using
   * suffixes such as `_zero`, `_one`, `_other` etc.
   *
   * Prefer (reasonable) brevity since many filters may be applied. For instance:
   * `<Field/> has ≤ <Value/>` may be better than
   * `<Field/> has less than or equal to <Value/>`
   **/
  'search.operator.array-count-equal.description_one': string;
  'search.operator.array-count-equal.description_other': string;
  'search.operator.array-count-equal.name': string;
  'search.operator.array-count-gt.description_one': string;
  'search.operator.array-count-gt.description_other': string;
  'search.operator.array-count-gt.name': string;
  'search.operator.array-count-gte.description_one': string;
  'search.operator.array-count-gte.description_other': string;
  'search.operator.array-count-gte.name': string;
  'search.operator.array-count-lt.description_one': string;
  'search.operator.array-count-lt.description_other': string;
  'search.operator.array-count-lt.name': string;
  'search.operator.array-count-lte.description_one': string;
  'search.operator.array-count-lte.description_other': string;
  'search.operator.array-count-lte.name': string;
  'search.operator.array-count-not-equal.description_one': string;
  'search.operator.array-count-not-equal.description_other': string;
  'search.operator.array-count-not-equal.name': string;
  /**
   * Array should have a count within the range of given filter values.
   * Gets passed `{{from}}` and `{{to}}` values.
   **/
  'search.operator.array-count-range.description': string;
  'search.operator.array-count-range.name': string;
  'search.operator.array-list-includes.description': string;
  'search.operator.array-list-includes.name': string;
  'search.operator.array-list-not-includes.description': string;
  'search.operator.array-list-not-includes.name': string;
  'search.operator.array-reference-includes.description': string;
  'search.operator.array-reference-includes.name': string;
  'search.operator.array-reference-not-includes.description': string;
  'search.operator.array-reference-not-includes.name': string;
  'search.operator.asset-file-equal.description': string;
  'search.operator.asset-file-equal.name': string;
  'search.operator.asset-file-not-equal.description': string;
  'search.operator.asset-file-not-equal.name': string;
  'search.operator.asset-image-equal.description': string;
  'search.operator.asset-image-equal.name': string;
  'search.operator.asset-image-not-equal.description': string;
  'search.operator.asset-image-not-equal.name': string;
  /**
   * Boolean value should be the given filter value (true/false).
   * Context passed is `true` and `false`, allowing for more specific translations:
   * - `search.operator.boolean-equal.description_true`
   * - `search.operator.boolean-equal.description_false`
   */
  'search.operator.boolean-equal.description': string;
  'search.operator.boolean-equal.name': string;
  'search.operator.date-after.description': string;
  'search.operator.date-after.name': string;
  'search.operator.date-before.description': string;
  'search.operator.date-before.name': string;
  'search.operator.date-equal.description': string;
  'search.operator.date-equal.name': string;
  'search.operator.date-last.description': string;
  'search.operator.date-last.name': string;
  'search.operator.date-not-equal.description': string;
  'search.operator.date-not-equal.name': string;
  'search.operator.date-range.description': string;
  'search.operator.date-range.name': string;
  'search.operator.date-time-after.description': string;
  'search.operator.date-time-after.name': string;
  'search.operator.date-time-before.description': string;
  'search.operator.date-time-before.name': string;
  'search.operator.date-time-equal.description': string;
  'search.operator.date-time-equal.name': string;
  'search.operator.date-time-last.description': string;
  'search.operator.date-time-last.name': string;
  'search.operator.date-time-not-equal.description': string;
  'search.operator.date-time-not-equal.name': string;
  'search.operator.date-time-range.description': string;
  'search.operator.date-time-range.name': string;
  'search.operator.defined.description': string;
  'search.operator.defined.name': string;
  'search.operator.not-defined.description': string;
  'search.operator.not-defined.name': string;
  'search.operator.number-equal.description': string;
  'search.operator.number-equal.name': string;
  'search.operator.number-gt.description': string;
  'search.operator.number-gt.name': string;
  'search.operator.number-gte.description': string;
  'search.operator.number-gte.name': string;
  'search.operator.number-lt.description': string;
  'search.operator.number-lt.name': string;
  'search.operator.number-lte.description': string;
  'search.operator.number-lte.name': string;
  'search.operator.number-not-equal.description': string;
  'search.operator.number-not-equal.name': string;
  'search.operator.number-range.description': string;
  'search.operator.number-range.name': string;
  'search.operator.portable-text-contains.description': string;
  'search.operator.portable-text-contains.name': string;
  'search.operator.portable-text-equal.description': string;
  'search.operator.portable-text-equal.name': string;
  'search.operator.portable-text-not-contains.description': string;
  'search.operator.portable-text-not-contains.name': string;
  'search.operator.portable-text-not-equal.description': string;
  'search.operator.portable-text-not-equal.name': string;
  'search.operator.reference-asset-file.description': string;
  'search.operator.reference-asset-file.name': string;
  'search.operator.reference-asset-image.description': string;
  'search.operator.reference-asset-image.name': string;
  'search.operator.reference-document.description': string;
  'search.operator.reference-document.name': string;
  'search.operator.reference-equal.description': string;
  'search.operator.reference-equal.name': string;
  'search.operator.reference-not-equal.description': string;
  'search.operator.reference-not-equal.name': string;
  'search.operator.slug-contains.description': string;
  'search.operator.slug-contains.name': string;
  'search.operator.slug-equal.description': string;
  'search.operator.slug-equal.name': string;
  'search.operator.slug-not-contains.description': string;
  'search.operator.slug-not-contains.name': string;
  'search.operator.slug-not-equal.description': string;
  'search.operator.slug-not-equal.name': string;
  'search.operator.string-contains.description': string;
  'search.operator.string-contains.name': string;
  'search.operator.string-equal.description': string;
  'search.operator.string-equal.name': string;
  'search.operator.string-list-equal.description': string;
  'search.operator.string-list-equal.name': string;
  'search.operator.string-list-not-equal.description': string;
  'search.operator.string-list-not-equal.name': string;
  'search.operator.string-not-contains.description': string;
  'search.operator.string-not-contains.name': string;
  'search.operator.string-not-equal.description': string;
  'search.operator.string-not-equal.name': string; /** Label for the "Best match" search ordering type */
  'search.ordering.best-match-label': string; /** Label for the "Created: Oldest first" search ordering type */
  'search.ordering.created-ascending-label': string; /** Label for the "Created: Newest first" search ordering type */
  'search.ordering.created-descending-label': string; /** Label for the "Updated: Oldest first" search ordering type */
  'search.ordering.updated-ascending-label': string; /** Label for the "Updated: Newest first" search ordering type */
  'search.ordering.updated-descending-label': string; /** Placeholder text for the global search input field */
  'search.placeholder': string; /** Accessibility label for the recent searches section, shown when no valid search terms has been given */
  'search.recent-searches-aria-label': string; /** Label/heading shown for the recent searches section */
  'search.recent-searches-label': string; /** Accessibility label for the search results section, shown when the user has typed valid terms */
  'search.search-results-aria-label': string; /** Label for the edit columns button to change field visibility in sheet list */
  'sheet-list.edit-columns': string; /** Label for the header menu option to hide a field from the sheet list */
  'sheet-list.hide-field': string; /** Label for reset column visibilities button */
  'sheet-list.reset-columns': string; /** Title for the edit columns menu */
  'sheet-list.select-fields': string; /** Accessibility label for the navbar status button */
  'status-button.aria-label': string;
  'time-zone.action.search-for-timezone-placeholder': string;
  'time-zone.action.select-local-time-zone': string;
  'time-zone.dialog-info.content-releases': string;
  'time-zone.dialog-info.input': string;
  'time-zone.dialog-info.scheduled-publishing': string;
  'time-zone.local-time': string;
  'time-zone.time-zone': string;
  'time-zone.time-zone-tooltip-content-releases': string;
  'time-zone.time-zone-tooltip-input': string;
  'time-zone.time-zone-tooltip-scheduled-publishing': string; /** Title for the changes tooltip in the history inspector*/
  'timeline.changes.title': string; /** Description for error when the timeline for the given document can't be loaded */
  'timeline.error.load-document-changes-description': string; /** Title for error when the timeline for the given document can't be loaded */
  'timeline.error.load-document-changes-title': string; /** Description for error when the timeline for the given document can't be loaded */
  'timeline.error.load-document-changes-version-description': string; /** Title for error when the timeline for the given version document can't be loaded */
  'timeline.error.load-document-changes-version-title': string; /** Error description for when the document doesn't have history */
  'timeline.error.no-document-history-description': string; /** Error title for when the document doesn't have history */
  'timeline.error.no-document-history-title': string; /** Error prompt when revision cannot be loaded */
  'timeline.error.unable-to-load-revision': string; /** Label for when the timeline item is the latest in the history */
  'timeline.latest': string; /** Label for latest revision for timeline menu dropdown */
  'timeline.latest-revision': string;
  /**
   * Label for latest revision for timeline menu dropdown
   * @deprecated as of `v3.47.0` `timeline.latest-revision` should be used instead. Note: _usage_ of this key is deprecated, but Studios on `< v3.47.0` still require this key to be _defined_
   * */
  'timeline.latest-version': string; /** The aria-label for the list of revisions in the timeline */
  'timeline.list.aria-label': string; /** Label for loading history */
  'timeline.loading-history': string;
  'timeline.no-previous-events': string; /** Label shown in review changes timeline when a document has been created */
  'timeline.operation.created': string; /** Label shown in review changes timeline when a document was initially created */
  'timeline.operation.created-initial': string; /** Label shown in review changes timeline when a document was initially created, with a timestamp */
  'timeline.operation.created-initial_timestamp': string; /** Label shown in review changes timeline when a document has been created, with a timestamp */
  'timeline.operation.created_timestamp': string; /** Label shown in review changes timeline when a document has been deleted */
  'timeline.operation.deleted': string; /** Label shown in review changes timeline when a document has been deleted, with a timestamp */
  'timeline.operation.deleted_timestamp': string; /** Label shown in review changes timeline when a draft document has been created*/
  'timeline.operation.draft-created': string; /** Label shown in review changes timeline when a draft document has been created, with a timestamp */
  'timeline.operation.draft-created_timestamp': string; /** Label shown in review changes timeline when a draft has been discarded */
  'timeline.operation.draft-discarded': string; /** Label shown in review changes timeline when a draft has been discarded, with a timestamp */
  'timeline.operation.draft-discarded_timestamp': string; /** Label shown in review changes timeline when a draft has been edited */
  'timeline.operation.edited-draft': string; /** Label shown in review changes timeline when a draft has been edited, with a timestamp */
  'timeline.operation.edited-draft_timestamp': string; /** Label shown in review changes timeline when a document has been edited live */
  'timeline.operation.edited-live': string; /** Label shown in review changes timeline when a document has been edited live, with a timestamp */
  'timeline.operation.edited-live_timestamp': string; /** Label shown in review changes timeline event when transactions have been deleted by retention policy */
  'timeline.operation.history-cleared': string; /** Label shown in review changes timeline when a document was published */
  'timeline.operation.published': string; /** Label shown in review changes timeline when a document was published, with a timestamp */
  'timeline.operation.published_timestamp': string; /** Label shown in review changes timeline when a document was unpublished */
  'timeline.operation.unpublished': string; /** Label shown in review changes timeline when a document was unpublished, with a timestamp */
  'timeline.operation.unpublished_timestamp': string; /** Label shown in review changes timeline when a document version has been created */
  'timeline.operation.version-created': string; /** Label shown in review changes timeline when a document version has been created, with a timestamp */
  'timeline.operation.version-created_timestamp': string; /** Label shown in review changes timeline when a document version has been discarded */
  'timeline.operation.version-discarded': string; /** Label shown in review changes timeline when a document version has been discarded, with a timestamp */
  'timeline.operation.version-discarded_timestamp': string;
  /**
   * Label for determining since which version the changes for timeline menu dropdown are showing.
   * Receives the time label as a parameter (`timestamp`).
   */
  'timeline.since': string; /** Label for missing change version for timeline menu dropdown are showing */
  'timeline.since-version-missing': string; /** Aria label for the action buttons in the PTE toolbar */
  'toolbar.portable-text.action-button-aria-label': string; /** Accessibility label for the breadcrumb menu */
  'tree-editing-dialog.breadcrumbs.menu': string; /** Title placeholder for search input in array of objects */
  'tree-editing-dialog.search-placeholder': string; /** Menu aria label for the search menu */
  'tree-editing-dialog.search.menu-label': string; /** Title label for when no search results are found on the tree of objects */
  'tree-editing-dialog.search.no-results-title': string; /** Label to close the sidebar */
  'tree-editing-dialog.sidebar.action.close': string; /** Collapse label the menu item in the sidebar  */
  'tree-editing-dialog.sidebar.action.collapse': string; /** Label to close the dialog */
  'tree-editing-dialog.sidebar.action.done': string; /** Exapnd label the menu item in the sidebar  */
  'tree-editing-dialog.sidebar.action.expand': string; /** Label to open the sidebar */
  'tree-editing-dialog.sidebar.action.open': string; /** Label for the button showed after trial ended */
  'user-menu.action.free-trial-finished': string; /** Label for button showing the free trial days left */
  'user-menu.action.free-trial_one': string;
  'user-menu.action.free-trial_other': string; /** Label for action to invite members to the current sanity project */
  'user-menu.action.invite-members': string; /** Accessibility label for action to invite members to the current sanity project */
  'user-menu.action.invite-members-aria-label': string; /** Label for action to manage the current sanity project */
  'user-menu.action.manage-project': string; /** Accessibility label for the action to manage the current project */
  'user-menu.action.manage-project-aria-label': string; /** Tooltip helper text when portable text annotation is disabled for empty block*/
  'user-menu.action.portable-text.annotation-disabled_empty-block': string; /** Tooltip helper text when portable text annotation is disabled for multiple blocks */
  'user-menu.action.portable-text.annotation-disabled_multiple-blocks': string; /** Label for action to sign out of the current sanity project */
  'user-menu.action.sign-out': string; /** Title for appearance section for the current studio (dark / light / system scheme) */
  'user-menu.appearance-title': string; /** Label for close menu button for user menu */
  'user-menu.close-menu': string; /** Description for using the "dark theme" in the appearance user menu */
  'user-menu.color-scheme.dark-description': string; /** Title for using the "dark theme" in the appearance user menu */
  'user-menu.color-scheme.dark-title': string; /** Description for using the "light theme" in the appearance user menu */
  'user-menu.color-scheme.light-description': string; /** Title for using the "light theme" in the appearance user menu */
  'user-menu.color-scheme.light-title': string; /** Description for using "system apparence" in the appearance user menu */
  'user-menu.color-scheme.system-description': string; /** Title for using system apparence in the appearance user menu */
  'user-menu.color-scheme.system-title': string; /** Title for locale section for the current studio */
  'user-menu.locale-title': string; /** Label for tooltip to show which provider the currently logged in user is using */
  'user-menu.login-provider': string; /** Label for open menu button for user menu */
  'user-menu.open-menu': string; /** Label for other users' agent bundle versions */
  'version.agent-bundle.agent-changes': string; /** Label for the current user's agent bundle versions */
  'version.agent-bundle.proposed-changes': string;
  /**
   * Label for action to add a workspace (currently a developer-oriented action, as this will
   * lead to the documentation on workspace configuration)
   */
  'workspaces.action.add-workspace': string;
  /**
   * Label for action to choose a different workspace, in the case where you are not logged in,
   * have selected a workspace, and are faced with the authentication options for the selected
   * workspace. In other words, label for the action shown when you have reconsidered which
   * workspace to authenticate in.
   */
  'workspaces.action.choose-another-workspace': string; /** Label for title to switch workspace before workspaces are listed */
  'workspaces.action.switch-workspace': string; /** Label for heading that indicates that you can choose your workspace */
  'workspaces.choose-your-workspace-label': string; /** Label for the workspace menu */
  'workspaces.select-workspace-aria-label': string; /** Button label for opening the workspace switcher */
  'workspaces.select-workspace-label': string; /** Tooltip for the workspace menu */
  'workspaces.select-workspace-tooltip': string; /** Title for Workplaces dropdown menu */
  'workspaces.title': string;
};
/**
 * The i18n resource keys for the studio.
 *
 * @alpha
 * @hidden
 */
type StudioLocaleResourceKeys = keyof typeof studioLocaleStrings;
/**
 * The string resources for validation.
 *
 * @internal
 * @hidden
 */
declare const validationLocaleStrings: {
  /** Array must have exactly "$wantedLength" items, but has more/less */readonly 'array.exact-length': "Must have exactly {{wantedLength}} items"; /** Portable Text array must have exactly "$wantedLength" blocks, but has more/less */
  readonly 'array.exact-length_blocks': "Must have exactly {{wantedLength}} blocks"; /** Array item is a duplicate, but array wants only unique items */
  readonly 'array.item-duplicate': "Can't be a duplicate"; /** Array has more than the maximum of "$maxLength" items */
  readonly 'array.maximum-length': "Must have at most {{maxLength}} items"; /** Portable Text array has more than the maximum of "$maxLength" items */
  readonly 'array.maximum-length_blocks': "Must have at most {{maxLength}} blocks"; /** Array has less than the minimum of "$minLength" items */
  readonly 'array.minimum-length': "Must have at least {{minLength}} items"; /** Portable Text array has less than the minimum of "$minLength" blocks */
  readonly 'array.minimum-length_blocks': "Must have at least {{minLength}} blocks"; /** Date is not valid or not in the correct format (ISO-8601) */
  readonly 'date.invalid-format': "Must be a valid ISO-8601 formatted date string"; /** Date is later than the given maximum date "$maxDate" */
  readonly 'date.maximum': "Must be at or before {{maxDate}}"; /** Date is earlier than the given minimum date "$minDate" */
  readonly 'date.minimum': "Must be at or after {{minDate}}"; /** A value of incorrect type is found, eg found `number` instead of `string` */
  readonly 'generic.incorrect-type': "Expected type \"{{expectedType}}\", got \"{{actualType}}\""; /** Value is not one of the values specifically allowed */
  readonly 'generic.not-allowed': "Value did not match any allowed values"; /** Value "$givenValue" is not one of the values specifically allowed */
  readonly 'generic.not-allowed_hint': "Value \"{{hint}}\" did not match any allowed values"; /** A value is expected, but none is provided */
  readonly 'generic.required': "Required"; /** Number is less than the given minimum threshold value "$threshold" */
  readonly 'number.greater-than': "Must be greater than {{threshold}}"; /** Number is greater than the given maximum threshold value "$threshold" */
  readonly 'number.less-than': "Must be less than {{threshold}}"; /** Number is higher than the given maximum value "$maxNumber" */
  readonly 'number.maximum': "Must be lower than or equal to {{maxNumber}}"; /** Number has more precision (decimals) than the allowed "$limit" */
  readonly 'number.maximum-precision': "Max precision is {{limit}}"; /** Number is lower than the given minimum value "$minNumber" */
  readonly 'number.minimum': "Must be greater than or equal to {{minNumber}}"; /** Number is not an integer ("whole number") */
  readonly 'number.non-integer': "Must be an integer"; /** Object is missing a reference to an asset document in its `asset` field */
  readonly 'object.asset-required': "Asset is required"; /** Object is missing a reference to a file asset document in its `asset` field */
  readonly 'object.asset-required_file': "File is required"; /** Object is missing a reference to an image asset document in its `asset` field */
  readonly 'object.asset-required_image': "Image is required"; /** Media can't be found in the Media Library */
  readonly 'object.media-not-found': "The asset could not be found in the Media Library"; /** Media object is missing a reference to a document in its `_ref` field */
  readonly 'object.not-media-library-asset': "Must be a reference to a Media Library asset"; /** Object is not a reference to a document (eg `{_ref: 'documentId'}`) */
  readonly 'object.not-reference': "Must be a reference to a document"; /** Object references a document which is not published */
  readonly 'object.reference-not-published': "Referenced document must be published"; /** Accessibility label for closing the validation panel */
  readonly 'panel.close-button-aria-label': "Close validation"; /** Message shown when the validation panel is opened but there are no errors/warnings */
  readonly 'panel.no-errors-message': "No validation errors"; /** Title for the actual "Validation" panel/feature */
  readonly 'panel.title': "Validation"; /** Message shown when the validation panel is opened but the document is going to unpublish */
  readonly 'panel.unpublish-message': "Document is going to unpublish, no validation errors are shown"; /** Slug is an object, but is missing a `current` string property */
  readonly 'slug.missing-current': "Slug must have a value"; /** Slug is not an object (eg `{current: 'some-slug'}`) */
  readonly 'slug.not-object': "Slug must be an object"; /** Slug is already in use somewhere else, but needs to be unique */
  readonly 'slug.not-unique': "Slug is already in use"; /** String is not a valid email address */
  readonly 'string.email': "Must be a valid email address"; /** String has a different character length than the exact number "$wantedLength" */
  readonly 'string.exact-length': "Must be exactly {{wantedLength}} characters long"; /** String contains characters that are not in lowercase  */
  readonly 'string.lowercase': "Must be all lowercase characters"; /** String is longer than the limit of "$maxLength" characters */
  readonly 'string.maximum-length': "Must be at most {{maxLength}} characters long"; /** String is shorter than the limit of "$minLength" characters */
  readonly 'string.minimum-length': "Must be at least {{minLength}} characters long"; /** String does not match the given regular expression, but should */
  readonly 'string.regex-does-not-match': "Does not match \"{{name}}\"-pattern"; /** String matches the given regular expression, but should not */
  readonly 'string.regex-match': "Should not match \"{{name}}\"-pattern"; /** String contains characters that are not in uppercase */
  readonly 'string.uppercase': "Must be all uppercase characters"; /** String contains a protocol/scheme that is not allowed, eg (`ftp`, `mailto`…) */
  readonly 'string.url.disallowed-scheme': "Does not match allowed protocols/schemes"; /** String contains a URL with a username or password specified before the host */
  readonly 'string.url.includes-credentials': "Username/password not allowed"; /** String is not a valid URL */
  readonly 'string.url.invalid': "Not a valid URL"; /** String is not an absolute URL (eg it is missing a protocol/host) */
  readonly 'string.url.not-absolute': "Relative URLs are not allowed"; /** String is not a relative URL (eg it contains a protocol/host) */
  readonly 'string.url.not-relative': "Only relative URLs are allowed";
};
/**
 * The i18n resource keys for the validation.
 *
 * @alpha
 * @hidden
 */
type ValidationLocaleResourceKeys = keyof typeof validationLocaleStrings;
/**
 * An object of locale resources, or a string array of resources
 *
 * @public
 */
type LocaleNestedResource = LocaleResourceRecord | string[];
/**
 * A locale resource key, which can be a leaf string, or a nested resource
 *
 * @public
 */
type LocaleResourceKey = string | LocaleNestedResource;
/**
 * An object of locale resources.
 *
 * @public
 */
interface LocaleResourceRecord {
  [key: string]: LocaleResourceKey;
}
/**
 * Context passed to locale config resolvers
 *
 * @public
 */
interface LocaleConfigContext {
  projectId: string;
  dataset: string;
}
/**
 * Either an array of locale definitions, or a resolver that returns one.
 *
 * @public
 */
type LocalesOption = ((prev: LocaleDefinition[], context: LocaleConfigContext) => LocaleDefinition[]) | LocaleDefinition[];
/**
 * Either an array of locale resource bundles, or a resolver that returns one.
 *
 * @public
 */
type LocalesBundlesOption = ((prev: LocaleResourceBundle[], context: LocaleConfigContext) => LocaleResourceBundle[]) | LocaleResourceBundle[];
/**
 * Options that defines or adds resources to existing locales
 *
 * @public
 */
interface LocalePluginOptions {
  /**
   * Locales available for user selection.
   *
   * Titles and icons can be changed by using a function (reducer pattern) and transforming values.
   */
  locales?: LocalesOption;
  /**
   * Bundles contain "resources" (strings) that yields translations for different locales
   * throughout the studio. The strings are scoped to a specific locale and namespace.
   * Namespaces in this context usually means a specific part of the studio, like a tool or plugin.
   */
  bundles?: LocalesBundlesOption;
}
/**
 * A locale resource bundle where the locale is inherited from the parent locale definition.
 *
 * @public
 */
type ImplicitLocaleResourceBundle = Omit<LocaleResourceBundle, 'locale'>;
/**
 * A collection of locale resources for a given locale and namespace.
 * In other words, an object of translated locale strings.
 *
 * @public
 */
interface LocaleResourceBundle {
  /**
   * The locale ID the resources belong to, eg `en-US`, `nb-NO`, `th-TH`…
   */
  locale: string;
  /**
   * The namespace the resources belong to, eg `vision`, `structure`, `studio`…
   */
  namespace: string;
  /**
   * An object of locale resources, or a function that resolves to one.
   * The localization framework automatically handles ESM modules with a default export,
   * since a common use case is to dynamically load a resource file on use. This is the
   * preferred option, since it allows for lazy loading of locale resources on use.
   */
  resources: LocaleResourceRecord | (() => Promise<LocaleResourceRecord | {
    default: LocaleResourceRecord;
  }>);
  /**
   * Whether the resources should be merged deeply (eg for nested objects). Default: true
   */
  deep?: boolean;
  /**
   * Whether any existing resource keys for the namespace be overwritten. Default: true
   */
  overwrite?: boolean;
}
/**
 * A locale resource bundle where the resources are static, eg not lazy loaded.
 *
 * @public
 */
type StaticLocaleResourceBundle = Omit<ImplicitLocaleResourceBundle, 'resources'> & {
  /**
   * The locale ID the resources belong to, eg `en-US`, `nb-NO`, `th-TH`…
   */
  locale?: string;
  /**
   * An object of locale resources.
   */
  resources: LocaleResourceRecord;
};
/**
 * A locale representation
 *
 * @public
 */
interface Locale {
  /**
   * The ID of the locale, eg `en-US`, `nb-NO`, `th-TH`…
   */
  id: string;
  /**
   * The title of locale, eg `English (US)`, `Norsk (bokmål)`, `ไทย`…
   */
  title: string;
  /**
   * Week information for this locale. Based on the `Intl.Locale['weekInfo']` type.
   */
  weekInfo: LocaleWeekInfo;
}
/**
 * An object representing week information associated with the Locale data specified in
 * {@link https://www.unicode.org/reports/tr35/tr35-dates.html#Date_Patterns_Week_Elements | UTS 35's Week Elements }
 *
 * @public
 */
interface LocaleWeekInfo {
  /**
   * An integer indicating the first day of the week for the locale.
   * Can be either 1 (Monday), 6 (Saturday) or 7 (Sunday).
   */
  firstDay: 1 | 6 | 7;
  /**
   * An array of integers indicating the weekend days for the locale, where 1 is Monday and 7 is Sunday.
   */
  weekend: (1 | 2 | 3 | 4 | 5 | 6 | 7)[];
  /**
   * An integer between 1 and 7 indicating the minimal days required in the first week of a month or year, for calendar purposes.
   * @deprecated Kept for backwards compatibility in typings, but not used anywhere.
   */
  minimalDays?: 1 | 2 | 3 | 4 | 5 | 6 | 7;
}
/**
 * A locale definition, which describes a locale and its resources.
 *
 * @public
 */
interface LocaleDefinition extends Locale {
  /**
   * Array of resource bundles for this locale, if any.
   *
   * Generally you'll want to provide some base resources, eg for the studio core namespace,
   * as well as for common namespaces like `structure` and `vision`. You can also provide resources
   * for other plugins/namespaces - but preferably the resources should be provided as an async
   * function that imports the resources, in order to lazy load them on use.
   */
  bundles?: (ImplicitLocaleResourceBundle | LocaleResourceBundle)[];
}
/**
 * Internal representation of the available locale configuration.
 *
 * Generally not something you will want to use directly.
 *
 * @public
 */
interface LocaleSource {
  /**
   * Current locale ID (eg `en-US`, `nb-NO`, `th-TH`…)
   */
  currentLocale: Locale;
  /**
   * Array of locale definitions
   */
  locales: Locale[];
  /**
   * Loads the given namespaces, if not already done.
   *
   * @param namespaces - Array of namespace names to load
   * @returns Promise which resolves once loaded.
   */
  loadNamespaces(namespaces: string[]): Promise<void>;
  /**
   * Translation function, eg `t('some.key') => 'Some string'`
   */
  t: TFunction$1;
}
/**
 * @internal
 * @hidden
 */
declare function LocaleProvider(props: PropsWithChildren): react.JSX.Element;
/**
 * @internal
 * @hidden
 */
declare function LocaleProviderBase({
  projectId,
  sourceId,
  locales,
  i18next,
  children
}: PropsWithChildren<{
  projectId: string;
  sourceId: string;
  locales: Locale[];
  i18next: i18n$1;
}>): react.JSX.Element;
/**
 * Defines a resource bundle for a given locale and namespace.
 *
 * @param bundle - The bundle of resources to define
 * @returns The bundle that was passed, as-is (this is an "identity function")
 * @public
 */
declare function defineLocaleResourceBundle(bundle: LocaleResourceBundle): LocaleResourceBundle;
/**
 * Defines a locale and makes it available for use in the studio.
 *
 * @param locale - The locale to define
 * @returns The locale that was passed, as-is (this is an "identity function")
 * @public
 */
declare function defineLocale(locale: LocaleDefinition): LocaleDefinition;
/**
 * Internal helper for definining resources for a given namespace.
 *
 * Used for automation (finding the officially defined namespaces and keys), and potentially in
 * the future for type safety/helpers.
 *
 * @param resources - Resources to define
 * @returns The resources that was passed, as-is (this is an "identity function")
 * @deprecated Sanity-internal helper, don't use in external code
 * @internal
 * @hidden
 */
declare function defineLocalesResources<R extends Record<string, string>>(namespace: string, resources: R): R;
/**
 * Removes any values that are undefined from the given object.
 *
 * This is used to remove any placeholders from the generated files, while being able to leave them
 * in place to ease spotting the missing translations.
 *
 * @param resources - The resources to remove undefined values from
 * @returns The resources without any undefined values
 * @public
 * @hidden
 */
declare function removeUndefinedLocaleResources<T extends {
  [key: string]: string | undefined;
}>(resources: T): { [K in keyof T]: Exclude<T[K], undefined> };
/**
 * Enforces the shape of an object allowed to be passed into `useI18nText`.
 * @internal
 */
type I18nNode<TNode extends {
  i18n?: { [TProp in string]: {
    key: string;
    ns: string;
  } };
}> = {
  i18n?: { [K in keyof TNode['i18n']]: {
    key: string;
    ns: string;
  } };
} & { [K in keyof TNode['i18n']]: string };
/**
 * A React hook for localizing strings in a given object (`node`) using the
 * `useTranslation` hook.
 *
 * This hook expects an object (`node`) with top-level keys associated with
 * string values. If an `i18n` property is present within the object, it should
 * contain localization configurations for each top-level key. Each
 * configuration must include a `key` and `ns` (namespace) used for the
 * translation of the corresponding string value.
 *
 * The hook uses a proxy to intercept access to properties of the `node`. For
 * properties defined in the `i18n` object, it returns the translated string
 * using the `t` function. If no translation is found, the original string value
 * is used as a fallback. For properties not defined in the `i18n` object, their
 * original values are returned.
 *
 * @param node - The object containing strings to be localized along with
 *  optional i18n configurations.
 * @returns A proxy of the original `node` object where each property access
 *  returns localized strings.
 * @internal
 */
declare function useI18nText<TNode extends I18nNode<TNode>>(node: TNode): TNode;
/**
 * Similar to `useI18nText` except returns a function that can be called
 * conditionally.
 * @internal
 */
declare function useGetI18nText<TNode extends I18nNode<TNode>>(input: TNode | undefined | Array<TNode | undefined>): (node: TNode) => TNode;
/**
 * Returns the currently active locale
 *
 * @public
 */
declare function useCurrentLocale(): Locale;
/**
 * @hidden
 * @internal
 */
declare function useLocale(): LocaleContextValue;
/**
 * Inlined from `react-i18next/helpers`, as our TSC doesn't support importing from it.
 */
type $Tuple<T> = readonly [T?, ...T[]];
/**
 * Return value from the `useTranslate` hook
 *
 * @public
 */
type UseTranslationResponse<Ns extends Namespace, KPrefix> = {
  /**
   * The translate function for the given namespace(s)
   */
  t: TFunction<Ns, KPrefix>;
};
/**
 * Options for the `useTranslate` hook
 *
 * @public
 */
interface UseTranslationOptions<KPrefix> {
  /**
   * @deprecated Avoid using this, it may be
   */
  keyPrefix?: KPrefix;
  lng?: string;
}
/**
 * Returns a `t` translator function for the given namespace.
 *
 * If the given namespace is not loaded, it will trigger a suspense, and the component will resume
 * rendering once the namespace is loaded.
 *
 * @public
 */
declare function useTranslation<Ns extends FlatNamespace | $Tuple<FlatNamespace> | undefined = undefined, KPrefix extends KeyPrefix<FallbackNs<Ns>> = undefined>(ns?: Ns, options?: UseTranslationOptions<KPrefix>): UseTranslationResponse<FallbackNs<Ns>, KPrefix>;
/**
 * The default US English locale for the studio.
 *
 * @internal
 * @hidden
 */
declare const usEnglishLocale: LocaleDefinition;
/**
 * The default locale for the studio.
 *
 * @internal
 * @hidden
 */
/** @alias */
declare const defaultLocale: LocaleDefinition;
/**
 * A map of component names to React components. The component names are the names used within the
 * locale resources, eg a key of `SearchTerm` should be rendered as `<SearchTerm/>` or
 * `<SearchTerm>{{term}}</SearchTerm>` (no whitespace in tag, nor attributes).
 *
 * The components receives `children`, but no other props.
 *
 * @public
 */
type TranslateComponentMap = Record<string, ComponentType<{
  children?: ReactNode;
}> | keyof React.JSX.IntrinsicElements>;
/**
 * Props for the `Translate` component.
 *
 * @public
 */
interface TranslationProps {
  /**
   * The `t` function to use, from the `useTranslation` hook
   */
  t: TFunction;
  /**
   * The i18n resource key to translate
   */
  i18nKey: string;
  /**
   * A map of component names to React components, used to render more complex content
   */
  components?: TranslateComponentMap;
  /**
   * A string representing the "context" of the resource key.
   *
   * For an i18nKey of `greeter.greet-entity`, passing `context: 'human'` will look for a key of
   * `greeter.greet-entity_human` in the locale resources. If not found, it will fall back to the
   * base key (`greeter.greet-entity`).
   */
  context?: string;
  /**
   * A map of values to interpolate into the translated string. The resources should use the
   * double curly bracket annotation to use them, eg `{{petName}}`. Will be escaped by React,
   * so no need to escape HTML.
   */
  values?: Record<string, string | string[] | number | undefined>;
}
/**
 * Component for translating i18n resources.
 *
 * Note that this component is more expensive to render than using the `t` function from
 * `useTranslate` directly, so prefer that if possible. Generally, the only valid use case
 * for this component is when the translation needs to render a React component as part of
 * the message.
 *
 * @public
 */
declare function Translate(props: TranslationProps): react.JSX.Element;
declare module '@sanity/types' {
  /**
   * Extended validation context that includes internationalization
   *
   * Why is this not directly part of `@sanity/types`, you ask?
   * Because `@sanity/types` shouldn't need to depend on the `i18next` package, which it needs
   * for the `TFunction` type. The `ValidationContext` should never have been part of the types
   * module in the first place, but is now unfortunately part of the public API and thus cannot
   * be changed easily.
   *
   * This is a temporary solution until we can remove the `ValidationContext` from the types module,
   * which is likely to happen at the next major version.
   *
   * @public
   */
  interface ValidationContext {
    /**
     * Internationalization utilities, for translation of validation messages
     *
     * See {@link LocaleSource} for details.
     */
    i18n: LocaleSource;
  }
}
/**
 * @beta
 */
interface ValidateDocumentOptions {
  /**
   * The document to be validated
   */
  document: SanityDocument;
  /**
   * The workspace instance (and associated schema) used to validate the given
   * document against.
   */
  workspace: Workspace;
  /**
   * Function used to check if referenced documents exists (and is published).
   *
   * If you're validating many documents in bulk, you may want to query for all
   * document IDs first and provide your own implementation using those.
   *
   * If no function is provided a default one will be provided that will batch
   * call the `doc` endpoint to check for document existence.
   */
  getDocumentExists?: (options: {
    id: string;
  }) => Promise<boolean>;
  /**
   * The factory function used to get a sanity client used in custom validators.
   * If not provided, the one from the workspace will be used (preferred).
   *
   * @deprecated For internal use only
   */
  getClient?: (clientOptions: SourceClientOptions) => SanityClient;
  /**
   * Specify the environment name. This will be passed down to the
   * `ValidationContext` and made available to custom validators.
   */
  environment?: 'cli' | 'studio';
  /**
   * The maximum amount of custom validation functions to be running
   * concurrently at once. This helps prevent custom validators from
   * overwhelming backend services (e.g. called via fetch) used in async,
   * user-defined validation functions. (i.e. `rule.custom(async() => {})`)
   *
   * Note that lowering this number may also help in cases where a custom
   * validator could potentially exhaust the fetch concurrency. This is 5 by
   * default.
   */
  maxCustomValidationConcurrency?: number;
  /**
   * The amount of allowed inflight fetch requests at once. You may need to up
   * this value if you have complex custom validations that require many
   * `client.fetch` requests at once. It's possible for custom validator to
   * stall if there are not enough concurrent fetch requests available to
   * fullfil the custom validation. This is 25 by default.
   */
  maxFetchConcurrency?: number;
  /**
   * The current user, when available. Used when resolving schema `hidden`
   * conditionals so validation matches what the form shows. If omitted, hidden
   * is resolved with no user (e.g. CLI or headless validation).
   */
  currentUser?: Omit<CurrentUser, 'role'> | null;
}
/**
 * Validates a document against the schema in the given workspace. Returns an
 * array of validation markers with a path, message, and validation level.
 *
 * @beta
 */
declare function validateDocument({
  document,
  workspace,
  environment,
  maxFetchConcurrency,
  currentUser,
  ...options
}: ValidateDocumentOptions): Promise<ValidationMarker[]>;
/**
 * @hidden
 * @beta */
interface ValidationStatus {
  isValidating: boolean;
  validation: ValidationMarker[];
  revision?: string;
}
/** @internal */
declare function useValidationStatus(validationTargetId: string, docTypeName: string, requirePublishedReferences: boolean): ValidationStatus;
/**
 * @alpha
 * Return the schema id for the current workspace
 */
declare const useWorkspaceSchemaId: () => string;
interface CommentsAuthoringPathProviderProps {
  children: ReactNode;
}
/**
 * @beta
 * @hidden
 * This provider keeps track of the path that the user is currently authoring a comment for.
 * This is needed to make sure that we consistently keep the editor open when the user is
 * authoring a comment. The state is kept in a context to make sure that it is preserved
 * across re-renders. If this state was kept in a component, it would be reset every time
 * the component re-renders, for example, when the form is temporarily set to `readOnly`
 * while reconnecting.
 */
declare function CommentsAuthoringPathProvider(props: CommentsAuthoringPathProviderProps): react.JSX.Element;
/**
 * @beta
 * @hidden
 */
interface CommentsAuthoringPathContextValue {
  setAuthoringPath: (nextAuthoringPath: string | null) => void;
  authoringPath: string | null;
}
/**
 * @beta
 * @hidden
 */
interface Loadable<T> {
  data: T | null;
  error: Error | null;
  loading: boolean;
}
/**
 * @beta
 * @hidden
 */
interface CommentUpdateOperationOptions {
  throttled: boolean;
}
/**
 * @beta
 * @hidden
 */
interface CommentOperations {
  create: (comment: CommentCreatePayload) => Promise<void>;
  react: (id: string, reaction: CommentReactionOption) => Promise<void>;
  remove: (id: string) => Promise<void>;
  update: (id: string, comment: CommentUpdatePayload, opts?: CommentUpdateOperationOptions) => Promise<void>;
}
/**
 * @beta
 * @hidden
 */
interface CommentThreadItem {
  breadcrumbs: CommentListBreadcrumbs;
  commentsCount: number;
  fieldPath: string;
  hasReferencedValue: boolean;
  parentComment: CommentDocument;
  replies: CommentDocument[];
  threadId: string;
}
/**
 * @beta
 * @hidden
 */
type CommentMessage = PortableTextBlock[] | null;
/**
 * @beta
 * @hidden
 */
type CommentStatus = 'open' | 'resolved';
/**
 * @beta
 * @hidden
 */
interface CommentsTextSelectionItem {
  _key: string;
  text: string;
}
/**
 * @beta
 * @hidden
 */
interface CommentTextSelection {
  type: 'text';
  value: CommentsTextSelectionItem[];
}
type CommentPathSelection = CommentTextSelection;
/**
 * @beta
 * @hidden
 */
interface CommentPath {
  field: string;
  selection?: CommentPathSelection;
}
/**
 * @beta
 * @hidden
 */
interface CommentContext {
  tool: string;
  payload?: Record<string, unknown>;
  notification?: {
    documentTitle: string;
    url?: string;
    workspaceTitle: string;
    workspaceName: string;
    currentThreadLength?: number;
    subscribers?: string[];
  };
  intent?: {
    title: string;
    name: string;
    params: IntentParameters;
  };
}
/**
 * @beta
 * @hidden
 */
type CommentIntentGetter = (comment: {
  id: string;
  type: string;
  path: string;
}) => CommentContext['intent'];
interface CommentCreateRetryingState {
  type: 'createRetrying';
}
interface CommentCreateFailedState {
  type: 'createError';
  error: Error;
}
/**
 * @beta
 * @hidden
 * The short names for the comment reactions.
 * We follow the convention for short names outlined in https://projects.iamcal.com/emoji-data/table.htm.
 */
type CommentReactionShortNames = ':-1:' | ':+1:' | ':eyes:' | ':heart:' | ':heavy_plus_sign:' | ':rocket:';
/**
 * @beta
 * @hidden
 */
interface CommentReactionOption {
  shortName: CommentReactionShortNames;
  title: string;
}
/**
 * @beta
 * @hidden
 */
interface CommentReactionItem {
  _key: string;
  shortName: CommentReactionShortNames;
  userId: string;
  addedAt: string;
  /**
   * This is a local value and is not stored on the server.
   * It is used to track the optimistic state of the reaction.
   */
  _optimisticState?: 'added' | 'removed';
}
/**
 * @beta
 * @hidden
 */
type CommentsType = 'field' | 'task';
/**
 * The state is used to track the state of the comment (e.g. if it failed to be created, etc.)
 * It is a local value and is not stored on the server.
 * When there's no state, the comment is considered to be in a "normal" state (e.g. created successfully).
 *
 * The state value is primarily used to update the UI. That is, to show an error message or retry button.
 */
type CommentState = CommentCreateFailedState | CommentCreateRetryingState | undefined;
/**
 * @beta
 * @hidden
 */
interface CommentDocument {
  _type: 'comment';
  _createdAt: string;
  _id: string;
  _rev: string;
  _state?: CommentState;
  authorId: string;
  message: CommentMessage;
  threadId: string;
  parentCommentId?: string;
  status: CommentStatus;
  lastEditedAt?: string;
  reactions: CommentReactionItem[] | null;
  context?: CommentContext;
  /**
   * A snapshot value of the content that the comment is related to.
   */
  contentSnapshot?: unknown;
  target: {
    path?: CommentPath;
    documentRevisionId?: string;
    documentVersionId?: string;
    documentType: string;
    document: {
      _dataset: string;
      _projectId: string;
      _ref: string;
      _type: 'crossDatasetReference';
      _weak: boolean;
    } | {
      _ref: string;
      _type: 'reference';
      _weak: boolean;
    };
  };
}
/**
 * @beta
 * @hidden
 */
type CommentPostPayload = Omit<CommentDocument, '_rev' | '_updatedAt' | '_createdAt'>;
/**
 * @beta
 * @hidden
 */
interface CommentBaseCreatePayload {
  id?: CommentDocument['_id'];
  message: CommentDocument['message'];
  parentCommentId: CommentDocument['parentCommentId'];
  reactions: CommentDocument['reactions'];
  status: CommentDocument['status'];
  threadId: CommentDocument['threadId'];
  payload?: {
    fieldPath: string;
  };
}
/**
 * @beta
 * @hidden
 */
interface CommentTaskCreatePayload extends CommentBaseCreatePayload {
  type: 'task';
  context: {
    notification: CommentContext['notification'];
  };
}
/**
 * @beta
 * @hidden
 */
interface CommentFieldCreatePayload extends CommentBaseCreatePayload {
  type: 'field';
  contentSnapshot?: CommentDocument['contentSnapshot'];
  /**
   * The stringified path to the field where the comment was created.
   */
  fieldPath: string;
  selection?: CommentPathSelection;
}
/**
 * @beta
 * @hidden
 */
type CommentCreatePayload = CommentTaskCreatePayload | CommentFieldCreatePayload;
/**
 * @beta
 * @hidden
 */
type CommentUpdatePayload = Partial<Omit<CommentPostPayload, '_id' | '_type'>>;
/**
 * @beta
 * @hidden
 */
interface CommentsListBreadcrumbItem {
  invalid: boolean;
  isArrayItem?: boolean;
  title: string;
}
/**
 * @beta
 * @hidden
 */
type CommentListBreadcrumbs = CommentsListBreadcrumbItem[];
/**
 * @beta
 * @hidden
 */
type CommentsUIMode = 'default' | 'upsell';
/**
 * @beta
 * @hidden
 */
interface CommentsProviderProps {
  children: ReactNode;
  documentId: string;
  documentType: string;
  releaseId?: ReleaseId;
  type: CommentsType;
  sortOrder: 'asc' | 'desc';
  isCommentsOpen?: boolean;
  onCommentsOpen?: () => void;
  getCommentLink?: (id: string) => string;
  selectedCommentId?: string | undefined;
  onClearSelectedComment?: () => void;
  onPathOpen?: (path: Path) => void;
  isConnecting?: boolean;
  mentionsDisabled?: boolean;
}
/**
 * @beta
 */
declare const CommentsProvider: react.NamedExoticComponent<CommentsProviderProps>;
interface CommentsEnabledProviderProps {
  children: ReactNode;
  documentId: string;
  documentType: string;
}
/**
 * @beta
 * @hidden
 */
declare const CommentsEnabledProvider: react.NamedExoticComponent<CommentsEnabledProviderProps>;
/**
 * @beta
 * @hidden
 */
interface CommentsIntentProviderProps {
  children: ReactNode;
  getIntent: CommentIntentGetter;
}
/**
 * @beta
 * @hidden
 */
declare const CommentsIntentProvider: react.NamedExoticComponent<CommentsIntentProviderProps>;
interface CommentsSelectedPathProviderProps {
  children: React.ReactNode;
}
/**
 * @internal
 */
declare const CommentsSelectedPathProvider: react.NamedExoticComponent<CommentsSelectedPathProviderProps>;
/**
 * @internal
 */
interface CommentsSelectedPath {
  origin: 'form' | 'inspector' | 'url';
  fieldPath: string | null;
  threadId: string | null;
}
/**
 * @internal
 */
interface CommentsSelectedPathContextValue {
  setSelectedPath: (nextSelectedPath: CommentsSelectedPath | null) => void;
  selectedPath: CommentsSelectedPath | null;
}
/**
 * A subset of the History API is used, and explicitly declared so it's possible to write a custom
 * history implementation that can be used to integrate the router in a variety of parent routers.
 * @internal
 */
type RequiredHistory = Pick<History, 'listen' | 'location' | 'push' | 'replace'>;
/**
 * The history context is either one of the implementations from the `history` package, or a custom one that only implements
 * the subset of the History API that is used by the router, documented in `RequiredHistory`.
 * @internal
 */
type RouterHistory = BrowserHistory | MemoryHistory | HashHistory | RequiredHistory;
/** @internal */
interface ActiveWorkspaceMatcherProps {
  children: ReactNode;
  unstable_history?: RouterHistory;
  NotFoundComponent: ComponentType<{
    onNavigateToDefaultWorkspace: () => void;
  }>;
  LoadingComponent: ComponentType;
}
/** @internal */
declare function ActiveWorkspaceMatcher({
  children,
  LoadingComponent,
  NotFoundComponent,
  unstable_history: historyProp
}: ActiveWorkspaceMatcherProps): react.JSX.Element;
/** @internal */
interface WorkspaceLike {
  name?: string;
  title?: string;
  basePath?: string;
}
/**
 * Gets a printable identifer for the workspace - either the name, or the index
 * and any potential title set for it
 *
 * @param workspace - The workspace to get the indentifier for
 * @param index - The index at which the workspace appeared in the source array
 * @returns Printable string (eg `intranet`, or `at index 5 (titled "Intranet")`)
 * @internal
 */
declare function getWorkspaceIdentifier({
  name,
  title
}: WorkspaceLike, index: number): string;
/** @internal */
declare function getNamelessWorkspaceIdentifier(title: string | undefined, index: number): string;
/** @internal */
declare function useWorkspaces(): WorkspaceSummary[];
/** @internal */
interface ValidateWorkspaceOptions {
  workspaces: WorkspaceLike[];
}
/**
 * Validates workspace configuration, throwing if:
 *
 * - Workspaces do not all have base paths and names (if multiple given)
 * - Base paths or names are invalid
 * - Base paths or names are not unique
 *
 * @internal
 */
declare function validateWorkspaces({
  workspaces
}: ValidateWorkspaceOptions): void;
/**
 * Validates the workspace names of every workspace
 * Only exported for testing purposes
 *
 * @param workspaces - An array of workspaces
 * @internal
 */
declare function validateNames(workspaces: WorkspaceLike[]): void;
/**
 * Validates the base paths of every workspace
 * Only exported for testing purposes
 *
 * @param workspaces - An array of workspaces
 * @internal
 */
declare function validateBasePaths(workspaces: WorkspaceLike[]): void;
/** @internal */
type WorkspacesContextValue = WorkspaceSummary[];
/** @internal */
interface WorkspacesProviderProps {
  config: Config;
  children: ReactNode;
  basePath?: string;
  LoadingComponent: ComponentType;
}
/** @internal */
declare function WorkspacesProvider({
  config,
  children,
  basePath,
  LoadingComponent
}: WorkspacesProviderProps): react.JSX.Element;
/** @internal */
type NormalizedWorkspace = {
  workspace: WorkspacesContextValue[number];
  name?: string | undefined;
  basePath: string;
  basePathRegex: RegExp;
};
/** @internal */
interface MatchWorkspaceOptions {
  workspaces: NormalizedWorkspace[];
  pathname: string;
  basePathRegex: RegExp;
}
/** @internal */
type MatchWorkspaceResult = {
  type: 'match';
  workspace: WorkspacesContextValue[number];
} | {
  type: 'redirect';
  pathname: string;
} | {
  type: 'not-found';
};
/**
 * Given a pathname and a list of workspaces, returns either a workspace match,
 * a redirect, or not-found.
 *
 * @internal
 */
declare function matchWorkspace({
  pathname,
  workspaces,
  basePathRegex
}: MatchWorkspaceOptions): MatchWorkspaceResult;
/** @internal */
declare function useActiveWorkspace(): ActiveWorkspaceMatcherContextValue;
interface AddonDatasetSetupProviderProps {
  children: React.ReactNode;
}
/**
 * This provider sets the addon dataset client, currently called `comments` dataset.
 * It also exposes a `createAddonDataset` function that can be used to create the addon dataset if it does not exist.
 * @beta
 * @hidden
 */
declare function AddonDatasetProvider(props: AddonDatasetSetupProviderProps): string | number | bigint | boolean | react.JSX.Element | Iterable<react.ReactNode> | Promise<string | number | bigint | boolean | Iterable<react.ReactNode> | react.ReactElement<unknown, string | react.JSXElementConstructor<any>> | react.ReactPortal | null | undefined> | null | undefined;
/**
 * @beta
 * @hidden
 */
interface AddonDatasetContextValue {
  /**
   * Addon dataset client, currently called `comments` dataset.
   */
  client: SanityClient | null;
  isCreatingDataset: boolean;
  /**
   * Function to create the addon dataset if it does not exist.
   */
  createAddonDataset: () => Promise<SanityClient | null>;
  ready: boolean;
  error: Error | null;
}
/**
 * @beta
 * @hidden
 */
declare function useAddonDataset(): AddonDatasetContextValue;
/** @public
 * @deprecated – Will be removed in upcoming major version
 * */
interface StudioTheme extends Omit<RootTheme, 'avatar' | 'button' | 'container' | 'focusRing' | 'input' | 'layer' | 'media' | 'radius' | 'shadows' | 'space' | 'styles' | 'color' | 'fonts'> {
  /** @internal */
  __dark?: boolean;
  /** @internal */
  __legacy?: boolean;
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  avatar?: RootTheme['avatar'];
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  button?: RootTheme['button'];
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  container?: RootTheme['container'];
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  focusRing?: RootTheme['focusRing'];
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  input?: RootTheme['input'];
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  layer?: RootTheme['layer'];
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  media?: RootTheme['media'];
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  radius?: RootTheme['radius'];
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  shadows?: RootTheme['shadows'];
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  space?: RootTheme['space'];
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  styles?: RootTheme['styles'];
  color?: RootTheme['color'];
  fonts?: RootTheme['fonts'];
}
/**
 * Used to specify light or dark mode, or to respect system settings (prefers-color-scheme media
 * query) use 'system'
 * @public
 */
type StudioColorScheme = ThemeColorSchemeKey$1 | 'system';
/**
 * Used to specify light or dark mode, or to respect system settings (prefers-color-scheme media
 * query) use 'system'
 * @public
 * @deprecated Use `StudioColorScheme` instead
 */
type StudioThemeColorSchemeKey = StudioColorScheme;
/** @internal */
interface ColorSchemeProviderProps {
  children: ReactNode;
  onSchemeChange?: (nextScheme: StudioThemeColorSchemeKey) => void;
  scheme?: StudioThemeColorSchemeKey;
}
/** @internal */
declare function ColorSchemeProvider({
  children,
  onSchemeChange,
  scheme: schemeProp
}: ColorSchemeProviderProps): react.JSX.Element;
/**
 * Uses useSyncExternalStore to ensure that localStorage is accessed in a SSR hydration compatible way
 * @internal
 */
declare function ColorSchemeLocalStorageProvider({
  children,
  onSchemeChange
}: Pick<ColorSchemeProviderProps, 'children' | 'onSchemeChange'>): react.JSX.Element;
/**
 * If the `scheme` prop is provided we don't need to setup any logic to handle localStorage
 * @internal
 */
declare function ColorSchemeCustomProvider({
  children,
  onSchemeChange,
  scheme
}: Pick<ColorSchemeProviderProps, 'children' | 'onSchemeChange'> & {
  scheme: StudioThemeColorSchemeKey;
}): React.JSX.Element;
/** @alpha */
declare function useColorSchemeSetValue(): false | ((nextScheme: StudioThemeColorSchemeKey) => void);
/** @internal */
declare function useColorSchemeInternalValue(): StudioThemeColorSchemeKey;
/** @alpha */
declare function useColorSchemeValue(): ThemeColorSchemeKey;
/**
 * @deprecated Use `useColorSchemeValue` or `useColorSchemeSetValue` instead
 * @internal
 */
declare function useColorScheme(): {
  scheme: "dark" | "light";
  setScheme: false | ((nextScheme: StudioColorScheme) => void);
};
interface ColorSchemeOption {
  icon: ComponentType;
  label: string;
  name: StudioThemeColorSchemeKey;
  onSelect: () => void;
  selected: boolean;
  title: string;
}
/**
 * @internal
 */
declare function useColorSchemeOptions(setScheme: (nextScheme: StudioThemeColorSchemeKey) => void, t: TFunction$1<'studio'>): ColorSchemeOption[];
/**
 * @internal
 */
declare function Filters({
  showTypeFilter
}: {
  showTypeFilter?: boolean;
}): react.JSX.Element;
interface SearchHeaderProps {
  ariaInputLabel?: string;
  onClose?: () => void;
}
/**
 * @internal
 */
declare const SearchHeader: react.ForwardRefExoticComponent<SearchHeaderProps & react.RefAttributes<HTMLInputElement>>;
type ItemSelectHandler = (item: Pick<SanityDocumentLike, '_id' | '_type' | 'title'>) => void;
/**
 * @internal
 */
interface SearchPopoverProps {
  disableFocusLock?: boolean;
  disableIntentLink?: boolean;
  onClose: () => void;
  onItemSelect?: ItemSelectHandler;
  previewPerspective?: StackablePerspective[];
  /**
   * If provided, will trigger to open the search popover when user types hotkey + k
   */
  onOpen?: () => void;
  open: boolean;
}
/**
 * @internal
 */
declare function SearchPopover({
  disableFocusLock,
  disableIntentLink,
  onClose,
  onItemSelect,
  onOpen,
  previewPerspective,
  open
}: SearchPopoverProps): react.JSX.Element;
interface SearchResultItemPreviewProps {
  documentId: string;
  documentType: string;
  layout?: GeneralPreviewLayoutKey;
  presence?: DocumentPresence[];
  perspective?: PerspectiveStack;
  schemaType: SchemaType;
  showBadge?: boolean;
}
/**
 * @internal
 */
declare function SearchResultItemPreview({
  documentId,
  documentType,
  layout,
  presence,
  schemaType,
  showBadge,
  perspective
}: SearchResultItemPreviewProps): react.JSX.Element;
/**
 * @internal
 */
interface SearchTerms<Type extends SchemaType | CrossDatasetType = SchemaType> {
  filter?: string;
  params?: Record<string, unknown>;
  query: string;
  types: Type[];
}
/**
 * @internal
 */
interface SearchStory {
  path: string;
  score: number;
  why: string;
}
/**
 * @internal
 */
interface SearchHit {
  hit: SanityDocumentLike;
}
/**
 * @internal
 */
interface WeightedHit extends SearchHit {
  resultIndex: number;
  score: number;
  stories: SearchStory[];
}
/**
 * @internal
 */
interface SearchFactoryOptions {
  maxDepth?: number;
  filter?: string;
  params?: Record<string, unknown>;
  tag?: string;
  unique?: boolean;
  strategy?: SearchStrategy;
  perspective?: ClientPerspective;
}
/**
 * @internal
 */
interface WeightedSearchResults {
  type: 'weighted';
  hits: WeightedHit[];
  nextCursor?: never;
}
/**
 * @internal
 */
interface Groq2024SearchResults {
  type: 'groq2024';
  hits: SearchHit[];
  nextCursor?: string;
}
/**
 * @internal
 */
type SearchStrategyFactory<TResult extends WeightedSearchResults | Groq2024SearchResults> = (types: (SchemaType | CrossDatasetType)[], client: SanityClient, commonOpts: SearchFactoryOptions) => (searchTerms: string | SearchTerms, searchOpts?: SearchOptions) => Observable<TResult>;
/**
 * @internal
 */
type SearchOptions = {
  __unstable_extendedProjection?: string;
  maxDepth?: number;
  comments?: string[];
  skipSortByScore?: boolean;
  sort?: SearchSort[];
  cursor?: string;
  limit?: number;
  perspective?: ClientPerspective;
  isCrossDataset?: boolean;
  queryType?: 'prefixLast' | 'prefixNone';
};
/**
 * @internal
 */
type SortDirection = 'asc' | 'desc';
/**
 * @internal
 */
type SearchSort = {
  direction: SortDirection;
  field: string;
  mapWith?: string;
};
/**
 * Get all defined document types from the schema that are searchable
 *
 * @param schema - The schema to get searchable types from
 * @param explicitlyAllowedTypes - Array of type names to explicitly allow, even if they are otherwise ignored. This is useful for cases where you want to allow say `sanity.imageAsset` explicitly, or an object type that was _previously_ defined as a document type, and thus still have documents.
 *
 * @internal
 */
declare const getSearchableTypes: (schema: Schema, explicitlyAllowedTypes?: string[]) => ObjectSchemaType[];
/**
 * Check if a perspective is 'raw'
 *
 * @param perspective - the list with perspective ids or a simple perspective id
 * @returns true if the perspective is 'raw'
 * @deprecated – use perspective === 'raw' instead
 * @internal
 */
declare function isPerspectiveRaw(perspective: string[] | string | undefined): boolean;
/** @internal */
declare const createSearch: SearchStrategyFactory<WeightedSearchResults | Groq2024SearchResults>;
/**
 * @alpha
 */
type I18nSearchOperatorNameKey = `search.operator.${Lowercase<string>}.name`;
/**
 * @alpha
 */
type I18nSearchOperatorDescriptionKey = `search.operator.${Lowercase<string>}.description`;
/**
 * @alpha
 */
interface SearchOperatorBase {
  /** i18n resource key for the "name", eg `quantity is` or `contains` */
  nameKey: I18nSearchOperatorNameKey;
  /** i18n resource key for the "name", eg `quantity is` or `contains` */
  descriptionKey: I18nSearchOperatorDescriptionKey;
  /** icon for explaining the operator (React component) */
  icon?: ComponentType;
  /** name/type of operator, eg `arrayCountEqual` or `numberGt` */
  type: string;
}
/**
 * @alpha
 */
type SearchOperatorInput<TValue> = ComponentType<OperatorInputComponentProps<TValue>>;
/**
 * @alpha
 */
type SearchOperatorButtonValue<TValue> = ComponentType<OperatorButtonValueComponentProps<TValue>>;
/**
 * @alpha
 */
interface OperatorButtonValueComponentProps<T> {
  value: T;
}
/**
 * @alpha
 */
interface OperatorInputComponentProps<T> {
  fieldDefinition?: SearchFieldDefinition;
  onChange: (value: T | null) => void;
  value: T | null;
}
/**
 * @alpha
 */
type SearchOperatorParams<TValue> = {
  fieldPath?: string;
  value?: TValue;
};
/**
 * @alpha
 */
type ValuelessSearchOperatorParams = {
  fieldPath?: string;
};
/**
 * @alpha
 */
type SearchValueFormatterContext = {
  i18n: LocaleSource;
};
/**
 * @alpha
 */
interface SearchOperatorBuilder<TType extends string, TValue> extends SearchOperatorBase {
  buttonValueComponent?: SearchOperatorButtonValue<TValue>;
  groqFilter: (params: SearchOperatorParams<TValue>) => string | null;
  initialValue: TValue | null;
  inputComponent: SearchOperatorInput<TValue>;
  type: TType;
}
/**
 * @alpha
 */
interface ValuelessSearchOperatorBuilder<TType extends string> extends SearchOperatorBase {
  buttonValueComponent?: never;
  groqFilter: (params: ValuelessSearchOperatorParams) => string | null;
  initialValue?: never;
  inputComponent?: never;
  type: TType;
}
/**
 * @alpha
 */
declare function defineSearchOperator<TType extends string, TValue extends unknown | never, TOperatorSnippet extends {
  type: TType;
  inputComponent?: never;
} | {
  type: TType;
  inputComponent: SearchOperatorInput<TValue>;
}>(definition: TOperatorSnippet extends {
  type: TType;
  inputComponent: SearchOperatorInput<TValue>;
} ? SearchOperatorBuilder<TType, TValue> : ValuelessSearchOperatorBuilder<TType>): typeof definition;
interface OperatorDateDirectionValue {
  includeTime?: boolean;
  date: string | null;
}
interface OperatorDateEqualValue {
  includeTime?: boolean;
  date: string | null;
}
interface OperatorDateRangeValue {
  to: string | null;
  from: string | null;
  includeTime?: boolean;
}
interface OperatorDateLastValue {
  unit: 'day' | 'month' | 'year';
  unitValue: number | null;
}
interface OperatorNumberRangeValue {
  from: number | null;
  to: number | null;
}
declare const searchOperators: {
  dateAfter: SearchOperatorBuilder<"dateAfter", OperatorDateDirectionValue> | ValuelessSearchOperatorBuilder<"dateAfter">;
  dateBefore: SearchOperatorBuilder<"dateBefore", OperatorDateDirectionValue> | ValuelessSearchOperatorBuilder<"dateBefore">;
  dateEqual: SearchOperatorBuilder<"dateEqual", OperatorDateEqualValue> | ValuelessSearchOperatorBuilder<"dateEqual">;
  dateLast: SearchOperatorBuilder<"dateLast", OperatorDateLastValue> | ValuelessSearchOperatorBuilder<"dateLast">;
  dateNotEqual: SearchOperatorBuilder<"dateNotEqual", OperatorDateEqualValue> | ValuelessSearchOperatorBuilder<"dateNotEqual">;
  dateRange: SearchOperatorBuilder<"dateRange", OperatorDateRangeValue> | ValuelessSearchOperatorBuilder<"dateRange">;
  dateTimeAfter: SearchOperatorBuilder<"dateTimeAfter", OperatorDateDirectionValue> | ValuelessSearchOperatorBuilder<"dateTimeAfter">;
  dateTimeBefore: SearchOperatorBuilder<"dateTimeBefore", OperatorDateDirectionValue> | ValuelessSearchOperatorBuilder<"dateTimeBefore">;
  dateTimeEqual: SearchOperatorBuilder<"dateTimeEqual", OperatorDateEqualValue> | ValuelessSearchOperatorBuilder<"dateTimeEqual">;
  dateTimeLast: SearchOperatorBuilder<"dateTimeLast", OperatorDateLastValue> | ValuelessSearchOperatorBuilder<"dateTimeLast">;
  dateTimeNotEqual: SearchOperatorBuilder<"dateTimeNotEqual", OperatorDateEqualValue> | ValuelessSearchOperatorBuilder<"dateTimeNotEqual">;
  dateTimeRange: SearchOperatorBuilder<"dateTimeRange", OperatorDateRangeValue> | ValuelessSearchOperatorBuilder<"dateTimeRange">;
  arrayCountEqual: SearchOperatorBuilder<"arrayCountEqual", number> | ValuelessSearchOperatorBuilder<"arrayCountEqual">;
  arrayCountGt: SearchOperatorBuilder<"arrayCountGt", number> | ValuelessSearchOperatorBuilder<"arrayCountGt">;
  arrayCountGte: SearchOperatorBuilder<"arrayCountGte", number> | ValuelessSearchOperatorBuilder<"arrayCountGte">;
  arrayCountLt: SearchOperatorBuilder<"arrayCountLt", number> | ValuelessSearchOperatorBuilder<"arrayCountLt">;
  arrayCountLte: SearchOperatorBuilder<"arrayCountLte", number> | ValuelessSearchOperatorBuilder<"arrayCountLte">;
  arrayCountNotEqual: SearchOperatorBuilder<"arrayCountNotEqual", number> | ValuelessSearchOperatorBuilder<"arrayCountNotEqual">;
  arrayCountRange: SearchOperatorBuilder<"arrayCountRange", OperatorNumberRangeValue> | ValuelessSearchOperatorBuilder<"arrayCountRange">;
  arrayListIncludes: SearchOperatorBuilder<"arrayListIncludes", string | number> | ValuelessSearchOperatorBuilder<"arrayListIncludes">;
  arrayListNotIncludes: SearchOperatorBuilder<"arrayListNotIncludes", string | number> | ValuelessSearchOperatorBuilder<"arrayListNotIncludes">;
  arrayReferenceIncludes: SearchOperatorBuilder<"arrayReferenceIncludes", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"arrayReferenceIncludes">;
  arrayReferenceNotIncludes: SearchOperatorBuilder<"arrayReferenceNotIncludes", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"arrayReferenceNotIncludes">;
  assetFileEqual: SearchOperatorBuilder<"assetFileEqual", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"assetFileEqual">;
  assetFileNotEqual: SearchOperatorBuilder<"assetFileNotEqual", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"assetFileNotEqual">;
  assetImageEqual: SearchOperatorBuilder<"assetImageEqual", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"assetImageEqual">;
  assetImageNotEqual: SearchOperatorBuilder<"assetImageNotEqual", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"assetImageNotEqual">;
  booleanEqual: SearchOperatorBuilder<"booleanEqual", boolean> | ValuelessSearchOperatorBuilder<"booleanEqual">;
  defined: SearchOperatorBuilder<"defined", unknown> | ValuelessSearchOperatorBuilder<"defined">;
  notDefined: SearchOperatorBuilder<"notDefined", unknown> | ValuelessSearchOperatorBuilder<"notDefined">;
  numberEqual: SearchOperatorBuilder<"numberEqual", number> | ValuelessSearchOperatorBuilder<"numberEqual">;
  numberGt: SearchOperatorBuilder<"numberGt", number> | ValuelessSearchOperatorBuilder<"numberGt">;
  numberGte: SearchOperatorBuilder<"numberGte", number> | ValuelessSearchOperatorBuilder<"numberGte">;
  numberLt: SearchOperatorBuilder<"numberLt", number> | ValuelessSearchOperatorBuilder<"numberLt">;
  numberLte: SearchOperatorBuilder<"numberLte", number> | ValuelessSearchOperatorBuilder<"numberLte">;
  numberNotEqual: SearchOperatorBuilder<"numberNotEqual", number> | ValuelessSearchOperatorBuilder<"numberNotEqual">;
  numberRange: SearchOperatorBuilder<"numberRange", OperatorNumberRangeValue> | ValuelessSearchOperatorBuilder<"numberRange">;
  portableTextEqual: SearchOperatorBuilder<"portableTextEqual", string | number> | ValuelessSearchOperatorBuilder<"portableTextEqual">;
  portableTextMatches: SearchOperatorBuilder<"portableTextMatches", string | number> | ValuelessSearchOperatorBuilder<"portableTextMatches">;
  portableTextNotEqual: SearchOperatorBuilder<"portableTextNotEqual", string | number> | ValuelessSearchOperatorBuilder<"portableTextNotEqual">;
  portableTextNotMatches: SearchOperatorBuilder<"portableTextNotMatches", string | number> | ValuelessSearchOperatorBuilder<"portableTextNotMatches">;
  referenceEqual: SearchOperatorBuilder<"referenceEqual", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"referenceEqual">;
  referenceNotEqual: SearchOperatorBuilder<"referenceNotEqual", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"referenceNotEqual">;
  referencesAssetFile: SearchOperatorBuilder<"referencesAssetFile", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"referencesAssetFile">;
  referencesAssetImage: SearchOperatorBuilder<"referencesAssetImage", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"referencesAssetImage">;
  referencesDocument: SearchOperatorBuilder<"referencesDocument", _sanity_types0.Reference> | ValuelessSearchOperatorBuilder<"referencesDocument">;
  slugEqual: SearchOperatorBuilder<"slugEqual", string | number> | ValuelessSearchOperatorBuilder<"slugEqual">;
  slugMatches: SearchOperatorBuilder<"slugMatches", string | number> | ValuelessSearchOperatorBuilder<"slugMatches">;
  slugNotEqual: SearchOperatorBuilder<"slugNotEqual", string | number> | ValuelessSearchOperatorBuilder<"slugNotEqual">;
  slugNotMatches: SearchOperatorBuilder<"slugNotMatches", string | number> | ValuelessSearchOperatorBuilder<"slugNotMatches">;
  stringEqual: SearchOperatorBuilder<"stringEqual", string | number> | ValuelessSearchOperatorBuilder<"stringEqual">;
  stringListEqual: SearchOperatorBuilder<"stringListEqual", string | number> | ValuelessSearchOperatorBuilder<"stringListEqual">;
  stringListNotEqual: SearchOperatorBuilder<"stringListNotEqual", string | number> | ValuelessSearchOperatorBuilder<"stringListNotEqual">;
  stringMatches: SearchOperatorBuilder<"stringMatches", string | number> | ValuelessSearchOperatorBuilder<"stringMatches">;
  stringNotEqual: SearchOperatorBuilder<"stringNotEqual", string | number> | ValuelessSearchOperatorBuilder<"stringNotEqual">;
  stringNotMatches: SearchOperatorBuilder<"stringNotMatches", string | number> | ValuelessSearchOperatorBuilder<"stringNotMatches">;
};
type DefaultOperators = typeof searchOperators;
/**
 * @alpha
 */
type SearchOperatorType = keyof DefaultOperators;
/**
 * @internal
 */
declare const operatorDefinitions: (SearchOperatorBuilder<"arrayCountEqual", number> | SearchOperatorBuilder<"arrayCountGt", number> | SearchOperatorBuilder<"arrayCountGte", number> | SearchOperatorBuilder<"arrayCountLt", number> | SearchOperatorBuilder<"arrayCountLte", number> | SearchOperatorBuilder<"arrayCountNotEqual", number> | SearchOperatorBuilder<"arrayCountRange", OperatorNumberRangeValue> | SearchOperatorBuilder<"arrayListIncludes", string | number> | SearchOperatorBuilder<"arrayListNotIncludes", string | number> | SearchOperatorBuilder<"arrayReferenceIncludes", _sanity_types0.Reference> | SearchOperatorBuilder<"arrayReferenceNotIncludes", _sanity_types0.Reference> | SearchOperatorBuilder<"assetFileEqual", _sanity_types0.Reference> | SearchOperatorBuilder<"assetFileNotEqual", _sanity_types0.Reference> | SearchOperatorBuilder<"assetImageEqual", _sanity_types0.Reference> | SearchOperatorBuilder<"assetImageNotEqual", _sanity_types0.Reference> | SearchOperatorBuilder<"booleanEqual", boolean> | SearchOperatorBuilder<"dateAfter", OperatorDateDirectionValue> | SearchOperatorBuilder<"dateBefore", OperatorDateDirectionValue> | SearchOperatorBuilder<"dateEqual", OperatorDateEqualValue> | SearchOperatorBuilder<"dateLast", OperatorDateLastValue> | SearchOperatorBuilder<"dateNotEqual", OperatorDateEqualValue> | SearchOperatorBuilder<"dateRange", OperatorDateRangeValue> | SearchOperatorBuilder<"dateTimeAfter", OperatorDateDirectionValue> | SearchOperatorBuilder<"dateTimeBefore", OperatorDateDirectionValue> | SearchOperatorBuilder<"dateTimeEqual", OperatorDateEqualValue> | SearchOperatorBuilder<"dateTimeLast", OperatorDateLastValue> | SearchOperatorBuilder<"dateTimeNotEqual", OperatorDateEqualValue> | SearchOperatorBuilder<"dateTimeRange", OperatorDateRangeValue> | SearchOperatorBuilder<"defined", unknown> | SearchOperatorBuilder<"notDefined", unknown> | SearchOperatorBuilder<"numberEqual", number> | SearchOperatorBuilder<"numberGt", number> | SearchOperatorBuilder<"numberGte", number> | SearchOperatorBuilder<"numberLt", number> | SearchOperatorBuilder<"numberLte", number> | SearchOperatorBuilder<"numberNotEqual", number> | SearchOperatorBuilder<"numberRange", OperatorNumberRangeValue> | SearchOperatorBuilder<"portableTextEqual", string | number> | SearchOperatorBuilder<"portableTextMatches", string | number> | SearchOperatorBuilder<"portableTextNotEqual", string | number> | SearchOperatorBuilder<"portableTextNotMatches", string | number> | SearchOperatorBuilder<"referenceEqual", _sanity_types0.Reference> | SearchOperatorBuilder<"referenceNotEqual", _sanity_types0.Reference> | SearchOperatorBuilder<"referencesAssetFile", _sanity_types0.Reference> | SearchOperatorBuilder<"referencesAssetImage", _sanity_types0.Reference> | SearchOperatorBuilder<"referencesDocument", _sanity_types0.Reference> | SearchOperatorBuilder<"slugEqual", string | number> | SearchOperatorBuilder<"slugMatches", string | number> | SearchOperatorBuilder<"slugNotEqual", string | number> | SearchOperatorBuilder<"slugNotMatches", string | number> | SearchOperatorBuilder<"stringEqual", string | number> | SearchOperatorBuilder<"stringListEqual", string | number> | SearchOperatorBuilder<"stringListNotEqual", string | number> | SearchOperatorBuilder<"stringMatches", string | number> | SearchOperatorBuilder<"stringNotEqual", string | number> | SearchOperatorBuilder<"stringNotMatches", string | number> | ValuelessSearchOperatorBuilder<"arrayCountEqual"> | ValuelessSearchOperatorBuilder<"arrayCountGt"> | ValuelessSearchOperatorBuilder<"arrayCountGte"> | ValuelessSearchOperatorBuilder<"arrayCountLt"> | ValuelessSearchOperatorBuilder<"arrayCountLte"> | ValuelessSearchOperatorBuilder<"arrayCountNotEqual"> | ValuelessSearchOperatorBuilder<"arrayCountRange"> | ValuelessSearchOperatorBuilder<"arrayListIncludes"> | ValuelessSearchOperatorBuilder<"arrayListNotIncludes"> | ValuelessSearchOperatorBuilder<"arrayReferenceIncludes"> | ValuelessSearchOperatorBuilder<"arrayReferenceNotIncludes"> | ValuelessSearchOperatorBuilder<"assetFileEqual"> | ValuelessSearchOperatorBuilder<"assetFileNotEqual"> | ValuelessSearchOperatorBuilder<"assetImageEqual"> | ValuelessSearchOperatorBuilder<"assetImageNotEqual"> | ValuelessSearchOperatorBuilder<"booleanEqual"> | ValuelessSearchOperatorBuilder<"dateAfter"> | ValuelessSearchOperatorBuilder<"dateBefore"> | ValuelessSearchOperatorBuilder<"dateEqual"> | ValuelessSearchOperatorBuilder<"dateLast"> | ValuelessSearchOperatorBuilder<"dateNotEqual"> | ValuelessSearchOperatorBuilder<"dateRange"> | ValuelessSearchOperatorBuilder<"dateTimeAfter"> | ValuelessSearchOperatorBuilder<"dateTimeBefore"> | ValuelessSearchOperatorBuilder<"dateTimeEqual"> | ValuelessSearchOperatorBuilder<"dateTimeLast"> | ValuelessSearchOperatorBuilder<"dateTimeNotEqual"> | ValuelessSearchOperatorBuilder<"dateTimeRange"> | ValuelessSearchOperatorBuilder<"defined"> | ValuelessSearchOperatorBuilder<"notDefined"> | ValuelessSearchOperatorBuilder<"numberEqual"> | ValuelessSearchOperatorBuilder<"numberGt"> | ValuelessSearchOperatorBuilder<"numberGte"> | ValuelessSearchOperatorBuilder<"numberLt"> | ValuelessSearchOperatorBuilder<"numberLte"> | ValuelessSearchOperatorBuilder<"numberNotEqual"> | ValuelessSearchOperatorBuilder<"numberRange"> | ValuelessSearchOperatorBuilder<"portableTextEqual"> | ValuelessSearchOperatorBuilder<"portableTextMatches"> | ValuelessSearchOperatorBuilder<"portableTextNotEqual"> | ValuelessSearchOperatorBuilder<"portableTextNotMatches"> | ValuelessSearchOperatorBuilder<"referenceEqual"> | ValuelessSearchOperatorBuilder<"referenceNotEqual"> | ValuelessSearchOperatorBuilder<"referencesAssetFile"> | ValuelessSearchOperatorBuilder<"referencesAssetImage"> | ValuelessSearchOperatorBuilder<"referencesDocument"> | ValuelessSearchOperatorBuilder<"slugEqual"> | ValuelessSearchOperatorBuilder<"slugMatches"> | ValuelessSearchOperatorBuilder<"slugNotEqual"> | ValuelessSearchOperatorBuilder<"slugNotMatches"> | ValuelessSearchOperatorBuilder<"stringEqual"> | ValuelessSearchOperatorBuilder<"stringListEqual"> | ValuelessSearchOperatorBuilder<"stringListNotEqual"> | ValuelessSearchOperatorBuilder<"stringMatches"> | ValuelessSearchOperatorBuilder<"stringNotEqual"> | ValuelessSearchOperatorBuilder<"stringNotMatches">)[];
type Operator<TOperators = string> = OperatorDivider | OperatorItem<TOperators>;
type OperatorDivider = {
  type: 'divider';
};
type OperatorItem<TOperators = string> = {
  name: TOperators;
  type: 'item';
};
interface SearchFilterBaseDefinition<TOperators> {
  description?: string;
  icon: ComponentType;
  name: string;
  operators: Operator<TOperators>[];
}
interface SearchFilterFieldDefinition<TOperators = string> extends SearchFilterBaseDefinition<TOperators> {
  fieldType: IntrinsicTypeName;
  type: 'field';
}
interface SearchFilterPinnedDefinition<TOperators = string> extends SearchFilterBaseDefinition<TOperators> {
  fieldPath?: string;
  group?: string;
  title: string;
  type: 'pinned';
}
/**
 * @beta
 */
type SearchFilterDefinition<TOperators = string> = SearchFilterFieldDefinition<TOperators> | SearchFilterPinnedDefinition<TOperators>;
/**
 * @alpha
 */
declare function defineSearchFilter<TOperators = SearchOperatorType>(filterDef: SearchFilterDefinition<TOperators>): typeof filterDef;
/**
 * @alpha
 */
declare function defineSearchFilterOperators<TOperators = SearchOperatorType>(operators: Operator<TOperators>[]): typeof operators;
/**
 * @internal
 */
type SearchFilterDefinitionDictionary = Record<SearchFilterDefinition['name'], SearchFilterDefinition>;
/**
 * @internal
 */
interface SearchFieldDefinition {
  documentTypes: string[];
  fieldPath: string;
  filterName: string;
  id: string;
  name: string;
  title: string;
  titlePath: string[];
  type: string;
}
/**
 * @internal
 */
type SearchFieldDefinitionDictionary = Record<SearchFieldDefinition['id'], SearchFieldDefinition>;
/**
 * @internal
 */
interface SearchFilter {
  fieldId?: string;
  filterName: string;
  operatorType: string;
  value?: any;
}
/**
 * @internal
 */
interface SearchOrdering {
  customMeasurementLabel?: string;
  ignoreScore?: boolean;
  sort?: SearchSort;
  /**
   * i18n key for title
   */
  titleKey: `search.ordering.${string}-label`;
}
type RecentSearch = SearchTerms & {
  __recent: {
    index: number;
    timestamp: number;
  };
  filters?: SearchFilter[];
};
/** @internal */
interface SearchOperatorDefinition<TValue = any> extends SearchOperatorBase {
  buttonValueComponent?: SearchOperatorButtonValue<TValue>;
  groqFilter: (params: SearchOperatorParams<TValue>) => string | null;
  initialValue?: TValue;
  inputComponent?: SearchOperatorInput<TValue>;
  type: string;
}
/** @internal */
type SearchOperatorDefinitionDictionary = Record<SearchOperatorDefinition['type'], SearchOperatorDefinition>;
interface PaginationState {
  cursor: string | null;
  nextCursor: string | null;
}
type SearchReducerState = PaginationState & {
  currentUser: CurrentUser | null;
  debug: boolean;
  definitions: SearchDefinitions;
  documentTypesNarrowed: string[];
  filters: SearchFilter[];
  filtersVisible: boolean;
  fullscreen?: boolean;
  lastAddedFilter?: SearchFilter | null;
  lastActiveIndex: number;
  ordering: SearchOrdering;
  result: SearchResult;
  terms: RecentSearch | SearchTerms;
  strategy?: SearchStrategy;
  disabledDocumentIds?: string[];
  canDisableAction?: boolean;
};
interface SearchDefinitions {
  fields: SearchFieldDefinitionDictionary;
  filters: SearchFilterDefinitionDictionary;
  operators: SearchOperatorDefinitionDictionary;
}
interface SearchResult {
  error: Error | null;
  hasLocal: boolean;
  hits: SearchHit[];
  loaded: boolean;
  loading: boolean;
}
type FiltersVisibleSet = {
  type: 'FILTERS_VISIBLE_SET';
  visible: boolean;
};
type LastActiveIndexSet = {
  type: 'LAST_ACTIVE_INDEX_SET';
  index: number;
};
type PageIncrement = {
  type: 'PAGE_INCREMENT';
};
type OrderingReset = {
  type: 'ORDERING_RESET';
};
type OrderingSet = {
  ordering: SearchOrdering;
  type: 'ORDERING_SET';
};
type SearchClear = {
  type: 'SEARCH_CLEAR';
};
type SearchRequestComplete = {
  type: 'SEARCH_REQUEST_COMPLETE';
  hits: SearchHit[];
  nextCursor: string | undefined;
};
type SearchRequestError = {
  type: 'SEARCH_REQUEST_ERROR';
  error: Error;
};
type SearchRequestStart = {
  type: 'SEARCH_REQUEST_START';
};
type TermsFiltersAdd = {
  filter: SearchFilter;
  type: 'TERMS_FILTERS_ADD';
};
type TermsFiltersClear = {
  type: 'TERMS_FILTERS_CLEAR';
};
type TermsFiltersRemove = {
  filterKey: string;
  type: 'TERMS_FILTERS_REMOVE';
};
type TermsFiltersSetOperator = {
  filterKey: string;
  operatorType: string;
  type: 'TERMS_FILTERS_SET_OPERATOR';
};
type TermsFiltersSetValue = {
  filterKey: string;
  type: 'TERMS_FILTERS_SET_VALUE';
  value?: any;
};
type TermsQuerySet = {
  type: 'TERMS_QUERY_SET';
  query: string;
};
type TermsSet = {
  type: 'TERMS_SET';
  filters?: SearchFilter[];
  terms: SearchTerms;
};
type TermsTypeAdd = {
  type: 'TERMS_TYPE_ADD';
  schemaType: SchemaType;
};
type TermsTypeRemove = {
  type: 'TERMS_TYPE_REMOVE';
  schemaType: SchemaType;
};
type TermsTypesClear = {
  type: 'TERMS_TYPES_CLEAR';
};
type SearchAction = FiltersVisibleSet | LastActiveIndexSet | OrderingReset | OrderingSet | PageIncrement | SearchClear | SearchRequestComplete | SearchRequestError | SearchRequestStart | TermsFiltersAdd | TermsFiltersClear | TermsFiltersSetOperator | TermsFiltersRemove | TermsFiltersSetValue | TermsQuerySet | TermsSet | TermsTypeAdd | TermsTypeRemove | TermsTypesClear;
/**
 * @internal
 */
interface SearchContextValue {
  dispatch: Dispatch<SearchAction>;
  onClose: (() => void) | null;
  searchCommandList: CommandListHandle | null;
  setSearchCommandList: Dispatch<SetStateAction<CommandListHandle | null>>;
  setOnClose: (onClose: () => void) => void;
  state: SearchReducerState;
}
interface SearchProviderProps {
  children?: ReactNode;
  fullscreen?: boolean;
  /**
   * list of perspective ids
   * if provided, then it means that the search is being done using a specific list of perspectives
   */
  /**
   * list of document ids that should be be disabled in the search
   * if they are found to exist in the search results
   * if provided, then ids should be checked against this list
   */
  disabledDocumentIds?: string[];
  /**
   * If true, the search action (such as adding a document to a release list, for example) should be allowed to disable under the right conditions
   */
  canDisableAction?: boolean;
}
/**
 * @internal
 */
declare function SearchProvider({
  children,
  fullscreen,
  disabledDocumentIds,
  canDisableAction
}: SearchProviderProps): react.JSX.Element;
/**
 * @internal
 */
declare function useSearchState(): SearchContextValue;
/**
 * @internal
 * @hidden
 */
interface PartialIndexSettings {
  partialIndexSettings: {
    maxFieldDepth: number;
  };
}
/**
 * @internal
 * @hidden
 */
declare function useSearchMaxFieldDepth(overrideClient?: SanityClient): number;
interface SearchButtonProps {
  onClick: () => void;
}
/**
 * @internal
 */
declare const SearchButton: react.ForwardRefExoticComponent<SearchButtonProps & react.RefAttributes<HTMLButtonElement>>;
interface SearchDialogProps {
  onClose: () => void;
  onOpen: () => void;
  open: boolean;
}
/**
 * @internal
 */
declare function SearchDialog({
  onClose,
  onOpen,
  open
}: SearchDialogProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
declare function StudioLogo(props: LogoProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
interface LayoutProps {
  renderDefault: (props: LayoutProps) => React.JSX.Element;
}
/**
 * @hidden
 * @beta */
interface LogoProps {
  title: string;
  renderDefault: (props: LogoProps) => React.JSX.Element;
}
interface NavbarActionBase {
  icon?: React.ComponentType;
  location: 'topbar' | 'sidebar';
  name: string;
}
interface ActionWithCustomRender extends NavbarActionBase {
  render: () => React.ReactElement;
}
interface Action extends NavbarActionBase {
  onAction: () => void;
  selected: boolean;
  title: string;
  render?: undefined;
}
/**
 * @internal
 * @beta
 * An internal API for defining actions in the navbar.
 */
type NavbarAction = Action | ActionWithCustomRender;
/**
 * @hidden
 * @beta */
interface NavbarProps {
  renderDefault: (props: NavbarProps) => React.JSX.Element;
  /**
   * @internal
   * @beta */
  __internal_actions?: NavbarAction[];
}
/**
 * @hidden
 * @beta */
interface ActiveToolLayoutProps {
  renderDefault: (props: ActiveToolLayoutProps) => React.JSX.Element;
  activeTool: Tool;
}
/**
 * @hidden
 * @beta */
interface ToolMenuProps {
  activeToolName?: string;
  closeSidebar: () => void;
  context: 'sidebar' | 'topbar';
  isSidebarOpen: boolean;
  tools: Tool[];
  renderDefault: (props: ToolMenuProps) => React.JSX.Element;
}
/**
 * @hidden
 * @beta */
interface StudioComponents {
  layout: ComponentType;
  /**
   * @deprecated Add custom icons on a per-workspace basis by customizing workspace `icon` instead.
   * @see {@link https://www.sanity.io/docs/workspaces}
   */
  logo: ComponentType<Omit<LogoProps, 'renderDefault'>>;
  navbar: ComponentType<Omit<NavbarProps, 'renderDefault'>>;
  toolMenu: ComponentType<Omit<ToolMenuProps, 'renderDefault'>>;
}
/**
 * @hidden
 * @beta */
interface StudioComponentsPluginOptions {
  activeToolLayout?: ComponentType<ActiveToolLayoutProps>;
  layout?: ComponentType<LayoutProps>;
  /**
   * @deprecated Add custom icons on a per-workspace basis by customizing workspace `icon` instead.
   * @see {@link https://www.sanity.io/docs/workspaces}
   */
  logo?: ComponentType<LogoProps>;
  navbar?: ComponentType<NavbarProps>;
  toolMenu?: ComponentType<ToolMenuProps>;
}
/**
 * @hidden
 * @beta */
declare function StudioNavbar(props: Omit<NavbarProps, 'renderDefault'>): react.JSX.Element;
/**
 * @hidden
 * @beta */
declare function StudioToolMenu(props: ToolMenuProps): react.JSX.Element | null;
/**
 * @hidden
 * @beta */
interface ToolLinkProps {
  children: ReactNode;
  name: string;
}
/**
 * @hidden
 * @beta */
declare const ToolLink: react.ForwardRefExoticComponent<Omit<ToolLinkProps & Omit<HTMLProps<HTMLAnchorElement>, "href" | "name">, "ref"> & react.RefAttributes<HTMLAnchorElement>>;
/**
 * @hidden
 * @beta */
interface FormPatchBase {
  /**
   * A property used to identify this as a Sanity patch type, eg "set", "unset", "insert", etc.
   * This allows us to potentially introduce new patch types in the future without breaking
   * existing code. This is an internal property/implementation detail and should not be used by
   * consumers.
   *
   * @internal
   */
  patchType: symbol;
}
/**
 *
 * @hidden
 * @beta
 */
type FormPatchJSONValue = number | string | boolean | {
  [key: string]: FormPatchJSONValue;
} | FormPatchJSONValue[];
/**
 *
 * @hidden
 * @beta
 */
type FormPatchOrigin = 'remote' | 'local' | 'internal';
/**
 *
 * @hidden
 * @beta
 */
interface FormSetPatch extends FormPatchBase {
  path: Path;
  type: 'set';
  origin?: FormPatchOrigin;
  value: FormPatchJSONValue;
}
/**
 *
 * @hidden
 * @beta
 */
interface FormIncPatch extends FormPatchBase {
  path: Path;
  type: 'inc';
  origin?: FormPatchOrigin;
  value: FormPatchJSONValue;
}
/**
 *
 * @hidden
 * @beta
 */
interface FormDecPatch extends FormPatchBase {
  path: Path;
  type: 'dec';
  origin?: FormPatchOrigin;
  value: FormPatchJSONValue;
}
/**
 *
 * @hidden
 * @beta
 */
interface FormSetIfMissingPatch extends FormPatchBase {
  path: Path;
  origin?: FormPatchOrigin;
  type: 'setIfMissing';
  value: FormPatchJSONValue;
}
/**
 *
 * @hidden
 * @beta
 */
interface FormUnsetPatch extends FormPatchBase {
  path: Path;
  origin?: FormPatchOrigin;
  type: 'unset';
}
/**
 *
 * @hidden
 * @beta
 */
type FormInsertPatchPosition = 'before' | 'after';
/**
 *
 * @hidden
 * @beta
 */
interface FormInsertPatch extends FormPatchBase {
  path: Path;
  origin?: FormPatchOrigin;
  type: 'insert';
  position: FormInsertPatchPosition;
  items: FormPatchJSONValue[];
}
/**
 *
 * @hidden
 * @beta
 */
interface FormDiffMatchPatch extends FormPatchBase {
  path: Path;
  type: 'diffMatchPatch';
  origin?: FormPatchOrigin;
  value: string;
}
/**
 *
 * @hidden
 * @beta
 */
type FormPatch = FormSetPatch | FormSetIfMissingPatch | FormUnsetPatch | FormInsertPatch | FormDiffMatchPatch;
/**
 *
 * @hidden
 * @beta
 */
type PatchArg = FormPatch | FormPatch[];
/**
 *
 * @hidden
 * @beta
 */
declare class PatchEvent {
  static from(input: PatchArg | PatchEvent): PatchEvent;
  patches: Array<FormPatch>;
  constructor(patches: Array<FormPatch>);
  prepend(...patches: PatchArg[]): PatchEvent;
  append(...patches: PatchArg[]): PatchEvent;
  prefixAll(segment: PathSegment): PatchEvent;
}
/**
 * @beta
 * @hidden
 */
interface SanityClipboardItem {
  type: 'sanityClipboardItem';
  documentId?: string;
  documentType?: string;
  isDocument: boolean;
  schemaTypeName: string;
  valuePath: Path;
  value: unknown;
  patchType?: 'replace' | 'append';
}
/**
 * @beta
 * @hidden
 */
interface DocumentMeta {
  documentId: string;
  documentType: string;
  schemaType: ObjectSchemaType;
  onChange: (event: PatchEvent) => void;
}
/**
 * @beta
 * @hidden
 */
interface CopyPasteContextType {
  setDocumentMeta: (documentMeta: DocumentMeta) => void;
  onCopy: (path: Path, value: FormDocumentValue | undefined, options: CopyOptions) => Promise<void>;
  onPaste: (targetPath: Path, value: FormDocumentValue | undefined, options: PasteOptions) => Promise<void>;
}
/**
 * @beta
 * @hidden
 */
interface BaseOptions {
  context: {
    source: 'fieldAction' | 'documentFieldAction' | 'keyboardShortcut' | 'arrayItem' | 'unknown';
  };
}
/**
 * @beta
 * @hidden
 */
interface CopyOptions extends BaseOptions {
  patchType?: 'replace' | 'append';
}
/**
 * @beta
 * @hidden
 */
interface PasteOptions extends BaseOptions {}
/**
 * @beta
 * @hidden
 */
declare const CopyPasteProvider: React.FC<{
  children: ReactNode;
}>;
/**
 * @beta
 * @hidden
 */
declare const useCopyPaste: () => CopyPasteContextType;
/**
 * Minimal workspace properties needed for studio manifest generation.
 * Both Workspace and WorkspaceSummary satisfy this type.
 * @internal
 */
type ManifestWorkspaceInput = Pick<Workspace, 'name' | 'projectId' | 'dataset' | 'basePath' | 'title' | 'subtitle' | 'icon' | 'mediaLibrary'>;
/**
 * Workspace configuration for the Studio manifest.
 * Used when registering a Studio with the Content Operating System.
 * @internal
 */
interface StudioWorkspaceManifest {
  name: string;
  projectId: string;
  dataset: string;
  schemaDescriptorId: string;
  basePath?: string;
  title?: string;
  subtitle?: string;
  icon?: string;
  mediaLibraryId?: string;
  apiHost?: string;
}
/**
 * Studio configuration manifest that gets registered with the Content Operating System.
 * @internal
 */
interface StudioManifest {
  version?: string;
  buildId?: string;
  bundleVersion?: string;
  workspaces: StudioWorkspaceManifest[];
}
/**
 * Options for generating a studio manifest.
 * @internal
 */
interface GenerateStudioManifestOptions<W extends ManifestWorkspaceInput> {
  /** The workspaces to include in the manifest */
  workspaces: W[];
  /**
   * Function to resolve the schema descriptor ID for a workspace.
   * Return undefined to skip the workspace in the manifest.
   */
  resolveSchemaDescriptorId: (workspace: W) => string | undefined | Promise<string | undefined>;
  /**
   * Function to resolve the icon HTML string for a workspace.
   * Return undefined if the icon cannot be resolved.
   */
  resolveIcon: (workspace: W) => string | undefined | Promise<string | undefined>;
  /** The Sanity version string */
  bundleVersion: string;
  /** Optional build ID */
  buildId?: string;
}
/**
 * Generates a StudioManifest from workspaces.
 * This is a shared utility used by both CLI deployment and live manifest registration.
 * @internal
 */
declare function generateStudioManifest<W extends ManifestWorkspaceInput>(options: GenerateStudioManifestOptions<W>): Promise<StudioManifest>;
/**
 * Provider that automatically uploads the studio manifest when the Studio loads.
 * This runs once when all workspaces are available and includes all workspace information.
 *
 * @internal
 */
declare function LiveManifestRegisterProvider(): null;
/**
 * Uploads the schema to Content Lake, returning a schema descriptor ID.
 * @internal
 */
declare function uploadSchema(schema: Schema, client: SanityClient): Promise<string | undefined>;
interface RenderStudioOptions {
  basePath?: string;
  reactStrictMode?: boolean;
}
/**
 * @internal
 * @deprecated Use `renderStudio(rootElement, config, {reactStrictMode: true})` instead
 */
declare function renderStudio(rootElement: HTMLElement | null, config: Config, options: boolean): () => void;
/** @internal */
declare function renderStudio(rootElement: HTMLElement | null, config: Config): () => void;
/** @internal */
declare function renderStudio(rootElement: HTMLElement | null, config: Config, options: RenderStudioOptions): () => void;
/** @internal */
type SourceProviderProps = {
  source: Source;
  children?: ReactNode;
} | {
  name: string;
  children?: ReactNode;
};
/** @internal */
declare function SourceProvider({
  children,
  ...props
}: SourceProviderProps): react.JSX.Element;
/**
 * @internal
 * @deprecated INTERNAL USE ONLY
 */
declare function useSource(): Source;
/**
 * @hidden
 * @beta */
interface StudioProps {
  config: Config;
  basePath?: string;
  /**
   * Useful for scenarios where the Studio is embedded in another app,
   * and the surrounding app also implements light and dark color schemes.
   *
   * The callback is fired whenever the user selects a new color scheme in the "Appearance" menu in the top-right dropdown.
   * It also fires on first render with its initial value if you don't provide a `scheme` prop.
   *
   * If the user selects "System" in the "Appearance" menu, the callback will be fired with `"system"` as the scheme.
   * To resolve `"system"` to the same color scheme as the Studio use the `usePrefersDark` hook from `@sanity/ui`:
   *
   * ```tsx
   * import {usePrefersDark} from '@sanity/ui'
   * import {Studio} from 'sanity'
   *
   * export default function StudioPage() {
   *   const prefersDark = usePrefersDark()
   *   const [_scheme, setScheme] = useState('system')
   *   const prefersScheme = prefersDark ? 'dark' : 'light'
   *   const scheme = _scheme === 'system' ? prefersScheme : _scheme
   *
   *   return (
   *     <AppLayout scheme={scheme}>
   *       <Studio config={config} onSchemeChange={setScheme} />
   *     </AppLayout>
   *   )
   * }
   * ```
   *
   *
   * @hidden
   * @beta
   */
  onSchemeChange?: (nextScheme: StudioThemeColorSchemeKey) => void;
  /**
   * By default the Studio handles the color scheme itself, but you can provide a color scheme to use.
   * If you only define `scheme` then the top-right "Appearance" dropdown menu will be hidden,
   * and the Studio will stay in sync with the `scheme` prop.
   *
   * You may setup two-way sync and re-enable the "Appearance" dropdown menu by also providing an `onSchemeChange` callback:
   * ```tsx
   * import {Studio} from 'sanity'
   * import {useSession} from 'your-app'
   *
   * export default function StudioPage() {
   *   const session = useSession()
   *   // Overrides the default scheme to be what's in the app user session
   *   const [_scheme, setScheme] = useState(session.scheme)
   *   const scheme = _scheme === 'system' ? session.scheme : _scheme
   *
   *   return (
   *     <AppLayout scheme={scheme}>
   *       <Studio config={config} scheme={scheme} onSchemeChange={setScheme} />
   *     </AppLayout>
   *   )
   * }
   * ```
   *
   *
   * @hidden
   * @beta
   */
  scheme?: StudioThemeColorSchemeKey;
  /**
   * @hidden
   * @beta */
  unstable_history?: RouterHistory;
  /**
   * @hidden
   * @beta */
  unstable_globalStyles?: boolean;
  /**
   * @hidden
   * @beta */
  unstable_noAuthBoundary?: boolean;
}
/**
 * @hidden
 * @beta */
declare function Studio(props: StudioProps): React.JSX.Element;
interface StudioAnnouncementCardProps {
  title: string;
  id: string;
  name: string;
  isOpen: boolean;
  preHeader: string;
  onCardClick: () => void;
  onCardDismiss: () => void;
}
/**
 * @internal
 * @hidden
 */
declare function StudioAnnouncementsCard({
  title,
  id,
  isOpen,
  name,
  preHeader,
  onCardClick,
  onCardDismiss
}: StudioAnnouncementCardProps): react.JSX.Element;
declare const audienceRoles: readonly ["administrator", "editor", "viewer", "contributor", "developer", "custom"];
type AudienceRole = (typeof audienceRoles)[number];
interface StudioAnnouncementDocument {
  _id: string;
  _type: 'productAnnouncement';
  _rev: string;
  _createdAt: string;
  _updatedAt: string;
  title: string;
  name: string;
  body: PortableTextBlock[];
  announcementType: 'whats-new';
  publishedDate: string;
  expiryDate?: string;
  audience: 'everyone' | 'specific-version' | 'greater-than-or-equal-version' | 'less-than-or-equal-version';
  audienceRole?: AudienceRole[] | undefined;
  studioVersion?: string;
  preHeader: string;
}
interface StudioAnnouncementsContextValue {
  studioAnnouncements: StudioAnnouncementDocument[];
  unseenAnnouncements: StudioAnnouncementDocument[];
  onDialogOpen: (mode: DialogMode) => void;
}
type DialogMode = 'card' | 'help_menu';
interface StudioAnnouncementDialogProps {
  announcements: StudioAnnouncementDocument[];
  onClose: () => void;
  mode: DialogMode;
}
/**
 * Renders the studio announcement dialog displaying unseen announcements.
 * @internal
 * @hidden
 */
declare function StudioAnnouncementsDialog({
  announcements,
  onClose,
  mode
}: StudioAnnouncementDialogProps): react.JSX.Element;
/**
 * @internal
 * @hidden
 */
declare function isValidAnnouncementAudience(document: {
  audience: StudioAnnouncementDocument['audience'];
  studioVersion: StudioAnnouncementDocument['studioVersion'];
}, sanityVersion: string): boolean;
/**
 * @internal
 * @hidden
 */
declare function isValidAnnouncementRole(audience: StudioAnnouncementDocument['audienceRole'] | undefined, userRoles: Role[] | undefined): boolean;
/** @internal */
interface NavbarContextValue {
  onSearchFullscreenOpenChange: (open: boolean) => void;
  onSearchOpenChange: (open: boolean) => void;
  searchFullscreenOpen: boolean;
  searchFullscreenPortalEl: HTMLElement | null;
  searchOpen: boolean;
}
/**
 * The Studio Layout component is the root component of the Sanity Studio UI.
 * It renders the navbar, the active tool, and the search modal as well as the error boundary.
 *
 * @public
 * @returns A Studio Layout element that renders the navbar, the active tool, and the search modal as well as the error boundary
 * @remarks This component should be used as a child component to the StudioProvider
 * @example Rendering a Studio Layout
 * ```ts
 * <StudioProvider
 *  basePath={basePath}
 *  config={config}
 *  onSchemeChange={onSchemeChange}
 *  scheme={scheme}
 *  unstable_history={unstable_history}
 *  unstable_noAuthBoundary={unstable_noAuthBoundary}
 * >
 *   <StudioLayout />
 *</StudioProvider>
 * ```
 */
declare function StudioLayout(): react.JSX.Element;
/**
 * @internal
 * The default Studio Layout component
 * */
declare function StudioLayoutComponent(): react.JSX.Element;
/**
 * @hidden
 * @beta */
interface StudioProviderProps extends StudioProps {
  children: ReactNode;
}
/**
 * @hidden
 * @beta */
declare function StudioProvider({
  children,
  config,
  basePath,
  onSchemeChange,
  scheme,
  unstable_history: history,
  unstable_noAuthBoundary: noAuthBoundary
}: StudioProviderProps): react.JSX.Element;
interface UpsellDialogActionsInfo {
  feature: 'comments' | 'scheduled_publishing' | 'ai_assist' | 'tasks';
  type: 'modal' | 'inspector';
}
/** @internal */
interface UpsellDialogViewedInfo extends UpsellDialogActionsInfo {
  source: 'field_action' | 'document_toolbar' | 'document_action' | 'navbar' | 'link' | 'pte';
}
/**
 * @internal
 */
declare const UpsellDialogViewed: _sanity_telemetry0.DefinedTelemetryLog<UpsellDialogViewedInfo>;
/**
 * @internal
 */
declare const UpsellDialogDismissed: _sanity_telemetry0.DefinedTelemetryLog<UpsellDialogActionsInfo>;
/**
 * @internal
 */
declare const UpsellDialogUpgradeCtaClicked: _sanity_telemetry0.DefinedTelemetryLog<UpsellDialogActionsInfo>;
/**
 * @internal
 */
declare const UpsellDialogLearnMoreCtaClicked: _sanity_telemetry0.DefinedTelemetryLog<UpsellDialogActionsInfo>;
/** @internal */
type InterpolationProp = {
  [key: string]: string | number;
};
interface DescriptionSerializerProps {
  blocks: PortableTextBlock[];
  onLinkClick?: ({
    url,
    linkTitle
  }: {
    url: string;
    linkTitle: string;
  }) => void;
  interpolation?: InterpolationProp;
}
/**
 * Portable text serializer for the description text for upsell elements.
 * Not meant for public consumption.
 * @internal
 */
declare function UpsellDescriptionSerializer(props: DescriptionSerializerProps): react.JSX.Element;
/** @internal */
interface WorkspaceProviderProps {
  workspace: Workspace;
  children: React.ReactNode;
}
/** @internal */
declare function WorkspaceProvider({
  children,
  workspace
}: WorkspaceProviderProps): React.JSX.Element;
/**
 * @hidden
 * @beta */
declare function useWorkspace(): Workspace;
/**
 * @internal
 */
interface ErrorMessageProps {
  message: string;
  stack?: string;
  error: unknown;
  path: Array<{
    name: string;
    type: string;
  }>;
}
/**
 * @internal
 */
declare function ErrorMessage({
  error,
  message,
  path,
  stack
}: ErrorMessageProps): react.JSX.Element;
interface WorkspaceLoaderProps {
  children: ReactNode;
  ConfigErrorsComponent: ComponentType;
  LoadingComponent: ComponentType;
}
/**
 * @internal
 */
declare function useWorkspaceLoader(activeWorkspace: WorkspaceSummary): Workspace | null;
/**
 * @internal
 */
declare function WorkspaceLoaderBoundary({
  ConfigErrorsComponent,
  ...props
}: WorkspaceLoaderProps): react.JSX.Element;
/**
 * @beta
 * @hidden
 */
interface UpsellData {
  _createdAt: string;
  _id: string;
  _rev: string;
  _type: string;
  _updatedAt: string;
  id: string;
  image: {
    asset: {
      url: string;
      altText: string | null;
    };
  } | null;
  descriptionText: PortableTextBlock[];
  ctaButton: {
    text: string;
    url: string;
  };
  secondaryButton: {
    url: string;
    text: string;
  };
}
interface CommentsUpsellContextValue {
  upsellDialogOpen: boolean;
  handleOpenDialog: (source: UpsellDialogViewedInfo['source']) => void;
  handleClose: () => void;
  upsellData: UpsellData | null;
  telemetryLogs: {
    dialogSecondaryClicked: () => void;
    dialogPrimaryClicked: () => void;
    panelViewed: (source: UpsellDialogViewedInfo['source']) => void;
    panelDismissed: () => void;
    panelPrimaryClicked: () => void;
    panelSecondaryClicked: () => void;
  };
}
/**
 * @beta
 * @hidden
 */
interface CommentsListProps {
  beforeListNode?: React.ReactNode;
  comments: CommentThreadItem[];
  currentUser: CurrentUser;
  error: Error | null;
  loading: boolean;
  mentionOptions: UserListWithPermissionsHookValue;
  mode: CommentsUIMode;
  onCopyLink?: (id: string) => void;
  onCreateRetry: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, payload: CommentUpdatePayload) => void;
  onNewThreadCreate: (payload: CommentBaseCreatePayload) => void;
  /**
   * @internal
   */
  onPathSelect?: (nextPath: CommentsSelectedPath) => void;
  onReactionSelect?: (id: string, reaction: CommentReactionOption) => void;
  onReply: (payload: CommentBaseCreatePayload) => void;
  onStatusChange?: (id: string, status: CommentStatus) => void;
  readOnly?: boolean;
  /**
   * @internal
   */
  selectedPath: CommentsSelectedPath | null;
  status: CommentStatus;
}
/**
 * @beta
 * @hidden
 */
declare const CommentsList: react.NamedExoticComponent<CommentsListProps & react.RefAttributes<HTMLDivElement>>;
/**
 * @internal
 */
interface CommentInputProps {
  currentUser: CurrentUser;
  expandOnFocus?: boolean;
  focusLock?: boolean;
  focusOnMount?: boolean;
  mentionOptions: UserListWithPermissionsHookValue;
  onBlur?: (e: FormEvent<HTMLDivElement>) => void;
  onChange: (value: PortableTextBlock[]) => void;
  onDiscardCancel?: () => void;
  onDiscardConfirm: () => void;
  onFocus?: (e: FormEvent<HTMLDivElement>) => void;
  onKeyDown?: (e: KeyboardEvent) => void;
  onMentionMenuOpenChange?: (open: boolean) => void;
  onSubmit?: () => void;
  placeholder?: ReactNode;
  readOnly?: boolean;
  renderBlock?: RenderBlockFunction;
  value: PortableTextBlock[] | null;
  withAvatar?: boolean;
  avatarSize?: AvatarSize;
}
interface CommentDiscardDialogController {
  open: () => void;
  close: () => void;
}
/**
 * @internal
 */
interface CommentInputHandle {
  blur: () => void;
  discardDialogController: CommentDiscardDialogController;
  focus: () => void;
  scrollTo: () => void;
  reset: () => void;
}
/**
 * @internal
 * @hidden
 */
declare const CommentInput: react.ForwardRefExoticComponent<CommentInputProps & react.RefAttributes<CommentInputHandle>>;
interface CommentInputContextValue {
  canSubmit?: boolean;
  closeMentions: () => void;
  editor: PortableTextEditor;
  expandOnFocus?: boolean;
  focused: boolean;
  focusEditor: () => void;
  focusOnMount?: boolean;
  hasChanges: boolean;
  insertAtChar: () => void;
  insertMention: (userId: string) => void;
  mentionOptions: UserListWithPermissionsHookValue;
  mentionsMenuOpen: boolean;
  mentionsSearchTerm: string;
  onBeforeInput: (event: InputEvent) => void;
  openMentions: () => void;
  readOnly: boolean;
  value: CommentMessage;
}
interface CommentInlineHighlightSpanProps {
  children: React.ReactNode;
  isAdded?: boolean;
  isAuthoring?: boolean;
  isHovered?: boolean;
  isNested?: boolean;
}
/**
 * @internal
 */
declare const CommentInlineHighlightSpan: react.ForwardRefExoticComponent<Omit<CommentInlineHighlightSpanProps & react.HTMLProps<HTMLSpanElement>, "ref"> & react.RefAttributes<HTMLSpanElement>>;
/**
 * @internal
 * @hidden
 */
declare const COMMENTS_INSPECTOR_NAME = "sanity/comments";
/**
 * @internal
 */
declare function hasCommentMessageValue(value: CommentMessage): boolean;
/**
 * A function that checks whether a comment is a text selection comment
 * @internal
 */
declare function isTextSelectionComment(comment: CommentDocument): boolean;
/**
 * @beta
 * @hidden
 */
interface CommentsContextValue {
  documentId: string;
  documentType: string;
  getComment: (id: string) => CommentDocument | undefined;
  getCommentLink?: (id: string) => string;
  selectedCommentId?: string | undefined;
  onClearSelectedComment?: () => void;
  isCreatingDataset: boolean;
  isCommentsOpen?: boolean;
  onCommentsOpen?: () => void;
  isConnecting?: boolean;
  onPathOpen?: (path: Path) => void;
  comments: {
    data: {
      open: CommentThreadItem[];
      resolved: CommentThreadItem[];
    };
    error: Error | null;
    loading: boolean;
  };
  operation: {
    create: CommentOperations['create'];
    remove: CommentOperations['remove'];
    update: CommentOperations['update'];
    react: CommentOperations['react'];
  };
  mentionOptions: UserListWithPermissionsHookValue;
  status: CommentStatus;
  setStatus: (status: CommentStatus) => void;
}
/**
 * @beta
 * @hidden
 */
declare function useComments(): CommentsContextValue;
type CommentsEnabledContextValue = {
  enabled: false;
  mode: null;
} | {
  enabled: true;
  mode: CommentsUIMode;
};
/**
 * @beta
 * @hidden
 */
declare function useCommentsEnabled(): CommentsEnabledContextValue;
interface CommentsOnboardingContextValue {
  isDismissed: boolean;
  setDismissed: () => void;
}
/**
 * @internal
 */
declare function useCommentsSelectedPath(): CommentsSelectedPathContextValue;
interface CommentsTelemetryHookValue {
  commentLinkCopied: () => void;
  commentListViewChanged: (view: CommentStatus) => void;
  commentViewedFromLink: () => void;
}
/** @internal */
declare function useCommentsTelemetry(): CommentsTelemetryHookValue;
interface BuildRangeDecorationsProps {
  comments: CommentDocument[];
  currentHoveredCommentId: string | null;
  onDecorationClick: (commentId: string) => void;
  onDecorationHoverEnd: (commentId: null) => void;
  onDecorationHoverStart: (commentId: string) => void;
  onDecorationMoved: (details: RangeDecorationOnMovedDetails) => void;
  selectedThreadId: string | null;
  value: PortableTextBlock[] | undefined;
}
/**
 * @internal
 */
declare function buildCommentRangeDecorations(props: BuildRangeDecorationsProps): RangeDecoration[];
/**
 * @internal
 */
interface BuildCommentsRangeDecorationsProps {
  value: PortableTextBlock[] | undefined;
  comments: CommentDocument[];
}
/**
 * @internal
 */
interface BuildCommentsRangeDecorationsResultItem {
  selection: RangeDecoration['selection'];
  comment: CommentDocument;
  range: CommentsTextSelectionItem;
}
/**
 * A function that builds range decoration selections from comments and their associated text.
 * @internal
 */
declare function buildRangeDecorationSelectionsFromComments(props: BuildCommentsRangeDecorationsProps): BuildCommentsRangeDecorationsResultItem[];
interface BuildSelectionFromFragmentProps {
  fragment: PortableTextBlock[];
  value: PortableTextBlock[];
  selection: EditorSelection;
}
/**
 * @internal
 */
declare function buildTextSelectionFromFragment(props: BuildSelectionFromFragmentProps): CommentTextSelection;
/** @internal */
interface CollapseMenuProps {
  children: ReactNode | ReactNode[];
  collapsed?: boolean;
  collapseText?: boolean;
  disableRestoreFocusOnClose?: boolean;
  gap?: number | number[];
  menuButtonProps?: Omit<MenuButtonProps$1, 'id' | 'menu' | 'button'> & {
    id?: string;
    button?: React.JSX.Element;
  };
  onMenuClose?: () => void;
}
/** @internal */
declare const CollapseMenu: react.ForwardRefExoticComponent<CollapseMenuProps & react.RefAttributes<any>>;
/** @internal */
declare const AutoCollapseMenu: react.ForwardRefExoticComponent<Omit<CollapseMenuProps, "children" | "collapsed"> & {
  menuOptions: react.JSX.Element[];
} & react.RefAttributes<HTMLDivElement>>;
/** @internal */
interface CommonProps extends Omit<ButtonProps$1, 'text' | 'iconRight'> {
  as?: ElementType | keyof React.JSX.IntrinsicElements;
  dividerBefore?: boolean;
  focused?: boolean;
  tooltipProps?: TooltipProps$1;
  tooltipText?: ReactNode;
}
/** @internal */
interface CollapseMenuButtonProps extends CommonProps {
  collapsedProps?: Omit<CommonProps, 'text'>;
  expandedProps?: CommonProps;
  text: string;
}
/** @internal */
declare const CollapseMenuButton: react.ForwardRefExoticComponent<Omit<CollapseMenuButtonProps & Omit<HTMLProps<HTMLButtonElement>, "as" | "size">, "ref"> & react.RefAttributes<HTMLButtonElement>>;
/** @internal */
declare function useOnScroll(callback: Subscriber<Event>): void;
/** @internal */
interface ScrollContainerProps<T extends ElementType> extends Omit<HTMLProps<T>, 'as' | 'onScroll'> {
  as?: ElementType | keyof React.JSX.IntrinsicElements;
  onScroll?: (event: Event) => () => void;
}
/**
 * This provides a utility function for use within Sanity Studios to create scrollable containers
 * It also provides a way for components inside a scrollable container to track onScroll on their first parent scroll container
 * NOTE: this is used by different studio utilities to track positions of elements on screen
 * NOTE: It will call any given `onScroll` callback with a Native DOM Event, and not a React Synthetic event
 * NOTE: It will not make sure the element is actually scrollable, this still needs to be done with css as usual
 *
 * @internal
 */
declare const ScrollContainer: react.NamedExoticComponent<Omit<ScrollContainerProps<ElementType>, "ref"> & react.RefAttributes<HTMLDivElement>>;
/** @internal */
type ScrollEventHandler = (event: Event) => void;
/** @internal */
interface ScrollContextValue {
  onScroll?: ScrollEventHandler;
}
interface SanityCreateConfigProviderProps {
  children: ReactNode;
}
/**
 * @internal
 */
declare function SanityCreateConfigProvider(props: SanityCreateConfigProviderProps): React.JSX.Element;
interface StudioAppResponse {
  id: string;
  title?: string;
  type: 'studio' | string;
  urlType: 'internal' | 'external' | string;
  appHost: string;
}
interface StudioApp extends StudioAppResponse {
  studioUrl: string;
}
interface CompatibleStudioAppId {
  /**
   * AppId to use for the current origin
   */
  appId: string | undefined;
  /**
   * All available studio apps
   */
  studioApps: StudioApp[];
}
interface AppIdCache {
  get: (args: {
    projectId: string;
    appIdFetcher: AppIdFetcher;
  }) => Promise<CompatibleStudioAppId | undefined>;
}
type AppIdFetcher = (projectId: string) => Promise<CompatibleStudioAppId>;
/** @internal */
interface CreateLinkMetadata {
  /** Create document ID */
  _id: string;
  /** Create user dataset ID */
  dataset: string;
  /**  If false, document should be put in a limited read-only state. */
  ejected: boolean;
  /**  set if Create document originates non-default origin */
  host?: string;
}
/** @internal */
interface CreateLinkedSanityDocument extends SanityDocument {
  _create?: CreateLinkMetadata;
}
/** @internal */
interface CreateLinkedActionsProps {
  metadata: CreateLinkMetadata;
  panelPortalElementId: string;
  onDocumentChange: (patchEvent: PatchEvent) => void;
  documentTitle?: string;
}
/** @internal */
interface CreateLinkedDocumentBannerContentProps {
  metadata: CreateLinkMetadata;
}
/**
 * @internal
 */
interface SanityCreateConfigContextValue {
  /**
   * A boolean indicating whether "Start in Create" new document pane footer should be shown, when available.
   */
  startInCreateEnabled: boolean;
  fallbackStudioOrigin?: string;
  appIdCache?: AppIdCache;
  components?: {
    documentLinkedBannerContent: ComponentType<CreateLinkedDocumentBannerContentProps> | undefined;
    documentLinkedActions: ComponentType<CreateLinkedActionsProps> | undefined;
  };
}
/**
 * @internal
 */
declare function useSanityCreateConfig(): SanityCreateConfigContextValue;
/**
 * @internal
 */
declare function getSanityCreateLinkMetadata(doc: SanityDocumentLike | undefined): CreateLinkMetadata | undefined;
/**
 * @internal
 */
declare function isSanityCreateLinked(metadata: CreateLinkMetadata | undefined): boolean;
/**
 * @internal
 */
declare function isSanityCreateLinkedDocument(doc: SanityDocumentLike | undefined): boolean;
/**
 * @internal
 */
declare function isSanityCreateExcludedType(schemaType: SchemaType): boolean;
/**
 * Documents with fields with a value (non-underscore-prefixed) are not supported by Start in Create yet,
 * because Create would overwrite them.
 * This includes pristine new documents with initialValues or created from initial value templates.
 * @internal
 */
declare function isSanityCreateStartCompatibleDoc(doc: SanityDocumentLike): boolean;
/** @internal */
declare const isDev: boolean;
/** @internal */
declare const isProd: boolean;
/** @internal */
type HexColor = string;
/** @internal */
type UserColorHue = string;
/** @internal */
type UserId = string;
/** @internal */
interface UserColor {
  name: ColorHueKey;
  background: HexColor;
  border: HexColor;
  text: HexColor;
  tints: ColorTints;
}
/** @internal */
interface UserColorManager {
  get: (userId: UserId | null) => UserColor;
  listen: (userId: UserId) => Observable<UserColor>;
}
/** @internal */
declare function useUserColorManager(): UserColorManager;
/** @internal */
declare function useUserColor(userId: string | null): UserColor;
/** @internal */
interface UserColorManagerOptions {
  anonymousColor?: UserColor;
  userStore?: {
    me: Observable<{
      id: string;
    } | null>;
  };
  colors?: Record<UserColorHue, UserColor>;
  currentUserColor?: UserColorHue;
  scheme: ThemeColorSchemeKey;
}
/** @internal */
declare function createUserColorManager(options: UserColorManagerOptions): UserColorManager;
/** @internal */
interface UserColorManagerProviderProps {
  children: ReactNode;
  manager?: UserColorManager;
}
/** @internal */
declare function UserColorManagerProvider({
  children,
  manager: managerFromProps
}: UserColorManagerProviderProps): React.JSX.Element;
/**
 * Events relevant for the whole document group.
 * @hidden
 * @beta
 */
type DocumentGroupEvent = CreateDocumentVersionEvent | DeleteDocumentVersionEvent | PublishDocumentVersionEvent | UnpublishDocumentEvent | ScheduleDocumentVersionEvent | UnscheduleDocumentVersionEvent | DeleteDocumentGroupEvent | CreateLiveDocumentEvent | UpdateLiveDocumentEvent | EditDocumentVersionEvent | HistoryClearedEvent;
/**
 * @hidden
 * @beta
 */
declare const isCreateDocumentVersionEvent: (event: Partial<DocumentGroupEvent>) => event is CreateDocumentVersionEvent;
/**
 * @hidden
 * @beta
 */
declare const isDeleteDocumentVersionEvent: (event: Partial<DocumentGroupEvent>) => event is DeleteDocumentVersionEvent;
/**
 * @hidden
 * @beta
 */
declare const isPublishDocumentVersionEvent: (event: Partial<DocumentGroupEvent>) => event is PublishDocumentVersionEvent;
/**
 * @hidden
 * @beta
 */
declare const isUnpublishDocumentEvent: (event: Partial<DocumentGroupEvent>) => event is UnpublishDocumentEvent;
/**
 * @hidden
 * @beta
 */
declare const isScheduleDocumentVersionEvent: (event: Partial<DocumentGroupEvent>) => event is ScheduleDocumentVersionEvent;
/**
 * @hidden
 * @beta
 */
declare const isUnscheduleDocumentVersionEvent: (event: Partial<DocumentGroupEvent>) => event is UnscheduleDocumentVersionEvent;
/**
 * @hidden
 * @beta
 */
declare const isDeleteDocumentGroupEvent: (event: Partial<DocumentGroupEvent>) => event is DeleteDocumentGroupEvent;
/**
 * @hidden
 * @beta
 */
declare const isCreateLiveDocumentEvent: (event: Partial<DocumentGroupEvent>) => event is CreateLiveDocumentEvent;
/**
 * @hidden
 * @beta
 */
declare const isUpdateLiveDocumentEvent: (event: Partial<DocumentGroupEvent>) => event is UpdateLiveDocumentEvent;
/**
 * @hidden
 * @beta
 */
declare const isEditDocumentVersionEvent: (event: Partial<DocumentGroupEvent>) => event is EditDocumentVersionEvent;
/**
 * A generic event with a type and a timestamp.
 * @hidden
 * @beta
 */
interface BaseEvent {
  id: string;
  timestamp: string;
  author: string;
  /**
   * This is added client side to enhance the UI.
   */
  documentVariantType: DocumentVariantType;
}
/**
 * @hidden
 * @beta
 */
interface CreateDocumentVersionEvent extends BaseEvent {
  type: 'createDocumentVersion';
  documentId: string;
  releaseId?: string;
  versionId: string;
  versionRevisionId: string;
  /**
   * This is undefined for versions and drafts. (will be present only in publish document?)
   */
  revisionId?: string;
  /**
   * This is present when this creation event is already published.
   */
  parentId?: string;
}
/**
 * @hidden
 * @beta
 */
interface HistoryClearedEvent extends BaseEvent {
  type: 'historyCleared';
  documentId: string;
}
/**
 * @hidden
 * @beta
 */
interface DeleteDocumentVersionEvent extends BaseEvent {
  type: 'deleteDocumentVersion';
  documentId: string;
  releaseId?: string;
  versionId: string;
  versionRevisionId: string;
  /**
   * This is added client side to enhance the UI.
   * For draft documents, it indicates the event that created this document that was later published
   * It will be used to expand the publish view.
   */
  creationEvent?: CreateDocumentVersionEvent;
}
/**
 * @hidden
 * @beta
 */
interface PublishDocumentVersionEvent extends BaseEvent {
  type: 'publishDocumentVersion';
  documentId: string;
  revisionId: string;
  versionId: string;
  releaseId?: string;
  /** This is only available when it was triggered by Publish action. */
  versionRevisionId?: string;
  publishCause: 'document.publish' | 'release.publish' | 'release.schedule';
  contributors?: string[];
  /**
   * This is added client side to enhance the UI.
   */
  release?: ReleaseDocument | {
    _id: string;
    metadata?: undefined;
  };
  /**
   * This is added client side to enhance the UI.
   * For draft documents, it indicates the event that created this document that was later published
   * It will be used to expand the publish view.
   */
  creationEvent?: CreateDocumentVersionEvent;
}
/**
 * @hidden
 * @beta
 */
interface UnpublishDocumentEvent extends BaseEvent {
  type: 'unpublishDocument';
  documentId: string;
  /** The version that was created based on it */
  versionId: string;
  versionRevisionId: string;
  releaseId?: string;
  author: string;
}
/**
 * @hidden
 * @beta
 */
interface ScheduleDocumentVersionEvent extends BaseEvent {
  type: 'scheduleDocumentVersion';
  documentId: string;
  releaseId: string;
  versionId: string;
  versionRevisionId: string;
  /** The _current_ state of this schedule. */
  state: 'pending' | 'unscheduled' | 'published';
  author: string;
  publishAt: string;
}
/**
 * @hidden
 * @beta
 */
interface UnscheduleDocumentVersionEvent extends BaseEvent {
  type: 'unscheduleDocumentVersion';
  documentId: string;
  releaseId: string;
  versionId: string;
  versionRevisionId: string;
  author: string;
}
/**
 * @hidden
 * @beta
 */
interface DeleteDocumentGroupEvent extends BaseEvent {
  type: 'deleteDocumentGroup';
  documentId: string;
  author: string;
}
/**
 * @hidden
 * @beta
 */
interface CreateLiveDocumentEvent extends BaseEvent {
  type: 'createLiveDocument';
  documentId: string;
  revisionId: string;
  author: string;
}
/**
 * @hidden
 * @beta
 */
interface UpdateLiveDocumentEvent extends BaseEvent {
  type: 'updateLiveDocument';
  documentId: string;
  revisionId: string;
  author: string;
}
/**
 * @hidden
 * @beta
 * This event won't be exposed by the API, it needs to be generated by validating the
 * transactions that occurred between two events. Usually, between two PublishDocumentEvents.
 * Or a create event and a publish event.
 */
interface EditDocumentVersionEvent extends BaseEvent {
  type: 'editDocumentVersion';
  documentId: string;
  contributors: string[];
  releaseId?: string;
  /**
   * One edit event could contain multiple transactions that are merged together.
   * This represents the newest transaction in the merged events.
   */
  revisionId: string;
  transactions: {
    type: 'editTransaction';
    author: string;
    timestamp: string;
    revisionId: string;
  }[];
  /**
   * Present when an edit was already published, then the user decided to expand the event.
   */
  parentId?: string;
}
/**
 * @hidden
 * @beta
 */
interface EventsStoreRevision {
  revisionId: string;
  loading: boolean;
  document?: SanityDocument | null;
}
/**
 * @internal
 * */
interface EventsStore {
  events: DocumentGroupEvent[];
  nextCursor: string | null;
  loading: boolean;
  error: Error | null;
  revision: EventsStoreRevision | null;
  sinceRevision: EventsStoreRevision | null;
  findRangeForRevision: (nextRev: string) => [string | null, string | null];
  findRangeForSince: (nextSince: string) => [string | null, string | null];
  loadMoreEvents: () => void;
  getChangesList: () => Observable<{
    diff: ObjectDiff$1 | null;
    loading: boolean;
    error: Error | null;
  }>;
  expandEvent: (event: DocumentGroupEvent) => Promise<void>;
}
/**
 * @internal
 **/
type DocumentVersionEventType = DocumentGroupEvent['type'];
interface EventsProviderProps {
  value: EventsStore;
  children: React.ReactNode;
}
/**
 * @internal
 */
declare function EventsProvider({
  value,
  children
}: EventsProviderProps): react.JSX.Element;
/**
 * @internal
 */
declare function useEvents(): EventsStore;
/**
 * @internal
 */
declare function useEventsStore({
  documentId,
  documentType,
  rev,
  since
}: {
  documentId: string;
  documentType: string;
  rev?: string | '@lastEdited' | '@lastPublished';
  since?: string | '@lastPublished';
}): EventsStore;
/** @internal */
interface FieldValueError {
  /**
   * i18n key for the error message
   */
  messageKey: StudioLocaleResourceKeys;
  /**
   * The expected type of the value
   */
  expectedType: string;
  /**
   * The actual type of the value
   */
  actualType: string;
  /**
   * The actual value of the field
   */
  value: unknown;
}
/** @internal */
declare function getValueError(value: unknown, schemaType: SchemaType): FieldValueError | undefined;
/**
 * History timeline / chunking
 *
 *
 * @hidden
 * @beta
 */
type ChunkType = 'initial' | 'create' | 'editDraft' | 'delete' | 'publish' | 'unpublish' | 'discardDraft' | 'editLive';
/**
 * @hidden
 * @beta */
type Chunk = {
  index: number;
  id: string;
  type: ChunkType;
  start: number;
  end: number;
  startTimestamp: string;
  endTimestamp: string;
  authors: Set<string>;
  draftState: 'present' | 'missing' | 'unknown';
  publishedState: 'present' | 'missing' | 'unknown';
};
/**
 * Annotation connected to a change
 *
 *
 * @hidden
 * @beta
 */
type AnnotationDetails = {
  event?: DocumentGroupEvent;
  timestamp: string;
  author: string;
};
/**
 * @hidden
 * @beta */
type Annotation = AnnotationDetails | null;
/** @internal */
type ArrayDiff$1<V = unknown> = ArrayDiff<Annotation, V>;
/** @internal */
type BooleanDiff$1 = BooleanDiff<Annotation>;
/** @internal */
type NullDiff$1 = NullDiff<Annotation>;
/** @internal */
type NumberDiff$1 = NumberDiff<Annotation>;
/** @internal */
type ObjectDiff$1<T extends object = Record<string, any>> = ObjectDiff<Annotation, T>;
/** @internal */
type StringDiff$1 = StringDiff<Annotation>;
/** @internal */
type ReferenceDiff = ObjectDiff$1<Reference>;
/** @internal */
type TypeChangeDiff$1 = TypeChangeDiff<Annotation>;
/** @internal */
type Diff$1<A = unknown, O extends object = Record<string, any>> = ArrayDiff$1<A> | BooleanDiff$1 | NullDiff$1 | NumberDiff$1 | ObjectDiff$1<O> | StringDiff$1 | TypeChangeDiff$1;
/** @internal */
type StringDiffSegment = StringSegmentChanged$1 | StringSegmentUnchanged$1;
/** @internal */
type StringSegmentChanged$1 = StringSegmentChanged<Annotation>;
/** @internal */
type StringSegmentUnchanged$1 = StringSegmentUnchanged;
/** @internal */
type ItemDiff$1 = ItemDiff<Annotation>;
/**
 * Diff extensions for presentational concerns
 *
 * @internal
 */
interface ArrayItemMetadata {
  fromType?: SchemaType;
  toType?: SchemaType;
}
/**
 * Diff components
 *
 * @internal
 */
type DiffComponent<T extends Diff$1 = Diff$1> = ComponentType<DiffProps<T>>;
/** @internal */
type DiffComponentOptions<T extends Diff$1 = Diff$1> = {
  component: DiffComponent<T>;
  showHeader?: boolean;
};
/** @internal */
type DiffProps<T extends Diff$1 = Diff$1> = {
  diff: T;
  schemaType: T extends ObjectDiff$1 ? ObjectSchemaType : T extends ArrayDiff$1 ? ArraySchemaType : T extends BooleanDiff$1 ? BooleanSchemaType : T extends StringDiff$1 ? StringSchemaType : T extends NumberDiff$1 ? NumberSchemaType : SchemaType;
};
/**
 * Resolvers
 *
 * @internal
 */
type DiffComponentResolver = (options: {
  schemaType: SchemaType;
  parentSchemaType?: ArraySchemaType | ObjectSchemaType;
}) => ComponentType<any> | DiffComponentOptions<any> | undefined;
/**
 * Schema
 */
/**
 * "Changes" (presentation-oriented grouping of diffs)
 *
 * @internal
 */
interface GroupChangeNode {
  type: 'group';
  changes: ChangeNode[];
  key: string;
  path: Path;
  titlePath: ChangeTitlePath;
  schemaType?: SchemaType;
  readOnly?: ConditionalProperty;
  hidden?: ConditionalProperty;
  fieldsetName?: string;
}
/** @internal */
interface FieldChangeNode {
  type: 'field';
  diff: Diff$1;
  itemDiff?: ItemDiff$1;
  parentDiff?: ObjectDiff$1 | ArrayDiff$1;
  key: string;
  path: Path;
  error?: FieldValueError;
  titlePath: ChangeTitlePath;
  schemaType: ObjectFieldType;
  showHeader: boolean;
  showIndex: boolean;
  diffComponent?: DiffComponent;
  parentSchema?: ArraySchemaType | ObjectSchemaType;
  readOnly?: ConditionalProperty;
  hidden?: ConditionalProperty;
}
/** @internal */
type ChangeNode = GroupChangeNode | FieldChangeNode;
/** @internal */
interface FromToIndex {
  hasMoved: boolean;
  fromIndex?: number;
  toIndex?: number;
  annotation?: Annotation;
}
/** @internal */
type ChangeTitlePath = (string | FromToIndex)[];
/** @internal */
interface FieldOperationsAPI {
  patch: {
    execute: (patches: PatchOperations[]) => void;
  };
}
/** @internal */
declare function getAnnotationColor(colorManager: UserColorManager, annotation?: Annotation | null): UserColor;
/** @internal */
declare function getAnnotationAtPath(diff: Diff$1, diffPath: string | Path): Annotation | undefined;
/** @internal */
declare function getDiffAtPath(diff: Diff$1, diffPath: string | Path): Diff$1 | undefined;
/** @internal */
type DiffVisitor = (diff: Diff$1 | StringDiffSegment, path: Path) => boolean;
/**
 * Visit all diffs in tree, until visitor returns false
 *
 * @param diff - Diff to visit
 * @param visitor - Visitor function, return false to stop from going deeper
 *
 * @internal
 */
declare function visitDiff(diff: Diff$1 | StringDiffSegment, visitor: DiffVisitor, path?: Path): void;
/** @internal */
declare function useAnnotationColor(annotation?: Annotation | null): UserColor;
/** @internal */
declare function useDiffAnnotationColor(diff: Diff$1, path?: string | Path): UserColor;
/** @internal */
declare function ChangeBreadcrumb(props: {
  change?: FieldChangeNode;
  titlePath: ChangeTitlePath;
}): react.JSX.Element;
/** @internal */
interface ChangeListProps {
  schemaType: ObjectSchemaType;
  diff: ObjectDiff$1;
  fields?: string[];
}
/** @internal */
declare function ChangeList({
  diff,
  fields,
  schemaType
}: ChangeListProps): React.JSX.Element | null;
/** @internal */
interface ChangeResolverProps {
  change: ChangeNode;
  readOnly?: ConditionalProperty;
  hidden?: ConditionalProperty;
  addParentWrapper?: boolean;
}
/** @internal */
declare function ChangeResolver(props: ChangeResolverProps): react.JSX.Element | null;
/**
 * @internal
 * */
declare function ChangesError({
  error
}: {
  error?: Error | null;
}): react.JSX.Element;
/** @internal */
declare function ChangeTitleSegment(props: {
  change?: FieldChangeNode;
  segment: string | FromToIndex;
}): react.JSX.Element;
/**
 * @internal
 * mapping of events types with a readable key for translation
 */
declare const TIMELINE_ITEM_I18N_KEY_MAPPING: Record<DocumentVariantType, Record<DocumentVersionEventType, StudioLocaleResourceKeys>>;
/** @internal */
interface DiffCardProps {
  annotation?: Annotation;
  as?: ElementType | keyof React.JSX.IntrinsicElements;
  diff?: Diff$1;
  disableHoverEffect?: boolean;
  path?: Path | string;
  tooltip?: {
    description?: ReactNode;
  } | boolean;
}
/** @internal */
declare const DiffCard: react.ForwardRefExoticComponent<Omit<DiffCardProps & Omit<HTMLProps<HTMLElement>, "as" | "height">, "ref"> & react.RefAttributes<unknown>>;
/** @internal */
interface DiffErrorBoundaryProps {
  children: ReactNode;
  t: TFunction$1;
}
/** @internal */
interface DiffErrorBoundaryState {
  error?: Error;
}
/** @internal */
declare class DiffErrorBoundary extends Component<DiffErrorBoundaryProps, DiffErrorBoundaryState> {
  static getDerivedStateFromError(error: Error): {
    error: Error;
  };
  state: DiffErrorBoundaryState;
  componentDidCatch(error: Error): void;
  render(): string | number | bigint | boolean | react.JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | Iterable<ReactNode> | react.ReactElement<unknown, string | react.JSXElementConstructor<any>> | react.ReactPortal | null | undefined> | null | undefined;
}
/** @internal */
type FieldPreviewComponent<T = any> = ComponentType<{
  color?: UserColor;
  schemaType: T extends Array<any> ? ArraySchemaType : T extends boolean ? BooleanSchemaType : T extends string ? StringSchemaType : T extends number ? NumberSchemaType : T extends Reference ? ReferenceSchemaType : T extends object ? ObjectSchemaType : any;
  value: T;
}>;
/** @internal */
interface DiffFromToProps {
  align?: 'top' | 'center' | 'bottom';
  cardClassName?: string;
  diff: Diff$1;
  layout?: 'grid' | 'inline';
  path?: Path | string;
  previewComponent: FieldPreviewComponent;
  schemaType: SchemaType;
}
/** @internal */
declare function DiffFromTo(props: DiffFromToProps): react.JSX.Element;
/** @internal */
interface DiffInspectWrapperProps {
  children: ReactNode;
  change: FieldChangeNode;
  as?: ExecutionProps['as'];
}
/** @internal */
declare function DiffInspectWrapper(props: DiffInspectWrapperProps & BoxProps): React.JSX.Element;
/** @internal */
declare function DiffStringSegment(props: {
  segment: StringDiffSegment;
}): React.JSX.Element;
/** @internal */
declare function DiffString(props: {
  diff: StringDiff$1;
}): react.JSX.Element;
/** @internal */
interface DiffTooltipProps extends TooltipProps$1 {
  children: React.JSX.Element;
  description?: ReactNode;
  diff: Diff$1;
  path?: Path | string;
}
/** @internal */
interface DiffTooltipWithAnnotationsProps extends TooltipProps$1 {
  annotations: AnnotationDetails[];
  children: React.JSX.Element;
  description?: ReactNode;
}
/** @internal */
declare function DiffTooltip(props: DiffTooltipProps | DiffTooltipWithAnnotationsProps): react.JSX.Element;
interface TimelineItemProps {
  event: DocumentGroupEvent;
  showChangesBy: 'tooltip' | 'inline' | 'hidden';
}
/**
 * @internal
 */
declare function Event$1({
  event,
  showChangesBy
}: TimelineItemProps): react.JSX.Element;
/** @internal */
declare const FallbackDiff: DiffComponent<Diff$1<unknown, Record<string, unknown>>>;
/** @internal */
declare function FieldChange(props: {
  change: FieldChangeNode;
  readOnly?: boolean;
  hidden?: boolean;
  addParentWrapper?: boolean;
} & HTMLAttributes<HTMLDivElement>): react.JSX.Element | null;
/** @internal */
type FromToProps = {
  align?: 'top' | 'center' | 'bottom';
  layout?: 'grid' | 'inline';
  from?: ReactNode;
  to?: ReactNode;
} & Omit<HTMLProps<HTMLDivElement>, 'children' | 'as' | 'height' | 'wrap'>;
/** @internal */
declare const FromTo: react.ForwardRefExoticComponent<Omit<FromToProps, "ref"> & react.RefAttributes<HTMLDivElement>>;
/** @internal */
type FromToArrowDirection = 'down' | 'right';
/** @internal */
declare function FromToArrow(props: {
  direction?: FromToArrowDirection;
} & TextProps & Omit<HTMLProps<HTMLDivElement>, 'children' | 'ref'>): react.JSX.Element;
/** @internal */
declare function GroupChange(props: {
  change: GroupChangeNode;
  readOnly?: boolean;
  hidden?: boolean;
} & HTMLAttributes<HTMLDivElement>): React.JSX.Element | null;
/** @internal */
interface MetaInfoProps {
  title: string;
  action?: string;
  icon?: ComponentType;
  children?: ReactNode;
  markRemoved?: boolean;
}
/** @internal */
declare function MetaInfo(props: MetaInfoProps): react.JSX.Element;
/** @internal */
declare function NoChanges(): react.JSX.Element;
/** @internal */
declare const RevertChangesButton: react.ForwardRefExoticComponent<Omit<ButtonProps$1, "tooltipProps"> & Omit<HTMLProps<HTMLButtonElement>, "ref"> & {
  changeCount: number;
} & react.RefAttributes<HTMLButtonElement>>;
interface RevertChangesConfirmDialogProps {
  open: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  changeCount: number;
  referenceElement: HTMLElement | null;
}
/**
 * @internal
 */
declare function RevertChangesConfirmDialog({
  open,
  onConfirm,
  onCancel,
  changeCount,
  referenceElement
}: RevertChangesConfirmDialogProps): react.JSX.Element;
/** @internal */
declare function ValueError({
  error
}: {
  error: FieldValueError;
}): react.JSX.Element;
/** @internal */
type DocumentChangeContextInstance = {
  documentId: string;
  schemaType: SchemaType;
  rootDiff: ObjectDiff$1 | null;
  isComparingCurrent: boolean;
  FieldWrapper: ComponentType<{
    path: Path;
    children: ReactNode;
    hasRevertHover: boolean;
  }>;
  value: Partial<SanityDocument>;
  /**
   * When comparing two values it decides if it shows the original "from" value in the Diff components.
   * Useful for the DocumentDiff in releases when showing the diff for a new document.
   */
  showFromValue: boolean;
};
/** @internal */
declare function noop(): void;
/** @internal */
declare function isFieldChange(change: ChangeNode): change is FieldChangeNode;
/** @internal */
declare function isGroupChange(change: ChangeNode): change is GroupChangeNode;
/** @internal */
declare function isAddedItemDiff(item: ItemDiff$1): item is ItemDiff$1 & {
  diff: Diff$1 & {
    action: 'added';
  };
};
/** @internal */
declare function isRemovedItemDiff(item: ItemDiff$1): item is ItemDiff$1 & {
  diff: Diff$1 & {
    action: 'removed';
  };
};
/** @internal */
declare function isUnchangedDiff(diff: Diff$1): diff is Diff$1 & {
  action: 'unchanged';
};
/** @internal */
declare function useDocumentChange(): DocumentChangeContextInstance;
/** @internal */
declare function resolveDiffComponent<D extends Diff$1 = any>(type: SchemaType, parentSchemaType?: ArraySchemaType | ObjectSchemaType): DiffComponent<D> | DiffComponentOptions | undefined;
/** @internal */
declare function pathToString(path: Path): string;
/** @internal */
declare function getValueAtPath(rootValue: unknown, path: Path): unknown;
/** @internal */
declare function findIndex(array: unknown[], segment: PathSegment): number;
/** @internal */
declare function stringToPath(path: string): Path;
/** @internal */
declare function normalizePathSegment(segment: string): PathSegment;
/** @internal */
declare function normalizeIndexSegment(segment: string): PathSegment;
/** @internal */
declare function normalizeKeySegment(segment: string): KeyedSegment;
/** @internal */
declare function normalizeIndexTupleSegment(segment: string): IndexTuple;
/** @internal */
declare function pathsAreEqual(pathA: Path, pathB: Path): boolean;
/** @internal */
declare function getItemKey(arrayItem: unknown): string | undefined;
/** @internal */
declare function getItemKeySegment(arrayItem: unknown): KeyedSegment | undefined;
/** @internal */
declare function isEmptyObject(item: unknown): boolean;
/** @internal */
type FIXME = any;
/**
 * @internal
 */
type PerspectiveNotWriteableReason = 'INSUFFICIENT_DATA' | 'RELEASE_NOT_ACTIVE' | 'PUBLISHED_NOT_WRITEABLE' | 'DRAFTS_NOT_WRITEABLE';
/**
 * Check whether the provided schema type can be written to the provided perspective. This depends
 * on factors such as whether the schema type supports live-editing, whether the perspective
 * represents an inactive release, and whether the perspective represents a special group (e.g.
 * published documents).
 *
 * @internal
 */
declare function isPerspectiveWriteable({
  selectedPerspective,
  isDraftModelEnabled,
  schemaType
}: {
  selectedPerspective: TargetPerspective;
  isDraftModelEnabled: boolean;
  schemaType?: ObjectSchemaType;
}): {
  result: true;
} | {
  result: false;
  reason: PerspectiveNotWriteableReason;
};
interface Props$4 {
  withReleasesToolButton?: boolean;
  menuItemProps?: ReleasesNavMenuItemPropsGetter;
}
/**
 * @internal
 */
declare const ReleasesNav: ComponentType<Props$4>;
/**
 * @internal
 */
declare function PerspectiveProvider({
  children,
  selectedPerspectiveName,
  excludedPerspectives
}: {
  children: React.ReactNode;
  selectedPerspectiveName: 'published' | ReleaseId | undefined;
  excludedPerspectives?: string[];
}): react.JSX.Element;
interface ExcludedPerspectiveValue {
  excludedPerspectives: string[];
  toggleExcludedPerspective: (perspectiveId: string) => void;
  isPerspectiveExcluded: (perspectiveId: string) => boolean;
}
/**
 * Gets the excluded perspectives.
 
 * @internal
 */
declare function useExcludedPerspective(): ExcludedPerspectiveValue;
/**
 * @beta
 * Exposes the default perspective based on the draft model enabled status.
 * If the user hasn't opt out from draft, the default perspective is `drafts`
 * Otherwise, the default perspective is `published`
 * @returns The default perspective based on the draft model enabled status.
 */
declare function useGetDefaultPerspective(): 'drafts' | 'published';
/**
 * @beta
 *
 * React hook that returns the current studio perspective and perspective stack.
 *
 * This will use the closest PerspectiveContext provider, which is either the global
 * PerspectiveContext or the DocumentPerspectiveProvider.
 *
 * @returns See {@link PerspectiveContextValue}
 * @example Reading the current perspective stack
 * ```ts
 * function MyComponent() {
 *  const {perspectiveStack} = usePerspective()
 *  // ... do something with the perspective stack , like passing it to the client perspective.
 * }
 * ```
 */
declare function usePerspective(): PerspectiveContextValue;
/**
 * @internal
 */
declare function useSetPerspective(): (releaseId: string | undefined) => void;
type ScheduleAction = 'publish' | 'unpublish';
type ScheduleState = 'cancelled' | 'scheduled' | 'succeeded';
type ScheduleSort = 'createdAt' | 'executeAt';
interface Schedule {
  author: string;
  action: ScheduleAction;
  createdAt: string;
  dataset: string;
  description: string;
  documents: {
    documentId: string;
    documentType?: string;
  }[];
  executeAt: string | null;
  executedAt?: string;
  id: string;
  name: string;
  projectId: string;
  state: ScheduleState;
  stateReason: string;
}
interface ScheduleFormData {
  date: string;
}
interface Props$3 {
  onChange?: (formData: ScheduleFormData) => void;
  value?: ScheduleFormData | null;
}
/**
 * Form for editing a schedule for a document when scheduled publishing is enabled.
 * @deprecated we will be dropping support for scheduled publishing on a future major version
 * @internal
 */
declare function EditScheduleForm(props: PropsWithChildren<Props$3>): react.JSX.Element;
/**
 * @internal
 */
interface SchedulesContextValue {
  activeSchedules: Schedule[];
  schedules: Schedule[];
  schedulesByDate: (date: Date) => Schedule[];
  scheduleState?: ScheduleState;
  selectedDate?: Date;
  setSortBy: (sortBy: ScheduleSort) => void;
  sortBy?: ScheduleSort;
}
/**
 * @hidden
 * @beta */
interface DocumentActionProps extends EditStateFor {
  revision?: string;
  /**
   * @deprecated - do not use, will be removed in a future major version, use local state instead, for example call `setDialogOpen(false)` in dialog's `onCancel` callback.
   */
  onComplete: () => void;
  /**
   * Whether the initial value has been resolved.
   */
  initialValueResolved: boolean;
}
type SanityDefinedAction = 'delete' | 'discardChanges' | 'discardVersion' | 'duplicate' | 'restore' | 'publish' | 'unpublish' | 'unpublishVersion' | 'linkToCanvas' | 'editInCanvas' | 'unlinkFromCanvas' | 'schedule';
/**
 * @beta
 * Indicates whether the action is a Sanity defined action or a custom action.
 *
 * @param action - The action to check.
 * @returns `true` if the action is a Sanity defined action, `false` otherwise.
 */
declare const isSanityDefinedAction: (action: DocumentActionDescription & {
  action?: SanityDefinedAction | undefined;
}) => boolean;
/**
 * @hidden
 * @beta */
interface DocumentActionComponent extends ActionComponent<DocumentActionProps, DocumentActionDescription> {
  /**
   * An optional meta property that can used to replace this document action
   * with another. E.g.:
   *
   * ```js
   * import {defineConfig} from 'sanity'
   * import {MyPublishAction} from '...'
   *
   * export default defineConfig({
   *   document: {
   *     actions: (prev) =>
   *       prev.map((previousAction) =>
   *         previousAction.action === 'publish' ? MyPublishAction : previousAction
   *       ),
   *   },
   * })
   * ```
   */
  action?: SanityDefinedAction;
  /**
   * For debugging purposes
   */
  displayName?: string;
}
/**
 * @hidden
 * @beta
 */
interface DuplicateActionProps extends DocumentActionProps {
  mapDocument?: MapDocument;
}
/**
 * @hidden
 * @beta
 */
interface DuplicateDocumentActionComponent extends ActionComponent<DuplicateActionProps, DocumentActionDescription>, Pick<DocumentActionComponent, 'action' | 'displayName'> {}
/**
 * @hidden
 * @beta */
interface DocumentActionConfirmDialogProps {
  type: 'confirm';
  tone?: ButtonTone;
  message: ReactNode;
  onConfirm: () => void;
  onCancel: () => void;
  cancelButtonIcon?: ComponentType | ReactNode;
  cancelButtonText?: string;
  confirmButtonIcon?: ComponentType | ReactNode;
  confirmButtonText?: string;
}
/**
 * @hidden
 * @beta */
interface DocumentActionModalDialogProps {
  type?: 'dialog';
  content: ReactNode;
  /**
   *
   * @hidden
   * @beta
   */
  footer?: DialogProps['footer'];
  /**
   *
   * @hidden
   * @beta
   */
  header?: ReactNode;
  onClose: () => void;
  showCloseButton?: boolean;
  /**
   *
   * @hidden
   * @beta
   */
  width?: 'small' | 'medium' | 'large' | 'full';
}
/**
 * @hidden
 * @beta */
interface DocumentActionPopoverDialogProps {
  type: 'popover';
  content: ReactNode;
  onClose: () => void;
}
/**
 * @hidden
 * @beta */
interface DocumentActionCustomDialogComponentProps {
  type: 'custom';
  component: ReactNode;
}
/**
 * @hidden
 * @beta */
type DocumentActionDialogProps = DocumentActionConfirmDialogProps | DocumentActionPopoverDialogProps | DocumentActionModalDialogProps | DocumentActionCustomDialogComponentProps;
/**
 * @hidden
 * @beta */
type DocumentActionGroup = 'default' | 'paneActions';
/**
 * @hidden
 * @beta
 */
interface DocumentActionDescription extends GroupableActionDescription<DocumentActionGroup> {
  dialog?: DocumentActionDialogProps | false | null;
}
declare function useScheduleAction(props: DocumentActionProps): {
  disabled: true;
  icon: react.ForwardRefExoticComponent<Omit<react.SVGProps<SVGSVGElement>, "ref"> & react.RefAttributes<SVGSVGElement>>;
  label: string;
  title: react.JSX.Element;
  dialog?: undefined;
  onHandle?: undefined;
} | {
  dialog: false | DocumentActionModalDialogProps;
  disabled: boolean;
  label: string;
  icon: react.ForwardRefExoticComponent<Omit<react.SVGProps<SVGSVGElement>, "ref"> & react.RefAttributes<SVGSVGElement>>;
  onHandle: () => void;
  title: "" | react.JSX.Element | null;
} | null;
declare namespace useScheduleAction {
  var action: ("delete" | "discardChanges" | "discardVersion" | "duplicate" | "editInCanvas" | "linkToCanvas" | "publish" | "restore" | "schedule" | "unlinkFromCanvas" | "unpublish" | "unpublishVersion") | undefined;
}
declare namespace useScheduleAction {
  var displayName: string | undefined;
}
/** @public */
interface HookCollectionActionHook<Args, State> {
  (args: Args): State | null;
  displayName?: string | undefined;
  action?: string;
}
/** @public */
interface GetHookCollectionStateProps<Args, State> {
  args: Args;
  children: (props: {
    states: State[];
  }) => React.ReactNode;
  hooks: HookCollectionActionHook<Args, State>[];
  /**
   * Force hooks state to reset, this pattern is discouraged and only supported for Document Actions for backwards compatibility.
   */
  resetRef?: React.Ref<() => void>;
}
/** @internal */
declare function GetHookCollectionState<Args, State>(props: GetHookCollectionStateProps<Args, State>): react.JSX.Element;
/**
 * @hidden
 * @beta */
interface DocumentBadgeDescription {
  title?: string;
  label?: string | undefined;
  color?: 'primary' | 'success' | 'warning' | 'danger';
  icon?: ReactNode | ComponentType;
}
/**
 * @hidden
 * @beta */
interface DocumentBadgeProps extends EditStateFor {}
/**
 * @hidden
 * @beta */
interface DocumentBadgeComponent extends HookCollectionActionHook<DocumentBadgeProps, DocumentBadgeDescription> {
  (props: DocumentBadgeProps): DocumentBadgeDescription | null;
}
/**
 * @deprecated we will be dropping support for scheduled publishing on a future major version
 * @beta
 */
declare const ScheduledBadge: DocumentBadgeComponent;
/**
 * @hidden
 * @beta */
declare function createSchema(schemaDef: {
  name: string;
  types: any[];
}): Schema;
/**
 * Get the most specific defined title of a schema type
 * If not set directly on the given type, it will traverse up the tree until it
 * finds one, falling back to the _name_ of the type.
 *
 * @param type - The schema type to get the title of
 * @returns A title, alternatively the schema type _name_
 * @internal
 */
declare function getSchemaTypeTitle(type: SchemaType): string;
interface SingleDocReleaseProviderProps {
  children: React.ReactNode;
  onSetScheduledDraftPerspective: (releaseId: string) => void;
}
/**
 * Provider for the single doc release context.
 * @internal
 */
declare function SingleDocReleaseProvider({
  children,
  onSetScheduledDraftPerspective
}: SingleDocReleaseProviderProps): react.JSX.Element;
/**
 * Hook to get the single doc release context
 * @internal
 */
declare function useSingleDocRelease(): SingleDocReleaseContextValue;
/**
 * Hook to check if the current perspective is viewing a paused scheduled draft.
 *
 * @returns Object containing isPaused boolean and the current release document (if any)
 * @internal
 */
declare function usePausedScheduledDraft(): {
  isPaused: boolean;
  currentRelease: ReleaseDocument | undefined;
};
/**
 * Hook to get the first document from a scheduled draft release bundle.
 *
 * @internal
 */
declare function useScheduledDraftDocument(releaseDocumentId: string | undefined, options?: {
  includePreview?: boolean;
}): {
  firstDocument: SanityDocument$1 | undefined;
  firstDocumentPreview: PreviewValue | undefined;
  firstDocumentValidation: ValidationMarker[] | undefined;
  documentsCount: number;
  loading: boolean;
  error: Error | null;
  previewLoading: boolean;
};
/**
 * @internal
 * @returns boolean indicating if the scheduled drafts feature is enabled
 */
declare function useScheduledDraftsEnabled(): boolean;
/**
 * Unless otherwise specified, this is the API version we use for controlled
 * requests on internal studio APIs. The user should always ask for a specific
 * API version when using the client - this way we can upgrade which version we
 * use internally without having the users code break unexpectedly. It also
 * means the user can easily upgrade to newer versions of GROQ when it arrives.
 *
 * @internal
 */
declare const DEFAULT_STUDIO_CLIENT_OPTIONS: SourceClientOptions;
/**
 * @beta
 * @hidden
 */
type TaskMessage = PortableTextBlock[] | null;
/**
 * @beta
 * @hidden
 */
type TaskStatus = 'open' | 'closed';
/**
 * @beta
 * @hidden
 */
interface TaskContext {
  tool?: string;
  payload?: Record<string, unknown>;
  notification?: {
    url: string;
    workspaceTitle: string;
    targetContentTitle: string | null;
    targetContentImageUrl: string | null;
  };
}
interface TaskCreateRetryingState {
  type: 'createRetrying';
}
interface TaskCreateFailedState {
  type: 'createError';
  error: Error;
}
/**
 * The state is used to track the state of the task (e.g. if it failed to be created, etc.)
 * It is a local value and is not stored on the server.
 * When there's no state, the task is considered to be in a "normal" state (e.g. created successfully).
 *
 * The state value is primarily used to update the UI. That is, to show an error message or retry button.
 */
type TaskState = TaskCreateFailedState | TaskCreateRetryingState | undefined;
interface TaskTarget {
  documentType: string;
  document: {
    _dataset: string;
    _projectId: string;
    _ref: string;
    _type: 'crossDatasetReference';
    _weak: boolean;
  };
}
/**
 * @beta
 * @hidden
 */
interface TaskDocument {
  _type: 'tasks.task';
  _createdAt: string;
  _updatedAt: string;
  _id: string;
  _rev: string;
  _state?: TaskState;
  title: string;
  description?: TaskMessage;
  status: TaskStatus;
  lastEditedAt?: string;
  context?: TaskContext;
  authorId: string;
  dueBy?: string;
  assignedTo?: string;
  subscribers?: string[];
  target?: TaskTarget;
  /**
   * Date representing when the task was created by the user and not by the system. When the `create task` button was clicked.
   */
  createdByUser?: string;
}
/**
 * @internal
 */
type TasksEnabledContextValue = {
  enabled: false;
  mode: null;
} | {
  enabled: true;
  mode: 'default' | 'upsell';
};
interface IsLastPaneProviderProps {
  isLastPane: boolean;
  children: React.ReactNode;
}
/**
 * @internal
 * @hidden
 */
declare function IsLastPaneProvider({
  children,
  isLastPane
}: IsLastPaneProviderProps): React.JSX.Element;
/**
 * @internal
 */
interface MentionUserContextValue {
  mentionOptions: UserListWithPermissionsHookValue;
  selectedDocument: SanityDocument$1 | null;
  setSelectedDocument: (document: SanityDocument$1 | null) => void;
}
type SidebarTabsIds = 'assigned' | 'subscribed' | 'document';
type ViewMode = 'create' | 'edit' | 'list' | 'draft' | 'duplicate';
interface State$2 {
  isOpen: boolean;
  viewMode: ViewMode;
  selectedTask: null | string;
  activeTabId: SidebarTabsIds;
  duplicateTaskValues: null | TaskDocument;
}
type ViewModeOptions = {
  type: 'list' | 'create';
} | {
  type: 'edit';
  id: string;
} | {
  type: 'duplicate';
  duplicateTaskValues: TaskDocument;
} | {
  type: 'draft';
  id: string;
};
type TasksNavigationContextValue = {
  state: State$2;
  setActiveTab: (id: SidebarTabsIds) => void;
  setViewMode: (options: ViewModeOptions) => void;
  handleCloseTasks: () => void;
  handleCopyLinkToTask: () => void;
  handleOpenTasks: () => void;
};
/**
 * @beta
 * @hidden
 */
type ActiveDocument = {
  documentId: string;
  documentType: string;
};
/**
 * @beta
 * @hidden
 */
interface TasksContextValue {
  activeDocument: ActiveDocument | null;
  setActiveDocument: (document: ActiveDocument | null) => void;
  data: TaskDocument[];
  isLoading: boolean;
}
interface TasksUpsellContextValue {
  upsellDialogOpen: boolean;
  handleOpenDialog: (source: UpsellDialogViewedInfo['source']) => void;
  handleClose: () => void;
  upsellData: UpsellData | null;
  telemetryLogs: {
    dialogSecondaryClicked: () => void;
    dialogPrimaryClicked: () => void;
    panelViewed: (source: UpsellDialogViewedInfo['source']) => void;
    panelDismissed: () => void;
    panelPrimaryClicked: () => void;
    panelSecondaryClicked: () => void;
  };
}
interface PreviewHookOptions {
  documentId: string;
  documentType: string;
  perspectiveStack: string[];
}
interface PreviewHookValue {
  isLoading: boolean;
  value: Partial<PreviewValue> | null;
}
/** @internal */
declare function useDocumentPreviewValues(options: PreviewHookOptions): PreviewHookValue;
/**
 * @internal
 * @deprecated – Will be removed in upcoming major version
 */
type LegacyThemeTints = { [key in ColorTintKey]: string };
/**
 * Properties that can be used to override the default theme.
 *
 * @public
 * @deprecated – Will be removed in upcoming major version
 */
interface LegacyThemeProps {
  '--font-family-monospace': string;
  '--font-family-base': string;
  '--black': string;
  '--white': string;
  '--brand-primary': string;
  '--component-bg': string;
  '--component-text-color': string;
  '--default-button-color': string;
  '--default-button-primary-color': string;
  '--default-button-success-color': string;
  '--default-button-warning-color': string;
  '--default-button-danger-color': string;
  '--focus-color': string;
  '--gray-base': string;
  '--gray': string;
  '--main-navigation-color': string;
  '--main-navigation-color--inverted': string;
  '--state-info-color': string;
  '--state-success-color': string;
  '--state-warning-color': string;
  '--state-danger-color': string;
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  '--screen-medium-break': string;
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  '--screen-default-break': string;
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  '--screen-large-break': string;
  /**
   * @deprecated this theme property is not configurable within the studio
   */
  '--screen-xlarge-break': string;
}
/**
 * Build a Sanity UI theme from legacy CSS properties.
 *
 * @example
 * ```tsx
 * import {buildLegacyTheme, defineConfig} from 'sanity'
 *
 * export default defineConfig({
 *   // project configuration ...
 *
 *   // Customize theming
 *   theme: buildLegacyTheme({
 *     '--black': '#000',
 *     '--gray': '#777',
 *     '--focus-color': '#00f',
 *   })
 * })
 * ```
 *
 * @param partialLegacyTheme - Properties to override the theme with. See {@link LegacyThemeProps}
 * @public
 * @deprecated – Will be removed in upcoming major version
 */
declare function buildLegacyTheme(partialLegacyTheme: Partial<LegacyThemeProps>): StudioTheme;
/**
 * The default theme. This is a proxy to the default theme, in order to lazily initialize it
 * on use and not pay the cost of building the theme on module load.
 *
 * @internal
 * @deprecated Will be removed in upcoming major version.
 * */
declare const defaultTheme: RootTheme;
type Selector<T, K> = (error: unknown, attemptNo: number, caught: Observable<T>) => Observable<K>;
/**
 * Like catchError, but passes the number of successive errors as the second argument to the selector function
 * @internal
 * @hidden
 */
declare function catchWithCount<T, K = T>(selector: Selector<T, K>): OperatorFunction<T, K>;
/** @internal */
type LoadingTuple<T> = [T, boolean];
/** @internal */
type ReactHook<TArgs, TResult> = (args: TArgs) => TResult;
/** @internal */
declare function createHookFromObservableFactory<T, TArg = void>(observableFactory: (arg: TArg) => Observable<T>, initialValue: T): ReactHook<TArg, LoadingTuple<T>>;
/** @internal */
declare function createHookFromObservableFactory<T, TArg = void>(observableFactory: (arg: TArg) => Observable<T>, initialValue?: T): ReactHook<TArg, LoadingTuple<T | undefined>>;
/** @internal */
declare const EMPTY_OBJECT: Record<string, unknown>;
/** @internal */
declare const EMPTY_ARRAY: never[];
/**
 * date-fns `formatRelative` defaults to formatting as `mm/dd/yyyy` if the date is more/less than
 * a week away. `formatRelativeLocale` will adjust formatting in these cases to match the correct
 * locale format.
 * @internal
 */
declare const formatRelativeLocale: (date: string | number | Date, baseDate: string | number | Date, options?: date_fns_formatRelative0.FormatRelativeOptions | undefined) => string;
/**
 * Safely extracts an error message from an unknown value that was thrown.
 * JavaScript allows throwing any value, not just Error instances.
 *
 * @param error - The unknown value that was thrown
 * @returns A string representation of the error
 * @internal
 */
declare function getErrorMessage(error: unknown): string;
/**
 * @beta
 * Given a document and a reference ID, returns the paths in which the reference is used within the document.
 *
 * For example:
 * ```ts
 * const document = {
 *   _type: 'test',
 *   _id: 'test',
 *   _createdAt: '2021-01-01',
 *   _updatedAt: '2021-01-01',
 *   _rev: 'test',
 *   rootReference: {
 *     _ref: 'foo-bar',
 *     _type: 'reference',
 *   },
 * }
 * const referencePaths = getReferencePaths(document, 'foo-bar')
 * expect(referencePaths).toEqual([['rootReference']])
 * ```
 */
declare function getReferencePaths(document: SanityDocument, referenceToId: string): Path[];
interface GlobalErrorChannelEvent {
  type: 'error' | 'rejection';
  error?: unknown;
  lineno?: number;
  colno?: number;
  filename?: string;
}
interface GlobalErrorChannel {
  subscribe: (callback: (event: GlobalErrorChannelEvent) => void) => () => void;
}
/** @internal */
declare const globalScope: typeof globalThis & {
  __sanityErrorChannel?: GlobalErrorChannel | undefined;
};
/** @internal */
declare function isArray(value: unknown): value is unknown[];
/**
 * @internal
 */
declare function isNonNullable<T>(value: T): value is NonNullable<T>;
/**
 * @internal
 */
declare function isRecord(value: unknown): value is Record<string, unknown>;
/** @internal */
declare function isString(value: unknown): value is string;
/** @internal */
declare function isTruthy<T>(value: T | false): value is T;
/** @internal */
type PartialExcept<T, K extends keyof T> = Pick<T, K> & Partial<Omit<T, K>>;
/**
 * A release document with cardinality 'one'
 *
 * @internal
 */
type CardinalityOneRelease = ReleaseDocument & {
  metadata: ReleaseDocument['metadata'] & {
    cardinality: 'one';
  };
};
/**
 * Check if the release is a cardinality one release
 *
 * @internal
 */
declare function isCardinalityOneRelease(release: ReleaseDocument): release is CardinalityOneRelease;
/**
 * Check if perspective represents a cardinality one release
 *
 * @internal
 */
declare function isCardinalityOnePerspective(perspective: unknown): perspective is CardinalityOneRelease;
/**
 * Checks if a release is a paused cardinality one release (scheduled draft).
 *
 * @internal
 */
declare function isPausedCardinalityOneRelease(release: ReleaseDocument | undefined): boolean;
/** @internal */
interface SharedResizeObserver {
  observe: (element: Element, observer: Subscriber<ResizeObserverEntry>, options?: ResizeObserverOptions) => () => void;
  unobserve: (element: Element) => void;
}
/** @internal */
declare const createSharedResizeObserver: () => SharedResizeObserver;
/** @internal */
declare const resizeObserver: SharedResizeObserver;
/**
 *
 * Create an SWR (Stale While Revalidate) rxjs operator that will store the latest value in a cache and emit the last know value upon observable subscription
 * @param options - Options
 * @internal
 */
declare function createSWR<T>(options: {
  maxSize: number;
}): (key: string) => OperatorFunction<T, {
  fromCache: boolean;
  value: T;
}>;
/**
 * @internal
 */
declare function _isSanityDocumentTypeDefinition(def: SchemaTypeDefinition): def is SchemaTypeDefinition<'document'>;
/**
 * @internal
 */
declare function _isCustomDocumentTypeDefinition(def: SchemaTypeDefinition): def is SchemaTypeDefinition<'document'>;
/**
 * Test if the given schema type or any of its ancestors matches the given type name.
 * @internal
 */
declare function _isType(schemaType: SchemaType, typeName: string): boolean;
type SearchPathSegment = string | number | [];
/** @internal */
declare const fieldNeedsEscape: (fieldName: string) => boolean;
/** @internal */
declare const escapeField: (fieldName: string) => string;
/** @internal */
declare const joinPath: (pathArray: SearchPathSegment[]) => string;
/** @internal */
declare const supportsTouch: boolean;
/** @internal */
declare const uncaughtErrorHandler: () => string;
/**
 * Truncates a string to a given length, taking into account surrogate pairs and grapheme clusters
 * (using zero-width joiners). This means the resulting string may be longer in number of bytes,
 * but will be shorter in number of "characters". Should only be used for display purposes -
 * not for truncating strings for storage or similar.
 *
 * Examples of differences between `String.prototype.slice` and this function:
 *
 * - '👨‍👨‍👧‍👧'.slice(0, 1) === '�'  vs sliceString('👨‍👨‍👧‍👧', 0, 1) === '👨‍👨‍👧‍👧'
 * - '👨‍👨‍👧‍👧'.slice(0, 2) === '👨' vs sliceString('👨‍👨‍👧‍👧', 0, 2) === '👨‍👨‍👧‍👧'
 *
 * @param str - String to slice
 * @param start - Start index
 * @param end - End index (exclusive)
 * @returns The sliced string
 * @internal
 */
declare function sliceString(str: string, start: number, end: number): string;
/**
 * Truncates a string to a given length, taking into account surrogate pairs and grapheme clusters
 * (using zero-width joiners). This means the resulting string may be longer in number of bytes,
 * but will be shorter in number of "characters". Should only be used for display purposes -
 * not for truncating strings for storage or similar.
 *
 * @param str - String to truncate
 * @param maxLength - Maximum length in "characters"
 * @returns The truncated string
 * @internal
 */
declare function truncateString(str: string, maxLength: number): string;
/** @internal */
type LoadableState<T> = LoadingState | LoadedState<T> | ErrorState;
/** @internal */
interface LoadingState {
  value: undefined;
  error: null;
  isLoading: true;
}
/** @internal */
interface LoadedState<T> {
  value: T;
  error: null;
  isLoading: false;
}
/** @internal */
interface ErrorState {
  value: undefined;
  error: Error;
  isLoading: false;
}
/** @internal */
declare function useLoadable<T>(value$: Observable<T>): LoadableState<T | undefined>;
/** @internal */
declare function useLoadable<T>(value$: Observable<T>, initialValue: T): LoadableState<T>;
/** @internal */
declare function asLoadable<T>(): OperatorFunction<T, LoadableState<T>>;
/**
 * Checks whether or not the given user has the role with the given ID
 *
 * @param user - The user to check (currently only the current user is supported)
 *   If `null` is passed, this function always returns `false`.
 * @param roleId - The ID of the role to check for
 *
 * @returns true if the user has the role, false otherwise
 *
 * @example
 * Fetch the current user and check if they have the role "administrator":
 * ```ts
 * import {userHasRole, useCurrentUser} from 'sanity'
 *
 * export function MyComponent() {
 *   const user = useCurrentUser()
 *   const hasAdminRole = userHasRole(user, 'administrator')
 *   return <div>Is administrator: {hasAdminRole ? 'Yes' : 'No'}</div>
 * }
 * ```
 * @public
 */
declare function userHasRole(user: (Omit<CurrentUser, 'role'> & {
  role?: string;
}) | null, roleId: string): boolean;
/**
 * @internal
 *
 * @example
 * ```tsx
 * // First create a callback using React’s `useCallback` hook
 * const myCallback = useCallback(() => {
 *   // this is not throttled
 * }, [])
 *
 * // Then make a throttled version using the `useThrottledCallback` hook
 * const myThrottledCallback = useThrottledCallback(myCallback, 100)
 *
 * // Call the throttled callback
 * <Button onClick={myThrottledCallback} />
 * ```
 */
declare function useThrottledCallback(callback: (...args: any[]) => any, wait: number, options: ThrottleSettings): (...args: any[]) => any;
/**
 * This React hook should be considered an escape hatch – to make sure that a value is the same
 * on every render. SHOULD NOT BE USED IN MOST CASES.
 * @deprecated please use `useMemo` and `useCallback` strategies instead to make deps stable, this hook runs comparisons on every single render and while each comparison can be fast, it quickly adds up
 *
 * @internal
 */
declare function useUnique<ValueType>(value: ValueType): ValueType;
/**
 * RxJS operator that measures the time from subscription to the first emission.
 * Calls `onMeasured` once with the elapsed duration in milliseconds and the emitted value.
 * Uses `tap()` internally so data flow is unchanged.
 *
 * Re-subscriptions (e.g. navigating between documents) naturally produce fresh measurements.
 *
 * @param onMeasured - Callback receiving the duration in ms and the first emitted value
 * @returns An RxJS operator
 * @internal
 */
declare function measureFirstEmission<T>(onMeasured: (durationMs: number, value: T) => void): MonoTypeOperatorFunction<T>;
/**
 * RxJS operator that measures the time from subscription to the first emission
 * where the given predicate returns `true`.
 * Calls `onMeasured` once with the elapsed duration in milliseconds and the matching value.
 * Uses `tap()` internally so data flow is unchanged.
 *
 * @param predicate - Function that determines if the emitted value is a match
 * @param onMeasured - Callback receiving the duration in ms and the first matching value
 * @returns An RxJS operator
 * @internal
 */
declare function measureFirstMatch<T>(predicate: (value: T) => boolean, onMeasured: (durationMs: number, value: T) => void): MonoTypeOperatorFunction<T>;
/**
 * @hidden
 * @beta
 */
declare const SANITY_VERSION: string;
interface CompanionDoc {
  _id: string;
  canvasDocumentId: string;
  studioDocumentId: string;
  isStudioDocumentEditable?: boolean;
}
/**
 * Given a document id, returns whether it is linked to canvas and the companion doc if it exists.
 * @beta
 */
declare const useCanvasCompanionDoc: (documentId: string) => {
  isLinked: boolean;
  isLockedByCanvas: boolean;
  companionDoc: CompanionDoc | undefined;
  loading: boolean | undefined;
};
type OpenCanvasOrigin = 'action' | 'banner';
/**
 *
 * @hidden
 * @internal
 */
declare const useNavigateToCanvasDoc: (canvasDocId: string | undefined, origin: OpenCanvasOrigin) => () => void;
/**
 * @internal
 */
declare function getDocumentIdForCanvasLink(actionProps: Omit<DocumentActionProps, 'onComplete'>): string;
/**
 * @internal
 */
declare const useDocumentLimitsUpsellContext: () => DocumentLimitUpsellContextValue;
/**
 * @internal
 */
declare const isDocumentLimitError: (error: unknown) => boolean;
/**
 * @internal
 */
declare const RELEASES_INTENT = "release";
interface ReleasesMetadata {
  /**
   * The number of documents with the release version as a prefix
   */
  documentCount: number;
  /**
   * The last time a document in the release was edited
   */
  updatedAt: string | null;
}
type ReleasesMetadataMap = Record<string, ReleasesMetadata>;
type MetadataWrapper = {
  data: ReleasesMetadataMap | null;
  error: null;
  loading: boolean;
};
interface BundleDeletedAction {
  id: string;
  currentUserId?: string;
  deletedByUserId: string;
  type: 'BUNDLE_DELETED';
}
interface ReleasesSetAction {
  payload: ReleaseDocument[] | null;
  type: 'RELEASES_SET';
}
interface LoadingStateChangedAction {
  payload: {
    loading: boolean;
    error: Error | undefined;
  };
  type: 'LOADING_STATE_CHANGED';
}
type ReleasesReducerAction = BundleDeletedAction | ReleasesSetAction | LoadingStateChangedAction;
/**
 * @internal
 */
declare function isReleaseDocument(doc: unknown): doc is ReleaseDocument;
/**
 * @internal
 */
interface VersionInfoDocumentStub {
  _id: string;
  _rev: string;
  _createdAt: string;
  _updatedAt: string;
}
interface ReleasesState {
  /**
   * Sorted array of releases, excluding archived releases
   */
  data: ReleaseDocument[];
  error?: Error;
  loading: boolean;
  dispatch: (event: ReleasesReducerAction) => void;
}
/**
 * Hook to get the (non archived, non published) active releases
 * @internal
 */
declare function useActiveReleases(): ReleasesState;
/**
 * @internal
 */
declare function useArchivedReleases(): {
  data: ReleaseDocument[];
  error?: Error;
  loading: boolean;
};
/**
 * Takes a document id, and returns information about what other versions of the document currently exists
 * @param documentId - The document id. Should be the published id
 * @internal
 */
declare function useDocumentVersionInfo(documentId: string): {
  isLoading: boolean;
  draft: VersionInfoDocumentStub | undefined;
  published: VersionInfoDocumentStub | undefined;
  versions: Record<string, VersionInfoDocumentStub | undefined>;
};
interface ReleasesUpsellContextValue {
  /**
   * Is upsell mode when the user has reached the release limit
   * Is default mode when the user has not reached the release limits
   */
  mode: 'upsell' | 'default';
  upsellDialogOpen: boolean;
  upsellData: UpsellData | null;
  guardWithReleaseLimitUpsell: (callback: () => void, throwError?: boolean, whenResolved?: (hasPassed: boolean) => void) => Promise<false | void>;
  onReleaseLimitReached: (limit: number) => void;
  handleOpenDialog: (source?: UpsellDialogViewedInfo['source']) => void;
  telemetryLogs: {
    dialogSecondaryClicked: () => void;
    dialogPrimaryClicked: () => void;
    panelViewed: (source: UpsellDialogViewedInfo['source']) => void;
    panelDismissed: () => void;
    panelPrimaryClicked: () => void;
    panelSecondaryClicked: () => void;
  };
}
interface DocumentValidationStatus extends ValidationStatus {
  hasError: boolean;
}
interface DocumentInRelease {
  memoKey: string;
  isPending?: boolean;
  document: SanityDocument & {
    publishedDocumentExists: boolean;
  };
  validation: DocumentValidationStatus;
}
/**
 * Gets all the releases ids
 * @internal
 */
declare function useReleasesIds(releases: ReleaseDocument[]): {
  releasesIds: string[];
};
/**
 * @internal
 */
declare const LATEST: "drafts";
/**
 * @internal
 */
declare const PUBLISHED: "published";
/**
 * @internal
 * @param releaseDocumentId - the document id of the release
 */
declare function getReleaseIdFromReleaseDocumentId(releaseDocumentId: string): ReleaseId;
/** @internal */
declare function getReleaseTone(release: TargetPerspective): BadgeTone;
/**
 * checks if the document has been set for unpublishing
 * @internal
 *
 * @param document - sanity document
 * @returns boolean if the system delete is set
 */
declare function isGoingToUnpublish(document: SanityDocument$1 | SanityDocumentLike): boolean;
/**
 * @internal This is the client options used for the releases studio client, using the `X` API version for now
 * Will change to a specific version soon.
 * TODO: Remove after API version is stable and support releases
 */
declare const RELEASES_STUDIO_CLIENT_OPTIONS: SourceClientOptions;
/**
 * @internal Checks if the perspective is a release perspective
 * TODO: Remove after API version is stable and support releases
 */
declare const isReleasePerspective: (perspective: string | _sanity_client0.StackablePerspective[] | string[] | undefined) => boolean;
/**
 * @beta
 * @param documentId - The document id, e.g. `my-document-id` or `drafts.my-document-id` or `summer.my-document-id`
 * @param perspective - The current perspective, e.g. `release.summer` or undefined, it can be obtained from `useRouter().stickyParams.perspective`
 * @returns boolean - `true` if the document is in the current perspective.
 * e.g:
 * - document: `summer.my-document-id`, perspective: `release.summer` : **true**
 * - document: `my-document-id`, perspective: `release.summer` : **false**
 * - document: `summer.my-document-id`perspective: `release.winter` : **false**
 * - document: `summer.my-document-id`, perspective: `undefined` : **false**
 * - document: `my-document-id`, perspective: `undefined` : **true**
 * - document: `drafts.my-document-id`, perspective: `undefined` : **true**
 */
declare function getDocumentIsInPerspective(documentId: string, perspective: string | undefined): boolean;
/** @internal */
declare function formatRelativeLocalePublishDate(release: ReleaseDocument): string;
/** @internal */
declare function isPublishedPerspective(perspective: TargetPerspective | string): perspective is 'published';
/** @internal */
declare function isDraftPerspective(perspective: TargetPerspective | string): perspective is 'drafts';
/** @internal */
declare function isReleaseScheduledOrScheduling(release: ReleaseDocument): boolean;
interface DocumentStatusProps$1 {
  draft?: PreviewValue | Partial<SanityDocument> | null;
  published?: PreviewValue | Partial<SanityDocument> | null;
  versions?: Record<string, VersionInfoDocumentStub | undefined>;
  singleLine?: boolean;
}
/**
 * Displays document status indicating both last published and edited dates in either relative (the default)
 * or absolute formats.
 *
 * These can be displayed in a single or multi-line (the default) lockups.
 *
 * Example: `**Published Oct 16 2023** Edited 8m ago`
 *
 * @internal
 */
declare function DocumentStatus({
  draft,
  published,
  versions,
  singleLine
}: DocumentStatusProps$1): react.JSX.Element;
/**
 * @internal
 */
type BaseStudioRenderingContext<Name extends string = string, Metadata = Record<PropertyKey, never>> = {
  name: Name;
  metadata: Metadata;
};
/**
 * @internal
 */
type DefaultRenderingContext = BaseStudioRenderingContext<'default'>;
/**
 * @internal
 */
type CoreUiRenderingContext = BaseStudioRenderingContext<'coreUi', {
  environment: string;
}>;
/**
 * @internal
 */
type StudioRenderingContext = DefaultRenderingContext | CoreUiRenderingContext;
/**
 * @internal
 */
declare const capabilities: readonly ["globalUserMenu", "globalWorkspaceControl", "comlink"];
/**
 * @internal
 */
type Capability = (typeof capabilities)[number];
/**
 * @internal
 */
type CapabilityRecord = Partial<Record<Capability, boolean>>;
/**
 * @internal
 */
type RenderingContextStore = {
  renderingContext: Observable<StudioRenderingContext>;
  capabilities: Observable<CapabilityRecord>;
};
type Props$2 = PropsWithChildren<{
  capability: Capability;
  condition?: 'available' | 'unavailable';
}>;
/**
 * `CapabilityGate` only renders its children if the current Studio rendering context does not
 * provide the specified capability.
 *
 * This allows consumers of the component to conveniently mark a portion of the React tree as
 * providing a capability that may be overriden by the Studio rendering context. If the rendering
 * context provides this capability, the local implementation will not be rendered.
 *
 * @internal
 */
declare const CapabilityGate: ComponentType<Props$2>;
interface DocumentStatusProps {
  draft?: VersionInfoDocumentStub | undefined;
  published?: VersionInfoDocumentStub | undefined;
  versions?: Record<string, VersionInfoDocumentStub | undefined>;
}
/**
 * Renders a dot indicating the current document status.
 *
 * @internal
 */
declare function DocumentStatusIndicator({
  draft,
  published,
  versions
}: DocumentStatusProps): react.JSX.Element;
/**
 * @internal
 */
interface ErrorActionsProps extends Pick<ComponentProps<typeof Button>, 'size'> {
  error: unknown;
  eventId?: string | null;
  onRetry?: () => void;
  isRetrying?: boolean;
}
/**
 * @internal
 */
declare const ErrorActions: ComponentType<ErrorActionsProps>;
/**
 * @internal
 */
interface ErrorWithId {
  error: unknown;
  eventId?: string | null;
}
/**
 * @internal
 */
declare function useCopyErrorDetails(error: unknown, eventId?: string | null): () => void;
/**
 * @internal
 */
declare function serializeError(): OperatorFunction<ErrorWithId, string>;
/**
 * Properties for the `Hotkeys` component.
 *
 * @public
 */
type HotkeysProps$1 = HotkeysProps & {
  /**
   * Whether to make the keys platform-aware (eg `alt` to `option` on Apple devices).
   *
   * @defaultValue true
   */
  makePlatformAware?: boolean;
} & Omit<HTMLProps<HTMLElement>, 'ref' | 'size' | 'as'> & RefAttributes<HTMLElement>;
/**
 * Renders given `keys` as "keycaps" visually.
 *
 * This is a wrapper around `@sanity/ui`'s `Hotkeys` component, which allows for altering keys
 * (eg `alt` to `option`) on Apple devices unless `makePlatformAware` is set to `false`.
 *
 * @param props - Properties to render with
 * @returns React element
 * @public
 */
declare function Hotkeys({
  makePlatformAware,
  keys: hotKeys,
  ...props
}: HotkeysProps$1): react.JSX.Element;
/** @internal */
interface InsufficientPermissionsMessageProps {
  currentUser?: CurrentUser | null;
  context: 'create-new-reference' | 'create-document-type' | 'create-any-document' | 'create-document' | 'delete-document' | 'delete-schedules' | 'discard-changes' | 'duplicate-document' | 'edit-schedules' | 'execute-schedules' | 'publish-document' | 'unpublish-document';
}
/** @internal */
declare function InsufficientPermissionsMessage({
  currentUser,
  context
}: InsufficientPermissionsMessageProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
declare function IntentButton(props: IntentLinkProps & ButtonProps$1 & Omit<HTMLProps<HTMLButtonElement>, 'ref' | 'size' | 'as'>): react.JSX.Element;
interface LoadingTestProps {
  /** Absolutely positions this component when `true`. */
  fill?: boolean;
  /** Optionally show loading title. If `true`, both text and spinner will appear and animate after an initial delay */
  showText?: boolean;
  /**
   * Text to display underneath the spinner.  If omitted, will default to `'Loading'`.
   * If providing a value, avoid using trailing ellipses.
   *
   * @defaultValue `'Loading'`
   */
  title?: string | null;
}
/**
 * A generic loading container which displays a spinner and text.
 * The spinner won't initially be visible and fades in after a short delay.
 *
 * @internal
 */
declare function LoadingBlock({
  fill,
  showText,
  title
}: LoadingTestProps): react.JSX.Element;
interface PopoverDialogProps {
  children: ReactNode;
  header?: ReactNode;
  onClose: () => void;
  referenceElement: PopoverProps$1['referenceElement'];
  width: ResponsiveWidthProps['width'];
  containerRef?: Dispatch<SetStateAction<HTMLDivElement | null>>;
}
/** @internal */
declare function PopoverDialog(props: PopoverDialogProps): react.JSX.Element;
/** @internal */
interface PreviewCardContextValue {
  selected?: boolean;
}
/** @internal */
declare function usePreviewCard(): PreviewCardContextValue;
/** @internal */
declare const PreviewCard: react.ForwardRefExoticComponent<Omit<CardProps & Omit<HTMLProps<HTMLDivElement>, "height">, "ref"> & react.RefAttributes<HTMLDivElement>>;
/**
 *  This is a workaround for a circular import issue.
 * Calling `styled(PreviewCard)` at program load time triggered a build error with the commonjs bundle because it tried
 * to access the PreviewCard variable/symbol before it was initialized.
 * The workaround is to colocate the styled component with the component itself.
 * @internal
 */
declare const ReferenceInputPreviewCard: styled_components_dist_types0.IStyledComponentBase<"web", styled_components0.FastOmit<Omit<CardProps & Omit<HTMLProps<HTMLDivElement>, "height">, "ref"> & react.RefAttributes<HTMLDivElement>, never>> & string & Omit<react.ForwardRefExoticComponent<Omit<CardProps & Omit<HTMLProps<HTMLDivElement>, "height">, "ref"> & react.RefAttributes<HTMLDivElement>>, keyof react.Component<any, {}, any>>;
/**
 * Portable text preview layout key
 *
 * @public
 */
type PortableTextPreviewLayoutKey = 'block' | 'blockImage' | 'inline';
/**
 * General preview layout key
 *
 * @public
 */
type GeneralPreviewLayoutKey = 'compact' | 'default' | 'media' | 'detail';
/**
 * General Document list layout key
 *
 * @hidden
 * @beta
 */
type GeneralDocumentListLayoutKey = GeneralPreviewLayoutKey | 'sheetList';
/**
 * Preview layout key. See also {@link GeneralPreviewLayoutKey} and {@link PortableTextPreviewLayoutKey}
 *
 * @public
 */
type PreviewLayoutKey = GeneralPreviewLayoutKey | PortableTextPreviewLayoutKey;
/**
 * @hidden
 * @public
 */
interface PreviewMediaDimensions {
  aspect?: number;
  dpr?: number;
  fit?: ImageUrlFitMode;
  height?: number;
  width?: number;
}
/**
 * @hidden
 * @beta
 */
interface PreviewProps<TLayoutKey = PreviewLayoutKey> {
  actions?: ReactNode | ComponentType<{
    layout: TLayoutKey;
  }>;
  children?: ReactNode;
  description?: ReactNode | ComponentType<{
    layout: TLayoutKey;
  }>;
  error?: Error | null;
  fallbackTitle?: ReactNode;
  imageUrl?: string;
  isPlaceholder?: boolean;
  layout?: TLayoutKey;
  media?: ReactNode | ComponentType<{
    dimensions: PreviewMediaDimensions;
    layout: TLayoutKey;
  }>;
  mediaDimensions?: PreviewMediaDimensions;
  progress?: number;
  status?: ReactNode | ComponentType<{
    layout: TLayoutKey;
  }>;
  subtitle?: ReactNode | ComponentType<{
    layout: TLayoutKey;
  }>;
  title?: ReactNode | ComponentType<{
    layout: TLayoutKey;
  }>;
  withBorder?: boolean;
  withRadius?: boolean;
  withShadow?: boolean;
  schemaType?: SchemaType;
  renderDefault: (props: PreviewProps) => React.JSX.Element;
}
/**
 * @hidden
 * @beta
 */
type PreviewComponent = ComponentType<PreviewProps>;
/**
 * @hidden
 * @beta */
type CompactPreviewProps = Omit<PreviewProps<'compact'>, 'renderDefault'>;
/**
 * @hidden
 * @beta */
declare function CompactPreview(props: CompactPreviewProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
interface DefaultPreviewProps extends Omit<PreviewProps<'default'>, 'renderDefault'> {
  styles?: {
    root?: string;
    placeholder?: string;
    media?: string;
    heading?: string;
    title?: string;
    subtitle?: string;
    hasSubtitle?: string;
    mediaString?: string;
    status?: string;
    children?: string;
  };
}
/**
 * @hidden
 * @beta */
declare function DefaultPreview(props: DefaultPreviewProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
type DetailPreviewProps = PreviewProps<'detail'>;
/**
 * @hidden
 * @beta */
declare function DetailPreview(props: DetailPreviewProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
type MediaPreviewProps = Omit<PreviewProps<'media'>, 'renderDefault'>;
/**
 * @hidden
 * @beta */
declare function MediaPreview(props: MediaPreviewProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
type BlockImagePreviewProps = Omit<PreviewProps<'blockImage'>, 'renderDefault'>;
/**
 * @hidden
 * @beta */
declare function BlockImagePreview(props: BlockImagePreviewProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
declare function BlockPreview(props: Omit<PreviewProps<'block'>, 'renderDefault'>): react.JSX.Element;
/**
 * @hidden
 * @beta */
type InlinePreviewProps = Omit<PreviewProps<'inline'>, 'renderDefault'>;
/**
 * @hidden
 * @beta */
declare function InlinePreview(props: InlinePreviewProps): react.JSX.Element;
interface MediaProps {
  border?: boolean;
  dimensions: PreviewMediaDimensions;
  layout: PreviewLayoutKey;
  media: PreviewProps['media'];
  radius?: number;
  responsive?: boolean;
  styles?: {
    media?: string;
    mediaString?: string;
  };
}
/**
 * @hidden
 * @beta */
interface TemplatePreviewProps {
  description?: ReactNode;
  isPlaceholder?: boolean;
  media?: MediaProps['media'];
  mediaDimensions?: PreviewMediaDimensions;
  subtitle?: ElementType<{
    layout: 'default';
  }> | ReactNode;
  title?: ElementType<{
    layout: 'default';
  }> | ReactNode;
}
/**
 * @hidden
 * @beta */
declare function TemplatePreview(props: TemplatePreviewProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
declare function CircularProgress(props: {
  /** Percentage */value: number;
}): react.JSX.Element;
/**
 * @hidden
 * @beta */
declare function LinearProgress(props: {
  /** Percentage */value: number;
}): react.JSX.Element;
/**
 * @internal
 */
interface RelativeTimeProps extends RelativeTimeOptions {
  time: string | Date;
}
/**
 * @internal
 */
declare function RelativeTime({
  time,
  ...options
}: RelativeTimeProps): react.JSX.Element;
interface ResizableProps {
  minWidth: number;
  maxWidth: number;
  initialWidth?: number;
  resizerPosition?: 'left' | 'right';
}
/**
 * @internal
 * Provides a resizable container with a resizer handle.
 */
declare function Resizable(props: ResizableProps & BoxProps & Omit<HTMLProps<HTMLDivElement>, 'as'>): react.JSX.Element;
/**
 * @hidden
 * @beta */
type RovingFocusNavigationType = 'arrows' | 'tab';
/**
 * @hidden
 * @beta */
interface RovingFocusProps {
  direction?: 'horizontal' | 'vertical';
  initialFocus?: 'first' | 'last';
  navigation?: RovingFocusNavigationType[];
  loop?: boolean;
  pause?: boolean;
  rootElement: HTMLElement | HTMLDivElement | null;
}
/**
 * This hook handles focus with the keyboard arrows.
 *
 * @see {@link https://a11y-solutions.stevenwoodson.com/solutions/focus/roving-focus/ | Roving focus definition}
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const [rootElement, setRootElement] = setRootElement(null)
 *
 *   useRovingFocus({
 *     rootElement: rootElement,
 *   })
 *
 *   return (
 *     <div ref={setRootElement}>
 *       <button>Button</button>
 *       <button>Button</button>
 *       <button>Button</button>
 *     </div>
 *   )
 * }
 * ```
 *
 *
 * @hidden
 * @beta
 */
declare function useRovingFocus(props: RovingFocusProps): undefined;
/** @hidden @beta */
type StatusButtonProps = ButtonProps$1 & {
  ['aria-label']: HTMLProps<HTMLButtonElement>['aria-label'];
  'forwardedAs'?: string;
  'disabled'?: boolean | {
    reason: ReactNode;
  };
  'mode'?: ButtonProps$1['mode'];
  'iconRight'?: undefined;
};
/** @hidden @beta */
declare const StatusButton: react.ForwardRefExoticComponent<(StatusButtonProps & Omit<HTMLProps<HTMLButtonElement>, "disabled" | "ref" | "size" | "title">) & react.RefAttributes<HTMLButtonElement>>;
/** @internal */
interface TextWithToneProps extends ComponentProps<typeof Text> {
  tone: ButtonTone;
  dimmed?: boolean;
}
/** @internal */
declare const TextWithTone: react.ForwardRefExoticComponent<Omit<TextWithToneProps, "ref"> & react.RefAttributes<HTMLDivElement>>;
/** @internal */
declare const TooltipOfDisabled: react.ForwardRefExoticComponent<Omit<_sanity_ui0.TooltipProps, "arrow" | "padding" | "shadow"> & {
  hotkeys?: string[] | undefined;
} & react.RefAttributes<HTMLDivElement>>;
/** @internal */
interface ToastParams$1 {
  closable?: boolean;
  description?: ReactNode;
  duration?: number;
  onClose?: () => void;
  title?: ReactNode;
  status?: 'error' | 'warning' | 'success' | 'info';
}
/**
 * @internal
 * @deprecated -- Refactor the component so it can call `useToast` instead
 */
declare const ImperativeToast: react.ForwardRefExoticComponent<react.RefAttributes<unknown>>;
/**
 * TODO: Rename to `ZOffsetsContextValue`
 *
 * @internal
 */
interface ZIndexContextValue {
  /** Used by: Navbar */
  navbar: number | number[];
  navbarPopover: number | number[];
  navbarDialog: number | number[];
  /** Used by: DefaultPane, DocumentPane */
  pane: number | number[];
  paneHeader: number | number[];
  paneFooter: number | number[];
  paneResizer: number | number[];
  paneDialog: number | number[];
  /** Used by: EditItemFoldOut, Spinner, ConnectorsOverlay, tippy.css, BaseDateTimeInput */
  portal: number | number[];
  /** Used by: Tooltip */
  popover: number | number[];
  /** Used by: `@sanity/google-maps-input` */
  modal: number | number[];
  /** TODO this path does not seem to be correct - fix?  */
  /** Used by: `movingItem` in packages/sanity/src/styles/layout/helpers.css */
  movingItem: number | number[];
  /** Used for shadow behind the navbar search, and behind sidemenu */
  drawershade: number | number[];
  /** Used by: Snackbar */
  drawer: number | number[];
  /** Used for UI that sits on top of the entire application */
  fullscreen: number | number[];
  /** Used for inspector dialog */
  inspectorDialog: number | number[];
  /** Used for toasts */
  toast: number | number[];
  dropdown: number | number[];
  navbarFixed: number | number[];
  fullscreenEdit: number | number[];
  popoverBackground: number | number[];
  tooltip: number | number[];
  modalBackground: number | number[];
  spinner: number | number[];
}
/** @internal */
type ZIndexContextValueKey = keyof ZIndexContextValue;
/**
 * This component should only be used by core Sanity packages.
 * @internal
 */
declare function LegacyLayerProvider({
  children,
  zOffset: zOffsetKey
}: {
  children: ReactNode;
  zOffset: ZIndexContextValueKey;
}): react.JSX.Element;
interface AvatarSkeletonProps {
  $size?: AvatarSize;
}
/**
 * A loading skeleton element representing a user avatar
 * @beta
 */
declare const AvatarSkeleton: styled_components_dist_types0.IStyledComponentBase<"web", styled_components_dist_types0.Substitute<Omit<_sanity_ui0.SkeletonProps & react.HTMLProps<HTMLDivElement>, "ref"> & react.RefAttributes<HTMLDivElement>, AvatarSkeletonProps>> & string & Omit<react.ForwardRefExoticComponent<Omit<_sanity_ui0.SkeletonProps & react.HTMLProps<HTMLDivElement>, "ref"> & react.RefAttributes<HTMLDivElement>>, keyof react.Component<any, {}, any>>;
/**
 * @hidden
 * @beta */
interface UserAvatarProps {
  __unstable_hideInnerStroke?: AvatarProps['__unstable_hideInnerStroke'];
  animateArrowFrom?: AvatarPosition;
  position?: AvatarPosition;
  size?: AvatarSize;
  status?: AvatarStatus;
  tone?: 'navbar';
  user: User | string;
  withTooltip?: boolean;
}
/**
 * @hidden
 * @beta */
declare function UserAvatar(props: UserAvatarProps): react.JSX.Element;
/**
 * @internal
 * @deprecated - Will be removed in 4.0.0, use the `useReferringDocuments(<documentId>)` hook instead
 */
declare function WithReferringDocuments({
  children,
  id
}: {
  children: (props: {
    isLoading: boolean;
    referringDocuments: SanityDocument[];
  }) => React.JSX.Element;
  /**
   * @deprecated - no longer required
   */
  documentStore?: DocumentStore;
  id: string;
}): react.JSX.Element;
/**
 * TODO: Rename to `useZOffsets`
 *
 * @internal
 */
declare function useZIndex(): ZIndexContextValue;
/**
 * TODO: Rename to `ZOffsetsProvider`
 *
 * @internal
 */
declare function ZIndexProvider({
  children
}: {
  children?: ReactNode;
}): React.JSX.Element;
/** @internal */
declare const SANITY_PATCH_TYPE: unique symbol;
/**
 * @hidden
 * @beta */
declare function setIfMissing(value: any, path?: Path): FormSetIfMissingPatch;
/**
 * @hidden
 * @beta */
declare function insert(items: any[], position: FormInsertPatchPosition, path?: Path): FormInsertPatch;
/**
 * @hidden
 * @beta */
declare function set(value: any, path?: Path): FormSetPatch;
/**
 * @hidden
 * @beta */
declare function unset(path?: Path): FormUnsetPatch;
/**
 * @hidden
 * @beta */
declare function diffMatchPatch(value: string, path?: Path): FormDiffMatchPatch;
/**
 * @hidden
 * @beta */
declare function inc(amount?: number, path?: Path): FormIncPatch;
/**
 * @hidden
 * @beta */
declare function dec(amount?: number, path?: Path): FormDecPatch;
/** @internal */
declare function prefixPath<T extends {
  path: Path;
}>(patch: T, segment: PathSegment): T;
/**
 *
 * @hidden
 * @beta
 */
interface MutationPatchMsg {
  type: 'mutation';
  patches: FormPatch[];
  snapshot: unknown;
}
/**
 *
 * @hidden
 * @beta
 */
interface RebasePatchMsg {
  type: 'rebase';
  patches: FormPatch[];
  snapshot: unknown;
}
/**
 *
 * @hidden
 * @beta
 */
type PatchMsg = MutationPatchMsg | RebasePatchMsg;
/**
 *
 * @hidden
 * @beta
 */
interface PatchMsgSubscriber {
  (msg: PatchMsg): void;
}
/**
 *
 * @hidden
 * @beta
 */
interface PatchChannel {
  publish: (msg: PatchMsg) => void;
  subscribe: (subscriber: PatchMsgSubscriber) => () => void;
}
/**
 * @internal
 */
declare function createPatchChannel(): PatchChannel;
/**
 * @internal
 */
interface ConditionalPropertyCallbackContext {
  parent?: unknown;
  document?: Record<string, unknown>;
  currentUser: Omit<CurrentUser, 'role'> | null;
  value: unknown;
  path: Path;
}
/**
 * @internal
 */
declare function resolveConditionalProperty(property: ConditionalProperty, context: ConditionalPropertyCallbackContext): boolean;
/**
 * The "all fields" group definition
 * Users can import this to create a custom "all fields" group.
 * Name must be `all-fields` to be considered an "all fields" group.
 *
 * @example hides the all fields group.
 * ```ts
 *
 * const author = defineType({
 *   name: 'author',
 *   title: 'Author',
 *   type: 'document',
 *   groups: [
 *     {
 *       ...ALL_FIELDS_GROUP,
 *       hidden: true,
 *     },
 *   ],
 * })
 * ```
 *
 * @public
 */
declare const ALL_FIELDS_GROUP: FieldGroup;
/**
 * When comparing documents, diff provenance reflects details about the bundle in which a change
 * was introduced.
 *
 * @public
 */
interface ProvenanceDiffAnnotation {
  provenance: {
    bundle?: TargetPerspective;
  };
}
/**
 * @hidden
 * @beta */
interface FormFieldGroup {
  name: string;
  selected?: boolean;
  disabled?: boolean;
  title?: string;
  i18n?: I18nTextRecord<'title'>;
  icon?: ComponentType;
  fields: ObjectField[];
}
/**
 * This error may happen if the member type is structurally incompatible with the defined schema type.
 * Some examples:
 *   - the schema type defines an array, but the actual value is an object (or vice versa)
 *   - the schema type defines a number, but the actual value is a string (or vice versa)
 *   - the schema type defines an object, but the actual value is a string (or vice versa)
 *
 * @public
 */
type IncompatibleTypeError = {
  type: 'INCOMPATIBLE_TYPE';
  expectedSchemaType: SchemaType;
  resolvedValueType: string;
  value: unknown;
};
/**
 * This error may happen if the _type of the value is different from the declared schema type
 * It represents a case where we encounter field value that is structurally compatible with the field's defined schema type
 * (e.g. they are both json objects), but the _type name is different from what the schema type expects
 *
 * Note on compatibility: The schema of a field may be defined as an object with fields (a, b, c), but the value is an object with (d, e, f)
 * These are still structurally compatible because (d, e, f) will be considered undeclared members
 *
 * @public
 */
type TypeAnnotationMismatchError = {
  type: 'TYPE_ANNOTATION_MISMATCH';
  expectedSchemaType: SchemaType;
  resolvedValueType: string;
};
/**
 * This error may happen for arrays of objects where one or more of the members are missing a _key
 *
 * @public
 */
type MissingKeysError = {
  type: 'MISSING_KEYS';
  schemaType: ArraySchemaType;
  value: {
    _key?: string;
  }[];
};
/**
 * This error may happen for arrays of objects where one or more of the members are having duplicate keys
 *
 * @public
 */
type DuplicateKeysError = {
  type: 'DUPLICATE_KEYS';
  schemaType: ArraySchemaType;
  duplicates: [index: number, key: string][];
};
/**
 * This error may happen for objects if we encounter fields that are not declared in the schema
 *
 * @public
 */
type UndeclaredMembersError = {
  type: 'UNDECLARED_MEMBERS';
  schemaType: ArraySchemaType;
};
/**
 * This error may happen for objects if we encounter fields that are not declared in the schema
 *
 * @public
 */
type MixedArrayError = {
  type: 'MIXED_ARRAY';
  schemaType: ArraySchemaType;
  value: unknown[];
};
/**
 * This error may happen for arrays (of both objects and primitive values) if we encounter items that are not valid according to the schema definition
 *
 *
 * @hidden
 * @beta
 */
type InvalidItemTypeError = {
  type: 'INVALID_ITEM_TYPE';
  validTypes: SchemaType[];
  resolvedValueType: string;
  value: unknown;
};
/**
 * Represents an error that occurred in a specific field of a data object.
 * @public
 *
 * @remarks
 * This interface is used to provide detailed information about the error,
 * including the field name, the error type, and the error message.
 */
interface FieldError {
  /**
   * The type of error that occurred.
   */
  kind: 'error';
  /**
   * The unique identifier for the error.
   */
  key: string;
  /**
   * The name of the field that the error occurred in.
   */
  fieldName: string;
  /**
   * The specific error that occurred.
   *
   * ```md
   * Possible error types include:
   * - IncompatibleTypeError
   * - TypeAnnotationMismatchError
   * - MissingKeysError
   * - DuplicateKeysError
   * - UndeclaredMembersError
   * - MixedArrayError
   * ```
   *
   * See {@link IncompatibleTypeError},
   * {@link TypeAnnotationMismatchError},
   * {@link MissingKeysError},
   * {@link DuplicateKeysError},
   * {@link UndeclaredMembersError} and
   * {@link MixedArrayError} for more information.
   *
   */
  error: IncompatibleTypeError | TypeAnnotationMismatchError | MissingKeysError | DuplicateKeysError | UndeclaredMembersError | MixedArrayError;
}
/**
 * @hidden
 * @beta */
interface ArrayItemError {
  kind: 'error';
  key: string;
  index: number;
  error: InvalidItemTypeError;
}
/**
 * @public
 */
type ComputeDiff<Annotation> = (value: unknown) => Diff<Annotation>;
/**
 * Props that encapsulate document chronology within a stack of versions.
 *
 * @public
 */
interface NodeChronologyProps {
  /**
   * Whether the document has an upstream version.
   */
  hasUpstreamVersion: boolean;
}
/**
 * Props that encapsulate changes in the node's value.
 *
 * @public
 */
interface NodeDiffProps<Annotation, Value = unknown> extends NodeChronologyProps {
  /**
   * A function that takes any value and produces a diff between that value and the value the node
   * is being compared to.
   *
   * This can be used to compute a diff optimistically.
   *
   * This is marked as unstable because the API may need to evolve as we iterate on the advanced
   * version control functionality. It will be stabilised when that project has matured.
   */
  __unstable_computeDiff: ComputeDiff<Annotation>;
  /**
   * Whether the current value is different to the value the node is being compared to.
   */
  changed: boolean;
  /**
   * The value the node is currently being compared to. This is taken from the upstream version, if
   * the document has an upstream version. Otherwise, it's taken from the document's current value.
   *
   * You can use the `hasUpstreamVersion` prop to determine whether the document has an upstream
   * version.
   */
  compareValue?: Value;
}
/**
 * @hidden
 * @public
 */
interface BaseFormNode<T = unknown, S extends SchemaType = SchemaType> extends NodeDiffProps<ProvenanceDiffAnnotation, T> {
  /** The unique identifier of the node. */
  id: string;
  /** The schema type of the node. */
  schemaType: S;
  /** The level of the node in the form hierarchy. */
  level: number;
  /** The path of the node in the form hierarchy. */
  path: Path;
  /**
   * @hidden
   * @beta */
  presence: FormNodePresence[];
  /** The validation markers of the node. */
  validation: FormNodeValidation[];
  /** The value of the node. */
  value: T | undefined;
  /** Whether the node is read-only. */
  readOnly?: boolean;
  /** Whether the node is focused. */
  focused?: boolean;
  displayInlineChanges?: boolean;
}
/** @internal */
interface HiddenField {
  kind: 'hidden';
  key: string;
  name: string;
  index: number;
}
/**
 * @hidden
 * @public */
type ObjectRenderMembersCallback = (members: ObjectMember[]) => ObjectMember[];
/** @public */
interface ObjectFormNode<T = { [key in string]: unknown }, S extends ObjectSchemaType = ObjectSchemaType> extends BaseFormNode<T, S & {
  renderMembers?: ObjectRenderMembersCallback;
}> {
  /** The focus path of the form node. */
  focusPath: Path;
  /**
   * @hidden
   * @beta */
  groups: FormFieldGroup[];
  /**
   * @hidden
   * @beta */
  members: ObjectMember[];
  /**
   * @hidden
   * @beta */
  _allMembers?: ObjectMember[];
}
/** @public */
interface ObjectArrayFormNode<T extends ObjectItem = ObjectItem, S extends ObjectSchemaType = ObjectSchemaType> extends BaseFormNode<T, S> {
  /** The focus path of the form node. */
  focusPath: Path;
  value: T;
  /**
   * @hidden
   * @beta */
  groups: FormFieldGroup[];
  /**
   * @hidden
   * @beta */
  members: ObjectMember[];
  changesOpen?: boolean;
}
/** @internal */
type DocumentFormNode<T extends { [key in string]: unknown } = { [key in string]: unknown }, S extends ObjectSchemaType = ObjectSchemaType> = ObjectFormNode<T, S>;
/** @public */
interface ArrayOfObjectsFormNode<T extends any[] = KeyedObject[], S extends ArraySchemaType = ArraySchemaType> extends BaseFormNode<T, S> {
  /** The focus path of the form node. */
  focusPath: Path;
  /**
   * @hidden
   * @beta */
  members: ArrayOfObjectsMember[];
}
/** @public */
interface ArrayOfPrimitivesFormNode<T extends (string | number | boolean)[] = (string | number | boolean)[], S extends ArraySchemaType = ArraySchemaType> extends BaseFormNode<T, S> {
  /** The focus path of the form node. */
  focusPath: Path;
  /**
   * @hidden
   * @beta */
  members: ArrayOfPrimitivesMember[];
}
/** @public */
type BooleanFormNode<S extends BooleanSchemaType = BooleanSchemaType> = BaseFormNode<boolean, S>;
/** @public */
type NumberFormNode<S extends NumberSchemaType = NumberSchemaType> = BaseFormNode<number, S>;
/** @public */
type StringFormNode<S extends StringSchemaType = StringSchemaType> = BaseFormNode<string, S>;
/**
 * @hidden
 * @beta */
type PrimitiveFormNode = BooleanFormNode | NumberFormNode | StringFormNode;
/** @public */
type ObjectMember = FieldMember | FieldSetMember | FieldError | DecorationMember;
/**
 * @hidden
 * @beta */
type ArrayOfObjectsMember = ArrayOfObjectsItemMember | ArrayItemError;
/**
 * @hidden
 * @beta */
type ArrayOfPrimitivesMember = ArrayOfPrimitivesItemMember | ArrayItemError;
/**
 * @hidden
 * @beta */
interface ArrayOfObjectsItemMember<Node extends ObjectArrayFormNode = ObjectArrayFormNode> {
  kind: 'item';
  key: string;
  index: number;
  collapsed: boolean | undefined;
  collapsible: boolean | undefined;
  open: boolean;
  parentSchemaType: ArraySchemaType;
  /**
   * @hidden
   * @beta */
  item: Node;
}
/**
 * @hidden
 * @beta */
interface ArrayOfPrimitivesItemMember<Node extends PrimitiveFormNode = PrimitiveFormNode> {
  kind: 'item';
  key: string;
  index: number;
  open: boolean;
  parentSchemaType: ArraySchemaType;
  /**
   * @hidden
   * @beta */
  item: Node;
}
/**
 * Represents a field member in a form.
 * @public
 */
interface FieldMember<Node extends BaseFormNode = BaseFormNode> {
  /** The kind of the form node. */
  kind: 'field';
  /** The key of the field. */
  key: string;
  /** The name of the field. */
  name: string;
  /** The index of the field. */
  index: number;
  /** Whether the field is collapsed. */
  collapsed: boolean | undefined;
  /** Whether the field is collapsible. */
  collapsible: boolean | undefined;
  /** Whether the field is open. */
  open: boolean;
  /**
   * @internal
   * Whether this field is in the selected group.
   */
  inSelectedGroup: boolean;
  /**
   * @internal
   * Names of the field groups this field is part of.
   */
  groups: string[];
  /**
   * @hidden
   * @beta
   * The form node that represents this field.
   */
  field: Node;
}
/**
 * @hidden
 * @public
 */
type FieldsetRenderMembersCallback = (members: FieldsetMembers[]) => FieldsetMembers[];
/**
 * Represents a member of a field set.
 * @public
 */
interface FieldSetMember {
  /** The kind of member. */
  kind: 'fieldSet';
  /** The key of the member. */
  key: string;
  /**
   * Indicates whether the member is included in the currently selected group.
   * If it's hidden and in the currently selected group, it should still be excluded from its group.
   * @internal
   */
  _inSelectedGroup: boolean;
  /** The names of the field groups the member belongs to. */
  groups: string[];
  /**
   * @hidden
   * @beta
   * The state of the field set.
   */
  fieldSet: FieldsetState;
  /**
   * @hidden
   * @beta
   * The callback to render the members of the field set.
   */
  renderMembers?: FieldsetRenderMembersCallback;
}
/**
 * Represents a decoration member for a form.
 * @hidden
 * @public
 */
interface DecorationMember {
  kind: 'decoration';
  key: string;
  component: React.JSX.Element | ComponentType;
}
/**
 * @hidden
 * @public */
type FieldsetMembers = FieldMember | FieldError | DecorationMember;
/**
 * @hidden
 * @beta */
interface FieldsetState {
  path: Path;
  name: string;
  level: number;
  title?: string;
  description?: string;
  hidden?: boolean;
  collapsible?: boolean;
  collapsed?: boolean;
  columns?: number | number[];
  members: FieldsetMembers[];
}
/**
 * @hidden
 * @beta */
interface StateTree<T> {
  value?: T | undefined;
  children?: {
    [key: string]: StateTree<T>;
  };
}
/** @internal */
declare function setAtPath<T>(currentTree: StateTree<T> | undefined, path: Path, value: T): StateTree<T>;
/** @internal */
type FormState<T extends { [key in string]: unknown } = { [key in string]: unknown }, S extends ObjectSchemaType = ObjectSchemaType> = ObjectFormNode<T, S>;
/** @internal */
interface UseFormStateOptions extends Pick<NodeChronologyProps, 'hasUpstreamVersion'> {
  schemaType: ObjectSchemaType;
  documentValue: unknown;
  comparisonValue: unknown;
  openPath: Path;
  focusPath: Path;
  perspective: TargetPerspective;
  presence: FormNodePresence[];
  validation: ValidationMarker[];
  fieldGroupState?: StateTree<string> | undefined;
  collapsedFieldSets?: StateTree<boolean> | undefined;
  collapsedPaths?: StateTree<boolean> | undefined;
  readOnly?: boolean;
  changesOpen?: boolean;
  displayInlineChanges?: boolean;
}
/** @internal */
declare function useFormState<T extends { [key in string]: unknown } = { [key in string]: unknown }, S extends ObjectSchemaType = ObjectSchemaType>({
  comparisonValue,
  documentValue,
  fieldGroupState,
  collapsedFieldSets,
  collapsedPaths,
  focusPath,
  openPath,
  presence,
  validation,
  readOnly: inputReadOnly,
  changesOpen,
  schemaType,
  perspective,
  hasUpstreamVersion,
  displayInlineChanges
}: UseFormStateOptions): FormState<T, S> | null;
/** @internal */
interface ExpandPathOperation {
  type: 'expandPath';
  path: Path;
}
/** @internal */
interface ExpandFieldSetOperation {
  type: 'expandFieldSet';
  path: Path;
}
/** @internal */
interface SetActiveGroupOperation {
  type: 'setSelectedGroup';
  path: Path;
  groupName: string;
}
/** @internal */
type ExpandOperation = ExpandPathOperation | ExpandFieldSetOperation | SetActiveGroupOperation;
/**
 * This takes a form state and returns a list of operations required to open a node at a particular path
 * @param node - The base form node (i.e. the form state node for the _document_)
 * @param path - The path to open
 *
 * @internal
 */
declare function getExpandOperations(node: BaseFormNode, path: Path): ExpandOperation[];
/** @internal */
interface FormCallbacksValue {
  transformPatches?: (patches: FormPatch[]) => FormPatch[];
  onChange: (patchEvent: PatchEvent) => void;
  onPathFocus: (path: Path, payload?: OnPathFocusPayload) => void;
  onPathBlur: (path: Path) => void;
  onPathOpen: (path: Path) => void;
  onSetPathCollapsed: (path: Path, collapsed: boolean) => void;
  onSetFieldSetCollapsed: (path: Path, collapsed: boolean) => void;
  onFieldGroupSelect: (path: Path, fieldGroupName: string) => void;
}
/** @internal */
declare const FormCallbacksProvider: react.NamedExoticComponent<FormCallbacksValue & {
  children: ReactNode;
}>;
/** @internal */
declare function useFormCallbacks(): FormCallbacksValue;
/** @internal */
interface TemplateOption {
  id: string;
  params?: Record<string, string | number | boolean>;
}
/**
 * @internal
 */
interface EditReferenceOptions {
  id: string;
  type: string;
  parentRefPath: Path;
  template: TemplateOption;
  version?: ReleaseId;
}
/** @internal */
interface EditReferenceLinkComponentProps {
  documentId: string;
  documentType: string;
  parentRefPath: Path;
  template?: TemplateOption;
  children: ReactNode;
}
/**
 * @internal
 */
interface ReferenceInputOptions {
  /**
   * Represents the highlighted path if ths current document has a related open
   * child (e.g. reference in place).
   */
  activePath?: {
    path: Path;
    state: 'selected' | 'pressed' | 'none';
  };
  /**
   * A specialized `EditReferenceLinkComponent` component that takes in the needed props to open a
   * referenced document to the right
   */
  EditReferenceLinkComponent?: ComponentType<Omit<HTMLProps<'a'>, 'children'> & EditReferenceLinkComponentProps>;
  initialValueTemplateItems?: TemplatePermissionsResult[];
  /**
   * Similar to `EditReferenceChildLink` expect without the wrapping component
   */
  onEditReference?: (options: EditReferenceOptions) => void;
  /**
   * Prevent creation of documents from reference fields.
   */
  disableNew?: boolean;
}
/**
 * @internal
 */
declare function useReferenceInputOptions(): ReferenceInputOptions;
/**
 * @internal
 */
declare function ReferenceInputOptionsProvider(props: ReferenceInputOptions & {
  children: ReactNode;
}): react.JSX.Element;
/** @internal */
declare const defaultRenderAnnotation: RenderAnnotationCallback;
/** @internal */
declare const defaultRenderBlock: RenderBlockCallback;
/** @internal */
declare const defaultRenderInlineBlock: RenderBlockCallback;
/** @internal */
declare const defaultRenderField: RenderFieldCallback;
/** @internal */
declare const defaultRenderInput: RenderInputCallback;
/** @internal */
declare const defaultRenderItem: RenderItemCallback;
/** @internal */
declare const defaultRenderPreview: RenderPreviewCallback;
/**
 * @alpha
 */
interface FormBuilderProps extends Omit<ObjectFormNode, 'level' | 'path' | 'presence' | 'validation' | '_allMembers' | '__unstable_computeDiff' | 'displayInlineChanges'> {
  /** @internal */
  __internal_fieldActions?: DocumentFieldAction[];
  /** @internal Considered internal – do not use. */
  __internal_patchChannel: PatchChannel;
  /** @internal Considered internal – do not use. */
  __internal_inspectOpen?: boolean;
  autoFocus?: boolean;
  changesOpen?: boolean;
  collapsedFieldSets: StateTree<boolean> | undefined;
  collapsedPaths: StateTree<boolean> | undefined;
  focused: boolean | undefined;
  focusPath: Path;
  id: string;
  onChange: (changeEvent: PatchEvent) => void;
  onFieldGroupSelect: (path: Path, groupName: string) => void;
  onPathBlur: (path: Path) => void;
  onPathFocus: (path: Path) => void;
  onPathOpen: (path: Path) => void;
  onSetFieldSetCollapsed: (path: Path, collapsed: boolean) => void;
  onSetPathCollapsed: (path: Path, collapsed: boolean) => void;
  openPath?: Path;
  perspective?: TargetPerspective;
  presence: FormNodePresence[];
  readOnly?: boolean;
  schemaType: ObjectSchemaType;
  validation: ValidationMarker[];
  value: FormDocumentValue | undefined;
  compareValue?: SanityDocument;
}
/**
 * @alpha
 */
declare function FormBuilder(props: FormBuilderProps): react.JSX.Element;
/**
 * @alpha This API might change.
 */
interface FormProviderProps {
  /** @internal */
  __internal_fieldActions?: DocumentFieldAction[];
  /** @internal Considered internal, do not use. */
  __internal_patchChannel: PatchChannel;
  /** @internal Considered internal, do not use. */
  __internal_inspectOpen?: boolean;
  autoFocus?: boolean;
  changesOpen?: boolean;
  children?: ReactNode;
  collapsedFieldSets: StateTree<boolean> | undefined;
  collapsedPaths: StateTree<boolean> | undefined;
  focusPath: Path;
  focused: boolean | undefined;
  groups: FormFieldGroup[];
  id: string;
  onChange: (changeEvent: PatchEvent) => void;
  onPathBlur: (path: Path) => void;
  onPathFocus: (path: Path) => void;
  onPathOpen: (path: Path) => void;
  onFieldGroupSelect: (path: Path, groupName: string) => void;
  onSetPathCollapsed: (path: Path, collapsed: boolean) => void;
  onSetFieldSetCollapsed: (path: Path, collapsed: boolean) => void;
  presence: FormNodePresence[];
  readOnly?: boolean;
  schemaType: ObjectSchemaType;
  validation: ValidationMarker[];
}
/**
 * Default wiring for `FormBuilderProvider` when used with Sanity
 *
 * @alpha This API might change.
 */
declare function FormProvider(props: FormProviderProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
type StudioCrossDatasetReferenceInputProps = ObjectInputProps<CrossDatasetReferenceValue, CrossDatasetReferenceSchemaType>;
/**
 *
 * @hidden
 * @beta
 */
declare function StudioCrossDatasetReferenceInput(props: StudioCrossDatasetReferenceInputProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
type StudioReferenceInputProps = ObjectInputProps<Reference, ReferenceSchemaType>;
/**
 *
 * @hidden
 * @beta
 */
declare function StudioReferenceInput(props: StudioReferenceInputProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
type UploadProgressEvent = {
  type: 'uploadProgress';
  patches: FormPatch[] | null;
};
/**
 *
 * @hidden
 * @beta
 */
type ResolvedUploader = {
  uploader: Uploader;
  type: SchemaType;
};
/**
 *
 * @hidden
 * @beta
 */
type UploadOptions = {
  metadata?: AssetMetadataType[];
  storeOriginalFilename?: boolean;
  label?: string;
  title?: string;
  description?: string;
  creditLine?: string;
  source?: AssetSourceSpec;
};
/**
 * @internal
 */
type UploaderDef = {
  type: string;
  accepts: string;
  upload: (client: SanityClient, file: File, type: SchemaType) => Observable<UploadProgressEvent>;
};
/**
 *
 * @hidden
 * @beta
 */
type Uploader<S extends SchemaType = SchemaType> = {
  type: string;
  accepts: string;
  upload: (client: SanityClient, file: File, type: S, options?: UploadOptions) => Observable<UploadProgressEvent>;
  priority: number;
};
/**
 *
 * @hidden
 * @beta
 */
interface FileLike {
  type: string;
  name?: string;
}
/**
 *
 * @hidden
 * @beta
 */
type UploaderResolver<S extends SchemaType = SchemaType> = (type: S, file: FileLike) => Uploader<S> | null;
/**
 *
 * @hidden
 * @beta
 */
type AssetSourcesResolver<S extends SchemaType = SchemaType> = (type: S, file?: FileLike) => AssetSource[];
/**
 * @hidden
 * @beta */
interface BaseFileInputValue extends Partial<File$1> {
  _upload?: UploadState;
}
/**
 * @hidden
 * @beta */
interface BaseFileInputProps extends ObjectInputProps<BaseFileInputValue, FileSchemaType> {
  assetSources: AssetSource[];
  directUploads?: boolean;
  observeAsset: (documentId: string) => Observable<FileAsset>;
  resolveUploader: UploaderResolver;
  client: SanityClient;
}
/**
 * @hidden
 * @beta */
type FileInputProps = Omit<BaseFileInputProps, 'assetSources' | 'directUploads' | 'observeAsset' | 'resolveUploader' | 'client' | 't'>;
/**
 * @hidden
 * @beta */
declare function StudioFileInput(props: FileInputProps): react.JSX.Element;
/**
 * @hidden
 * @beta
 */
interface BaseImageInputValue extends Partial<Image> {
  _upload?: UploadState;
}
/**
 * @hidden
 * @beta */
interface BaseImageInputProps extends ObjectInputProps<BaseImageInputValue, ImageSchemaType> {
  assetSources: AssetSource[];
  directUploads?: boolean;
  imageUrlBuilder: ImageUrlBuilder;
  isUploading: boolean;
  observeAsset: (documentId: string) => Observable<ImageAsset>;
  resolveUploader: UploaderResolver;
  client: SanityClient;
  t: (key: string, values?: Record<string, string>) => string;
}
/**
 * @hidden
 * @beta */
type ImageInputProps = Omit<BaseImageInputProps, 'assetSources' | 'directUploads' | 'imageUrlBuilder' | 'observeAsset' | 'client' | 'resolveUploader'>;
/**
 * @hidden
 * @beta */
declare function StudioImageInput(props: ImageInputProps): react.JSX.Element;
/**
 * @internal
 */
interface EnhancedObjectDialogContextValue {
  /**
   * A boolean indicating whether tree editing is enabled
   */
  enabled: boolean;
  /**
   * A boolean indicating whether legacy editing is enabled - meaning that it will use the old modal based editing experience
   */
  legacyEditing: boolean;
}
/**
 * @internal
 * @deprecated This hook is no longer used and will be removed in a future release as we make the enhanced object dialog the default.
 */
declare function useEnhancedObjectDialog(): EnhancedObjectDialogContextValue;
/**
 * @hidden
 * @beta */
interface ArrayInputInsertEvent<Item> {
  items: Item[];
  position: 'before' | 'after';
  referenceItem: KeyedSegment | number;
  skipInitialValue?: boolean;
  open?: boolean;
}
/**
 * @hidden
 * @beta */
interface ArrayInputCopyEvent<Item> {
  items: Item[];
}
/**
 * @hidden
 * @beta */
interface ArrayInputMoveItemEvent {
  fromIndex: number;
  toIndex: number;
}
/**
 * @hidden
 * @beta */
interface UploadEvent {
  file: File;
  schemaType: SchemaType;
  uploader: Uploader;
}
/**
 * Props for rendering text decorations in Portable Text blocks.
 * It could be decorations like bold, italic, subscript etc.
 *
 * @public
 */
interface BlockDecoratorProps {
  /**
   * The span node as rendered without the decorator.
   */
  children: React.JSX.Element;
  /**
   * If the span node currently is focused by the user.
   */
  focused: boolean;
  /**
   * The default render function for this decorator,
   * some decorators are proved by default and has a default rendering.
   */
  renderDefault: (props: BlockDecoratorProps) => React.JSX.Element;
  /**
   * The decorator schema type. Icon can be found here.
   */
  schemaType: BlockDecoratorDefinition;
  /**
   * If the span node text currently is selected by the user.
   */
  selected: boolean;
  /**
   * The title of the decorator (e.g. 'Underlined text') for UI-representation.
   */
  title: string;
  /**
   * The value of the decorator (e.g. 'underlined') as it
   * appears in the child.marks array of the text node.
   */
  value: string;
}
/**
 * Props for rendering a text block style.
 *
 * @public
 */
interface BlockStyleProps {
  /**
   * The value of the block that is rendered style for.
   */
  block: PortableTextTextBlock;
  /**
   * The block as rendered without this style.
   */
  children: React.JSX.Element;
  /**
   * If the block currently has focus in the text editor.
   */
  focused: boolean;
  /**
   * The default rendering function for this style.
   */
  renderDefault: (props: BlockStyleProps) => React.JSX.Element;
  /**
   * The schema type for this style.
   */
  schemaType: BlockStyleDefinition;
  /**
   * If the block currently have a text selection.
   */
  selected: boolean;
  /**
   * The title of the style (e.g. 'Large Heading') for UI-representation.
   */
  title: string;
  /**
   * The value of the style (e.g. 'h1') as it appears in the block's `.style` property value.
   */
  value: string;
}
/**
 * Props for rendering a Portable Text block as a list item.
 *
 * @public
 */
interface BlockListItemProps {
  /**
   * The block that is rendered as a list item.
   */
  block: PortableTextTextBlock;
  /**
   * The block rendered without the list style.
   */
  children: React.JSX.Element;
  /**
   * If the block currently is focused by the user.
   */
  focused: boolean;
  /**
   * The nesting level of this list item.
   */
  level: number;
  /**
   * The default function for rendering this as a list item. Some list types are built in and
   * will have a default rendering.
   */
  renderDefault: (props: BlockListItemProps) => React.JSX.Element;
  /**
   * The schema type for this list type. Icon can be found here.
   */
  schemaType: BlockListDefinition;
  /**
   * If the user currently has a text selection in this block.
   */
  selected: boolean;
  /**
   * The title of the list item type (e.g. 'Bullet list') for UI-representation.
   */
  title: string;
  /**
   * The value of the list item type (e.g. 'bullet') as it appears in the block.listItem attribute.
   */
  value: string;
}
/**
 * Props for rendering a Portable Text annotation
 *
 * @public
 * @remarks If you want to render a mix of the annotated text and non-text content, you have to attribute
 * the non-text containers with `contentEditable={false}`. See the second example.
 * @example Simple example of customizing the annotation text to render yellow.
 * ```ts
 * (props: BlockAnnotationProps) =>
 *   props.renderDefault({
 *     ...props,
 *     textElement: <span style={{color: 'yellow'}}>{props.textElement}</span>,
 *   })
 * ```
 * @example Simple example of rendering the annotation with a custom modal for editing.
 * Note that the form content container is attributed as `contentEditable={false}`.
 * This is to signal to the text editor that this content isn't part of the editable text.
 * ```ts
 * (props: BlockAnnotationProps) => {
 *   return (
 *     <>
 *       // Render the annotated text
 *       <span onClick={props.onOpen}>
 *         {props.textElement}
 *       </span>
 *       // Render the editing form if the object is opened
 *       {props.open && (
 *         <Dialog
 *           contentEditable={false} // Attribute this as non-editable to the text editor
 *           header={`Edit ${props.schemaType.title}`}
 *           id={`dialog-${props.value._key}`}
 *           onClickOutside={props.onClose}
 *           onClose={props.onClose}
 *         >
 *           <Box margin={2} padding={2}>
 *             {props.children}
 *           </Box>
 *         </Dialog>
 *      )}
 *     </>
 *   )
 * }
 * ```
 * */
interface BlockAnnotationProps {
  /**
   * Boundary element of the floating toolbar element.
   */
  __unstable_floatingBoundary: HTMLElement | null;
  /**
   * Boundary element where the text for this annotation appears.
   */
  __unstable_referenceBoundary: HTMLElement | null;
  /**
   * DOM element for the annotated text.
   */
  __unstable_referenceElement: HTMLElement | null;
  /**
   * Wether the annotated text node has editor focus.
   * @remarks differs from `focused` which is wether the annotation object has form focus.
   */
  __unstable_textElementFocus?: boolean;
  /**
   * The input form for the annotation object.
   * @remarks If you wrap this in something, you must make sure to put `contentEditable={false}` on the root container.
   * Otherwise the editor will think content is part of the editable text and will error.
   */
  children: ReactNode;
  /**
   * If the editor form for this annotation object currently have form focus.
   */
  focused: boolean;
  /**
   * Markers (meta data) connected to this annotation.
   * @deprecated - use `renderBlock` and `renderInlineBlock` interfaces instead
   */
  markers: PortableTextMarker[];
  /**
   * Closes the editing form connected to this annotation.
   */
  onClose: () => void;
  /**
   * Opens the editing form connected to this annotation.
   */
  onOpen: () => void;
  /**
   * Focus a form node in the object for this annotation.
   * @param path - the relative path to the form node to put focus on.
   */
  onPathFocus: (path: Path) => void;
  /**
   * Removes the annotation object from the text.
   */
  onRemove: () => void;
  /**
   * If the annotation is currently opened for editing.
   */
  open: boolean;
  /**
   * The parent schema type. For annotations this this the block type.
   */
  parentSchemaType: SchemaType;
  /**
   * The full form path to this annotation from document root.
   */
  path: Path;
  /**
   * Form presence for this annotation.
   */
  presence: FormNodePresence[];
  /**
   * Is the annotation object read only?
   */
  readOnly: boolean;
  /**
   * Plugin chain render callback.
   */
  renderAnnotation?: RenderAnnotationCallback;
  /**
   * Plugin chain render callback.
   */
  renderBlock?: RenderBlockCallback;
  /**
   * Plugin chain render callback.
   */
  renderDefault: (props: BlockAnnotationProps) => React.JSX.Element;
  /**
   * Plugin chain render callback.
   */
  renderField: RenderFieldCallback;
  /**
   * Plugin chain render callback.
   */
  renderInlineBlock?: RenderBlockCallback;
  /**
   * Plugin chain render callback.
   */
  renderInput: RenderInputCallback;
  /**
   * Plugin chain render callback.
   */
  renderItem: RenderArrayOfObjectsItemCallback;
  /**
   * Plugin chain render callback.
   */
  renderPreview: RenderPreviewCallback;
  /**
   * The schema type for the annotation object.
   */
  schemaType: ObjectSchemaType & {
    i18nTitleKey?: string;
  };
  /**
   * If the annotated text currently is selected by the user.
   */
  selected: boolean;
  /**
   * React element of the text that is being annotated.
   */
  textElement: React.JSX.Element;
  /**
   * Form validation for the annotation object.
   */
  validation: FormNodeValidation[];
  /**
   * Value of the annotation object.
   */
  value: PortableTextObject;
}
/**
 * Props for rendering a Portable Text block
 *
 * @public
 */
interface BlockProps {
  /**
   * Boundary element of the floating toolbar element.
   */
  __unstable_floatingBoundary: HTMLElement | null;
  /**
   * Boundary element for the block.
   */
  __unstable_referenceBoundary: HTMLElement | null;
  /**
   * DOM element for the block.
   */
  __unstable_referenceElement: HTMLElement | null;
  /**
   * The default rendering of the block (the text).
   */
  children: ReactNode;
  /**
   * Whether the block has changes compared to the published version.
   */
  changed: boolean;
  /**
   * If the block currently is focused by the user.
   */
  focused: boolean;
  /**
   * Markers (meta data) connected to this annotation.
   * @deprecated - use `renderBlock` and `renderInlineBlock` interfaces instead
   */
  markers: PortableTextMarker[];
  /**
   * Closes the editing form connected to this block.
   * For regular text blocks this is not relevant.
   */
  onClose: () => void;
  /**
   * Opens the editing form connected to this block.
   * For regular text blocks this is not relevant.
   */
  onOpen: () => void;
  /**
   * Focus a form node in this block.
   * @param path - the relative path to the form node to put focus on.
   */
  onPathFocus: (path: Path) => void;
  /**
   * Removes the block.
   */
  onRemove: () => void;
  /**
   * If the block is currently opened for editing.
   */
  open: boolean;
  /**
   * The parent schema type (array type).
   */
  parentSchemaType: ArraySchemaType | ObjectSchemaType;
  /**
   * The full form path to this block from document root.
   */
  path: Path;
  /**
   * Form presence for this block.
   */
  presence: FormNodePresence[];
  /**
   * Is the block object read only?
   */
  readOnly: boolean;
  /**
   * Plugin chain render callback.
   */
  renderAnnotation?: RenderAnnotationCallback;
  /**
   * Plugin chain render callback.
   */
  renderBlock?: RenderBlockCallback;
  /**
   * Plugin chain render callback (default rendering function of the block).
   */
  renderDefault: (props: BlockProps) => React.JSX.Element;
  /**
   * Plugin chain render callback.
   */
  renderField: RenderFieldCallback;
  /**
   * Plugin chain render callback.
   */
  renderInlineBlock?: RenderBlockCallback;
  /**
   * Plugin chain render callback.
   */
  renderInput: RenderInputCallback;
  /**
   * Plugin chain render callback.
   */
  renderItem: RenderArrayOfObjectsItemCallback;
  /**
   * Plugin chain render callback.
   */
  renderPreview: RenderPreviewCallback;
  /**
   * The schema type for the block.
   */
  schemaType: ObjectSchemaType;
  /**
   * If the block is in the user's selection.
   */
  selected: boolean;
  /**
   * Form validation for the block object.
   */
  validation: FormNodeValidation[];
  /**
   * Value of the block.
   */
  value: PortableTextBlock;
}
/**
 * Props for rendering Portable Text plugins
 *
 * @beta
 */
interface PortableTextPluginsProps {
  renderDefault: (props: PortableTextPluginsProps) => React.JSX.Element;
  plugins: {
    markdown?: {
      /**
       * @deprecated - add the configuration directly to `markdown` instead
       */
      config: MarkdownConfig;
    } | (MarkdownShortcutsPluginProps & {
      config?: undefined;
      /**
       * @defaultValue true
       */
      enabled?: boolean;
    });
    pasteLink?: {
      /**
       * @defaultValue true
       */
      enabled?: boolean;
    } & PasteLinkPluginProps;
    typography?: {
      /**
       * @defaultValue true
       */
      enabled?: boolean;
    } & TypographyPluginProps;
  };
}
/**
 * @beta
 */
type MarkdownConfig = Omit<MarkdownShortcutsPluginProps, 'unorderedList' | 'orderedList'> & ({
  orderedList?: undefined;
  /**
   * @deprecated - use `orderedList` instead
   */
  orderedListStyle?: MarkdownShortcutsPluginProps['orderedList'];
} | {
  orderedList?: MarkdownShortcutsPluginProps['orderedList'];
  /**
   * @deprecated - use `orderedList` instead
   */
  orderedListStyle?: undefined;
}) & ({
  unorderedList?: undefined;
  /**
   * @deprecated - use `unorderedList` instead
   */
  unorderedListStyle?: MarkdownShortcutsPluginProps['unorderedList'];
} | {
  unorderedList?: MarkdownShortcutsPluginProps['unorderedList'];
  /**
   * @deprecated - use `unorderedList` instead
   */
  unorderedListStyle?: undefined;
});
/** @public */
type ObjectItem = {
  _type?: string;
  _key: string;
};
/**
 * Props for the base item component.
 *
 * @public
 */
interface BaseItemProps<T> extends NodeDiffProps<ProvenanceDiffAnnotation> {
  /** The schema type of the item. */
  schemaType: SchemaType;
  /** The index of the item. */
  index: number;
  /** The level of the item. */
  level: number;
  /** The value of the item. */
  value: unknown;
  /** The path of the item. */
  path: Path;
  /** The title of the item. */
  title: string | undefined;
  /** The description of the item. */
  description: string | undefined;
  /** The ID of the input element. */
  inputId: string;
  /** The function to call when the item receives focus. */
  onFocus: (event: FocusEvent) => void;
  /** The function to call when the item loses focus. */
  onBlur: (event: FocusEvent) => void;
  /** Whether the item is read-only. */
  readOnly?: boolean;
  /** Whether the item is focused. */
  focused?: boolean;
  /** The function to call when the item is removed. */
  onRemove: () => void;
  /**
   * @hidden
   * @beta */
  onInsert: (event: Omit<ArrayInputInsertEvent<T>, 'referenceItem'>) => void;
  /**
   * @hidden
   * @beta */
  onCopy: (event: Omit<ArrayInputCopyEvent<T>, 'referenceItem'>) => void;
  /** The children of the item. */
  children: ReactNode;
  /** The validation markers for the item. */
  validation: FormNodeValidation[];
  /**
   * @hidden
   * @beta */
  presence: FormNodePresence[];
  /** The function to call to render the default item. See {@link ItemProps} */
  renderDefault: (props: ItemProps) => React.JSX.Element;
}
/**
 * Props for the ObjectItem component.
 * @public
 */
interface ObjectItemProps<Item extends ObjectItem = ObjectItem> extends BaseItemProps<Item> {
  /** Whether the item has changes in a draft. */
  changed: boolean;
  /** The schema type of the object. */
  schemaType: ObjectSchemaType;
  /** The schema type of the parent array. */
  parentSchemaType: ArraySchemaType;
  /** Whether the item is collapsed. */
  collapsed: boolean | undefined;
  /** Whether the item is collapsible. */
  collapsible: boolean | undefined;
  /** Callback for when the item is collapsed. */
  onCollapse: () => void;
  /** Callback for when the item is expanded. */
  onExpand: () => void;
  /** Whether the item is open. */
  open: boolean;
  /** Callback for when the item is closed. */
  onClose: () => void;
  /** Callback for when the item is opened. */
  onOpen: () => void;
  /** The value of the item. */
  value: Item;
  /**
   * @hidden
   * @beta */
  inputProps: Omit<ObjectInputProps, 'renderDefault'>;
}
/** @public */
type ItemProps = ObjectItemProps | ObjectItemProps<CrossDatasetReferenceValue & ObjectItem> | ObjectItemProps<FileValue & ObjectItem> | ObjectItemProps<GeopointValue & ObjectItem> | ObjectItemProps<ImageValue & ObjectItem> | ObjectItemProps<ReferenceValue & ObjectItem> | ObjectItemProps<SlugValue & ObjectItem> | PrimitiveItemProps;
/** @public */
interface PrimitiveItemProps extends BaseItemProps<string | number | boolean> {
  /**
   * The value of the primitive item.
   */
  value: string | number | boolean;
  /**
   * The schema type of the primitive item.
   */
  schemaType: NumberSchemaType | BooleanSchemaType | StringSchemaType;
  /**
   * The schema type of the parent array containing the item.
   */
  parentSchemaType: ArraySchemaType;
}
/**
 * @hidden
 * @public  */
type RenderArrayOfObjectsItemCallback = (itemProps: Omit<ObjectItemProps, 'renderDefault'>) => ReactNode;
/**
 * @hidden
 * @beta */
type RenderArrayOfPrimitivesItemCallback = (itemProps: Omit<PrimitiveItemProps, 'renderDefault'>) => ReactNode;
/**
 * @hidden
 * @public */
type RenderItemCallback = (itemProps: Omit<ObjectItemProps, 'renderDefault'> | Omit<PrimitiveItemProps, 'renderDefault'>) => ReactNode;
/**
 * @hidden
 * @public */
type RenderFieldCallback<T extends FieldProps = FieldProps> = (fieldProps: Omit<T, 'renderDefault'>) => ReactNode;
/**
 * @hidden
 * @public */
type RenderInputCallback<T extends InputProps = InputProps> = (inputProps: Omit<T, 'renderDefault'>) => ReactNode;
/**
 * @hidden
 * @public */
type RenderBlockCallback<T extends BlockProps = BlockProps> = (blockProps: Omit<T, 'renderDefault'>) => ReactNode;
/**
 * @hidden
 * @public */
type RenderAnnotationCallback<T extends BlockAnnotationProps = BlockAnnotationProps> = (annotationProps: Omit<T, 'renderDefault'>) => ReactNode;
/**
 *
 * @hidden
 * @public
 */
interface RenderPreviewCallbackProps<TLayoutKey = PreviewLayoutKey> {
  actions?: ReactNode | ComponentType<{
    layout: TLayoutKey;
  }>;
  children?: ReactNode;
  error?: Error | null;
  fallbackTitle?: ReactNode;
  isPlaceholder?: boolean;
  layout?: TLayoutKey;
  mediaDimensions?: PreviewMediaDimensions;
  progress?: number;
  status?: ReactNode | ComponentType<{
    layout: TLayoutKey;
  }>;
  value: unknown;
  withBorder?: boolean;
  withRadius?: boolean;
  withShadow?: boolean;
  schemaType: SchemaType;
  skipVisibilityCheck?: boolean;
  style?: CSSProperties;
}
/**
 * @hidden
 * @public */
type RenderPreviewCallback = (props: RenderPreviewCallbackProps) => ReactNode;
/**
 * @hidden
 * @beta */
interface OnPathFocusPayload {
  selection?: EditorSelection;
}
/**
 * @hidden
 * @beta */
interface InputOnSelectFileFunctionProps {
  assetSource: AssetSource;
  schemaType: SchemaType;
  file: File;
}
/**
 * @hidden
 * @public */
interface BaseInputProps {
  renderDefault: (props: InputProps) => React.JSX.Element;
  /**
   * Whether the input should display inline changes. Inline changes express how a field's value
   * differs from its upstream version. Unlike custom diff components, inline changes is a mode
   * that allows the input component itself to display the change in situ.
   */
  displayInlineChanges: boolean;
}
/**
 * @hidden
 * @public */
interface ObjectInputProps<T = Record<string, any>, S extends ObjectSchemaType = ObjectSchemaType> extends BaseInputProps, Omit<ObjectFormNode<T, S>, '_allMembers' | 'displayInlineChanges'> {
  /**
   * @hidden
   * @beta */
  groups: FormFieldGroup[];
  /**
   * @hidden
   * @beta */
  onChange: (patch: FormPatch | FormPatch[] | PatchEvent) => void;
  /**
   * @hidden
   * @beta */
  onFieldCollapse: (fieldName: string) => void;
  /**
   * @hidden
   * @beta */
  onFieldExpand: (fieldName: string) => void;
  /**
   * @hidden
   * @beta */
  onFieldSetCollapse: (fieldSetName: string) => void;
  /**
   * @hidden
   * @beta */
  onFieldSetExpand: (fieldSetName: string) => void;
  /**
   * @hidden
   * @beta */
  onFieldGroupSelect: (groupName: string) => void;
  /**
   * @hidden
   * @beta */
  onPathFocus: (path: Path) => void;
  /**
   * @hidden
   * @beta */
  onFieldOpen: (fieldName: string) => void;
  /**
   * @hidden
   * @beta */
  onFieldClose: (fieldName: string) => void;
  /**
   * @hidden
   * @beta */
  renderAnnotation?: RenderAnnotationCallback;
  /**
   * @hidden
   * @beta */
  renderBlock?: RenderBlockCallback;
  /**
   * @hidden
   * @beta */
  renderInput: RenderInputCallback;
  /**
   * @hidden
   * @beta */
  renderField: RenderFieldCallback;
  /**
   * @hidden
   * @beta */
  renderInlineBlock?: RenderBlockCallback;
  /**
   * @hidden
   * @beta */
  renderItem: RenderArrayOfObjectsItemCallback;
  /**
   * @hidden
   * @beta */
  renderPreview: RenderPreviewCallback;
  /**
   * @hidden
   * @beta */
  elementProps: ComplexElementProps;
}
/**
 * @hidden
 * @public */
interface ArrayOfObjectsInputProps<T extends {
  _key: string;
} = {
  _key: string;
}, S extends ArraySchemaType = ArraySchemaType> extends BaseInputProps, Omit<ArrayOfObjectsFormNode<T[], S>, 'displayInlineChanges'> {
  /**
   * @hidden
   * @beta */
  arrayFunctions?: ComponentType<ArrayInputFunctionsProps<T, S>>;
  /**
   * @hidden
   * @beta */
  onChange: (patch: FormPatch | FormPatch[] | PatchEvent) => void;
  /**
   * @hidden
   * @beta */
  onItemAppend: (item: T) => void;
  /**
   * @hidden
   * @beta */
  onItemPrepend: (item: T) => void;
  /**
   * @hidden
   * @beta */
  onItemRemove: (itemKey: string) => void;
  /**
   * @hidden
   * @beta */
  onItemMove: (event: ArrayInputMoveItemEvent) => void;
  /**
   * @hidden
   * @beta */
  onInsert: (event: ArrayInputInsertEvent<T>) => void;
  /**
   * @hidden
   * @beta */
  resolveInitialValue: (type: SchemaType, params: Record<string, unknown>) => Promise<T>;
  /**
   * @hidden
   * @beta */
  resolveUploader: UploaderResolver<ObjectSchemaType>;
  /**
   * @hidden
   * @beta */
  onUpload?: (event: UploadEvent) => void;
  /**
   * @hidden
   * @beta */
  onSelectFile?: (props: InputOnSelectFileFunctionProps) => void;
  /**
   * @hidden
   * @beta */
  onPathFocus: (path: Path, payload?: OnPathFocusPayload) => void;
  /**
   * for array inputs using expand/collapse semantics for items
   *
   * @hidden
   * @beta
   */
  onItemCollapse: (itemKey: string) => void;
  /**
   * @hidden
   * @beta */
  onItemExpand: (itemKey: string) => void;
  /**
   * for array inputs using modal open/close semantics for items
   *
   * @hidden
   * @beta
   */
  onItemOpen: (path: Path) => void;
  /**
   * @hidden
   * @beta */
  onItemClose: () => void;
  /**
   * @hidden
   * @beta */
  renderAnnotation?: RenderAnnotationCallback;
  /**
   * @hidden
   * @beta */
  renderBlock?: RenderBlockCallback;
  /**
   * @hidden
   * @beta */
  renderInlineBlock?: RenderBlockCallback;
  /**
   * @hidden
   * @beta */
  renderField: RenderFieldCallback;
  /**
   * @hidden
   * @beta */
  renderInput: RenderInputCallback;
  /**
   * @hidden
   * @beta */
  renderItem: RenderArrayOfObjectsItemCallback;
  /**
   * @hidden
   * @beta */
  renderPreview: RenderPreviewCallback;
  /**
   * @hidden
   * @beta */
  elementProps: ComplexElementProps;
}
/**
 * @hidden
 * @beta */
type ArrayOfPrimitivesElementType<T extends any[]> = T extends (infer K)[] ? K : unknown;
/**
 * @hidden
 * @public */
interface ArrayOfPrimitivesInputProps<T extends string | boolean | number = string | boolean | number, S extends ArraySchemaType = ArraySchemaType> extends BaseInputProps, Omit<ArrayOfPrimitivesFormNode<T[], S>, 'displayInlineChanges'> {
  /**
   * @hidden
   * @beta */
  arrayFunctions?: ComponentType<ArrayInputFunctionsProps<T, S>>;
  onSetCollapsed: (collapsed: boolean) => void;
  /**
   * @hidden
   * @beta */
  onChange: (patch: FormPatch | FormPatch[] | PatchEvent) => void;
  /**
   * @hidden
   * @beta */
  onItemAppend: (item: ArrayOfPrimitivesElementType<T[]>) => void;
  /**
   * @hidden
   * @beta */
  onItemPrepend: (item: ArrayOfPrimitivesElementType<T[]>) => void;
  /**
   * @hidden
   * @beta */
  onItemRemove: (index: number) => void;
  /**
   * @hidden
   * @beta */
  onMoveItem: (event: ArrayInputMoveItemEvent) => void;
  /**
   * @hidden
   * @beta */
  onInsert: (event: {
    items: T[];
    position: 'before' | 'after';
    referenceIndex: number;
  }) => void;
  /**
   * @hidden
   * @beta */
  resolveUploader: UploaderResolver<NumberSchemaType | BooleanSchemaType | StringSchemaType>;
  /**
   * @hidden
   * @beta */
  onUpload: (event: UploadEvent) => void;
  /**
   * @hidden
   * @beta */
  onIndexFocus: (index: number) => void;
  /**
   * @hidden
   * @beta */
  renderAnnotation?: RenderAnnotationCallback;
  /**
   * @hidden
   * @beta */
  renderBlock?: RenderBlockCallback;
  /**
   * @hidden
   * @beta */
  renderInlineBlock?: RenderBlockCallback;
  /**
   * @hidden
   * @beta */
  renderInput: RenderInputCallback;
  /**
   * @hidden
   * @beta */
  renderItem: RenderArrayOfPrimitivesItemCallback;
  /**
   * @hidden
   * @beta */
  renderPreview: RenderPreviewCallback;
  /**
   * @hidden
   * @beta */
  elementProps: ComplexElementProps;
}
/**
 * @hidden
 * @public */
interface PrimitiveInputElementProps {
  'value'?: string;
  'id': string;
  'readOnly': boolean;
  'placeholder'?: string;
  'onChange': FormEventHandler;
  'onFocus': FocusEventHandler;
  'onBlur': FocusEventHandler;
  'ref': MutableRefObject<any>;
  'aria-describedby': string | undefined;
}
/**
 * @hidden
 * @beta */
interface ComplexElementProps {
  'id': string;
  'onFocus': FocusEventHandler;
  'onBlur': FocusEventHandler;
  'ref': MutableRefObject<any>;
  'aria-describedby': string | undefined;
}
/**
 * @hidden
 * @public */
interface StringInputProps<S extends StringSchemaType = StringSchemaType> extends BaseInputProps, Omit<StringFormNode<S>, 'displayInlineChanges'> {
  /**
   * @hidden
   * @beta */
  onChange: (patch: FormPatch | FormPatch[] | PatchEvent) => void;
  validationError?: string;
  /**
   * @hidden
   * @beta */
  elementProps: PrimitiveInputElementProps;
}
/**
 * @hidden
 * @public */
interface NumberInputProps<S extends NumberSchemaType = NumberSchemaType> extends BaseInputProps, Omit<NumberFormNode<S>, 'displayInlineChanges'> {
  /**
   * @hidden
   * @beta */
  onChange: (patch: FormPatch | FormPatch[] | PatchEvent) => void;
  validationError?: string;
  /**
   * @hidden
   * @beta */
  elementProps: PrimitiveInputElementProps;
}
/**
 * @hidden
 * @public */
interface BooleanInputProps<S extends BooleanSchemaType = BooleanSchemaType> extends BaseInputProps, Omit<BooleanFormNode<S>, 'displayInlineChanges'> {
  /**
   * @hidden
   * @beta */
  onChange: (patch: FormPatch | FormPatch[] | PatchEvent) => void;
  /**
   * A shorthand aggregation of any validation errors the input currently have
   * Will be falsey if no error.
   * In the case of multiple errors it will be a newline delimited string of each error message
   * For advanced use cases use the ´validation´ prop which contains more levels and details
   */
  validationError?: string;
  /**
   * @hidden
   * @beta */
  elementProps: PrimitiveInputElementProps;
}
/**
 * @hidden
 * @beta */
type PrimitiveInputProps = StringInputProps | BooleanInputProps | NumberInputProps;
/**
 * Component props for the {@link PortableTextInput} React component.
 *
 * Extends {@link ArrayOfObjectsInputProps}.
 *
 * @public
 * */
interface PortableTextInputProps extends ArrayOfObjectsInputProps<PortableTextBlock, ArraySchemaType<PortableTextBlock>> {
  /**
   * A React Ref that can reference the underlying editor instance
   */
  editorRef?: React.MutableRefObject<PortableTextEditor | null>;
  /**
   * Option to hide the default toolbar
   */
  hideToolbar?: boolean;
  /**
   * Assign hotkeys that can be attached to custom editing functions
   */
  hotkeys?: HotkeyOptions;
  /**
   * Whether the input is activated and should receive events on mount.
   * By default, this value is set to `true`
   */
  initialActive?: boolean;
  /**
   * Whether the input is _initially_ open in fullscreen mode
   */
  initialFullscreen?: boolean;
  /**
   * Array of {@link PortableTextMarker} with meta data connected to the content.
   * @deprecated will be removed in the next major version of Sanity Studio.
   * Use the `renderBlock` interface instead.
   */
  markers?: PortableTextMarker[];
  /**
   * Returns changes from the underlying editor
   */
  onEditorChange?: (change: EditorChange, editor: PortableTextEditor) => void;
  /**
   * Optional callback for when the editor goes into or out of full screen mode
   * @hidden
   * @beta
   */
  onFullScreenChange?: (isFullScreen: boolean) => void;
  /**
   * Custom copy function
   */
  onCopy?: OnCopyFn;
  /**
   * Custom paste function
   */
  onPaste?: OnPasteFn;
  /**
   * Function to render custom block actions
   * @deprecated will be removed in the next major version of Sanity Studio.
   * Use the `renderBlock` interface instead.
   */
  renderBlockActions?: RenderBlockActionsCallback;
  /**
   * Function to render custom markers
   * @deprecated will be removed in the next major version of Sanity Studio.
   * Use the `renderBlock` interface instead.
   */
  renderCustomMarkers?: RenderCustomMarkers;
  /**
   * Array of {@link RangeDecoration} that can be used to decorate the content.
   */
  rangeDecorations?: RangeDecoration[];
}
/**
 * @hidden
 * @public */
type InputProps = ArrayOfObjectsInputProps | ArrayOfPrimitivesInputProps | BooleanInputProps | NumberInputProps | ObjectInputProps | ObjectInputProps<CrossDatasetReferenceValue> | ObjectInputProps<FileValue> | ObjectInputProps<GeopointValue> | ObjectInputProps<ImageValue> | ObjectInputProps<ReferenceValue> | ObjectInputProps<SlugValue> | PortableTextInputProps | StringInputProps;
/**
 * Data passed to the `onPaste` handler when content is pasted into a
 * Portable Text editor in Sanity Studio.
 *
 * @beta
 * @remarks
 * This is Studio's own version of the editor's `PasteData` type.
 * The `schemaTypes` field contains Sanity-specific
 * `PortableTextMemberSchemaTypes` instead of the editor's `EditorSchema`.
 */
type PasteData$1 = Omit<PasteData, 'schemaTypes'> & {
  schemaTypes: PortableTextMemberSchemaTypes;
};
/**
 * Custom paste handler for Portable Text in Sanity Studio.
 *
 * @beta
 * @remarks
 * It is encouraged not to return `Promise<undefined>` from the `OnPasteFn` as
 * a mechanism to fall back to the native paste behaviour. This doesn't work in
 * all cases. Always return plain `undefined` if possible.
 */
type OnPasteFn = (data: PasteData$1) => OnPasteResultOrPromise;
/**
 * Studio-owned change types emitted by the Portable Text editor.
 *
 * These types mirror the editor's internal event types but are owned by Studio
 * to decouple Studio's public callback interface from the editor's internals.
 * The `EditorChangePlugin` in `PortableTextInput.tsx` translates
 * `EditorEmittedEvent`s into these change types.
 *
 * @beta
 */
type EditorChange = {
  type: 'blur';
  event: FocusEvent<HTMLDivElement>;
} | {
  type: 'error';
  name: string;
  level: 'warning' | 'error';
  description: string;
  data?: unknown;
} | {
  type: 'focus';
  event: FocusEvent<HTMLDivElement>;
} | {
  type: 'invalidValue';
  resolution: InvalidValueResolution | null;
  value: PortableTextBlock[] | undefined;
} | {
  type: 'loading';
  isLoading: boolean;
} | {
  type: 'mutation';
  patches: Patch[];
  snapshot: PortableTextBlock[] | undefined;
} | {
  type: 'patch';
  patch: Patch;
} | {
  type: 'ready';
} | {
  type: 'connection';
  value: 'online' | 'offline';
} | {
  type: 'redo';
  patches: Patch[];
  snapshot: PortableTextBlock[] | undefined;
} | {
  type: 'selection';
  selection: EditorSelection;
} | {
  type: 'undo';
  patches: Patch[];
  snapshot: PortableTextBlock[] | undefined;
} | {
  type: 'unset';
  previousValue: PortableTextBlock[];
} | {
  type: 'value';
  value: PortableTextBlock[] | undefined;
};
/** @internal @deprecated DO NOT USE */
interface FieldCommentsProps {
  hasComments: boolean;
  button: ReactNode;
  isAddingComment: boolean;
}
/**
 * @hidden
 * @public */
interface BaseFieldProps {
  /** @beta */
  actions?: DocumentFieldAction[];
  /** @internal @deprecated DO NOT USE */
  __internal_comments?: FieldCommentsProps;
  /** @internal @deprecated ONLY USED BY AI ASSIST PLUGIN */
  __internal_slot?: ReactNode;
  schemaType: SchemaType;
  title: string | undefined;
  description: string | undefined;
  /**
   * @hidden
   * @beta */
  presence: FormNodePresence[];
  validation: FormNodeValidation[];
  level: number;
  inputId: string;
  value: unknown | undefined;
  path: Path;
  name: string;
  index: number;
  changed: boolean;
  children: ReactNode;
  version?: string;
  renderDefault: (props: FieldProps) => React.JSX.Element;
}
/**
 * @hidden
 * @public */
interface ObjectFieldProps<T = Record<string, unknown>> extends BaseFieldProps {
  schemaType: ObjectSchemaType;
  value: T | undefined;
  collapsed?: boolean;
  collapsible?: boolean;
  onCollapse: () => void;
  onExpand: () => void;
  open: boolean;
  onClose: () => void;
  onOpen: () => void;
  inputProps: ObjectInputProps<T>;
}
/**
 * @hidden
 * @public */
interface ArrayFieldProps extends BaseFieldProps {
  schemaType: ArraySchemaType;
  value: unknown[] | undefined;
  collapsed?: boolean;
  collapsible?: boolean;
  onCollapse: () => void;
  onExpand: () => void;
  inputProps: ArrayOfObjectsInputProps;
}
/**
 * @hidden
 * @public */
interface ArrayOfPrimitivesFieldProps extends BaseFieldProps {
  schemaType: ArraySchemaType;
  value: unknown[] | undefined;
  collapsed?: boolean;
  collapsible?: boolean;
  onCollapse: () => void;
  onExpand: () => void;
  inputProps: ArrayOfPrimitivesInputProps;
}
/**
 * @hidden
 * @public */
interface NumberFieldProps extends BaseFieldProps {
  schemaType: NumberSchemaType;
  value: number | undefined;
  inputProps: NumberInputProps;
}
/**
 * @hidden
 * @public */
interface BooleanFieldProps extends BaseFieldProps {
  schemaType: BooleanSchemaType;
  value: boolean | undefined;
  inputProps: BooleanInputProps;
}
/**
 * @hidden
 * @public */
interface StringFieldProps extends BaseFieldProps {
  schemaType: StringSchemaType;
  value: string | undefined;
  inputProps: StringInputProps;
}
/** @internal */
type PrimitiveFieldProps = NumberFieldProps | BooleanFieldProps | StringFieldProps;
/**
 * @hidden
 * @public */
type FieldProps = ObjectFieldProps | ObjectFieldProps<CrossDatasetReferenceValue> | ObjectFieldProps<FileValue> | ObjectFieldProps<GeopointValue> | ObjectFieldProps<ImageValue> | ObjectFieldProps<ReferenceValue> | ObjectFieldProps<SlugValue> | ArrayFieldProps | NumberFieldProps | BooleanFieldProps | StringFieldProps;
/**
 * Function for rendering custom block markers
 *
 * @public
 * @hidden
 * @deprecated use `renderBlock`, `renderInlineBlock`, `renderAnnotation` interfaces instead
 */
type RenderCustomMarkers = (markers: PortableTextMarker[]) => ReactNode;
/**
 * Props for rendering block actions
 *
 * @public
 * @hidden
 * @deprecated use `renderBlock`, `renderInlineBlock`, `renderAnnotation` interfaces instead
 */
interface RenderBlockActionsProps {
  block: PortableTextBlock;
  value: PortableTextBlock[] | undefined;
  set: (block: PortableTextBlock) => void;
  unset: () => void;
  insert: (block: PortableTextBlock | PortableTextBlock[]) => void;
}
/**
 * Function for rendering custom block actions
 *
 * @public
 * @hidden
 * @deprecated use `renderBlock`, `renderInlineBlock`, `renderAnnotation` interfaces instead
 */
type RenderBlockActionsCallback = (props: RenderBlockActionsProps) => ReactNode;
/**
 * A generic marker for attaching metadata to specific nodes of the Portable Text input.
 *
 * @public
 * @hidden
 * @deprecated use `renderBlock`, `renderInlineBlock`, `renderAnnotation` interfaces instead
 * @param type - a type name for this marker
 * @param data - some data connected to this marker
 * @param path - the path to the Portable Text content connected to this marker
 */
interface PortableTextMarker {
  type: string;
  data?: unknown;
  path: Path;
}
/**
 * Component for rendering custom block markers
 *
 * @public
 * @hidden
 * @deprecated use `renderBlock`, `renderInlineBlock`, `renderAnnotation` interfaces instead
 */
type FormBuilderCustomMarkersComponent = ComponentType<{
  markers: PortableTextMarker[];
}>;
/**
 *
 * @hidden
 * @beta
 */
type FormBuilderMarkersComponent = ComponentType<{
  markers: PortableTextMarker[];
  renderCustomMarkers?: RenderCustomMarkers;
  validation: FormNodeValidation[];
}>;
/**
 *
 * @hidden
 * @beta
 */
type FormBuilderInputComponentMap = Record<string, {
  field?: ComponentType<FieldProps>;
  item?: ComponentType<ItemProps>;
  input?: ComponentType<InputProps>;
  preview?: ComponentType<PreviewProps>;
}>;
/**
 * These are the props an implementation of the ArrayFunctions component will receive
 *
 *
 * @hidden
 * @beta
 */
interface ArrayInputFunctionsProps<Item, SchemaType extends ArraySchemaType> {
  children?: ReactNode;
  onItemAppend: (itemValue: Item) => void;
  onChange: (event: PatchEvent) => void;
  onValueCreate: (type: SchemaType) => Item;
  onItemPrepend: (itemValue: Item) => void;
  path: Path;
  readOnly?: boolean;
  schemaType: SchemaType;
  value?: Item[];
}
/**
 * @internal
 */
interface FormBuilderFilterFieldFn {
  (type: ObjectSchemaType, field: ObjectField, selectedLanguageIds: string[]): boolean;
}
/**
 * @hidden
 * @beta */
declare function isObjectItemProps(item: ItemProps | Omit<ItemProps, 'renderDefault'>): item is ObjectItemProps;
/**
 * @hidden
 * @beta */
declare function isObjectInputProps(inputProps: InputProps | Omit<InputProps, 'renderDefault'>): inputProps is ObjectInputProps;
/**
 * @hidden
 * @beta */
declare function isStringInputProps(inputProps: InputProps | Omit<InputProps, 'renderDefault'>): inputProps is StringInputProps;
/**
 * @hidden
 * @beta */
declare function isNumberInputProps(inputProps: InputProps | Omit<InputProps, 'renderDefault'>): inputProps is NumberInputProps;
/**
 * @hidden
 * @beta */
declare function isBooleanInputProps(inputProps: InputProps | Omit<InputProps, 'renderDefault'>): inputProps is BooleanInputProps;
/**
 * @hidden
 * @beta */
declare function isArrayOfObjectsInputProps(inputProps: InputProps | Omit<InputProps, 'renderDefault'>): inputProps is ArrayOfObjectsInputProps;
/**
 * @hidden
 * @beta */
declare function isArrayOfBlocksInputProps(inputProps: InputProps | Omit<InputProps, 'renderDefault'>): inputProps is ArrayOfObjectsInputProps;
/**
 * @hidden
 * @beta */
declare function isArrayOfPrimitivesInputProps(inputProps: InputProps | Omit<InputProps, 'renderDefault'>): inputProps is ArrayOfPrimitivesInputProps;
declare module '@sanity/types' {
  /**
   *
   * @hidden
   * @beta
   */
  interface ArrayOfObjectsComponents {
    annotation?: ComponentType<BlockAnnotationProps>;
    block?: ComponentType<BlockProps>;
    diff?: ComponentType<any>;
    field?: ComponentType<ArrayFieldProps>;
    inlineBlock?: ComponentType<BlockProps>;
    input?: ComponentType<ArrayOfObjectsInputProps>;
    item?: ComponentType<ObjectItemProps>;
    preview?: ComponentType<PreviewProps>;
    portableText?: {
      plugins: ComponentType<PortableTextPluginsProps>;
    };
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface ArrayOfPrimitivesComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<ArrayOfPrimitivesFieldProps>;
    input?: ComponentType<ArrayOfPrimitivesInputProps>;
    item?: ComponentType<PrimitiveItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface BooleanComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<BooleanFieldProps>;
    input?: ComponentType<BooleanInputProps>;
    item?: ComponentType<PrimitiveItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface DateComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<StringFieldProps>;
    input?: ComponentType<StringInputProps>;
    item?: ComponentType<PrimitiveItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface DatetimeComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<StringFieldProps>;
    input?: ComponentType<StringInputProps>;
    item?: ComponentType<PrimitiveItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface DocumentComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<ObjectFieldProps>;
    input?: ComponentType<ObjectInputProps>;
    item?: ComponentType<ObjectItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface FileComponents {
    annotation?: ComponentType<BlockAnnotationProps>;
    block?: ComponentType<BlockProps>;
    diff?: ComponentType<any>;
    field?: ComponentType<ObjectFieldProps<FileValue>>;
    inlineBlock?: ComponentType<BlockProps>;
    input?: ComponentType<ObjectInputProps<FileValue>>;
    item?: ComponentType<ObjectItemProps<FileValue & ObjectItem>>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface GeopointComponents {
    annotation?: ComponentType<BlockAnnotationProps>;
    block?: ComponentType<BlockProps>;
    diff?: ComponentType<any>;
    field?: ComponentType<ObjectFieldProps<GeopointValue>>;
    inlineBlock?: ComponentType<BlockProps>;
    input?: ComponentType<ObjectInputProps<GeopointValue>>;
    item?: ComponentType<ObjectItemProps<GeopointValue & ObjectItem>>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface ImageComponents {
    annotation?: ComponentType<BlockAnnotationProps>;
    block?: ComponentType<BlockProps>;
    diff?: ComponentType<any>;
    field?: ComponentType<ObjectFieldProps<ImageValue>>;
    inlineBlock?: ComponentType<BlockProps>;
    input?: ComponentType<ObjectInputProps<ImageValue>>;
    item?: ComponentType<ObjectItemProps<ImageValue & ObjectItem>>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface NumberComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<NumberFieldProps>;
    input?: ComponentType<NumberInputProps>;
    item?: ComponentType<PrimitiveItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface ObjectComponents {
    annotation?: ComponentType<BlockAnnotationProps>;
    block?: ComponentType<BlockProps>;
    diff?: ComponentType<any>;
    field?: ComponentType<ObjectFieldProps>;
    inlineBlock?: ComponentType<BlockProps>;
    input?: ComponentType<ObjectInputProps>;
    item?: ComponentType<ObjectItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface ReferenceComponents {
    annotation?: ComponentType<BlockAnnotationProps>;
    block?: ComponentType<BlockProps>;
    diff?: ComponentType<any>;
    field?: ComponentType<ObjectFieldProps<ReferenceValue>>;
    inlineBlock?: ComponentType<BlockProps>;
    input?: ComponentType<StudioReferenceInputProps>;
    item?: ComponentType<ObjectItemProps<ReferenceValue & ObjectItem>>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface CrossDatasetReferenceComponents {
    annotation?: ComponentType<BlockAnnotationProps>;
    block?: ComponentType<BlockProps>;
    diff?: ComponentType<any>;
    field?: ComponentType<ObjectFieldProps<CrossDatasetReferenceValue>>;
    inlineBlock?: ComponentType<BlockProps>;
    input?: ComponentType<StudioCrossDatasetReferenceInputProps>;
    item?: ComponentType<ObjectItemProps<CrossDatasetReferenceValue & ObjectItem>>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface SlugComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<ObjectFieldProps<SlugValue>>;
    input?: ComponentType<ObjectInputProps<SlugValue>>;
    item?: ComponentType<ObjectItemProps<SlugValue & ObjectItem>>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface SpanComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<ObjectFieldProps>;
    input?: ComponentType<ObjectInputProps>;
    item?: ComponentType<ObjectItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface StringComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<StringFieldProps>;
    input?: ComponentType<StringInputProps>;
    item?: ComponentType<PrimitiveItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface TextComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<StringFieldProps>;
    input?: ComponentType<StringInputProps>;
    item?: ComponentType<PrimitiveItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface UrlComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<StringFieldProps>;
    input?: ComponentType<StringInputProps>;
    item?: ComponentType<PrimitiveItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  /**
   *
   * @hidden
   * @beta
   */
  interface EmailComponents {
    diff?: ComponentType<any>;
    field?: ComponentType<StringFieldProps>;
    input?: ComponentType<StringInputProps>;
    item?: ComponentType<PrimitiveItemProps>;
    preview?: ComponentType<PreviewProps>;
  }
  interface ArrayDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: ArrayOfObjectsComponents | ArrayOfPrimitivesComponents;
  }
  interface BlockDefinition {
    /**
     * Components for the block schema type
     *
     * @public
     * @remarks - This only applies to the block text type, and not block object types (like images).
     * - Don't render arbitrary text nodes inside regular text blocks, as this will confuse the editor with
     * what is editable text and not. Make sure to wrap all nodes which are NOT part of the edited text inside a
     * container with `contentEditable={false}` and with `style={{userSelection: 'none'}}` so that
     * the editor can distinguish between editable text and non-editable text.
     * @example Example of custom block component with delete button next to it that removes the block.
     * ```ts
     * {
     *   block: (blockProps) => {
     *     return (
     *       <Flex>
     *         <Box flex={1}>{blockProps.renderDefault(blockProps)}</Box>
     *         <Box contentEditable={false} style={{userSelect: 'none'}}>
     *           <Button
     *             icon={TrashIcon}
     *             onClick={(event) => {
     *               event.preventDefault()
     *               blockProps.onRemove()
     *              }}
     *             />
     *         </Box>
     *       </Flex>
     *     )
     *   },
     * },
     * ```
     */
    components?: {
      block?: ComponentType<BlockProps>;
    };
  }
  interface BlockDecoratorDefinition {
    /**
     * Component for rendering a decorator.
     *
     * See also {@link BlockDecoratorProps | BlockDecoratorProps}
     *
     * @public
     * @remarks - Try not to hard code CSS properties that could be derived from `@sanity/ui`.
     * This will make sure your rendering looks good independent of the theme context it appears in.
     * - Don't render arbitrary text nodes as this will confuse the editor with
     * what is editable text and not. If you need arbitrary text, make sure to wrap them in in a
     * container with `contentEditable={false}`.
     * @example Example of rendering custom decorator that highlights text.
     * ```ts
     * const Highlight = (props: BlockDecoratorProps) => (
     *   <span style={{backgroundColor: '#ff0'}}>
     *     {props.children}
     *   </span>
     * )
     * ```
     */
    component?: ComponentType<BlockDecoratorProps>;
  }
  interface BlockStyleDefinition {
    /**
     * Component for rendering a text style.
     *
     * See also {@link BlockStyleProps | BlockStyleProps}
     *
     * @public
     * @remarks - Try not to hard code CSS properties that could be derived from `@sanity/ui`.
     * This will make sure your rendering looks good independent of the theme context it appears in.
     * - Don't render arbitrary text nodes as this will confuse the editor with
     * what is editable text and not. If you need arbitrary text, make sure to wrap them in in a
     * container with `contentEditable={false}`.
     * @example Example of rendering a custom style for article leads which is bigger,
     * and bolder, but will adapt to what the current `@sanity/ui` theme has defined
     * as actual values for weight "bold" and `size={3}`.
     * ```ts
     * import {Text} from '@sanity/ui'
     *
     * const LeadStyle = (props: BlockStyleProps) => (
     *   <Text weight="bold" size={3}>
     *     {props.children}
     *   </Text>
     * )
     * ```
     */
    component?: ComponentType<BlockStyleProps>;
  }
  interface BlockListDefinition {
    /**
     * Component for rendering a block as a list item
     *
     * See also {@link BlockListItemProps | BlockListItemProps}
     *
     * @public
     * @remarks - Try not to hard code CSS properties that could be derived from `@sanity/ui`.
     * This will make sure your rendering looks good independent of the theme context it appears in.
     * - Don't render arbitrary text nodes as this will confuse the editor with
     * what is editable text and not. If you need arbitrary text, make sure to wrap them in in a
     * container with `contentEditable={false}`.
     */
    component?: ComponentType<BlockListItemProps>;
  }
  interface BlockAnnotationDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: {
      annotation?: ComponentType<BlockAnnotationProps>;
    };
  }
  interface BooleanDefinition {
    components?: BooleanComponents;
  }
  interface DateDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: DateComponents;
  }
  interface DatetimeDefinition {
    components?: DatetimeComponents;
  }
  interface DocumentDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: DocumentComponents;
  }
  interface FileDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: FileComponents;
  }
  interface GeopointDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: GeopointComponents;
  }
  interface ImageDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: ImageComponents;
  }
  interface NumberDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: NumberComponents;
  }
  interface ObjectDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: ObjectComponents;
    /**
     * Callback that allows developers to customize the members of the object input.
     * It can be used to add decoration members to the object input, instead of using empty fields.
     * For example:
     * ```ts
     * import { Decoration } from './Decoration'
     *
     * renderMembers: (members) => {
     *   return [
     *     ...members,
     *     {
     *       key: 'decoration',
     *       kind: 'decoration',
     *       component: Decoration,
     *     },
     *   ]
     * ```
     *
     * @hidden
     * @beta
     */
    renderMembers?: ObjectRenderMembersCallback;
  }
  interface FieldsetDefinition {
    /**
     * Callback that allows developers to customize the members present in the fieldset.
     * It can be used to add decoration members to the fieldset, instead of using empty fields.
     * For example:
     * ```ts
     * import { Decoration } from './Decoration'
     *
     * renderMembers: (members) => {
     *   return [
     *     ...members,
     *     {
     *       key: 'decoration',
     *       kind: 'decoration',
     *       component: Decoration,
     *     },
     *   ]
     * ```
     *
     * @hidden
     * @beta
     */
    renderMembers?: FieldsetRenderMembersCallback;
  }
  interface MultiFieldSet {
    /**
     * Callback that allows developers to customize the members present in the fieldset.
     * It can be used to add decoration members to the fieldset, instead of using empty fields.
     * For example:
     * ```ts
     * import { Decoration } from './Decoration'
     *
     * renderMembers: (members) => {
     *   return [
     *     ...members,
     *     {
     *       key: 'decoration',
     *       kind: 'decoration',
     *       component: Decoration,
     *     },
     *   ]
     * ```
     *
     * @hidden
     * @beta
     */
    renderMembers?: FieldsetRenderMembersCallback;
  }
  interface ReferenceDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: ReferenceComponents;
  }
  interface CrossDatasetReferenceDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: CrossDatasetReferenceComponents;
  }
  interface SlugDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: SlugComponents;
  }
  interface SpanDefinition {
    components?: SpanComponents;
  }
  interface StringDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: StringComponents;
  }
  interface TextDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: TextComponents;
  }
  interface UrlDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: UrlComponents;
  }
  interface EmailDefinition {
    /**
     *
     * @hidden
     * @beta
     */
    components?: EmailComponents;
  }
}
/**
 * @internal
 */
declare function Preview(props: RenderPreviewCallbackProps & {
  perspectiveStack?: PerspectiveStack;
}): react.JSX.Element;
/**
 * This component is responsible for converting renderPreview() calls into an element.
 * It:
 * - subscribes to "prepared" preview value as long as the element is visible on screen
 * - resolves the configured preview component for the schema type
 * - prepares "preview"-props and passes this to the configured preview component
 * @internal
 * */
declare function PreviewLoader(props: RenderPreviewCallbackProps & {
  component: ComponentType<Omit<PreviewProps, 'renderDefault'>>;
  perspectiveStack?: PerspectiveStack;
}): React.JSX.Element;
/** @internal */
interface SanityDefaultPreviewProps extends Omit<PreviewProps, 'renderDefault'> {
  error?: Error | null;
  icon?: ElementType | false;
  tooltip?: ReactNode;
}
/**
 * Used in cases where no custom preview component is provided
 * @internal
 * */
declare const SanityDefaultPreview: react.NamedExoticComponent<SanityDefaultPreviewProps>;
/**
 * @internal
 * @beta
 *
 * Observes a document by its ID and returns the document and loading state
 * it will listen to the document changes.
 */
declare function useUnstableObserveDocument<T extends SanityDocument>(documentId: string, apiConfig?: ObserveDocumentAPIConfig): {
  document: T | null;
  loading: boolean;
};
/**
 * @deprecated Use `useUnstableObserveDocument` instead
 * @internal
 * @beta
 */
declare const unstable_useObserveDocument: (args: [documentId: string, apiConfig?: ObserveDocumentAPIConfig | undefined]) => {
  document: SanityDocument | null;
  loading: boolean;
};
/**
 * @internal
 * @deprecated use useValuePreview instead
 */
declare function unstable_useValuePreview(args: Parameters<typeof useValuePreview>[0]): State$1;
interface State$1 {
  isLoading: boolean;
  error?: Error;
  value?: PreviewValue;
}
/**
 * @internal
 */
declare function useValuePreview(props: {
  enabled?: boolean;
  ordering?: SortOrdering;
  schemaType?: SchemaType;
  value: unknown | undefined;
  perspectiveStack?: PerspectiveStack;
}): State$1;
/** @internal */
declare function getPreviewPaths(preview: PreviewableType['preview']): PreviewPath[] | undefined;
/**
 * @internal
 */
interface PreviewState {
  isLoading?: boolean;
  /**
   * The preview snapshot as seen through the current perspective stack
   */
  snapshot: PreviewValue | Partial<SanityDocument> | null;
  /**
   * The preview snapshot in either a single `version` perspective, or the `drafts` perspective
   * This can be used as a fallback if the document exists in e.g. drafts form, but not in the current perspective
   */
  original: PreviewValue | Partial<SanityDocument> | null;
}
/**
 * Obtain a document's published and draft state, along with loading status.
 *
 * @internal
 */
declare function getPreviewStateObservable(documentPreviewStore: DocumentPreviewStore, schemaType: SchemaType, documentId: string, perspective?: PerspectiveStack, viewOptions?: PrepareViewOptions): Observable<PreviewState>;
/**
 * @internal
 */
type Sources = {
  /**
   * Preview snapshot with current perspective applied
   * This takes priority of original and fallback
   */
  snapshot?: Partial<SanityDocument> | PreviewValue | null | undefined;
  /**
   * Preview of the original document (e.g. without current perspective applied)
   */
  original?: Partial<SanityDocument> | PreviewValue | null | undefined;
  /**
   * last resort fallback in case we don't have anything to preview
   * this can be a hard-coded preview value, or a document stub
   */
  fallback?: Partial<SanityDocument> | PreviewValue;
};
/**
 * Obtain document preview values used in <SanityPreview> and <SanityDefaultPreview> components.
 * Also displays fallback values if the document cannot be found.
 *
 * @internal
 */
declare function getPreviewValueWithFallback({
  snapshot,
  original,
  fallback
}: Sources): Partial<SanityDocument> | PreviewValue | {
  title: react.JSX.Element;
  subtitle: react.JSX.Element;
  media: () => react.JSX.Element;
};
/** @internal */
declare function prepareForPreview(rawValue: unknown, type: PreviewableType, viewOptions?: PrepareViewOptions): PreviewValue & {
  _createdAt?: string;
  _updatedAt?: string;
};
interface ComlinkStore {
  node?: Node<FrameMessages, WindowMessages>;
}
/**
 * Represents "commit requests" from the mutator.
 * These are emitted from the BufferedDocument instance's `requestHandler` callback
 *
 * @internal
 */
interface CommitRequest {
  mutation: Mutation;
  success: () => void;
  failure: (error: Error) => void;
  cancel: (error: Error) => void;
}
/** @internal */
declare const createObservableBufferedDocument: (listenerEvent$: Observable<ListenerEvent>) => {
  updates$: Observable<DocumentMutationEvent | DocumentRebaseEvent | SnapshotEvent>;
  consistency$: Observable<boolean>;
  remoteSnapshot$: Observable<RemoteSnapshotEvent>;
  commitRequest$: Subject<CommitRequest>;
  addMutation: (mutation: MutationPayload) => void;
  addMutations: (mutations: MutationPayload[]) => void;
  commit: () => void;
};
/**
 * @hidden
 * @beta */
type BufferedDocumentEvent = SnapshotEvent | DocumentRebaseEvent | DocumentMutationEvent | CommittedEvent;
/** @internal */
interface BufferedDocumentWrapper {
  consistency$: Observable<boolean>;
  remoteSnapshot$: Observable<RemoteSnapshotEvent>;
  events: Observable<BufferedDocumentEvent>;
  commitRequest$: Observable<CommitRequest>;
  patch: (patches: any[]) => MutationPayload[];
  create: (document: Partial<SanityDocument>) => MutationPayload;
  createIfNotExists: (document: SanityDocument) => MutationPayload;
  createOrReplace: (document: SanityDocument) => MutationPayload;
  delete: () => MutationPayload;
  mutate: (mutations: MutationPayload[]) => void;
  commit: () => void;
}
/** @internal */
declare const createBufferedDocument: (documentId: string, listenerEvent$: Observable<ListenerEvent>) => BufferedDocumentWrapper;
/**
 * @hidden
 * @beta */
type WithVersion<T> = T & {
  version: DocumentVariantType;
};
/**
 * @hidden
 * @beta */
type DocumentVersionEvent = WithVersion<ReconnectEvent | BufferedDocumentEvent | WelcomeEvent | WelcomeBackEvent | ResetEvent>;
/**
 * @hidden
 * @beta */
type RemoteSnapshotVersionEvent = WithVersion<RemoteSnapshotEvent>;
/**
 * @hidden
 * @beta
 * The SingleMutationResult type from `@sanity/client` doesn't reflect what we get back from POST /mutate
 */
type MutationResult = Omit<SingleMutationResult, 'documentId'>;
/**
 * @hidden
 * @beta */
interface DocumentVersion {
  consistency$: Observable<boolean>;
  remoteSnapshot$: Observable<RemoteSnapshotVersionEvent>;
  events: Observable<DocumentVersionEvent>;
  patch: (patches: any[]) => MutationPayload[];
  create: (document: Partial<SanityDocument>) => MutationPayload;
  createIfNotExists: (document: SanityDocument) => MutationPayload;
  createOrReplace: (document: SanityDocument) => MutationPayload;
  delete: () => MutationPayload;
  mutate: (mutations: MutationPayload[]) => void;
  commit: () => void;
}
/**
 * @hidden
 * @beta */
type Pair = {
  /** @internal */transactionsPendingEvents$: Observable<PendingMutationsEvent>;
  published: DocumentVersion;
  draft: DocumentVersion;
  version?: DocumentVersion;
};
/** @internal */
declare function checkoutPair(client: SanityClient, idPair: IdPair, serverActionsEnabled: Observable<boolean>, options?: DocumentStoreExtraOptions): Pair;
/**
 * @hidden
 * @beta */
type DocumentRemoteMutationVersionEvent = Exclude<RemoteSnapshotVersionEvent, {
  type: 'snapshot';
}>;
/**
 * @hidden
 * @beta */
interface CombinedDocument {
  draft: Record<string, unknown> | null;
  published: Record<string, unknown> | null;
}
/**
 * @hidden
 * @beta */
interface Transaction {
  index: number;
  id: string;
  author: string;
  timestamp: string;
  draftEffect?: MendozaEffectPair;
  publishedEffect?: MendozaEffectPair;
}
/**
 * @hidden
 * @beta */
type ParsedTimeRef = Chunk | 'loading' | 'invalid';
/**
 * @hidden
 * @beta */
interface TimelineOptions {
  publishedId: string;
  enableTrace?: boolean;
}
/**
 * Timeline maintains information about the history of a document:
 * Grouping raw translog entries into sensible groups, replaying and
 * reconstructing different versions and abstract other details.
 *
 * Note that this class by itself is not capable of _fetching_ information,
 * but will only organize and structure the incoming translog entries.
 *
 *
 * @hidden
 * @beta
 */
declare class Timeline {
  reachedEarliestEntry: boolean;
  publishedId: string;
  draftId: string;
  private _transactions;
  private _chunks;
  private _possiblePendingTransactions;
  private _recreateTransactionsFrom?;
  private _trace?;
  constructor(opts: TimelineOptions);
  get chunkCount(): number;
  /** Maps over the chunk from newest to oldest. */
  mapChunks<T>(mapper: (chunk: Chunk, idx: number) => T): T[];
  reset(): void;
  /**
   * Adds a remote mutation to the timeline. This methods assumes that the remote mutations
   * come in correct order for their respective version, but has no ordering requirements
   * across draft/published.
   *
   * Example: [D1, D2, P1] (where D1 and P1 were mutations done to the draft and published
   * version in the same transaction) is a valid input. [P1, D2, D1] is _not_ valid since
   * the mutation for the draft is out of order.
   */
  addRemoteMutation(entry: DocumentRemoteMutationVersionEvent): void;
  addTranslogEntry(event: TransactionLogEventWithEffects): void;
  /** Mark that we've reached the earliest entry. */
  didReachEarliestEntry(): void;
  /**
   * updateChunks synchronizes the chunks to match the current state
   * of the transactions array. After calling this method you need
   * to invalidate all Chunks.
   */
  updateChunks(): void;
  private _removeInvalidatedChunks;
  private _addChunksFromTransactions;
  private _invalidateTransactionFrom;
  private _createInitialChunk;
  /**
   * Resolves a time reference.
   *
   * Note that the chunk returned is only valid if the timeline stays constant.
   * Once the timeline is updated, you must re-parse all references.
   */
  parseTimeId(id: string): ParsedTimeRef;
  findLastPublishedBefore(chunk: Chunk | null): ParsedTimeRef;
  isLatestChunk(chunk: Chunk): boolean;
  createTimeId(chunk: Chunk): string;
  lastChunk(): Chunk;
  transactionByIndex(idx: number): Transaction | null;
  chunkByTransactionIndex(idx: number, startChunkIdx?: number): Chunk;
  replayBackwardsBetween(firstIdx: number, lastIdx: number, doc: CombinedDocument): CombinedDocument;
  replayBackwardsUntil(firstIdx: number, doc: CombinedDocument): CombinedDocument;
  calculateDiff(initialDoc: CombinedDocument, finalDoc: CombinedDocument, firstIdx: number, lastIdx: number): Diff<Annotation>;
}
/**
 * @hidden
 * @beta */
type TimelineControllerOptions = {
  timeline: Timeline;
  client: SanityClient;
  documentId: string;
  documentType: string;
  handler?: (err: Error | null, controller: TimelineController) => void;
};
/**
 * @hidden
 * @beta */
type SelectionState = 'inactive' | 'rev' | 'range' | 'loading' | 'invalid';
/**
 * The controller is responsible for fetching information
 * about a document and maintaining a Timeline.
 *
 *
 * @hidden
 * @beta
 */
declare class TimelineController {
  timeline: Timeline;
  client: SanityClient;
  handler: TimelineControllerOptions['handler'];
  version: number;
  /**
   * The selection state represents the  different states of the current selection:
   * - inactive: No selection is active.
   * - rev: A selection is active for a single revision.
   * - range: A selection is active for a range and we have all the data needed to render it.
   * - loading: A selection is active, but we don't have the entries yet.
   * - invalid: The selection picked is invalid.
   */
  selectionState: SelectionState;
  constructor(options: TimelineControllerOptions);
  private _aligner;
  private _fetchMore;
  private _fetchAtLeast;
  private _isRunning;
  private _isSuspended;
  private _didErr;
  private _since;
  private _sinceTime;
  private _rev;
  private _revTime;
  private _reconstruction?;
  setHandler(handler: TimelineControllerOptions['handler']): void;
  clearRange(): void;
  setRange(since: string | null, rev: string | null): void;
  setLoadMore(flag: boolean): void;
  get sinceTime(): Chunk | null;
  get revTime(): Chunk | null;
  get isLoading(): boolean;
  get realRevChunk(): Chunk;
  /** Returns true when there's an older revision we want to render. */
  onOlderRevision(): boolean;
  findRangeForNewRev(rev: Chunk): [string | null, string | null];
  findRangeForNewSince(since: Chunk): [string, string | null];
  setRevTime(rev: string | null): void;
  setSinceTime(since: string | null): void;
  sinceAttributes(): Record<string, unknown> | null;
  displayed(): Record<string, unknown> | null;
  setReconstruction(since: Chunk | null, rev: Chunk): void;
  currentDiff(): Diff<Annotation> | null;
  currentObjectDiff(): ObjectDiff<Annotation> | null;
  handleRemoteMutation(ev: RemoteSnapshotVersionEvent): void;
  start(): void;
  resume(): void;
  suspend(): void;
  private tick;
  private fetchMoreTransactions;
  private markChange;
}
/**
 * Represents a document revision identifier.
 * Can be either a specific revision string
 * or 'lastRevision' to get the most recent revision.
 *
 * @beta
 */
type DocumentRevision = string | 'lastRevision';
/**
 * @hidden
 * @beta */
interface HistoryStore {
  getDocumentAtRevision: (documentId: string, revision: DocumentRevision) => Promise<SanityDocument | undefined>;
  getHistory: (documentIds: string[], options?: {
    time?: string;
    revision?: string;
  }) => Promise<{
    documents: SanityDocument[];
  }>;
  getTransactions: (documentIds: string[]) => Promise<TransactionLogEventWithMutations[]>;
  restore: (id: string, targetId: string, rev: DocumentRevision, options?: RestoreOptions) => Observable<void>;
  /** @internal */
  getTimelineController: (options: {
    client: SanityClient;
    documentId: string;
    documentType: string;
  }) => TimelineController;
}
interface RestoreOptions {
  fromDeleted: boolean;
  useServerDocumentActions?: boolean;
}
/** @internal */
declare const removeMissingReferences: (doc: SanityDocument, existingIds: Record<string, boolean | undefined>) => SanityDocument;
/** @internal */
interface HistoryStoreOptions {
  client: SanityClient;
}
/** @internal */
declare function createHistoryStore({
  client
}: HistoryStoreOptions): HistoryStore;
interface UseTimelineControllerOpts {
  documentId: string;
  documentType: string;
  onError?: (err: Error) => void;
  rev?: string;
  since?: string;
}
/** @internal */
interface TimelineState {
  chunks: Chunk[];
  diff: ObjectDiff<Annotation> | null;
  /** null is used here when the chunks hasn't loaded / is not known */
  hasMoreChunks: boolean | null;
  isLoading: boolean;
  /**
   * Whether this timeline is fully loaded and completely empty (true for new documents)
   * It can be `null` when the chunks hasn't loaded / is not known
   */
  isPristine: boolean | null;
  lastNonDeletedRevId: string | null;
  onOlderRevision: boolean;
  realRevChunk: Chunk | null;
  revTime: Chunk | null;
  selectionState: SelectionState;
  sinceAttributes: Record<string, unknown> | null;
  sinceTime: Chunk | null;
  timelineDisplayed: Record<string, unknown> | null;
  timelineReady: boolean;
}
/** @internal */
interface TimelineStore {
  findRangeForRev: TimelineController['findRangeForNewRev'];
  findRangeForSince: TimelineController['findRangeForNewSince'];
  loadMore: () => void;
  getSnapshot: () => TimelineState;
  subscribe: (callback: () => void) => () => void;
}
/**
 * Creates a store which handles the creation of a document Timeline,
 * TimelineController and also fetches pre-requisite document snapshots.
 *
 * `TimelineStore` exposes select TimelineController methods used to query
 * ranges and fetch more transactions. It can also be used with
 * `useSyncExternalStore` to subscribe to selected state changes.
 *
 * @internal
 * */
declare function useTimelineStore({
  documentId,
  documentType,
  onError,
  rev,
  since
}: UseTimelineControllerOpts): TimelineStore;
/**
 * Custom hook which wraps around `useSyncExternalStore`.
 * Accepts a selector function which can be used to opt-in to specific timelineStore updates.
 *
 * @internal
 */
declare function useTimelineSelector<ReturnValue>(timelineStore: TimelineStore | undefined, selector: (timelineState: TimelineState) => ReturnValue): ReturnValue;
/** @internal */
interface DocumentVersionSnapshots {
  snapshots$: Observable<SanityDocument>;
  patch: (patches: any[]) => MutationPayload[];
  create: (document: any) => MutationPayload;
  createIfNotExists: (document: any) => MutationPayload;
  createOrReplace: (document: any) => MutationPayload;
  delete: () => MutationPayload;
  mutate: (mutations: MutationPayload[]) => void;
  commit: () => void;
}
/** @internal */
interface SnapshotPair {
  transactionsPendingEvents$: Observable<PendingMutationsEvent>;
  draft: DocumentVersionSnapshots;
  published: DocumentVersionSnapshots;
  version?: DocumentVersionSnapshots;
}
/** @internal */
declare const snapshotPair: (client: SanityClient, idPair: IdPair, typeName: string, serverActionsEnabled: Observable<boolean>, pairListenerOptions?: DocumentStoreExtraOptions | undefined) => Observable<SnapshotPair>;
/** @public */
type MapDocument = (document: SanityDocumentLike) => SanityDocumentLike;
/** @internal */
interface OperationImpl<ExtraArgs extends any[] = [], DisabledReason extends string = string> {
  disabled: (args: OperationArgs) => DisabledReason | 'NOT_READY' | false;
  execute(args: OperationArgs, ...extra: ExtraArgs): void;
}
/** @internal */
interface Operation<ExtraArgs extends any[] = [], ErrorStrings extends string = string> {
  disabled: false | ErrorStrings | 'NOT_READY';
  execute(...extra: ExtraArgs): void;
}
type GuardedOperation = Operation<any[], 'NOT_READY'>;
type Patch$1 = any;
/** @internal */
interface OperationsAPI {
  commit: Operation | GuardedOperation;
  delete: Operation<[versions?: string[]], 'NOTHING_TO_DELETE' | 'NOT_READY'>;
  del: Operation<[versions?: string[]], 'NOTHING_TO_DELETE'> | GuardedOperation;
  publish: Operation<[], 'LIVE_EDIT_ENABLED' | 'ALREADY_PUBLISHED' | 'NO_CHANGES'> | GuardedOperation;
  patch: Operation<[patches: Patch$1[], initialDocument?: Record<string, any>]> | GuardedOperation;
  discardChanges: Operation<[], 'NO_CHANGES' | 'NOT_PUBLISHED'> | GuardedOperation;
  unpublish: Operation<[], 'LIVE_EDIT_ENABLED' | 'NOT_PUBLISHED'> | GuardedOperation;
  duplicate: Operation<[documentId: string, options?: {
    mapDocument?: MapDocument;
  }], 'NOTHING_TO_DUPLICATE'> | GuardedOperation;
  restore: Operation<[revision: DocumentRevision]> | GuardedOperation;
}
/** @internal */
interface OperationArgs {
  historyStore: HistoryStore;
  client: SanityClient;
  schema: Schema;
  typeName: string;
  idPair: IdPair;
  snapshots: {
    draft: null | SanityDocument;
    published: null | SanityDocument;
    version?: null | SanityDocument;
  };
  draft: DocumentVersionSnapshots;
  published: DocumentVersionSnapshots;
  version?: DocumentVersionSnapshots;
  serverActionsEnabled: boolean;
}
interface ExecuteArgs {
  operationName: keyof OperationsAPI;
  idPair: IdPair;
  typeName: string;
  extraArgs: any[];
}
/** @internal */
declare function emitOperation(operationName: keyof OperationsAPI, idPair: IdPair, typeName: string, extraArgs: any[]): void;
/**
 * @hidden
 * @beta */
interface OperationError {
  type: 'error';
  /** @internal */
  op: keyof OperationsAPI;
  id: string;
  error: Error;
}
/**
 * @hidden
 * @beta */
interface OperationSuccess {
  type: 'success';
  /** @internal */
  op: keyof OperationsAPI;
  id: string;
}
interface IntermediarySuccess {
  type: 'success';
  args: ExecuteArgs;
}
interface IntermediaryError {
  type: 'error';
  args: ExecuteArgs;
  error: any;
}
/** @internal */
declare const operationEvents: (ctx: {
  client: SanityClient;
  historyStore: HistoryStore;
  schema: Schema;
  serverActionsEnabled: Observable<boolean>;
  extraOptions?: DocumentStoreExtraOptions | undefined;
}) => Observable<IntermediaryError | IntermediarySuccess>;
/** @internal */
declare const remoteSnapshots: (client: SanityClient, idPair: IdPair, typeName: string, serverActionsEnabled: Observable<boolean>, pairListenerOptions?: DocumentStoreExtraOptions | undefined) => Observable<RemoteSnapshotVersionEvent>;
/** @internal */
declare const validation$1: (ctx: {
  client: SanityClient;
  getClient: (options: SourceClientOptions) => SanityClient;
  observeDocumentPairAvailability: (id: string) => Observable<DraftsModelDocumentAvailability>;
  schema: Schema;
  i18n: LocaleSource;
  serverActionsEnabled: Observable<boolean>;
  pairListenerOptions?: DocumentStoreExtraOptions | undefined;
  currentUser?: Omit<CurrentUser, "role"> | null | undefined;
}, {
  draftId,
  publishedId,
  versionId
}: IdPair, typeName: string, validationTarget: DocumentVariantType, validatePublishedReferences: boolean) => Observable<ValidationStatus>;
/**
 * @hidden
 * @beta */
interface InitialValueLoadingMsg {
  type: 'loading';
}
/**
 * @hidden
 * @beta */
interface InitialValueSuccessMsg {
  type: 'success';
  value: SanityDocumentLike | null;
}
/**
 * @hidden
 * @beta */
interface InitialValueErrorMsg {
  type: 'error';
  error: Error;
}
/**
 * @hidden
 * @beta */
type InitialValueMsg = InitialValueLoadingMsg | InitialValueSuccessMsg | InitialValueErrorMsg;
/** @internal */
interface InitialValueState {
  loading: boolean;
  error: Error | null;
  value: SanityDocumentLike;
}
/**
 * @hidden
 * @beta */
interface InitialValueOptions {
  documentId: string;
  documentType: string;
  templateName?: string;
  templateParams?: Record<string, any>;
}
/**
 * @internal
 */
declare function getInitialValueStream(schema: Schema, initialValueTemplates: Template[], documentPreviewStore: DocumentPreviewStore, opts: InitialValueOptions, context: InitialValueResolverContext): Observable<InitialValueMsg>;
/** @internal */
type ListenQueryParams = Record<string, string | number | boolean | string[]>;
/**
 * @hidden
 * @beta */
interface ListenQueryOptions {
  tag?: string;
  apiVersion?: string;
  perspective?: ClientPerspective;
  throttleTime?: number;
  transitions?: ('update' | 'appear' | 'disappear')[];
}
/** @internal */
declare function listenQuery(client: SanityClient, query: string | {
  fetch: string;
  listen: string;
}, params?: ListenQueryParams, options?: ListenQueryOptions): Observable<any>;
/**
 * @hidden
 * @beta */
type QueryParams$1 = Record<string, string | number | boolean | string[]>;
/**
 * @hidden
 * @beta */
interface DocumentStore {
  /**
   * Checks out a document (with its published and draft version) for real-time editing.
   * Note that every call to this function will open a new listener to the server.
   * It's recommended to use the helper functions on `pair` below which will re-use a single connection.
   *
   * @internal
   **/
  checkoutPair: (idPair: IdPair) => Pair;
  initialValue: (opts: InitialValueOptions, context: InitialValueResolverContext) => Observable<InitialValueMsg>;
  listenQuery: (query: string | {
    fetch: string;
    listen: string;
  }, params: QueryParams$1, options: ListenQueryOptions) => Observable<any>;
  resolveTypeForDocument: (id: string, specifiedType?: string) => Observable<string>;
  pair: {
    consistencyStatus: (publishedId: string, type: string, version?: string) => Observable<boolean>; /** @internal */
    documentEvents: (publishedId: string, type: string, version?: string) => Observable<DocumentVersionEvent>; /** @internal */
    editOperations: (publishedId: string, type: string, version?: string) => Observable<OperationsAPI>;
    editState: (publishedId: string, type: string, version?: string) => Observable<EditStateFor>;
    operationEvents: (publishedId: string, type: string) => Observable<OperationSuccess | OperationError>;
    validation: (validationTargetId: string, type: string, validatePublishedReferences: boolean) => Observable<ValidationStatus>;
  };
}
/** @internal */
interface DocumentStoreOptions {
  getClient: (options: SourceClientOptions) => SanityClient;
  documentPreviewStore: DocumentPreviewStore;
  historyStore: HistoryStore;
  schema: Schema;
  initialValueTemplates: Template[];
  i18n: LocaleSource;
  serverActionsEnabled: Observable<boolean>;
  extraOptions?: DocumentStoreExtraOptions;
  currentUser?: Omit<CurrentUser, 'role'> | null;
}
/** @internal */
declare function createDocumentStore({
  getClient,
  documentPreviewStore,
  historyStore,
  initialValueTemplates,
  schema,
  i18n,
  serverActionsEnabled,
  extraOptions,
  currentUser
}: DocumentStoreOptions): DocumentStore;
/** @internal */
interface DocumentTypeResolveState {
  isLoaded: boolean;
  documentType: string | undefined;
}
/** @internal */
declare function useDocumentType(documentId: string, specifiedType?: string): DocumentTypeResolveState;
/** @internal */
declare function useDocumentValues<T = Record<string, unknown>>(documentId: string, paths: string[]): LoadableState<T | undefined>;
/**
 * Determine whether the document represented by the provided `EditState` object has any existing
 * snapshot, meaning a version of the document has been written to the dataset.
 *
 * This is `true` when a document is first created in Studio, but no user action (e.g. editing its
 * value) has caused it to be written to the dataset.
 *
 * This is `undefined` while loading.
 *
 * @returns A boolean reflecting whether any version of the document exists in the dataset, and `undefined` while loading.
 * @internal
 */
declare function isNewDocument(editState: Pick<EditStateFor, 'ready' | 'draft' | 'published' | 'version'> | null): boolean | undefined;
/**
 * Given an `EditState` object targeting the upstream version, select the first relevant document
 * that exists.
 *
 * - This is the version document itself if it exists.
 * - Otherwise, it is the published document.
 * - If neither documents exist, there is no existent upstream version.
 *
 * Unlike in other parts of the codebase, draft versions are never relevant here, because they
 * cannot be the upstream version of another document.
 *
 * @internal
 */
declare function selectUpstreamVersion(upstreamEditState: EditStateFor): SanityDocument | null;
/**
 * @internal
 */
declare function useInitialValue(props: {
  documentId: string;
  documentType: string;
  templateName?: string;
  templateParams?: Record<string, unknown>;
  version?: string;
}): InitialValueState;
/**
 * @internal
 */
declare function useInitialValueResolverContext(): InitialValueResolverContext;
/** @internal */
declare function useResolveInitialValueForType<Params extends Record<string, unknown>>(): (
/**
 * This is the name of the document.
 */

type: SchemaType,
/**
 * Params is a sanity context object passed to every initial value function.
 */

params: Params) => Promise<any>;
/**
 * @hidden
 * @beta */
type DocumentValuePermission = 'read' | 'create' | 'update' | 'history' | 'editHistory';
/** @internal */
interface Grant {
  filter: string;
  permissions: DocumentValuePermission[];
}
/**
 * @hidden
 * @beta */
interface PermissionCheckResult {
  granted: boolean;
  reason: string;
}
/**
 * @hidden
 * @beta */
interface GrantsStore {
  /**
   * Returns an observable of `PermissionCheckResult`
   *
   * This API is returns an observable (vs a promise) so the consumer can react
   * to incoming changes to the user permissions (e.g. for changing _debug_
   * roles).
   *
   * This API also accepts a `null` document in which it should return
   * `granted: true`
   */
  checkDocumentPermission(checkPermissionName: DocumentValuePermission, document: Partial<SanityDocument> | null): Observable<PermissionCheckResult>;
}
/** @internal */
interface EvaluationParams {
  identity?: string;
}
/** @internal */
type DocumentPermission = 'delete' | 'discardDraft' | 'discardVersion' | 'publish' | 'unpublish' | 'update' | 'duplicate';
/** @internal */
interface DocumentPairPermissionsOptions {
  client: SanityClient;
  schema: Schema;
  grantsStore: GrantsStore;
  id: string;
  type: string;
  version?: string;
  permission: DocumentPermission;
  serverActionsEnabled: Observable<boolean>;
  pairListenerOptions?: DocumentStoreExtraOptions;
}
/**
 * The observable version of `useDocumentPairPermissions`
 *
 * @see useDocumentPairPermissions
 *
 * @internal
 */
declare function getDocumentPairPermissions({
  client,
  grantsStore,
  schema,
  id,
  permission,
  type,
  serverActionsEnabled,
  version: v,
  pairListenerOptions
}: DocumentPairPermissionsOptions): Observable<PermissionCheckResult>;
/**
 * Gets document pair permissions based on a document ID and a type.
 *
 * This permissions API is a high-level permissions API that is draft-model
 * aware. In order to determine whether or not the user has the given
 * permission, both the draft and published documents are pulled and run through
 * all of the user's grants. If any pre or post conditions fail a permissions
 * checks, the operations will not be granted.
 *
 * The operations this hook accepts are only relevant to document pairs. E.g.
 * `'create'` is not included as an operation because it's not possible to tell
 * if a document can be created by only using the initial ID and type because an
 * initial template value may not have a matching grant (e.g. locked-document
 * pattern `!locked`). In contrast, the operation `'duplicate'` is supported
 * because the draft value of the document can be live queried and checked for
 * matching grants.
 *
 * Note: for live-edit documents, non-applicable operations (e.g. publish) will
 * return as true.
 *
 * @see useDocumentValuePermissions
 *
 * @internal
 */
declare const useDocumentPairPermissionsFromHookFactory: ReactHook<DocumentPairPermissionsOptions, LoadingTuple<PermissionCheckResult | undefined>>;
/** @internal */
declare function useDocumentPairPermissions({
  id,
  type,
  version,
  permission,
  client: overrideClient,
  schema: overrideSchema,
  grantsStore: overrideGrantsStore,
  pairListenerOptions
}: PartialExcept<DocumentPairPermissionsOptions, 'id' | 'type' | 'permission'>): ReturnType<typeof useDocumentPairPermissionsFromHookFactory>;
/** @internal */
interface DocumentValuePermissionsOptions {
  grantsStore: GrantsStore;
  document: Record<string, unknown>;
  permission: DocumentValuePermission;
}
/**
 * Gets permissions based on the value of the document passed into the hook
 * (stateless).
 *
 * Note: this is a lower-level API (compared to `useDocumentPairPermissions`)
 * that is _not_ draft-model aware.
 *
 * As a consequence, the operations it accepts are also low-level. (e.g.
 * `'publish'` permissions can't be determined with this API). This is because
 * it's not possible to tell if a user can do high-level document pair
 * operations on document using only one document value.
 *
 * For example, in order to determine if a user can publish, the current value
 * of the published document needs to be pulled and checked against the user's
 * grants. If there are no matching grants, then it fails the pre-condition and
 * no operation is allowed regardless of the given document.
 *
 * @see useDocumentPairPermissions
 *
 * @internal
 */
declare function getDocumentValuePermissions({
  grantsStore,
  document,
  permission
}: DocumentValuePermissionsOptions): Observable<PermissionCheckResult>;
/** @internal */
declare function useDocumentValuePermissions({
  document,
  permission,
  grantsStore: specifiedGrantsStore
}: PartialExcept<DocumentValuePermissionsOptions, 'permission' | 'document'>): LoadingTuple<PermissionCheckResult | undefined>;
interface GrantsStoreOptionsCurrentUser {
  client: SanityClient;
  /**
   * @deprecated The `currentUser` option is deprecated. Use `userId` instead.
   */
  currentUser: CurrentUser | null;
}
interface GrantsStoreOptionsUserId {
  client: SanityClient;
  userId: string | null;
}
/** @internal */
type GrantsStoreOptions = GrantsStoreOptionsCurrentUser | GrantsStoreOptionsUserId;
/** @internal */
declare function createGrantsStore(opts: GrantsStoreOptions): GrantsStore;
/**
 * @internal
 * Takes a grants object, a permission and a document
 * checks whether the permission is granted for the given document
 */
declare function grantsPermissionOn(userId: string | null, grants: Grant[], permission: DocumentValuePermission, document: SanityDocument | null): Promise<PermissionCheckResult>;
/** @internal */
interface TemplatePermissionsResult<TInitialValue = Record<string, unknown>> extends PermissionCheckResult, InitialValueTemplateItem {
  granted: boolean;
  reason: string;
  resolvedInitialValue: TInitialValue;
  subtitle?: string;
  template: Template;
}
/** @internal */
interface TemplatePermissionsOptions {
  grantsStore: GrantsStore;
  schema: Schema;
  templates: Template[];
  templateItems: InitialValueTemplateItem[];
  context: InitialValueResolverContext;
}
/**
 * The observable version of `useTemplatePermissions`
 *
 * @internal
 */
declare function getTemplatePermissions({
  grantsStore,
  templateItems,
  templates,
  schema,
  context
}: TemplatePermissionsOptions): Observable<Array<TemplatePermissionsResult>>;
/**
 * Takes in an array of initial template values and returns an object of
 * `TemplatePermissionsResult` keyed by the IDs of the initial template values
 * given.
 *
 * The `TemplatePermissionsResult` is an object that contains a `granted`
 * boolean per key and can be used to determine if a user has the ability to
 * create documents using the given initial value template items.
 *
 * For each initial template value item, the corresponding template is found and
 * resolved against the parameters in each the initial template value item. The
 * resolved value is then run through the document-value permissions. If there
 * are any matching grants for the resolved initial template value, the
 * `TemplatePermissionsResult` will include `granted: true`.
 *
 * @internal
 */
declare const useTemplatePermissionsFromHookFactory: ReactHook<TemplatePermissionsOptions, LoadingTuple<TemplatePermissionsResult<Record<string, unknown>>[] | undefined>>;
/** @internal */
declare function useTemplatePermissions({
  templateItems,
  ...rest
}: PartialExcept<TemplatePermissionsOptions, 'templateItems'>): ReturnType<typeof useTemplatePermissionsFromHookFactory>;
/** @internal */
interface UserStoreOptions {
  client: SanityClient;
  currentUser: CurrentUser | null;
}
/**
 * @hidden
 * @beta */
interface UserStore {
  getUser(userId: string): Promise<User | null>;
  getUsers(userIds: string[]): Promise<User[]>;
}
/**
 * Given a `client` and a `currentUser` creates a datastore that handles
 * fetching, batch fetching, and caching users.
 *
 * @internal
 */
declare function createUserStore({
  client: _client,
  currentUser
}: UserStoreOptions): UserStore;
/** @internal */
type Status = 'online' | 'editing' | 'inactive';
/** @internal */
interface Session {
  sessionId: string;
  userId: string;
  lastActiveAt: string;
  locations: PresenceLocation[];
}
/** @internal */
interface PresenceLocation {
  type: 'document';
  documentId: string;
  lastActiveAt: string;
  path: Path;
  selection?: EditorSelection;
}
/** @internal */
interface UserSessionPair {
  user: User;
  session: Session;
}
/** @internal */
interface DocumentPresence {
  user: User;
  path: Path;
  sessionId: string;
  /**
   * this is the specific id of the document that the user is in
   * e.g. if the user is in the draft, this will be the draft id, if the user is in a version, it will be the version id
   * */
  documentId?: string;
  lastActiveAt: string;
}
/** @internal */
type GlobalPresence = {
  user: User;
  status: Status;
  lastActiveAt: string;
  locations: PresenceLocation[];
};
/**
 * @hidden
 * @beta */
interface PresenceStore {
  /**
   * @internal
   */
  documentPresence: (documentId: string, options?: {
    excludeVersions?: boolean;
  }) => Observable<DocumentPresence[]>;
  /**
   * @internal
   */
  globalPresence$: Observable<GlobalPresence[]>;
  /**
   * @internal
   */
  reportLocations: (locations: PresenceLocation[]) => Observable<void>;
  /**
   * @internal
   */
  setLocation: (nextLocation: PresenceLocation[]) => void;
  /**
   * @internal
   */
  debugPresenceParam$: Observable<string[]>;
}
/** @internal */
declare const SESSION_ID: string;
/** @internal */
declare function createPresenceStore(context: {
  bifur: BifurClient;
  connectionStatusStore: ConnectionStatusStore;
  userStore: UserStore;
}): PresenceStore;
/**
 * @hidden
 * @beta */
interface ProjectData {
  id: string;
  displayName: string;
  /**
   * @deprecated Use the `/user-applications` endpoint instead, which lists all deployed studios/applications
   * @see https://www.sanity.io/help/studio-host-user-applications
   */
  studioHost: string | null;
  isBlocked: boolean;
  isDisabled: boolean;
  isDisabledByUser: boolean;
  metadata: {
    color: string;
    /**
     * @deprecated Use the `/user-applications` endpoint instead, which lists all deployed studios/applications
     * @see https://www.sanity.io/help/studio-host-user-applications
     */
    externalStudioHost: string;
  };
  maxRetentionDays: number;
  activityFeedEnabled: boolean;
  createdAt: string;
  updatedAt: string;
  organizationId: string;
  members: {
    id: string;
    createdAt: string;
    updatedAt: string;
    isCurrentUser: boolean;
    isRobot: boolean;
    role: string;
    roles: Role[];
  }[];
  features: string[];
  pendingInvites: number;
}
/**
 * @hidden
 * @beta */
interface ProjectDatasetData {
  name: string;
  aclMode: 'public' | 'private';
  createdAt: string;
  createdByUserId: string;
  tags: {
    name: string;
    title: string;
  }[];
}
/**
 * @hidden
 * @beta */
type ProjectGrants = Record<string, {
  id: string;
  name: string;
  title: string;
  description: string | null;
  isCustom: boolean;
  config: Record<string, unknown>;
  grants: {
    name: string;
    params: Record<string, unknown>;
  }[];
}[] | undefined>;
/**
 * @hidden
 * @beta */
interface ProjectStore {
  get: () => Observable<ProjectData>;
  getDatasets: () => Observable<ProjectDatasetData[]>;
  getOrganizationId: () => Observable<string | null>;
  getGrants: () => Observable<ProjectGrants>;
}
/** @internal */
declare function createProjectStore(context: {
  client: SanityClient;
}): ProjectStore;
/** @internal */
declare function useProject(): {
  value: ProjectData | null;
};
/** @internal */
declare function useProjectDatasets(): {
  value: ProjectDatasetData[] | null;
};
/**
 * @hidden
 * @beta */
declare function useUserStore(): UserStore;
/**
 * @hidden
 * @beta */
declare function useGrantsStore(): GrantsStore;
/**
 * @hidden
 * @beta */
declare function useHistoryStore(): HistoryStore;
/**
 * @hidden
 * @beta */
declare function useDocumentPreviewStore(): DocumentPreviewStore;
/**
 * @hidden
 * @beta */
declare function useDocumentStore(): DocumentStore;
/** @internal */
declare function useConnectionStatusStore(): ConnectionStatusStore;
/**
 * @hidden
 * @beta */
declare function usePresenceStore(): PresenceStore;
/**
 * @hidden
 * @beta */
declare function useProjectStore(): ProjectStore;
/**
 * Returns a KeyValueStore instance for storing user preferences.
 *
 * The store is cached by project identity (projectId + apiHost) rather than
 * workspace, because the /users/me/keyvalue endpoint is project-scoped -
 * user preferences are shared across all datasets within a project.
 *
 * @internal
 */
declare function useKeyValueStore(): KeyValueStore;
/** @internal */
declare function useRenderingContextStore(): RenderingContextStore;
/** @internal */
declare function useComlinkStore(): ComlinkStore;
/** @internal */
declare function useDocumentPresence(documentId: string): DocumentPresence[];
/** @internal */
declare function useGlobalPresence(): GlobalPresence[];
/** @internal */
interface ResourceCache {
  get<T = unknown>(options: {
    namespace: string;
    dependencies: (object | null)[];
  }): T | undefined;
  set(options: {
    namespace: string;
    dependencies: (object | null)[];
    value: unknown;
  }): void;
}
/** @internal */
interface ResourceCacheProviderProps {
  children: ReactNode;
}
/** @internal */
declare function ResourceCacheProvider({
  children
}: ResourceCacheProviderProps): react.JSX.Element;
/** @internal */
declare function useResourceCache(): ResourceCache;
/**
 * Returns whether the given version name (e.g. from `getVersionFromId`) is an
 * agent bundle name (starts with `agent-`).
 *
 * @internal
 */
declare function isAgentBundleName(versionName: unknown): boolean;
/**
 * Display overrides for an agent bundle version chip.
 *
 * @internal
 */
type AgentVersionDisplay = {
  displayName: string;
  tone: BadgeTone;
};
/**
 * Filters a list of version document IDs and provides display metadata for
 * agent bundles.
 *
 * - Other users' `agent-*` versions are removed from the returned list.
 * - The current user's `agent-*` versions are kept and can be resolved to
 *   display overrides via `getVersionDisplay`.
 * - Non-agent versions pass through unchanged.
 * - While the SSE connection is loading, only the currently active agent
 *   bundle (if any) is kept; all others are hidden until ownership is confirmed.
 *
 * Call this hook once and thread the results down — don't call it per-item.
 *
 * @internal
 */
declare function useAgentVersionDisplay(versionIds: string[], activeBundleId?: string): {
  /** Version IDs with other users' agent bundles removed. */filteredVersionIds: string[];
  /**
   * Returns display overrides for a version document ID if it's the current
   * user's agent bundle, or `null` for all other versions.
   */
  getVersionDisplay: (versionDocumentId: string) => AgentVersionDisplay | null;
};
/** @internal */
declare function useUser(userId: string): LoadingTuple<User | null | undefined>;
/**
 * Retrieves information about the currently authenticated user.
 *
 * @returns The current user or null if not available.
 *
 * @public
 *
 * @example
 * ```ts
 * const currentUser = useCurrentUser()
 *
 * if (currentUser) {
 *  console.log('Logged in as', currentUser.name)
 * }
 * ```
 */
declare function useCurrentUser(): CurrentUser | null;
/** @internal */
interface DocumentPreviewPresenceProps {
  presence: Omit<DocumentPresence, 'path'>[];
}
/** @internal */
declare function DocumentPreviewPresence(props: DocumentPreviewPresenceProps): react.JSX.Element;
/** @internal */
type Position = 'top' | 'bottom' | 'inside' | null;
/** @internal */
type Size = 'xsmall' | 'small' | 'medium';
/** @internal */
type ReportedRegionWithRect<T> = T & {
  id: string;
  rect: Rect;
};
/** @internal */
type RegionWithIntersectionDetails = {
  distanceTop: number;
  distanceBottom: number;
  position: 'top' | 'bottom' | 'inside';
  region: ReportedRegionWithRect<FieldPresenceData>;
};
/** @internal */
type FieldPresenceData = {
  element: HTMLElement | null;
  presence: FormNodePresence[];
  maxAvatars: number;
};
/** @internal */
type PresentUser = {
  user: User;
  status?: Status;
  sessions?: Session[];
};
/** @internal */
interface Location {
  documentId: string;
  path: Path;
}
/**
 * @hidden
 * @public */
interface FormNodePresence {
  user: User;
  path: Path;
  sessionId: string;
  lastActiveAt: string;
  selection?: EditorSelection;
}
/** @internal */
interface Rect {
  height: number;
  width: number;
  top: number;
  left: number;
}
/** @internal */
interface FieldPresenceInnerProps {
  maxAvatars?: number;
  presence: FormNodePresence[];
  stack?: boolean;
  position?: AvatarPosition;
  animateArrowFrom?: AvatarPosition;
}
/** @internal */
declare const FieldPresenceInner: react.NamedExoticComponent<FieldPresenceInnerProps>;
/** @internal */
interface FieldPresenceProps {
  presence: FormNodePresence[];
  maxAvatars: number;
}
/** @internal */
declare function FieldPresence(props: FieldPresenceProps): react.JSX.Element;
/**
 * @internal
 * @hidden
 * @deprecated Use `FieldPresence` instead
 * @alias
 */
declare const FieldPresenceWithOverlay: typeof FieldPresence;
/** @internal */
interface PresenceOverlayProps {
  children: ReactNode;
  margins?: [number, number, number, number];
}
/** @internal */
declare function PresenceOverlay({
  children,
  margins
}: PresenceOverlayProps): react.JSX.Element;
/** @internal */
interface PresenceScopeProps {
  readOnly?: boolean;
  path: Path;
  children: ReactNode;
}
/** @internal */
declare function PresenceScope(props: PresenceScopeProps): react.JSX.Element;
/** @internal */
interface FormFieldProps {
  /**
   * @hidden
   * @beta
   */
  __unstable_headerActions?: DocumentFieldActionNode[];
  /**
   * @hidden
   * @beta
   */
  __unstable_presence?: FormNodePresence[];
  /** @internal @deprecated DO NOT USE */
  __internal_comments?: FieldCommentsProps;
  /** @internal @deprecated ONLY USED BY AI ASSIST PLUGIN */
  __internal_slot?: ReactNode;
  children: ReactNode;
  description?: ReactNode;
  /**
   * The unique ID used to target the actual input element
   */
  inputId?: string;
  /**
   * The nesting level of the form field
   */
  level?: number;
  title?: ReactNode;
  /**
   * @beta
   */
  validation?: FormNodeValidation[];
  deprecated?: DeprecatedProperty;
}
/** @internal */
declare const FormField: react.NamedExoticComponent<FormFieldProps & Omit<HTMLProps<HTMLDivElement>, "as" | "height" | "ref">>;
/** @internal */
interface FormFieldHeaderTextProps {
  /**
   *
   * @hidden
   * @beta
   */
  validation?: FormNodeValidation[];
  description?: ReactNode;
  /**
   * The unique ID used to target the actual input element
   */
  inputId?: string;
  title?: ReactNode;
  deprecated?: DeprecatedProperty;
  /**
   * Additional content to be rendered alongside the title
   */
  suffix?: ReactNode;
}
/** @internal */
declare const FormFieldHeaderText: react.NamedExoticComponent<FormFieldHeaderTextProps>;
/** @internal */
interface FormFieldSetProps {
  /**
   *
   * @hidden
   * @beta
   */
  __unstable_headerActions?: DocumentFieldActionNode[];
  /**
   * @beta
   */
  __unstable_presence?: FormNodePresence[];
  /** @internal @deprecated DO NOT USE */
  __internal_comments?: FieldCommentsProps;
  /** @internal @deprecated ONLY USED BY AI ASSIST PLUGIN */
  __internal_slot?: ReactNode;
  children: ReactNode | (() => ReactNode);
  collapsed?: boolean;
  collapsible?: boolean;
  columns?: number | number[];
  description?: ReactNode;
  /**
   * The nesting level of the form field set
   */
  level?: number;
  onCollapse?: () => void;
  onExpand?: () => void;
  title?: ReactNode;
  /**
   *
   * @hidden
   * @beta
   */
  validation?: FormNodeValidation[];
  inputId: string;
  deprecated?: DeprecatedProperty;
}
/** @internal */
declare const FormFieldSet: react.ForwardRefExoticComponent<FormFieldSetProps & Omit<HTMLProps<HTMLDivElement>, "as" | "height" | "ref"> & react.RefAttributes<HTMLDivElement>>;
/** @internal */
interface FieldStatusProps {
  children?: ReactNode;
  maxAvatars?: number;
  position?: 'top' | 'bottom';
}
/** @internal */
declare function FormFieldStatus({
  children,
  maxAvatars,
  position
}: FieldStatusProps): react.JSX.Element;
/** @internal */
interface FormFieldValidationStatusProps {
  /**
   *
   * @hidden
   * @beta
   */
  validation?: FormNodeValidation[];
  /**
   *
   * @hidden
   * @beta
   */
  __unstable_showSummary?: boolean;
  fontSize?: number;
  placement?: Placement;
}
/** @internal */
declare function FormFieldValidationStatus(props: FormFieldValidationStatusProps): react.JSX.Element;
/** @internal */
interface FormFieldValidationWarning {
  type: 'warning';
  label: string;
}
/** @internal */
interface FormFieldValidationError {
  type: 'error';
  label: string;
}
/** @internal */
interface FormFieldValidationInfo {
  type: 'info';
  label: string;
}
/** @internal */
type FormFieldValidation = FormFieldValidationWarning | FormFieldValidationError | FormFieldValidationInfo;
/** @internal */
type FormInputAbsolutePathArg = {
  absolutePath: Path;
};
/** @internal */
type FormInputRelativePathArg = {
  relativePath: Path;
};
/** @internal */
declare const FormInput: react.NamedExoticComponent<(ArrayOfObjectsInputProps<{
  _key: string;
}, _sanity_types0.ArraySchemaType<unknown>> | ObjectInputProps<Record<string, any>, _sanity_types0.ObjectSchemaType>) & ((FormInputAbsolutePathArg | FormInputRelativePathArg) & {
  /**
   * Whether to include the field around the input. Defaults to false
   */
  includeField?: boolean | undefined;
  includeItem?: boolean | undefined;
})>;
declare const areas: readonly ["gutterStart", "body", "gutterEnd"];
type FormArea = (typeof areas)[number];
interface FormRowProps extends PropsWithChildren {
  gutterStartCell?: ReactNode;
}
/**
 * @internal
 */
declare const FormRow: ComponentType<FormRowProps>;
interface Props$1 {
  $area: FormArea;
}
/**
 * @internal
 */
declare const FormCell: styled_components_dist_types0.IStyledComponentBase<"web", styled_components_dist_types0.Substitute<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, Props$1>> & string;
/**
 * @internal
 */
declare const FormContainer: styled_components_dist_types0.IStyledComponentBase<"web", styled_components0.FastOmit<react.DetailedHTMLProps<react.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, never>> & string;
/**
 * @internal
 * @hidden
 */
interface FormValueContextValue {
  value: FormDocumentValue | undefined;
}
/**
 *
 * @internal
 * @hidden
 */
declare function FormValueProvider(props: {
  value: FormDocumentValue | undefined;
  children: ReactNode;
}): react.JSX.Element;
/**
 * React hook that returns the value of the field specified by a path.
 * @public
 *
 * @param path - An array notation with segments that are either strings representing field names, index integers for arrays with simple values, or objects with a _key for arrays containing objects
 *
 * @returns The value of the field specified by the path
 *
 * @example Using the `useFormValue` hook
 * ```ts
 * function MyComponent() {
 *    // get value of field 'name' in object 'author'
 *    const authorName = useFormValue(['author', 'name'])
 *    // get value of the second item in array 'tags' of type 'string'
 *    const secondTag = useFormValue(['tags', 1])
 *    // get value of the reference with the matching key in an array of references
 *    const specificBook = useFormValue([ 'bibliography', {_key: '<key>'} ])
 *   // ... do something with the form values ...
 * }
 * ```
 */
declare function useFormValue(path: Path): unknown;
declare function GetFormValueProvider(props: {
  value: FormDocumentValue | undefined;
  children: ReactNode;
}): react.JSX.Element;
declare namespace GetFormValueProvider {
  var displayName: string;
}
/**
 * React hook that returns a function that can be called to look up the value from the current document at the given path.
 * The returned function is stable and never changes identity.
 * NOTE: This hook will *not* trigger a re-render when the value of the document changes, which makes it less suitable for use in render functions.
 * The main use case for using this is to look up values at the current document during an event handler
 * @public
 *
 * @returns A function that can be called to look up the value from the current document at the given path.
 *
 * @example Using the `useGetFormValue` hook
 * ```ts
 * function MyComponent() {
 *    // get value of field 'name' in object 'author'
 *    const getFormValue = useGetFormValue()
 *
 *    const handleClick = useCallback(() => {
 *      console.log(getFormValue(['author', 'name']))
 *    }, [getFormValue])
 * }
 * ```
 */
declare function useGetFormValue(): sanity__singletons0.GetFormValueContextValue;
/** @internal */
interface FieldActionMenuProps {
  nodes: DocumentFieldActionNode[];
  onMenuOpenChange: (open: boolean) => void;
}
/** @internal */
declare const FieldActionMenu: react.NamedExoticComponent<FieldActionMenuProps>;
type FieldActionsProviderProps = PropsWithChildren<{
  actions: DocumentFieldActionNode[]; /** @internal @deprecated DO NOT USE */
  __internal_comments?: FieldCommentsProps;
  __internal_slot?: ReactNode;
  focused?: boolean;
  path: Path;
}>;
/** @internal */
declare const FieldActionsProvider: react.NamedExoticComponent<FieldActionsProviderProps>;
/** @internal */
interface FieldActionsProps {
  actions: DocumentFieldAction[];
  documentId: string;
  documentType: string;
  onActions: (actions: DocumentFieldActionNode[]) => void;
  path: Path;
  schemaType: SchemaType;
}
/**
 *
 * The `FieldActionsResolver` component is responsible for resolving the actions for a given field.
 *
 * Since each field action is a React hook, they need to be rendered in a component that returns
 * `null` to allow for the hook's return value to be resolved.
 *
 * The way this works:
 *
 * - The parent component (`FieldProvider`) renders the `FieldActionsResolver` component.
 * - The `FieldActionsResolver` component renders each field action as a child component.
 * - Each field action is a React hook that returns a node, and calls `setFieldAction` with its
 *   index and value.
 * - The `FieldActionsResolver` keeps a state with the array of hook values, making sure the array
 *   has the same length as the number of actions.
 * - The `FieldActionsResolver` calls `onActions` with the array of hook values.
 *
 * @internal
 */
declare const FieldActionsResolver: react.NamedExoticComponent<FieldActionsProps>;
/** @internal */
declare function useFieldActions(): FieldActionsContextValue;
/** @internal */
declare const HoveredFieldProvider: react.NamedExoticComponent<{
  children?: react.ReactNode;
}>;
/** @internal */
declare function useHoveredField(): HoveredFieldContextValue;
/**
 *
 * @hidden
 * @beta
 */
interface FormBuilderContextValue {
  /**
   * @deprecated INTERNAL USE ONLY
   * @internal
   */
  __internal: {
    components: {
      CustomMarkers: FormBuilderCustomMarkersComponent;
      Markers: FormBuilderMarkersComponent;
    };
    file: {
      assetSources: AssetSource[];
      directUploads: boolean;
    };
    filterField: FormBuilderFilterFieldFn;
    image: {
      assetSources: AssetSource[];
      directUploads: boolean;
    };
    patchChannel: PatchChannel;
    inspectOpen?: boolean;
  };
  autoFocus?: boolean;
  changesOpen?: boolean;
  collapsedFieldSets: StateTree<boolean> | undefined;
  collapsedPaths: StateTree<boolean> | undefined;
  focusPath: Path;
  focused?: boolean;
  groups: FormFieldGroup[];
  id: string;
  readOnly?: boolean;
  renderAnnotation?: RenderAnnotationCallback;
  renderBlock?: RenderBlockCallback;
  renderField: RenderFieldCallback;
  renderInlineBlock?: RenderBlockCallback;
  renderInput: RenderInputCallback;
  renderItem: RenderItemCallback;
  renderPreview: RenderPreviewCallback;
  schemaType: ObjectSchemaType;
}
/**
 * A hook for doing side effects as a response to a change in a hook value between renders
 *
 * @example
 * ```ts
 * useDidUpdate(hasFocus, (hadFocus, hasFocus) => {
 *  if (hasFocus) {
 *    scrollIntoView(elementRef.current)
 *   }
 * })
 * ```
 *
 * @beta
 * @hidden
 */
declare function useDidUpdate<T>(/** The value you want to respond to changes in. */

current: T, /** Callback to run when the value changes. */

didUpdate: (previous: T | undefined, current: T) => void, compare?: (previous: T | undefined, current: T) => boolean): void;
/**
 * @hidden
 * @beta */
declare function ArrayOfObjectsFunctions<Item extends ObjectItem, TSchemaType extends ArraySchemaType>(props: ArrayInputFunctionsProps<Item, TSchemaType>): react.JSX.Element | null;
/**
 *
 * @hidden
 * @beta
 */
declare function ArrayOfObjectsInput(props: ArrayOfObjectsInputProps): react.JSX.Element;
/**
 * @internal
 */
interface VirtualizerScrollInstance {
  /**
   * The parent that has the overflow scroll
   */
  scrollElement: HTMLElement | null;
  /**
   * The container that wraps the array items
   */
  containerElement: MutableRefObject<HTMLElement | null>;
}
/**
 * @internal
 */
declare function useVirtualizerScrollInstance(): VirtualizerScrollInstance;
/**
 * @internal
 */
interface VirtualizerScrollInstanceProviderProps extends VirtualizerScrollInstance {
  children: ReactNode;
}
/**
 *
 * @internal
 */
declare function VirtualizerScrollInstanceProvider(props: VirtualizerScrollInstanceProviderProps): react.JSX.Element;
/**
 * @hidden
 * Array of predefined object options input
 * Note: this input can handle only object values
 *
 *
 * @hidden
 * @beta
 */
declare function ArrayOfObjectOptionsInput(props: ArrayOfObjectsInputProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
declare function ArrayOfOptionsInput(props: ArrayOfObjectsInputProps | ArrayOfPrimitivesInputProps): react.JSX.Element;
/**
 * Array of predefined primitive options input
 * Note: this input can only handle primitive values
 *
 *
 * @hidden
 * @beta
 */
declare function ArrayOfPrimitiveOptionsInput(props: ArrayOfPrimitivesInputProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
declare function ArrayOfPrimitivesFunctions<MemberType extends string | boolean | number, SchemaType extends ArraySchemaType>(props: ArrayInputFunctionsProps<MemberType, SchemaType>): react.JSX.Element | null;
type PrimitiveValue = string | number | boolean;
interface State {
  disableTransition: boolean;
}
/**
 * Note: this should be a class component until React provides support for a hook version of getSnapshotBeforeUpdate
 *
 * @hidden
 * @beta
 */
declare class ArrayOfPrimitivesInput extends PureComponent<ArrayOfPrimitivesInputProps, State> {
  _element: HTMLElement | null;
  constructor(props: ArrayOfPrimitivesInputProps);
  handleAppend: (itemValue: PrimitiveValue) => void;
  handlePrepend: (itemValue: PrimitiveValue) => void;
  handleSortEnd: (event: {
    fromIndex: number;
    toIndex: number;
  }) => void;
  handleItemMoveStart: () => void;
  handleItemMoveEnd: () => void;
  focus(): void;
  getSnapshotBeforeUpdate(prevProps: ArrayOfPrimitivesInputProps): {
    prevFocusedIndex: _sanity_types0.PathSegment;
    restoreSelection: {
      text: string;
      start: number | null;
      end: number | null;
      value: string;
    };
  } | {
    prevFocusedIndex?: undefined;
    restoreSelection?: undefined;
  } | null;
  componentDidUpdate(prevProps: ArrayOfPrimitivesInputProps, prevState: Record<string, unknown>, snapshot?: {
    restoreSelection: {
      start: number;
      end: number;
    };
    prevFocusedIndex: number;
  }): void;
  renderArrayItem: (props: Omit<PrimitiveItemProps, "renderDefault">) => react.JSX.Element;
  render(): react.JSX.Element;
}
/**
 * Universal array input that will introspect its schemaType and delegate to the right implementation
 * Useful as a fallback/last resort input for an array type
 *
 *
 * @hidden
 * @beta
 */
declare function UniversalArrayInput(props: ArrayOfObjectsInputProps | ArrayOfPrimitivesInputProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
declare function BooleanInput(props: BooleanInputProps): react.JSX.Element;
/**
 * Used to preview a referenced type
 * Takes the reference type as props
 *
 * @internal
 */
declare function CrossDatasetReferencePreview(props: {
  availability: DocumentAvailability | null;
  id: string;
  hasStudioUrl?: boolean;
  showStudioUrlIcon?: boolean;
  preview: {
    published: PreviewValue | undefined;
  };
  dataset: string;
  projectId: string;
  refType?: CrossDatasetType;
  showTypeLabel: boolean;
}): react.JSX.Element;
/**
 * @hidden
 * @beta */
type DateInputProps = StringInputProps;
/**
 * @hidden
 * @beta */
declare function DateInput(props: DateInputProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
type DateTimeInputProps = StringInputProps;
/**
 * @hidden
 * @beta */
declare function DateTimeInput(props: DateTimeInputProps): react.JSX.Element;
interface CalendarLabels {
  ariaLabel: string;
  goToTomorrow: string;
  goToToday: string;
  goToYesterday: string;
  goToPreviousYear: string;
  goToNextYear: string;
  goToPreviousMonth: string;
  goToNextMonth: string;
  selectTime: string;
  setToCurrentTime: string;
  tooltipText: string;
  monthNames: MonthNames;
  weekDayNamesShort: WeekDayNames;
  setToTimePreset: (time: string, date: Date) => string;
}
type WeekDayNames = [mon: string, tue: string, wed: string, thu: string, fri: string, sat: string, sun: string];
type MonthNames = [jan: string, feb: string, mar: string, apr: string, may: string, jun: string, jul: string, aug: string, sep: string, oct: string, nov: string, dec: string];
/**
 * @internal
 */
declare function getCalendarLabels(t: (key: string, values?: Record<string, unknown>) => string): CalendarLabels;
/**
 *
 * @hidden
 * @beta
 */
type EmailInputProps = StringInputProps;
/**
 *
 * @hidden
 * @beta
 */
declare function EmailInput(props: EmailInputProps): react.JSX.Element;
/**
 * @hidden
 * @beta
 */
type AssetAccessPolicy = 'checking' | 'private' | 'public' | 'unknown';
/**
 *
 * @hidden
 * @beta
 */
declare function NumberInput(props: NumberInputProps): react.JSX.Element;
/**
 * @hidden
 * @beta */
declare const ObjectInput: react.NamedExoticComponent<ObjectInputProps<Record<string, any>, _sanity_types0.ObjectSchemaType>>;
/** @internal */
interface PortableTextMemberItem {
  kind: 'annotation' | 'textBlock' | 'objectBlock' | 'inlineObject';
  key: string;
  member: ArrayOfObjectsItemMember;
  node: ObjectFormNode;
  input?: ReactNode;
}
/**
 * Input component for editing block content
 * ({@link https://github.com/portabletext/portabletext | Portable Text}) in the Sanity Studio.
 *
 * Supports multi-user real-time block content editing on larger documents.
 *
 * This component can be configured and customized extensively.
 * {@link https://www.sanity.io/docs/customizing-the-portable-text-editor | Go to the documentation for more details}.
 *
 * @public
 * @param props - {@link PortableTextInputProps} component props.
 */
declare function PortableTextInput(props: PortableTextInputProps): ReactNode;
/**
 * `EditorProvider` doesn't have a `readOnly` prop. Instead, this custom PTE
 * plugin listens for the prop change and sends a `toggle readOnly` event to
 * the editor.
 *
 * @internal
 */
declare function UpdateReadOnlyPlugin(props: {
  readOnly: boolean;
}): null;
interface ReferenceTemplate {
  id: string;
  params?: Record<string, string | number | boolean>;
}
/**
 * @internal
 */
interface CreateReferenceOption {
  id: string;
  title: string;
  i18n?: I18nTextRecord<'title'>;
  icon?: ReactNode | ComponentType;
  type: string;
  template: ReferenceTemplate;
  permission: {
    granted: boolean;
    reason: string;
  };
}
interface Props extends Omit<HTMLProps<HTMLButtonElement>, 'as' | 'size' | 'width' | 'type' | 'ref'> {
  id: string;
  createOptions: CreateReferenceOption[];
  menuRef?: RefObject<HTMLDivElement | null>;
  onCreate: (option: CreateReferenceOption) => void;
  readOnly?: boolean;
}
/**
 * @internal
 */
declare function CreateButton(props: Props): react.JSX.Element;
/**
 * @internal
 */
declare const ReferenceAutocomplete: react.ForwardRefExoticComponent<Omit<_sanity_ui0.AutocompleteProps<_sanity_ui0.BaseAutocompleteOption> & Omit<react.HTMLProps<HTMLInputElement>, "aria-activedescendant" | "aria-autocomplete" | "aria-expanded" | "aria-owns" | "as" | "autoCapitalize" | "autoComplete" | "autoCorrect" | "id" | "inputMode" | "onChange" | "onSelect" | "popover" | "prefix" | "ref" | "role" | "spellCheck" | "type" | "value"> & {
  ref?: Ref<HTMLInputElement> | undefined;
} & {
  path: Path;
  referenceElement: HTMLDivElement | null;
  searchString?: string | undefined;
  portalRef?: RefObject<HTMLDivElement | null> | undefined;
}, "ref"> & react.RefAttributes<HTMLInputElement>>;
/**
 *
 * @hidden
 * @beta
 */
declare function SelectInput(props: StringInputProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
type SlugInputProps = ObjectInputProps<SlugValue, SlugSchemaType>;
/**
 *
 * @hidden
 * @beta
 */
declare function SlugInput(props: SlugInputProps): react.JSX.Element;
/**
 * @hidden
 * @beta
 */
declare function StringInput(props: StringInputProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
type TagsArrayInputProps = ArrayOfPrimitivesInputProps<string>;
/**
 *
 * @hidden
 * @beta
 */
declare function TagsArrayInput(props: TagsArrayInputProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
type TelephoneInputProps = StringInputProps;
/**
 *
 * @hidden
 * @beta
 */
declare function TelephoneInput(props: TelephoneInputProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
type TextInputProps = StringInputProps<TextSchemaType>;
/**
 *
 * @hidden
 * @beta
 */
declare function TextInput(props: TextInputProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
type UrlInputProps = StringInputProps;
/**
 *
 * @hidden
 * @beta
 */
declare function UrlInput(props: UrlInputProps): react.JSX.Element;
/** @internal */
interface ArrayOfObjectsMemberProps {
  member: ArrayOfObjectsMember;
  renderAnnotation?: RenderAnnotationCallback;
  renderBlock?: RenderBlockCallback;
  renderField: RenderFieldCallback;
  renderInlineBlock?: RenderBlockCallback;
  renderInput: RenderInputCallback;
  renderItem: RenderArrayOfObjectsItemCallback;
  renderPreview: RenderPreviewCallback;
}
/**
 * Convenience component for rendering an "array of objects"-item
 * @internal
 */
declare function ArrayOfObjectsInputMember(props: ArrayOfObjectsMemberProps): react.JSX.Element | null;
/** @internal */
interface ArrayOfObjectsInputMembersProps {
  members: ArrayOfObjectsMember[];
  renderAnnotation?: RenderAnnotationCallback;
  renderBlock?: RenderBlockCallback;
  renderInlineBlock?: RenderBlockCallback;
  renderInput: RenderInputCallback;
  renderField: RenderFieldCallback;
  renderItem: RenderArrayOfObjectsItemCallback;
  renderPreview: RenderPreviewCallback;
}
/**
 * Convenience component for wrapping an array of objects
 * @internal
 */
declare function ArrayOfObjectsInputMembers(props: ArrayOfObjectsInputMembersProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
interface MemberItemProps {
  member: ArrayOfObjectsItemMember;
  renderAnnotation?: RenderAnnotationCallback;
  renderBlock?: RenderBlockCallback;
  renderInlineBlock?: RenderBlockCallback;
  renderItem: RenderArrayOfObjectsItemCallback;
  renderField: RenderFieldCallback;
  renderInput: RenderInputCallback;
  renderPreview: RenderPreviewCallback;
}
/**
 *
 * @hidden
 * @beta
 */
declare function ArrayOfObjectsItem(props: MemberItemProps): react.JSX.Element;
/**
 *
 * @hidden
 * @beta
 */
interface PrimitiveMemberItemProps {
  member: ArrayOfPrimitivesItemMember;
  renderItem: RenderArrayOfPrimitivesItemCallback;
  renderInput: RenderInputCallback;
}
/**
 *
 * @hidden
 * @beta
 */
declare function ArrayOfPrimitivesItem(props: PrimitiveMemberItemProps): react.JSX.Element;
/** @internal */
declare function MemberItemError(props: {
  member: ArrayItemError;
}): react.JSX.Element;
/** @internal */
interface MemberFieldProps {
  member: FieldMember;
  renderAnnotation?: RenderAnnotationCallback;
  renderBlock?: RenderBlockCallback;
  renderField: RenderFieldCallback;
  renderInlineBlock?: RenderBlockCallback;
  renderInput: RenderInputCallback;
  renderItem: RenderArrayOfObjectsItemCallback;
  renderPreview: RenderPreviewCallback;
}
/** @internal */
declare const MemberField: react.NamedExoticComponent<MemberFieldProps>;
/** @internal */
declare function MemberFieldError(props: {
  member: FieldError;
}): react.JSX.Element;
/** @internal */
declare const MemberFieldSet: react.NamedExoticComponent<{
  member: FieldSetMember;
  renderAnnotation?: RenderAnnotationCallback | undefined;
  renderBlock?: RenderBlockCallback | undefined;
  renderField: RenderFieldCallback;
  renderInlineBlock?: RenderBlockCallback | undefined;
  renderInput: RenderInputCallback;
  renderItem: RenderArrayOfObjectsItemCallback;
  renderPreview: RenderPreviewCallback;
}>;
/** @internal */
interface ObjectInputMemberProps {
  member: ObjectMember;
  renderAnnotation?: RenderAnnotationCallback;
  renderBlock?: RenderBlockCallback;
  renderField: RenderFieldCallback;
  renderInlineBlock?: RenderBlockCallback;
  renderInput: RenderInputCallback;
  renderItem: RenderArrayOfObjectsItemCallback;
  renderPreview: RenderPreviewCallback;
}
/** @internal */
declare const ObjectInputMember: react.NamedExoticComponent<ObjectInputMemberProps>;
/** @internal */
interface ObjectMembersProps {
  members: ObjectMember[];
  renderAnnotation?: RenderAnnotationCallback;
  renderBlock?: RenderBlockCallback;
  renderInlineBlock?: RenderBlockCallback;
  renderInput: RenderInputCallback;
  renderField: RenderFieldCallback;
  renderItem: RenderArrayOfObjectsItemCallback;
  renderPreview: RenderPreviewCallback;
}
/**
 * Convenience component for wrapping an object input
 * @internal
 */
declare function ObjectInputMembers(props: ObjectMembersProps): react.JSX.Element;
/**
 * @deprecated Use ObjectInputMembers instead
 * @internal
 * @alias
 */
declare const ObjectMembers: typeof ObjectInputMembers;
interface DocumentFormOptions {
  documentType: string;
  documentId: string;
  releaseId?: ReleaseId;
  initialValue?: InitialValueState;
  initialFocusPath?: Path;
  selectedPerspectiveName?: ReleaseId | 'published';
  readOnly?: boolean | ((editState: EditStateFor) => boolean);
  /**
   * Usually the historical _rev value selected, if not defined, it will use the current document value
   * so no comparison will be done.
   */
  comparisonValue?: Partial<SanityDocument$1> | ((editState: EditStateFor) => Partial<SanityDocument$1>) | null;
  onFocusPath?: (path: Path) => void;
  changesOpen?: boolean;
  /**
   * Callback that allows to transform the value before it's passed to the form
   * used by the <DocumentPaneProvider > to display the history values.
   */
  getFormDocumentValue?: (value: SanityDocumentLike) => SanityDocumentLike;
  displayInlineChanges?: boolean;
}
interface DocumentFormValue extends Pick<NodeChronologyProps, 'hasUpstreamVersion'> {
  /**
   * `EditStateFor` for the displayed document.
   * */
  editState: EditStateFor;
  /**
   *  `EditStateFor` for the displayed document's upstream version.
   */
  upstreamEditState: EditStateFor;
  connectionState: ConnectionState;
  collapsedFieldSets: StateTree<boolean> | undefined;
  collapsedPaths: StateTree<boolean> | undefined;
  openPath: Path;
  ready: boolean;
  value: SanityDocumentLike;
  formState: FormState;
  focusPath: Path;
  validation: ValidationMarker[];
  permissions: PermissionCheckResult | undefined;
  isPermissionsLoading: boolean;
  onBlur: (blurredPath: Path) => void;
  onFocus: (_nextFocusPath: Path, payload?: OnPathFocusPayload) => void;
  onSetCollapsedPath: (path: Path, collapsed: boolean) => void;
  onSetActiveFieldGroup: (path: Path, groupName: string) => void;
  onSetCollapsedFieldSet: (path: Path, collapsed: boolean) => void;
  onChange: (event: PatchEvent) => void;
  onPathOpen: (path: Path) => void;
  onProgrammaticFocus: (nextPath: Path) => void;
  formStateRef: RefObject<FormState>;
  schemaType: ObjectSchemaType;
}
/**
 * @internal
 * Hook for creating a form state and combine it with the <FormBuilder>.
 * It will handle the connection state, edit state, validation, and presence.
 *
 * Use this as a base point to create your own form.
 */
declare function useDocumentForm(options: DocumentFormOptions): DocumentFormValue;
/**
 *
 * @hidden
 * @beta
 */
declare function useFormBuilder(): FormBuilderContextValue;
/**
 * @internal
 */
type MutationPatch = Record<string, any>;
/**
 * @internal
 */
declare function toMutationPatches(patches: FormPatch[]): MutationPatch[];
/**
 * @internal
 */
declare function fromMutationPatches(origin: FormPatchOrigin, patches: MutationPatch[]): FormPatch[];
/**
 * @internal
 */
declare function encodePath(formBuilderPath: Path): string;
/**
 * @internal
 */
declare function decodePath(gradientPath: string): Path;
type PatchTransformer = (patches: FormPatch[]) => FormPatch[];
/**
 * @hidden
 * @beta */
declare const TransformPatches: react.NamedExoticComponent<{
  transform: PatchTransformer;
} & {
  children: ReactNode;
}>;
/**
 * Login methods that may be used for Studio authentication.
 *
 * @public
 */
type LoginMethod = 'dual' | 'cookie' | 'token';
/**
 * Login methods that acknowledge cookieless authentication tokens.
 *
 * @internal
 * @hidden
 */
type CookielessCompatibleLoginMethod = Extract<LoginMethod, 'dual' | 'token'>;
/**
 * Authentication options
 *
 * @public
 */
interface AuthConfig {
  /**
   * Login method to use for the studio. Can be one of:
   * - `dual` (default) - attempt to use cookies where possible, falling back to
   *   storing authentication token in `localStorage` otherwise
   * - `cookie` - explicitly disable `localStorage` method, relying only on cookies. May fail due
   *   to cookies being treated as third-party cookies in some browsers, thus the default is `dual`.
   * - `token` - explicitly disable cookies, relying only on `localStorage` method
   */
  loginMethod?: LoginMethod;
  /**
   * Whether to append the providers specified in `providers` with the default providers from the
   * API, or replace the default providers with the ones specified.
   *
   * @deprecated Use the function form of `providers` instead for more control
   */
  mode?: 'append' | 'replace';
  /**
   * If true, the "Choose login provider" (eg "Google, "GitHub", "E-mail/password") screen
   * will be skipped if only a single provider is configured in the `providers` array -
   * instead it will redirect unauthenticated users straight to the authentication URL.
   */
  redirectOnSingle?: boolean;
  /**
   * Array of authentication providers to use, or a function that takes an array of default
   * authentication providers (fetched from the Sanity API) and should return a new list of
   * providers. This can be used to selectively replace, add or remove providers from the
   * list of choices.
   *
   * @remarks If a static array of providers is provided, the `mode` property is taken into account
   *   when determining what to do with it - `append` will append the providers to the default set
   *   of providers, while `replace` will replace the default providers with the ones specified.
   *
   * If not set, the default providers will be used.
   */
  providers?: AuthProvider[] | ((prev: AuthProvider[]) => AuthProvider[] | Promise<AuthProvider[]>);
  /**
   * The API hostname for requests. Should usually be left undefined,
   * but can be set if using custom cname for API domain.
   */
  apiHost?: string;
}
/**
 * A provider of authentication.
 *
 * By default, a list of providers for a project will be fetched from the
 * {@link https://api.sanity.io/v1/auth/providers | Sanity API}, but you may choose to limit this
 * list by explicitly defining the providers you want to allow, or add additional custom providers
 * that conforms to the authentication provider specification outlined in
 * {@link https://www.sanity.io/docs/third-party-login | the documentation}.
 *
 * @public
 */
interface AuthProvider {
  /**
   * URL-friendly identifier/name for the provider, eg `github`
   */
  name: string;
  /**
   * Human friendly title for the provider, eg `GitHub`
   */
  title: string;
  /**
   * URL for the authentication endpoint that will trigger the authentication flow
   */
  url: string;
  /**
   * URL for a logo to display next to the provider in the login screen
   */
  logo?: string;
}
/**
 * @hidden
 * @beta */
interface DocumentFieldAction {
  name: string;
  useAction: DocumentFieldActionHook;
}
/**
 * @hidden
 * @beta */
interface DocumentFieldActionHook {
  (props: DocumentFieldActionProps): DocumentFieldActionItem | DocumentFieldActionGroup;
}
/**
 * @hidden
 * @beta */
interface DocumentFieldActionProps {
  documentId: string;
  documentType: string;
  path: Path;
  schemaType: SchemaType;
}
/**
 * @hidden
 * @beta */
type DocumentFieldActionStatus = 'info' | 'success' | 'warning' | 'error';
/**
 * @hidden
 * @beta */
type DocumentFieldActionTone = 'primary' | 'positive' | 'caution' | 'critical';
/**
 * @hidden
 * @beta */
interface DocumentFieldActionItem {
  type: 'action';
  disabled?: boolean | {
    reason: ReactNode;
  };
  hidden?: boolean;
  icon?: ComponentType;
  iconRight?: ComponentType;
  onAction: () => void;
  renderAsButton?: boolean;
  selected?: boolean;
  status?: DocumentFieldActionStatus;
  title: string;
  i18n?: I18nTextRecord<'title'>;
  tone?: DocumentFieldActionTone;
}
/**
 * @hidden
 * @beta */
interface DocumentFieldActionDivider {
  type: 'divider';
}
/**
 * @hidden
 * @beta */
interface DocumentFieldActionGroup {
  type: 'group';
  children: DocumentFieldActionNode[];
  disabled?: boolean | {
    reason: ReactNode;
  };
  expanded?: boolean;
  hidden?: boolean;
  icon?: ComponentType;
  renderAsButton?: boolean;
  status?: DocumentFieldActionStatus;
  title: string;
  i18n?: I18nTextRecord<'title'>;
  tone?: DocumentFieldActionTone;
}
/**
 * @hidden
 * @beta */
type DocumentFieldActionNode = DocumentFieldActionItem | DocumentFieldActionGroup | DocumentFieldActionDivider;
/**
 * @hidden
 * @beta */
interface DocumentFieldActionsResolverContext extends ConfigContext$1 {
  documentId: string;
  documentType: string;
  schemaType: SchemaType;
}
/**
 * @hidden
 * @beta */
type DocumentFieldActionsResolver = ComposableOption<DocumentFieldAction[], DocumentFieldActionsResolverContext>;
/** @internal */
declare function defineDocumentFieldAction(fieldAction: DocumentFieldAction): DocumentFieldAction;
/** @internal */
declare const documentFieldActionsReducer: ConfigPropertyReducer<DocumentFieldAction[], DocumentFieldActionsResolverContext>;
/** @internal */
declare const initialDocumentFieldActions: DocumentFieldAction[];
/** @hidden @beta */
interface DocumentInspectorProps {
  documentId: string;
  documentType: string;
  onClose: () => void;
}
/** @hidden @beta */
type DocumentInspectorComponent = ComponentType<DocumentInspectorProps>;
/** @hidden @beta */
interface DocumentInspectorUseMenuItemProps {
  documentId: string;
  documentType: string;
}
/** @hidden @beta */
interface DocumentInspectorMenuItem {
  hidden?: boolean;
  hotkeys?: string[];
  icon?: ComponentType;
  showAsAction?: boolean;
  status?: ButtonTone;
  title: string;
  tone?: ButtonTone;
}
/** @hidden @beta */
interface DocumentInspector {
  name: string;
  component: DocumentInspectorComponent;
  /**
   * Hook for defining a menu item for the inspector.
   */
  useMenuItem?: (props: DocumentInspectorUseMenuItemProps) => DocumentInspectorMenuItem;
  /**
   * Callback for when the inspector is closed, which can be used to clean up custom document pane
   * parameters.
   */
  onClose?: (ctx: {
    params: Record<string, string | undefined>;
  }) => {
    params: Record<string, string | undefined>;
  };
  /**
   * Callback for when the inspector is opened, which can be used to set custom document pane
   * parameters.
   */
  onOpen?: (ctx: {
    params: Record<string, string | undefined>;
  }) => {
    params: Record<string, string | undefined>;
  };
}
/**
 * Define a document inspector to be used in Sanity configuration.
 *
 * @example
 *
 * ```ts
 * // sanity.config.ts
 *
 * import {RocketIcon} from '@sanity/icons'
 * import {defineConfig, defineDocumentInspector} from 'sanity'
 *
 * const customInspector = defineDocumentInspector({
 *   name: 'custom',
 *   useMenuItem: () => ({
 *     icon: RocketIcon,
 *     showAsAction: true,
 *     title: 'Custom'
 *   }),
 *   component: lazy(() => import('./inspectors/custom')),
 * })
 *
 * export default defineConfig({
 *   // ...
 *
 *   document: {
 *     inspectors: (prev) => [customInspector, ...prev],
 *   },
 * })
 * ```
 *
 * @hidden @beta
 * */
declare function defineDocumentInspector(inspector: DocumentInspector): DocumentInspector;
/**
 * @hidden
 * @beta */
interface FormComponents {
  annotation?: ComponentType<BlockAnnotationProps>;
  block?: ComponentType<BlockProps>;
  field?: ComponentType<FieldProps>;
  inlineBlock?: ComponentType<BlockProps>;
  input?: ComponentType<InputProps>;
  item?: ComponentType<ItemProps>;
  preview?: ComponentType<PreviewProps>;
  portableText?: {
    plugins?: ComponentType<PortableTextPluginsProps>;
  };
}
/**
 * @public
 */
interface ReleaseActionProps {
  release: ReleaseDocument;
  documents: DocumentInRelease[];
}
/**
 * @hidden
 * @public
 */
interface ReleaseActionComponent {
  (props: ReleaseActionProps): ReleaseActionDescription;
  displayName?: string;
}
/**
 * @hidden
 * @public
 */
interface ReleaseActionDescription {
  disabled?: boolean;
  icon?: ReactNode | ComponentType;
  label: string;
  onHandle?: () => void;
  title?: ReactNode;
}
/**
 * @hidden
 * @public
 */
type ReleaseActionsContext = ConfigContext$1 & ReleaseActionProps;
/**
 * @hidden
 * @beta
 */
interface ActionComponent<ActionProps, ActionDescription> {
  (props: ActionProps): ActionDescription | null;
}
/**
 * @hidden
 * @beta
 */
interface BaseActionDescription {
  disabled?: boolean;
  icon?: ReactNode | ComponentType;
  label: string;
  onHandle?: () => void;
  title?: ReactNode;
  tone?: ButtonTone;
  shortcut?: string | null;
  dialog?: unknown;
}
/**
 * @hidden
 * @beta
 */
interface GroupableActionDescription<GroupType = unknown> extends BaseActionDescription {
  group?: GroupType[];
}
/**
 * Symbol for configuring decision parameters schema
 * @beta
 */
declare const DECISION_PARAMETERS_SCHEMA: unique symbol;
/**
 * Configuration for decision parameters
 * @beta
 */
interface DecisionParametersConfig {
  [key: string]: string[];
}
/**
 * @hidden
 * @beta
 */
type AssetSourceResolver = ComposableOption<AssetSource[], ConfigContext$1>;
/**
 * @public
 */
interface SanityFormConfig {
  /**
   * these have not been migrated over
   *
   *
   * @hidden
   * @beta
   */
  unstable?: {
    CustomMarkers?: FormBuilderCustomMarkersComponent;
    Markers?: FormBuilderMarkersComponent;
  };
  /**
   * Components for the form.
   * @hidden
   * @beta
   */
  components?: FormComponents;
  file?: {
    /**
     * @hidden
     * @beta
     */
    assetSources?: AssetSource[] | AssetSourceResolver;
    directUploads?: boolean;
  };
  /**
   * @hidden
   * @beta
   */
  image?: {
    assetSources?: AssetSource[] | AssetSourceResolver;
    directUploads?: boolean;
  };
}
/** @internal */
interface FormBuilderComponentResolverContext extends ConfigContext$1 {
  schemaType: SchemaType;
}
/**
 * A tool can be thought of as a top-level "view" or "app".
 * They are available through the global menu bar, and has a URL route associated with them.
 *
 * In essence, a tool is a React component that is rendered when the tool is active,
 * along with a title, name (URL segment) and icon.
 *
 * Tools can handle {@link structure.Intent | intents} such as "edit" or "create" by defining a
 * function for the `canHandleIntent` property, as well as the `getIntentState` property,
 * which defines what an intent will be mapped to in terms of the tool's URL state.
 *
 * @public
 */
interface Tool<Options = any> {
  /**
   * The React component that renders the tool.
   */
  component: ComponentType<{
    tool: Tool<Options>;
  }>;
  /**
   * React component for the icon representing the tool.
   */
  icon?: ComponentType;
  /**
   * The name of the tool, used as part of the URL.
   */
  name: string;
  /**
   * Options are passed through from the configuration to the component defined by the `component`
   */
  options?: Options;
  /**
   * The router for the tool. See {@link router.Router}
   */
  router?: Router;
  /**
   * Title of the tool - used for the navigation menu item, along with the icon.
   */
  title: string;
  /**
   * Determines whether the tool will control the `document.title`.
   */
  controlsDocumentTitle?: boolean;
  /**
   * Gets the state for the given intent.
   *
   * @param intent - The intent to get the state for.
   * @param params - The parameters for the intent.
   * @param routerState - The current router state. See {@link router.RouterState}
   * @param payload - The payload for the intent.
   * @returns The state for the intent.
   */
  getIntentState?: (intent: string, params: Record<string, string>, routerState: RouterState | undefined, payload: unknown) => unknown;
  /**
   * Determines whether the tool can handle the given intent.
   *
   * Can either return a boolean, or an object where the keys represent the parameters that
   * can/can not be handled. This will be used to determine whether or not a tool is the best
   * suited to handle an intent. Note that an object of only `false` values (or an empty object)
   * is treated as `true`, so you want to explicitly return `false` if you know the intent cannot
   * fulfill the intent request.
   *
   * @param intent - The intent to check.
   * @param params - The parameters for the intent.
   * @param payload - The payload for the intent.
   * @returns Boolean: whether it can handle the intent. Object: Values representing what specific parameters can be handled.
   */
  canHandleIntent?: (intent: string, params: Record<string, unknown>, payload: unknown) => boolean | {
    [key: string]: boolean;
  };
  /**
   * Internal application type identifier used to classify system tools.
   *
   * @internal
   */
  __internalApplicationType?: string;
}
/** @public */
type ComposableOption<TValue, TContext> = (prev: TValue, context: TContext) => TValue;
/**
 * @hidden
 * @beta
 */
type AsyncComposableOption<TValue, TContext> = (prev: TValue, context: TContext) => Promise<TValue>;
/** @public */
interface ConfigContext$1 {
  /**
   * The ID of the project.
   */
  projectId: string;
  /**
   * The name of the dataset.
   */
  dataset: string;
  /**
   * The schema for this source.
   */
  schema: Schema;
  /**
   * The current user or `null` if not authenticated.
   */
  currentUser: CurrentUser | null;
  /**
   * A function that returns a Sanity client with the {@link SourceClientOptions | specified options}.
   */
  getClient: (options: SourceClientOptions) => SanityClient;
  /**
   * Localization resources
   */
  i18n: LocaleSource;
  /** @beta */
  [DECISION_PARAMETERS_SCHEMA]?: DecisionParametersConfig;
}
/** @public */
type TemplateResolver = ComposableOption<Template[], ConfigContext$1>;
/**
 * @hidden
 * @beta
 */
interface SchemaPluginOptions {
  name?: string;
  types?: SchemaTypeDefinition[] | ComposableOption<SchemaTypeDefinition[], Omit<ConfigContext$1, 'schema' | 'currentUser' | 'getClient' | 'client' | 'i18n'>>;
  templates?: Template[] | TemplateResolver;
}
/**
 * @hidden
 * @beta
 */
type NewDocumentOptionsResolver = ComposableOption<TemplateItem[], NewDocumentOptionsContext>;
/**
 * @hidden
 * @beta
 */
interface NewDocumentOptionsContext extends ConfigContext$1 {
  creationContext: NewDocumentCreationContext;
}
/**
 * @hidden
 * @beta
 */
type NewDocumentCreationContext = {
  type: 'global';
  documentId?: undefined;
  schemaType?: undefined;
} | {
  type: 'document';
  documentId: string;
  schemaType: string;
} | {
  type: 'structure';
  documentId?: undefined;
  schemaType: string;
};
/**
 * @hidden
 * @beta
 */
interface DocumentPluginOptions {
  badges?: DocumentBadgeComponent[] | DocumentBadgesResolver;
  actions?: DocumentActionComponent[] | DocumentActionsResolver;
  /**
   * Components for the document.
   * @internal
   */
  components?: DocumentComponents$1;
  /** @internal */
  unstable_fieldActions?: DocumentFieldAction[] | DocumentFieldActionsResolver;
  /** @hidden @beta */
  inspectors?: DocumentInspector[] | DocumentInspectorsResolver;
  /**
   * @hidden
   * @beta
   */
  productionUrl?: AsyncComposableOption<string | undefined, ResolveProductionUrlContext>;
  /**
   * @hidden
   * @beta
   */
  unstable_languageFilter?: DocumentLanguageFilterResolver;
  /**
   * @hidden
   * @beta
   */
  newDocumentOptions?: NewDocumentOptionsResolver;
  /** @deprecated Use `comments` instead */
  unstable_comments?: {
    enabled: boolean | ((context: DocumentCommentsEnabledContext) => boolean);
  };
  /** @internal */
  comments?: {
    enabled: boolean | ((context: DocumentCommentsEnabledContext) => boolean);
  };
  drafts?: {
    /**
     * Whether the workspace provides the draft model for interacting with documents.
     *
     * When switched off, documents may only be edited:
     *
     *  - Inside a release.
     *  - Outside a release if they support live-edit.
     */
    enabled?: boolean;
  };
}
/**
 *
 * @hidden
 * @beta
 */
interface DocumentLanguageFilterContext extends ConfigContext$1 {
  documentId?: string;
  schemaType: string;
}
/**
 *
 * @hidden
 * @beta
 */
type DocumentLanguageFilterComponent = ComponentType<{
  schemaType: ObjectSchemaType;
}>;
/**
 *
 * @hidden
 * @beta
 */
type DocumentLanguageFilterResolver = ComposableOption<DocumentLanguageFilterComponent[], DocumentLanguageFilterContext>;
/**
 * @hidden
 * @beta
 */
type DocumentActionsResolver = ComposableOption<DocumentActionComponent[], DocumentActionsContext>;
/**
 * @hidden
 * @beta
 */
type DocumentBadgesResolver = ComposableOption<DocumentBadgeComponent[], DocumentBadgesContext>;
/**
 * @hidden
 * @public
 */
type ReleaseActionsResolver = ComposableOption<ReleaseActionComponent[], ReleaseActionsContext>;
/** @hidden @beta */
type DocumentInspectorsResolver = ComposableOption<DocumentInspector[], DocumentInspectorContext>;
/**
 * @public
 * Config for the apps that are available in the studio.
 */
type AppsOptions = {
  canvas?: {
    enabled: boolean;
    /**
     * To allow the "Link to canvas" action on localhost, or in studios not listed under Studios in https://www.sanity.io/manage
     * provide a fallback origin as a string.
     *
     * The string must be the exactly equal `name` as shown for the Studio in manage, and the studio must have create-manifest.json available.
     *
     * If the provided fallback Studio does not expose create-manifest.json "Link to canvas" will fail when using the fallback.
     *
     * Example: `wonderful.sanity.studio`
     *
     * Keep in mind that when fallback origin is used, Canvas will use the schema types and dataset in the *deployed* Studio,
     * not from localhost.
     *
     * To see data synced from Canvas in your localhost Studio, you must ensure that the deployed fallback studio uses the same
     * workspace and schemas as your local configuration.
     *
     */
    fallbackStudioOrigin?: string;
  };
};
/** @beta */
interface PluginOptions {
  name: string;
  plugins?: PluginOptions[];
  schema?: SchemaPluginOptions;
  document?: DocumentPluginOptions;
  tools?: Tool[] | ComposableOption<Tool[], ConfigContext$1>;
  form?: SanityFormConfig;
  __internal_tasks?: {
    footerAction: ReactNode;
  };
  studio?: {
    /**
     * Components for the studio.
     * @hidden
     * @beta
     */
    components?: StudioComponentsPluginOptions;
  };
  /** @beta @hidden */
  i18n?: LocalePluginOptions;
  search?: {
    unstable_partialIndexing?: {
      enabled: boolean;
    };
    /**
     * Control the strategy used for searching documents. This should generally only be used if you
     * wish to try experimental search strategies.
     *
     * This option takes precedence over the deprecated `search.enableLegacySearch` option.
     *
     * Can be one of:
     *
     * - `"groqLegacy"` (default): Use client-side tokenization and schema introspection to search
     *   using the GROQ Query API.
     * - `"groq2024"`: (experimental) Perform full text searching using the GROQ Query API and its
     *   new `text::matchQuery` function.
     */
    strategy?: SearchStrategy;
    /**
     * Enables the legacy Query API search strategy.
     *
     * @deprecated Use `search.strategy` instead.
     */
    enableLegacySearch?: boolean;
  };
  /** @internal */
  __internal_serverDocumentActions?: WorkspaceOptions['__internal_serverDocumentActions'];
  /** Configuration for Scheduled drafts */
  scheduledDrafts?: DefaultPluginsWorkspaceOptions['scheduledDrafts'];
  /** @beta */
  [DECISION_PARAMETERS_SCHEMA]?: DecisionParametersConfig;
  /** Configuration for Content Releases */
  releases?: DefaultPluginsWorkspaceOptions['releases'];
  /** Configuration for studio beta features.
   * @internal
   */
  beta?: BetaFeatures;
  /** Configuration for error handling.
   * @beta
   */
  onUncaughtError?: (error: Error, errorInfo: ErrorInfo) => void;
  /**
   * @hidden
   * @internal
   */
  announcements?: {
    enabled: boolean;
  };
  /**
   * Config for the Sanity Media Library asset source integration.
   * @beta
   */
  mediaLibrary?: DefaultPluginsWorkspaceOptions['mediaLibrary'];
  /**
   * Advanced version control provides features such as inline content diffs in Studio to make
   * resolving conflicts across document versions easier.
   *
   * @beta
   */
  advancedVersionControl?: {
    /**
     * Control whether advanced version control functionality is enabled.
     *
     * Advanced version control provides features such as inline content diffs in Studio to make
     * resolving conflicts across document versions easier.
     *
     * @beta
     */
    enabled?: boolean | ComposableOption<boolean, ConfigContext$1>;
  };
}
/** @internal */
type ConfigPropertyReducer<TValue, TContext> = (prev: TValue, config: PluginOptions, context: TContext) => TValue;
/** @internal */
type AsyncConfigPropertyReducer<TValue, TContext> = (prev: TValue, config: PluginOptions, context: TContext) => TValue | Promise<TValue>;
/**
 * @hidden
 * @beta
 */
type Plugin<TOptions = void> = (options: TOptions) => PluginOptions;
/**
 * @hidden
 * @beta
 */
interface WorkspaceOptions extends SourceOptions {
  basePath: string;
  subtitle?: string;
  /**
   * The workspace logo
   *
   * @deprecated Custom logo components are no longer supported.
   * Users are encouraged to provide custom components for individual workspace icons instead.
   */
  logo?: ComponentType;
  icon?: ComponentType;
  /**
   * @hidden
   * @beta
   */
  theme?: StudioTheme;
  /**
   * @hidden
   * @beta
   */
  unstable_sources?: SourceOptions[];
  /**
   * @deprecated Use `tasks` instead
   */
  unstable_tasks?: DefaultPluginsWorkspaceOptions['tasks'];
  /**
   * @internal
   */
  tasks?: DefaultPluginsWorkspaceOptions['tasks'];
  /**
   * @internal
   */
  releases?: DefaultPluginsWorkspaceOptions['releases'];
  /**
   * @internal
   */
  mediaLibrary?: DefaultPluginsWorkspaceOptions['mediaLibrary'];
  apps?: AppsOptions;
  /**
   * @hidden
   * @internal
   */
  __internal_serverDocumentActions?: {
    /**
     * @deprecated The Mutations API integration will be removed in a future release.
     */
    enabled?: boolean;
  };
  scheduledDrafts?: DefaultPluginsWorkspaceOptions['scheduledDrafts'];
  /**
   * @beta
   */
  [DECISION_PARAMETERS_SCHEMA]?: DecisionParametersConfig;
  scheduledPublishing?: DefaultPluginsWorkspaceOptions['scheduledPublishing'];
}
/**
 * @hidden
 * @beta
 */
interface SourceOptions extends PluginOptions {
  title?: string;
  /**
   * Project ID for this source
   */
  projectId: string;
  /**
   * Dataset name for this source
   */
  dataset: string;
  /**
   * API hostname used for requests. Generally used for custom CNAMEs, allowing businesses to use
   * their own domain for API requests. Must include protocol:
   * eg `https://sanityapi.mycompany.com`
   *
   * Note that (currently) the project ID will be prepended to the passed URL, so the above
   * example would end up as: `https://<projectId>.sanityapi.mycompany.com`
   */
  apiHost?: string;
  /**
   * Authentication options for this source.
   */
  auth?: AuthConfig | AuthStore;
  /**
   * @hidden
   * @beta
   */
  unstable_clientFactory?: (options: ClientConfig) => SanityClient;
}
/**
 * @hidden
 * @beta
 */
interface ResolveProductionUrlContext extends ConfigContext$1 {
  document: SanityDocumentLike;
}
/**
 * @hidden
 * @beta
 */
type DocumentActionsVersionType = 'published' | 'draft' | 'revision' | 'version' | 'scheduled-draft';
/**
 * @hidden
 * @beta
 */
interface DocumentActionsContext extends ConfigContext$1 {
  documentId?: string;
  schemaType: string;
  /** releaseId of the open document, it's undefined if it's published or the draft */
  releaseId: string | undefined;
  /** the type of the currently active document. */
  versionType: DocumentActionsVersionType;
}
/**
 * @hidden
 * @beta
 */
interface DocumentBadgesContext extends ConfigContext$1 {
  documentId?: string;
  schemaType: string;
}
/** @hidden @beta */
interface DocumentInspectorContext extends ConfigContext$1 {
  documentId?: string;
  documentType: string;
}
/** @hidden @beta */
interface DocumentCommentsEnabledContext {
  documentId?: string;
  documentType: string;
}
/**
 * @hidden
 * @beta
 */
type PartialContext<TContext extends ConfigContext$1> = Pick<TContext, Exclude<keyof TContext, keyof ConfigContext$1>>;
/** @internal*/
interface DocumentLayoutProps {
  /**
   * The ID of the document. This is a read-only property and changing it will have no effect.
   */
  documentId: string;
  /**
   * The type of the document. This is a read-only property and changing it will have no effect.
   */
  documentType: string;
  renderDefault: (props: DocumentLayoutProps) => React.JSX.Element;
}
interface DocumentComponents$1 {
  /** @internal */
  unstable_layout?: ComponentType<DocumentLayoutProps>;
}
/** @public */
interface SourceClientOptions {
  /**
   * API version to use. See {@link https://www.sanity.io/docs/api-versioning | api-versioning}
   */
  apiVersion: string;
}
/**
 * Represents a source.
 * @public
 */
interface Source {
  /** The type of the source. */
  type: 'source';
  /** The name of the source. */
  name: string;
  /** The title of the source. */
  title: string;
  /** The ID of the project. */
  projectId: string;
  /** The name of the dataset. */
  dataset: string;
  /** The schema of the source. */
  schema: Schema;
  /** The templates of the source. */
  templates: Template[];
  /** The tools of the source. */
  tools: Tool[];
  /** The current user of the source. */
  currentUser: CurrentUser | null;
  /** Whether the user is authenticated. */
  authenticated: boolean;
  /** @internal */
  auth: AuthStore;
  /**
   * Returns a client instance.
   * @param clientOptions - Options to pass to the client. See {@link SourceClientOptions}
   */
  getClient: (clientOptions: SourceClientOptions) => SanityClient;
  /**
   * Document-related functionality.
   * @hidden
   * @beta
   */
  document: {
    /**
     * Returns an array of actions for the document.
     * @hidden
     * @beta
     */
    actions: (props: PartialContext<DocumentActionsContext>) => DocumentActionComponent[];
    /**
     * Returns an array of badges for the document.
     * @hidden
     * @beta
     */
    badges: (props: PartialContext<DocumentBadgesContext>) => DocumentBadgeComponent[];
    /**
     * Components for the document.
     * @internal
     */
    components?: DocumentComponents$1;
    drafts: {
      /**
       * Whether the workspace provides the draft model for interacting with documents.
       *
       * When switched off, documents may only be edited:
       *
       *  - Inside a release.
       *  - Outside a release if they support live-edit.
       */
      enabled: boolean;
    }; /** @internal */
    unstable_fieldActions: (props: PartialContext<DocumentFieldActionsResolverContext>) => DocumentFieldAction[];
    /**
     * Resolves the production URL for the document.
     * @hidden
     * @beta
     */
    resolveProductionUrl: (context: PartialContext<ResolveProductionUrlContext>) => Promise<string | undefined>;
    /**
     * Resolves the new document options.
     * @hidden
     * @beta
     */
    resolveNewDocumentOptions: (context: NewDocumentCreationContext) => InitialValueTemplateItem[]; /** @alpha */
    unstable_languageFilter: (props: PartialContext<DocumentLanguageFilterContext>) => DocumentLanguageFilterComponent[];
    /**
     * @hidden
     * @beta
     */
    inspectors: (props: PartialContext<DocumentInspectorContext>) => DocumentInspector[]; /** @deprecated  Use `comments` instead */
    unstable_comments: {
      enabled: (props: DocumentCommentsEnabledContext) => boolean;
    }; /** @internal */
    comments: {
      enabled: (props: DocumentCommentsEnabledContext) => boolean;
    };
  };
  /** @internal */
  __internal_tasks?: {
    footerAction: ReactNode;
  };
  /**
   * Form-related functionality.
   * @hidden
   * @beta
   */
  form: {
    /**
     * File-related functionality.
     * @hidden
     * @beta
     */
    file: {
      /** The asset sources. */assetSources: AssetSource[]; /** Whether direct uploads are enabled. */
      directUploads: boolean;
    };
    /**
     * Image-related functionality.
     * @hidden
     * @beta
     */
    image: {
      /** The asset sources. */assetSources: AssetSource[]; /** Whether direct uploads are enabled. */
      directUploads: boolean;
    };
    /**
     * Components for the form.
     * @hidden
     * @beta
     */
    components?: FormComponents;
    /**
     * these have not been migrated over and are not merged by the form builder
     *
     * @hidden
     * @beta
     */
    unstable?: {
      CustomMarkers?: FormBuilderCustomMarkersComponent;
      Markers?: FormBuilderMarkersComponent;
    };
  };
  /**
   * @hidden
   * @beta
   */
  studio?: {
    /**
     * Components for the studio.
     * @hidden
     * @beta
     */
    components?: StudioComponents;
  };
  /** @alpha */
  search: {
    filters: SearchFilterDefinition[];
    operators: SearchOperatorDefinition[];
    unstable_partialIndexing?: {
      enabled: boolean;
    };
    enableLegacySearch?: boolean;
    strategy?: SearchStrategy;
  };
  /** @internal */
  i18n: LocaleSource;
  /** @internal */
  __internal: {
    /** @internal */bifur: BifurClient; /** @internal */
    staticInitialValueTemplateItems: InitialValueTemplateItem[]; /** @internal */
    options: SourceOptions;
    /**
     * _VERY_ internal, likely to change at any point.
     * @internal
     */
    i18next: i18n$1;
    /**
     * The schema descriptor ID.
     *
     * This can be `undefined` in the case where uploading the schema has been disabled.
     *
     * @internal
     */
    schemaDescriptorId: Promise<string | undefined>;
  };
  /** @beta */
  tasks?: WorkspaceOptions['tasks'];
  scheduledDrafts?: {
    enabled: boolean;
  };
  /** @beta */
  releases?: {
    enabled?: boolean;
    /**
     * Limit the number of releases that can be created by this workspace.
     */
    limit?: number;
    /**
     * Returns an array of actions for the release.
     */
    actions?: (props: PartialContext<ReleaseActionsContext>) => ReleaseActionComponent[];
  };
  /** @internal */
  __internal_serverDocumentActions?: WorkspaceOptions['__internal_serverDocumentActions'];
  /** Configuration for studio features.
   * @internal
   */
  beta?: BetaFeatures;
  /** Configuration for error handling.
   * @beta
   */
  onUncaughtError?: (error: Error, errorInfo: ErrorInfo) => void;
  /**
   * @hidden
   * @internal
   */
  announcements?: {
    enabled: boolean;
  };
  /**
   * Config for the Sanity Media Library asset source integration.
   * @beta
   */
  mediaLibrary?: WorkspaceOptions['mediaLibrary'];
  /**
   * Advanced version control provides features such as inline content diffs in Studio to make
   * resolving conflicts across document versions easier.
   *
   * @beta
   */
  advancedVersionControl: {
    /**
     * Control whether advanced version control functionality is enabled.
     *
     * Advanced version control provides features such as inline content diffs in Studio to make
     * resolving conflicts across document versions easier.
     *
     * @beta
     */
    enabled: boolean;
  };
}
/** @internal */
interface WorkspaceSummary extends DefaultPluginsWorkspaceOptions {
  type: 'workspace-summary';
  name: string;
  title: string;
  /**
   * User supplied component if provided, otherwise falls back to
   * an automatically generated default icon.
   */
  icon: ReactNode;
  /** Returns true if a custom icon has been provided in studio config */
  customIcon: boolean;
  subtitle?: string;
  basePath: string;
  auth: AuthStore;
  projectId: string;
  dataset: string;
  /**
   * API hostname used for requests. Used to determine if the workspace
   * points to staging or production environment.
   * @internal
   */
  apiHost?: string;
  theme: StudioTheme;
  schema: Schema;
  i18n: LocaleSource;
  /**
   * @internal
   * @deprecated not actually deprecated but don't use or you'll be fired
   */
  __internal: {
    sources: Array<{
      name: string;
      projectId: string;
      dataset: string;
      title: string;
      auth: AuthStore;
      schema: Schema;
      i18n: LocaleSource;
      source: Observable<Source>;
    }>;
  };
}
/**
 * Config for the Scheduled Publishing plugin.
 * @public
 */
interface ScheduledPublishingPluginOptions {
  /**
   * Whether scheduled publishing is enabled for this workspace.
   */
  enabled: boolean;
  /**
   * Date format to use for input fields. This must be a valid `date-fns` {@link https://date-fns.org/docs/format | formatted string}.
   * @defaultValue 'dd/MM/yyyy HH:mm' make sure to specify minutes and hours if you are specifying a custom format
   */
  inputDateTimeFormat?: string;
  /**
   * @hidden
   * Whether scheduled publishing is enabled by the workspace.
   * Sanity is enabling it by default in the config, {@link "../scheduledPublishing/constants.ts"}
   */
  __internal__workspaceEnabled?: boolean;
  /**
   * Whether to show the use releases warning banner in the tool.
   * @deprecated The banner this controls is no longer being used
   */
  showReleasesBanner?: boolean;
}
/**
 * Definition for Workspace
 *
 * @public
 */
interface Workspace extends Omit<Source, 'type'> {
  type: 'workspace';
  /**
   * URL base path to use, for instance `/myWorkspace`
   * Note that this will be prepended with any _studio_ base path, eg `/studio/myWorkspace`,
   * and is a client-side routing feature. If you're looking to serve your studio from a subpath,
   * you're probably looking for the `basePath` property in `sanity.cli.ts`/`sanity.cli.js`.
   */
  basePath: string;
  /** Subtitle to show under the name of the workspace */
  subtitle?: string;
  /** React component to use as icon for this workspace */
  icon: ReactNode;
  /**
   *
   * @hidden
   * @beta
   */
  unstable_sources: Source[];
  scheduledPublishing: ScheduledPublishingPluginOptions;
  apps?: AppsOptions;
}
/**
 * If a single workspace is used, not specifying a name or basePath is acceptable
 *
 *
 * @hidden
 * @beta
 */
type SingleWorkspace = Omit<WorkspaceOptions, 'name' | 'basePath'> & {
  name?: string;
  basePath?: string;
};
/**
 * @hidden
 * @beta
 */
type Config = SingleWorkspace | WorkspaceOptions[];
/**
 * @hidden
 * @beta
 */
interface MissingConfigFile {
  missingConfigFile: true;
}
/** @internal */
interface PreparedConfig {
  type: 'prepared-config';
  workspaces: WorkspaceSummary[];
}
/** @beta */
type DefaultPluginsWorkspaceOptions = {
  tasks: {
    enabled: boolean;
  };
  scheduledDrafts: {
    enabled: boolean;
  };
  scheduledPublishing: ScheduledPublishingPluginOptions;
  releases: {
    enabled?: boolean;
    /**
     * Limit the number of releases that can be created by this workspace.
     */
    limit?: number;
    /**
     * Actions for releases.
     */
    actions?: ReleaseActionComponent[] | ReleaseActionsResolver;
  };
  mediaLibrary?: MediaLibraryConfig;
};
/**
 * Config for the Sanity Media Library asset source integration.
 * @beta
 */
interface MediaLibraryConfig {
  /**
   * Whether the Media Library is enabled.
   */
  enabled?: boolean;
  /**
   * The ID of the Media Library that is connected to the Studio.
   * If not provided, the Media Library will be automatically detected.
   */
  libraryId?: string;
  /**
   * Internal configuration for the Media Library.
   * @internal
   * @hidden
   */
  __internal?: {
    /**
     * Override the Media Library frontend host URL.
     * Used for internal testing against local or custom environments.
     * @example 'http://localhost:3001'
     * @internal
     * @hidden
     */
    frontendHost?: string;
  };
}
/**
 * @internal
 * Configuration for studio beta features.
 * */
interface BetaFeatures {
  form?: {
    /** @deprecated `enhancedObjectDialog` has been removed. The enhanced object dialog is now always enabled and is considered the default studio experience. */enhancedObjectDialog?: never;
  };
  /**
   * @deprecated - The Start in Create flow has been removed and will be updated in an upcoming studio release.
   */
  create?: {
    /**
     * When true, a "Start in Sanity Create" action will be shown for all new documents, in place of regular document actions,
     * when the following are true:
     * - the origin of the current url is listed under Studios in sanity.to/manage (OR fallbackStudioOrigin is provided)
     * - [origin]/static/create-manifest.json is available over HTTP GET
     *
     * The manifest file is automatically created and deployed when deploying studios with `sanity deploy`
     *
     * @see #fallbackStudioOrigin
     */
    startInCreateEnabled?: boolean;
    /**
     * To show the "Start in Create" button on localhost, or in studios not listed under Studios in https://www.sanity.io/manage
     * provide a fallback origin as a string.
     *
     * The string must be the exactly equal `name` as shown for the Studio in manage, and the studio must have create-manifest.json available.
     *
     * If the provided fallback Studio does not expose create-manifest.json "Start in Sanity Create" will fail when using the fallback.
     *
     * Example: `wonderful.sanity.studio`
     *
     * Keep in mind that when fallback origin is used, Sanity Create will used the schema types and dataset in the *deployed* Studio,
     * not from localhost.
     *
     * To see data synced from Sanity Create in your localhost Studio, you must ensure that the deployed fallback studio uses the same
     * workspace and schemas as your local configuration.
     *
     * @see #startInCreateEnabled
     */
    fallbackStudioOrigin?: string;
  };
  /**
   * Config for the history events API .
   *
   * If enabled, it will use the new events API to fetch document history.
   *
   * If it is not enabled, it will continue using the legacy Timeline.
   */
  eventsAPI?: {
    documents?: boolean;
    releases?: boolean;
  };
}
/**
 * @internal
 * This hook returns a component based on the Components API middleware chain.
 *
 * - The `pick` function is used to select a component from the provided plugin options in the configuration.
 * - The `defaultComponent` is the default component that gets rendered with `renderDefault`.
 *   The `renderDefault` function is added to the props of the middleware components so that they can render the default
 *   component and continue the middleware chain.
 *
 * @example
 * Example usage of:
 *
 * ```ts
 *  const StudioLayout = useMiddlewareComponents({
 *   pick: (plugin) => plugin.studio?.components?.layout,
 *   defaultComponent: StudioLayout,
 *  })
 *
 * return <StudioLayout />
 *```
 */
declare function useMiddlewareComponents<T extends {}>(props: {
  pick: (plugin: PluginOptions) => ComponentType<T>;
  defaultComponent: ComponentType<T>;
}): ComponentType<T>;
/** @internal */
interface ConfigPropertyErrorOptions {
  propertyName: string;
  path: string[];
  cause: unknown;
}
/** @internal */
declare class ConfigPropertyError extends Error {
  propertyName: string;
  path: string[];
  cause: unknown;
  constructor({
    propertyName,
    path,
    cause
  }: ConfigPropertyErrorOptions);
}
/** @internal */
interface ConfigResolutionErrorOptions {
  name: string;
  type: string;
  causes: Array<ConfigResolutionError | Error | unknown>;
}
/** @internal */
declare class ConfigResolutionError extends Error {
  name: string;
  type: string;
  causes: unknown[];
  constructor({
    causes,
    name,
    type
  }: ConfigResolutionErrorOptions);
}
/**
 * Creates an icon element based on the input title
 * @internal
 */
declare function createDefaultIcon(title: string, subtitle: string): react.JSX.Element;
/**
 * @hidden
 * @beta */
declare function defineConfig<const T extends Config>(config: T): T;
/**
 * @deprecated Use `defineConfig` instead
 *
 * @hidden
 * @beta
 */
declare function createConfig<const T extends Config>(config: T): T;
/**
 * @hidden
 * @beta */
type PluginFactory<TOptions> = (options: TOptions) => PluginOptions;
/**
 * @hidden
 * @beta */
declare function definePlugin<TOptions = void>(arg: PluginFactory<TOptions> | PluginOptions): Plugin<TOptions>;
/**
 * @deprecated Use `definePlugin` instead
 *
 * @hidden
 * @beta
 */
declare function createPlugin<TOptions = void>(arg: PluginFactory<TOptions> | PluginOptions): Plugin<TOptions>;
/**
 * @internal
 *
 * This function flattens the config tree into a list of configs in the order they should be applied.
 */
declare const flattenConfig: ({
  plugins,
  ...currentConfig
}: PluginOptions, path: string[]) => {
  config: PluginOptions;
  path: string[];
}[];
/**
 * Takes in a config (created from the `defineConfig` function) and returns
 * an array of `WorkspaceSummary`. Note: this only partially resolves a config.
 *
 * For usage inside the Studio, it's preferred to pull the pre-resolved
 * workspaces and sources via `useWorkspace` or `useSource`. For usage outside
 * the Studio or for testing, use `resolveConfig`.
 *
 * @internal
 */
declare function prepareConfig(config: Config | MissingConfigFile, options?: {
  basePath?: string;
}): PreparedConfig;
/**
 * Fully resolves a configuration including subscribing to all sources and
 * workspaces from a config. Returns an `Observable` that waits till all sources
 * emit once before emitting an array of fully resolved sources and workspaces.
 *
 * @internal
 */
declare function resolveConfig(config: Config): Observable<Workspace[]>;
/** @internal */
type CreateWorkspaceFromConfigOptions = SingleWorkspace | (SingleWorkspace & {
  currentUser: CurrentUser;
  getClient: (options: {
    apiVersion: string;
  }) => SanityClient;
  schema?: SchemaPluginOptions;
});
/**
 * PRIMARILY FOR TESTING PURPOSES.
 *
 * This will create a fully resolved workspace from a config and optionally
 * allows a `client` and `currentUser` override. This exists primarily for
 * testing purposes. If you need to use a workspace, we recommend using the
 * `useWorkspace` hook to grab the fully resolved workspace from the
 * `StudioProvider`
 *
 * @internal
 */
declare function createWorkspaceFromConfig(options: CreateWorkspaceFromConfigOptions): Promise<Workspace>;
/**
 * PRIMARILY FOR TESTING PURPOSES.
 *
 * This will create a fully resolved source from a config and optionally
 * allows a `client` and `currentUser` override. This exists primarily for
 * testing purposes. If you need to use a source, we recommend using the
 * `useSource` hook to grab the fully resolved source from the `StudioProvider`
 *
 * @internal
 */
declare function createSourceFromConfig(options: CreateWorkspaceFromConfigOptions): Promise<Source>;
declare const schemaTypesReducer: ConfigPropertyReducer<SchemaTypeDefinition[], Omit<ConfigContext$1, 'schema' | 'currentUser' | 'client' | 'getClient' | 'i18n'>>;
type ConfigContext<T> = T extends ConfigPropertyReducer<any, infer TContext> ? TContext : never;
type SchemaTypeContext = ConfigContext<typeof schemaTypesReducer>;
interface ResolveSchemaTypesOptions {
  config: PluginOptions;
  context: SchemaTypeContext;
}
/**
 * @internal
 * @hidden
 */
declare function resolveSchemaTypes({
  config,
  context
}: ResolveSchemaTypesOptions): SchemaTypeDefinition[];
/** @internal */
declare class SchemaError extends Error {
  schema: Schema;
  constructor(schema: Schema);
}
/**
 * Reduce a {@link Source} down to a {@link ConfigContext}, memoizing using `useMemo`
 *
 * @param source - Source to convert
 * @returns A config context containing only the defined properties of that interface
 * @internal
 */
declare function useConfigContextFromSource(source: Source): ConfigContext$1;
/**
 * Reduce a {@link Source} down to a {@link ConfigContext}, without memoization - use for non-react contexts
 *
 * @param source - Source to convert
 * @returns A config context containing only the defined properties of that interface
 * @internal
 */
declare function getConfigContextFromSource(source: Source): ConfigContext$1;
/** @internal */
interface ActiveWorkspaceMatcherContextValue {
  activeWorkspace: WorkspaceSummary;
  setActiveWorkspace: (workspaceName: string) => void;
}
export { MissingConfigFile as $, isDraft as $C, useOnlyHasVersions as $S, ToolLinkProps as $_, snapshotPair as $a, UnitFormatter as $b, FieldsetState as $c, supportsTouch as $d, DocumentBadgeProps as $f, useWorkspace as $g, UserId as $h, TemplatePermissionsResult as $i, useZIndex as $l, FieldOperationsAPI as $m, UniversalArrayInput as $n, FormBuilderInputComponentMap as $o, MetaInfoProps as $p, FieldPresenceWithOverlay as $r, PortableTextPluginsProps as $s, MutationPatch as $t, Hotkeys as $u, useColorSchemeInternalValue as $v, EditStateFor as $x, CommentUpdatePayload as $y, ComposableOption as A, VersionChip as AC, CommentDisabledIcon as AS, CopyPasteProvider as A_, createDocumentStore as Aa, ImplicitLocaleResourceBundle as Ab, defaultRenderInput as Ac, DEFAULT_ANNOTATIONS as Ad, defaultTheme as Af, useCommentsSelectedPath as Ag, UnpublishDocumentEvent as Ah, useProjectStore as Ai, MixedArrayError as Al, ChangeBreadcrumb as Am, StringInput as An, prepareForPreview as Ao, getValueAtPath as Ap, FormInputRelativePathArg as Ar, PrimitiveInputElementProps as As, DocumentInspectorUseMenuItemProps as At, MediaPreviewProps as Au, SearchOperatorInput as Av, ConnectionStatusStoreOptions as Aw, DocumentField as Ax, CommentsIntentProvider as Ay, DocumentBadgesContext as B, PublishedId as BC, useTrackerStore as BS, FormDiffMatchPatch as B_, InitialValueSuccessMsg as Ba, LocaleWeekInfo as Bb, FormCallbacksValue as Bc, measureFirstMatch as Bd, TasksEnabledContextValue as Bf, CommentInputContextValue as Bg, isUnpublishDocumentEvent as Bh, PresenceStore as Bi, PatchMsgSubscriber as Bl, ArrayDiff$1 as Bm, ObjectInput as Bn, PreviewLoader as Bo, useDocumentChange as Bp, FormFieldSetProps as Br, RenderPreviewCallback as Bs, DocumentFieldActionNode as Bt, PreviewComponent as Bu, SearchOptions as Bv, AuthStoreOptions as Bw, GlobalCopyPasteElementHandler as Bx, CommentListBreadcrumbs as By, ActionComponent as C, PreviewableType as CC, UseDateTimeFormatOptions as CS, uploadSchema as C_, isNewDocument as Ca, useI18nText as Cb, FormProviderProps as Cc, useDocumentVersionInfo as Cd, formatRelativeLocale as Cf, AutoCollapseMenu as Cg, DocumentVersionEventType as Ch, useConnectionStatusStore as Ci, StringFormNode as Cl, TIMELINE_ITEM_I18N_KEY_MAPPING as Cm, UrlInputProps as Cn, WithVersion as Co, ReleasesNav as Cp, FormValueProvider as Cr, InputProps as Cs, ReleaseActionProps as Ct, TemplatePreviewProps as Cu, I18nSearchOperatorDescriptionKey as Cv, CorsOriginError as Cw, SyncState as Cx, WorkspaceLike as Cy, AsyncConfigPropertyReducer as D, ReleaseTitle as DC, useConnectionState as DS, ManifestWorkspaceInput as D_, DocumentStore as Da, removeUndefinedLocaleResources as Db, defaultRenderBlock as Dc, isReleaseDocument as Dd, ReactHook as Df, buildRangeDecorationSelectionsFromComments as Dg, HistoryClearedEvent as Dh, useHistoryStore as Di, IncompatibleTypeError as Dl, ChangeResolverProps as Dm, TelephoneInputProps as Dn, createBufferedDocument as Do, findIndex as Dp, FormRow as Dr, OnPathFocusPayload as Ds, DocumentInspectorComponent as Dt, BlockImagePreview as Du, SearchOperatorBase as Dv, ConnectingStatus as Dw, useReviewChanges as Dx, CommentsSelectedPath as Dy, AsyncComposableOption as E, getVersionInlineBadge as EC, ConnectionState as ES, generateStudioManifest as E_, useDocumentType as Ea, defineLocalesResources as Eb, defaultRenderAnnotation as Ec, VersionInfoDocumentStub as Ed, LoadingTuple as Ef, buildTextSelectionFromFragment as Eg, EventsStoreRevision as Eh, useGrantsStore as Ei, FieldError as El, ChangeResolver as Em, TelephoneInput as En, BufferedDocumentWrapper as Eo, FIXME as Ep, FormCell as Er, OnPasteFn as Es, DocumentInspector as Et, BlockPreview as Eu, OperatorInputComponentProps as Ev, ConnectedStatus as Ew, useSchema as Ex, RouterHistory as Ey, DecisionParametersConfig as F, SelectedPerspective as FC, ChangeIndicatorTrackerContextValue as FS, DocumentMeta as F_, getInitialValueStream as Fa, LocalePluginOptions as Fb, ReferenceInputOptions as Fc, getDocumentIdForCanvasLink as Fd, TasksUpsellContextValue as Ff, CommentsContextValue as Fg, isDeleteDocumentGroupEvent as Fh, createProjectStore as Fi, ALL_FIELDS_GROUP as Fl, getAnnotationColor as Fm, CreateButton as Fn, useValuePreview as Fo, normalizePathSegment as Fp, FormFieldValidationStatus as Fr, RenderArrayOfPrimitivesItemCallback as Fs, DocumentFieldAction as Ft, CompactPreview as Fu, defineSearchOperator as Fv, isAuthStore as Fw, useNumberFormat as Fx, CommentContext as Fy, DocumentLanguageFilterComponent as G, createPublishedFrom as GC, ChangeConnectorRoot as GS, FormPatchBase as G_, emitOperation as Ga, ValidationLocaleResourceKeys as Gb, SetActiveGroupOperation as Gc, LoadableState as Gd, SingleDocReleaseProvider as Gf, CommentsUpsellContextValue as Gg, UserColorManagerOptions as Gh, PresenceLocation as Gi, diffMatchPatch as Gl, Chunk as Gm, EmailInputProps as Gn, isBooleanInputProps as Go, isUnchangedDiff as Gp, PresenceScope as Gr, ObjectItemProps as Gs, DocumentFieldActionsResolverContext as Gt, PreviewCardContextValue as Gu, SearchPopoverProps as Gv, LoginComponentProps as Gw, useFormattedDuration as Gx, CommentReactionItem as Gy, DocumentCommentsEnabledContext as H, VERSION_FOLDER as HC, IsEqualFunction as HS, FormInsertPatch as H_, remoteSnapshots as Ha, LocalesOption as Hb, ExpandFieldSetOperation as Hc, useThrottledCallback as Hd, useScheduledDraftsEnabled as Hf, CommentInputHandle as Hg, isUpdateLiveDocumentEvent as Hh, createPresenceStore as Hi, createPatchChannel as Hl, BooleanDiff$1 as Hm, AssetAccessPolicy as Hn, isArrayOfBlocksInputProps as Ho, isFieldChange as Hp, FormFieldHeaderTextProps as Hr, BaseItemProps as Hs, DocumentFieldActionStatus as Ht, PreviewMediaDimensions as Hu, SearchTerms as Hv, createAuthStore as Hw, FormDocumentValue as Hx, CommentOperations as Hy, DefaultPluginsWorkspaceOptions as I, TargetPerspective as IC, TrackedArea as IS, PasteOptions as I_, InitialValueErrorMsg as Ia, LocaleResourceBundle as Ib, ReferenceInputOptionsProvider as Ic, useNavigateToCanvasDoc as Id, TasksContextValue as If, hasCommentMessageValue as Ig, isDeleteDocumentVersionEvent as Ih, ProjectData as Ii, resolveConditionalProperty as Il, getDiffAtPath as Im, CreateReferenceOption as In, unstable_useObserveDocument as Io, pathToString as Ip, FormFieldValidationStatusProps as Ir, RenderBlockCallback as Is, DocumentFieldActionDivider as It, CompactPreviewProps as Iu, createSearch as Iv, isCookielessCompatibleLoginMethod as Iw, UseManageFavoriteProps as Ix, CommentCreatePayload as Iy, DocumentLayoutProps as J, getIdPair as JC, ChangeIndicator as JS, FormSetIfMissingPatch as J_, Operation as Ja, UserListWithPermissionsHookValue as Jb, UseFormStateOptions as Jc, asLoadable as Jd, createSchema as Jf, useWorkspaceLoader as Jg, useUserColorManager as Jh, UserSessionPair as Ji, prefixPath as Jl, DiffComponent as Jm, DateTimeInputProps as Jn, isObjectItemProps as Jo, ValueError as Jp, PresenceOverlayProps as Jr, BlockDecoratorProps as Js, CookielessCompatibleLoginMethod as Jt, PopoverDialog as Ju, ColorSchemeCustomProvider as Jv, KeyValueStoreValue as Jw, useEditState as Jx, CommentStatus as Jy, DocumentLanguageFilterContext as K, documentIdEquals as KC, ChangeConnectorRootProps as KS, FormPatchJSONValue as K_, operationEvents as Ka, StudioLocaleResourceKeys as Kb, getExpandOperations as Kc, LoadedState as Kd, useSingleDocRelease as Kf, UpsellData as Kg, createUserColorManager as Kh, Session as Ki, inc as Kl, ChunkType as Km, getCalendarLabels as Kn, isNumberInputProps as Ko, noop as Kp, PresenceScopeProps as Kr, PrimitiveItemProps as Ks, AuthConfig as Kt, ReferenceInputPreviewCard as Ku, SearchHeader as Kv, createKeyValueStore as Kw, useFilteredReleases as Kx, CommentReactionOption as Ky, DocumentActionsContext as L, CollatedHit as LC, TrackedChange as LS, SanityClipboardItem as L_, InitialValueLoadingMsg as La, LocaleResourceKey as Lb, TemplateOption as Lc, useCanvasCompanionDoc as Ld, TasksNavigationContextValue as Lf, isTextSelectionComment as Lg, isEditDocumentVersionEvent as Lh, ProjectDatasetData as Li, MutationPatchMsg as Ll, visitDiff as Lm, PortableTextInput as Ln, useUnstableObserveDocument as Lo, pathsAreEqual as Lp, FieldStatusProps as Lr, RenderFieldCallback as Ls, DocumentFieldActionGroup as Lt, GeneralDocumentListLayoutKey as Lu, isPerspectiveRaw as Lv, getProviderTitle as Lw, useManageFavorite as Lx, CommentDocument as Ly, ConfigContext$1 as M, PerspectiveStack as MC, ChangeIndicatorsTracker as MS, BaseOptions as M_, ListenQueryParams as Ma, LocaleConfigContext as Mb, defaultRenderPreview as Mc, ReleaseDocument$1 as Md, LegacyThemeProps as Mf, useCommentsEnabled as Mg, UpdateLiveDocumentEvent as Mh, useUserStore as Mi, UndeclaredMembersError as Ml, useDiffAnnotationColor as Mm, SlugInputProps as Mn, getPreviewStateObservable as Mo, normalizeIndexSegment as Mp, FormFieldValidationError as Mr, StringInputProps as Ms, initialDocumentFieldActions as Mt, DetailPreviewProps as Mu, SearchValueFormatterContext as Mv, RetryingStatus as Mw, useReconnectingToast as Mx, CommentsEnabledProvider as My, ConfigPropertyReducer as N, ReleaseId as NC, useChangeIndicatorsReportedValues as NS, CopyOptions as N_, listenQuery as Na, LocaleDefinition as Nb, EditReferenceLinkComponentProps as Nc, isDocumentLimitError as Nd, LegacyThemeTints as Nf, CommentsEnabledContextValue as Ng, isCreateDocumentVersionEvent as Nh, useProjectDatasets as Ni, FormFieldGroup as Nl, DiffVisitor as Nm, SelectInput as Nn, getPreviewPaths as No, normalizeIndexTupleSegment as Np, FormFieldValidationInfo as Nr, RenderAnnotationCallback as Ns, documentFieldActionsReducer as Nt, DefaultPreview as Nu, ValuelessSearchOperatorBuilder as Nv, createConnectionStatusStore as Nw, useProjectId as Nx, CommentsProvider as Ny, BaseActionDescription as O, ReleaseAvatar as OC, useConditionalToast as OS, StudioManifest as O_, DocumentStoreOptions as Oa, LocaleProvider as Ob, defaultRenderField as Oc, MetadataWrapper as Od, createHookFromObservableFactory as Of, buildCommentRangeDecorations as Og, PublishDocumentVersionEvent as Oh, useKeyValueStore as Oi, InvalidItemTypeError as Ol, ChangeList as Om, TagsArrayInput as On, CommitRequest as Oo, getItemKey as Op, FormInput as Or, PasteData$1 as Os, DocumentInspectorMenuItem as Ot, BlockImagePreviewProps as Ou, SearchOperatorBuilder as Ov, ConnectionStatus as Ow, RelativeTimeOptions as Ox, CommentsSelectedPathContextValue as Oy, DECISION_PARAMETERS_SCHEMA as P, ReleasesNavMenuItemPropsGetter as PC, useChangeIndicatorsReporter as PS, CopyPasteContextType as P_, InitialValueOptions as Pa, LocaleNestedResource as Pb, EditReferenceOptions as Pc, useDocumentLimitsUpsellContext as Pd, useDocumentPreviewValues as Pf, useComments as Pg, isCreateLiveDocumentEvent as Ph, useProject as Pi, ProvenanceDiffAnnotation as Pl, getAnnotationAtPath as Pm, ReferenceAutocomplete as Pn, unstable_useValuePreview as Po, normalizeKeySegment as Pp, FormFieldValidationWarning as Pr, RenderArrayOfObjectsItemCallback as Ps, defineDocumentFieldAction as Pt, DefaultPreviewProps as Pu, ValuelessSearchOperatorParams as Pv, onRetry as Pw, UseNumberFormatOptions as Px, CommentBaseCreatePayload as Py, MediaLibraryConfig as Q, idMatchesPerspective as QC, useVersionOperations as QS, ToolLink as Q_, DocumentVersionSnapshots as Qa, FormattableMeasurementUnit as Qb, FieldsetMembers as Qc, uncaughtErrorHandler as Qd, DocumentBadgeDescription as Qf, WorkspaceProviderProps as Qg, UserColorManager as Qh, TemplatePermissionsOptions as Qi, ZIndexProvider as Ql, FieldChangeNode as Qm, BooleanInput as Qn, FormBuilderFilterFieldFn as Qo, MetaInfo as Qp, FieldPresenceProps as Qr, MarkdownConfig as Qs, encodePath as Qt, InsufficientPermissionsMessageProps as Qu, useColorScheme as Qv, createSanityMediaLibraryImageSource as Qw, useDocumentIdStack as Qx, CommentUpdateOperationOptions as Qy, DocumentActionsResolver as R, DRAFTS_FOLDER as RC, TrackerContextGetSnapshot as RS, PatchEvent as R_, InitialValueMsg as Ra, LocaleResourceRecord as Rb, useReferenceInputOptions as Rc, SANITY_VERSION as Rd, MentionUserContextValue as Rf, COMMENTS_INSPECTOR_NAME as Rg, isPublishDocumentVersionEvent as Rh, ProjectGrants as Ri, PatchChannel as Rl, Annotation as Rm, PortableTextMemberItem as Rn, SanityDefaultPreview as Ro, stringToPath as Rp, FormFieldStatus as Rr, RenderInputCallback as Rs, DocumentFieldActionHook as Rt, GeneralPreviewLayoutKey as Ru, getSearchableTypes as Rv, MockAuthStoreOptions as Rw, UseListFormatOptions as Rx, CommentFieldCreatePayload as Ry, useMiddlewareComponents as S, Previewable as SC, useDialogStack as SS, renderStudio as S_, selectUpstreamVersion as Sa, I18nNode as Sb, FormProvider as Sc, ReleasesUpsellContextValue as Sd, getErrorMessage as Sf, CommonProps as Sg, DocumentGroupEvent as Sh, useComlinkStore as Si, PrimitiveFormNode as Sl, DiffCardProps as Sm, UrlInput as Sn, RemoteSnapshotVersionEvent as So, PerspectiveProvider as Sp, FormValueContextValue as Sr, InputOnSelectFileFunctionProps as Ss, ReleaseActionDescription as St, TemplatePreview as Su, operatorDefinitions as Sv, BetaBadgeProps as Sw, TypeTarget as Sx, getWorkspaceIdentifier as Sy, AssetSourceResolver as T, VersionInlineBadge as TC, useDataset as TS, GenerateStudioManifestOptions as T_, DocumentTypeResolveState as Ta, defineLocaleResourceBundle as Tb, FormBuilderProps as Tc, useActiveReleases as Td, EMPTY_OBJECT as Tf, CollapseMenuProps as Tg, EventsStore as Th, useDocumentStore as Ti, DuplicateKeysError as Tl, ChangesError as Tm, TextInputProps as Tn, BufferedDocumentEvent as To, isPerspectiveWriteable as Tp, FormContainer as Tr, ObjectInputProps as Ts, FormComponents as Tt, InlinePreviewProps as Tu, OperatorButtonValueComponentProps as Tv, CONNECTING as Tw, useStudioUrl as Tx, ActiveWorkspaceMatcherProps as Ty, DocumentInspectorContext as U, collate as UC, Reported as US, FormInsertPatchPosition as U_, OperationError as Ua, StaticLocaleResourceBundle as Ub, ExpandOperation as Uc, userHasRole as Ud, useScheduledDraftDocument as Uf, CommentInputProps as Ug, UserColorManagerProvider as Uh, DocumentPresence as Ui, SANITY_PATCH_TYPE as Ul, ChangeNode as Um, ImageUrlBuilder$1 as Un, isArrayOfObjectsInputProps as Uo, isGroupChange as Up, FormField as Ur, ItemProps as Us, DocumentFieldActionTone as Ut, PreviewProps as Uu, SearchResultItemPreview as Uv, AuthState as Uw, FormattedDuration as Ux, CommentPath as Uy, DocumentBadgesResolver as V, SystemBundle as VC, useTrackerStoreReporter as VS, FormIncPatch as V_, validation$1 as Va, LocalesBundlesOption as Vb, useFormCallbacks as Vc, useUnique as Vd, DEFAULT_STUDIO_CLIENT_OPTIONS as Vf, CommentInput as Vg, isUnscheduleDocumentVersionEvent as Vh, SESSION_ID as Vi, RebasePatchMsg as Vl, ArrayItemMetadata as Vm, NumberInput as Vn, Preview as Vo, isAddedItemDiff as Vp, FormFieldHeaderText as Vr, RenderPreviewCallbackProps as Vs, DocumentFieldActionProps as Vt, PreviewLayoutKey as Vu, SearchSort as Vv, _createAuthStore as Vw, useGlobalCopyPasteElementHandler as Vx, CommentMessage as Vy, DocumentInspectorsResolver as W, createDraftFrom as WC, ReporterHook as WS, FormPatch as W_, OperationSuccess as Wa, TFunction$1 as Wb, ExpandPathOperation as Wc, ErrorState as Wd, usePausedScheduledDraft as Wf, CommentsList as Wg, UserColorManagerProviderProps as Wh, GlobalPresence as Wi, dec as Wl, ChangeTitlePath as Wm, EmailInput as Wn, isArrayOfPrimitivesInputProps as Wo, isRemovedItemDiff as Wp, FormFieldProps as Wr, ObjectItem as Ws, DocumentFieldActionsResolver as Wt, PreviewCard as Wu, SearchPopover as Wv, AuthStore as Ww, UseFormattedDurationOptions as Wx, CommentPostPayload as Wy, FormBuilderComponentResolverContext as X, getVersionFromId as XC, ChangeFieldWrapper as XS, FormUnsetPatch as X_, OperationImpl as Xa, UserWithPermission as Xb, setAtPath as Xc, sliceString as Xd, ScheduledBadge as Xf, ErrorMessageProps as Xg, UserColor as Xh, UserStoreOptions as Xi, setIfMissing as Xl, DiffComponentResolver as Xm, DateInputProps as Xn, ArrayInputFunctionsProps as Xo, RevertChangesButton as Xp, FieldPresenceInner as Xr, BlockProps as Xs, TransformPatches as Xt, IntentButton as Xu, ColorSchemeProvider as Xv, EditPortal as Xw, useDocumentOperation as Xx, CommentTextSelection as Xy, DocumentPluginOptions as Y, getPublishedId as YC, ChangeIndicatorProps as YS, FormSetPatch as Y_, OperationArgs as Ya, UserListWithPermissionsOptions as Yb, useFormState as Yc, useLoadable as Yd, SchedulesContext as Yf, ErrorMessage as Yg, HexColor as Yh, UserStore as Yi, set as Yl, DiffComponentOptions as Ym, DateInput as Yn, isStringInputProps as Yo, RevertChangesConfirmDialog as Yp, FieldPresence as Yr, BlockListItemProps as Ys, LoginMethod as Yt, LoadingBlock as Yu, ColorSchemeLocalStorageProvider as Yv, EnhancedObjectDialog as Yw, useDocumentOperationEvent as Yx, CommentTaskCreatePayload as Yy, GroupableActionDescription as Z, getVersionId as ZC, sortReleases as ZS, PatchArg as Z_, OperationsAPI as Za, useUserListWithPermissions as Zb, StateTree as Zc, truncateString as Zd, DocumentBadgeComponent as Zf, WorkspaceProvider as Zg, UserColorHue as Zh, createUserStore as Zi, unset as Zl, DiffProps as Zm, CrossDatasetReferencePreview as Zn, FormBuilderCustomMarkersComponent as Zo, NoChanges as Zp, FieldPresenceInnerProps as Zr, BlockStyleProps as Zs, decodePath as Zt, InsufficientPermissionsMessage as Zu, ColorSchemeProviderProps as Zv, createSanityMediaLibraryFileSource as Zw, DocumentIdStack as Zx, CommentThreadItem as Zy, createDefaultIcon as _, ObserveDocumentAvailabilityFn as _C, DocumentRebaseEvent as _S, Studio as __, GrantsStore as _a, UseTranslationResponse as _b, UploaderResolver as _c, getReleaseTone as _d, isRecord as _f, ScrollContainer as _g, BaseEvent as _h, ResourceCacheProvider as _i, NodeDiffProps as _l, FieldPreviewComponent as _m, MemberItemProps as _n, Transaction as _o, EditScheduleForm as _p, FieldActionsProvider as _r, ArrayOfPrimitivesInputProps as _s, Tool as _t, Resizable as _u, SearchContextValue as _v, CommandListHandle as _w, TemplateArrayFieldDefinition as _x, validateBasePaths as _y, resolveSchemaTypes as a, ObserveForPreviewFn as aC, ListenerEvent as aS, UpsellDialogViewed as a_, grantsPermissionOn as aa, CommentsAuthoringPathContextValue as ab, useEnhancedObjectDialog as ac, ErrorActionsProps as ad, _isType as af, isSanityCreateLinkedDocument as ag, ObjectDiff$1 as ah, Rect as ai, FieldMember as al, FieldChange as am, ObjectMembers as an, HistoryStore as ao, DocumentActionConfirmDialogProps as ap, VirtualizerScrollInstanceProvider as ar, ArrayFieldProps as as, PluginOptions as at, ZIndexContextValueKey as au, NavbarAction as av, newDraftFrom as aw, useTemplates as ax, StudioThemeColorSchemeKey as ay, ConfigPropertyError as b, PreparedSnapshot as bC, RemoteSnapshotEvent as bS, SourceProviderProps as b_, useInitialValue as ba, useLocale as bb, StudioCrossDatasetReferenceInput as bc, PUBLISHED as bd, globalScope as bf, CollapseMenuButton as bg, DeleteDocumentGroupEvent as bh, useGlobalPresence as bi, ObjectFormNode as bl, DiffErrorBoundaryState as bm, ArrayOfObjectsInputMember as bn, MutationResult as bo, useGetDefaultPerspective as bp, GetFormValueProvider as br, ComplexElementProps as bs, WorkspaceSummary as bt, LinearProgress as bu, defineSearchFilterOperators as bv, CommandListRenderItemCallback as bw, TemplateParameter as bx, useWorkspaces as by, createWorkspaceFromConfig as c, AvailabilityReason as cC, MutationEvent as cS, StudioProviderProps as c_, useDocumentValuePermissions as ca, useValidationStatus as cb, FileInputProps as cc, DocumentStatus as cd, createSharedResizeObserver as cf, useSanityCreateConfig as cg, StringDiffSegment as ch, Size as ci, ObjectMember as cl, DiffTooltip as cm, ObjectInputMemberProps as cn, removeMissingReferences as co, DocumentActionDialogProps as cp, ArrayOfObjectsInput as cr, BooleanFieldProps as cs, ResolveProductionUrlContext as ct, ToastParams$1 as cu, StudioComponentsPluginOptions as cv, Chip as cw, isBuilder as cx, AddonDatasetProvider as cy, flattenConfig as d, DocumentStackAvailability as dC, ResetEvent as dS, StudioLayoutComponent as d_, getDocumentPairPermissions as da, Translate as db, FileLike as dc, isDraftPerspective as dd, isCardinalityOnePerspective as df, CreateLinkedDocumentBannerContentProps as dg, TypeChangeDiff$1 as dh, useCurrentUser as di, BaseFormNode as dl, DiffString as dm, MemberField as dn, TimelineControllerOptions as do, DocumentActionPopoverDialogProps as dp, FormBuilderContextValue as dr, NumberFieldProps as ds, SchemaPluginOptions as dt, TextWithToneProps as du, SearchDialog as dv, ContextMenuButton as dw, resolveInitialValueForType as dx, MatchWorkspaceResult as dy, useIsReleaseActive as eC, editState$1 as eS, InterpolationProp as e_, getTemplatePermissions as ea, CommentsListBreadcrumbItem as eb, ArrayInputCopyEvent as ec, HotkeysProps$1 as ed, escapeField as ef, isDev as eg, FromToIndex as eh, FieldPresenceData as ei, ArrayOfObjectsItemMember as el, GroupChange as em, fromMutationPatches as en, useTimelineSelector as eo, GetHookCollectionState as ep, ArrayOfPrimitivesInput as er, FormBuilderMarkersComponent as es, NewDocumentCreationContext as et, WithReferringDocuments as eu, StudioToolMenu as ev, isDraftId as ew, UseUnitFormatterOptions as ex, useColorSchemeOptions as ey, PluginFactory as f, DraftsModelDocument as fC, WelcomeBackEvent as fS, isValidAnnouncementAudience as f_, useDocumentPairPermissions as fa, TranslateComponentMap as fb, ResolvedUploader as fc, isPublishedPerspective as fd, isCardinalityOneRelease as ff, CreateLinkedSanityDocument as fg, FieldValueError as fh, useUser as fi, BooleanFormNode as fl, DiffStringSegment as fm, MemberFieldProps as fn, ParsedTimeRef as fo, DocumentActionProps as fp, useHoveredField as fr, ObjectFieldProps as fs, SingleWorkspace as ft, StatusButton as fu, SearchButton as fv, CommandList as fw, defaultTemplateForType as fx, matchWorkspace as fy, defineConfig as g, InvalidationChannelEvent as gC, DocumentMutationEvent as gS, StudioAnnouncementsCard as g_, Grant as ga, UseTranslationOptions as gb, UploaderDef as gc, isGoingToUnpublish as gd, isString as gf, ScrollEventHandler as gg, useEvents as gh, ResourceCache as gi, NodeChronologyProps as gl, DiffFromToProps as gm, ArrayOfObjectsItem as gn, DocumentRemoteMutationVersionEvent as go, SchedulesContextValue as gp, FieldActionsResolver as gr, ArrayOfPrimitivesElementType as gs, TemplateResolver as gt, RovingFocusProps as gu, SearchProvider as gv, CommandListGetItemSelectedCallback as gw, Template as gx, ValidateWorkspaceOptions as gy, createConfig as h, Id as hC, CommittedEvent as hS, StudioAnnouncementsContextValue as h_, EvaluationParams as ha, usEnglishLocale as hb, Uploader as hc, isReleasePerspective as hd, isTruthy as hf, ScrollContextValue as hg, EventsProvider as hh, isAgentBundleName as hi, HiddenField as hl, DiffFromTo as hm, PrimitiveMemberItemProps as hn, CombinedDocument as ho, isSanityDefinedAction as hp, FieldActionsProps as hr, ArrayOfObjectsInputProps as hs, SourceOptions as ht, RovingFocusNavigationType as hu, useSearchState as hv, CommandListGetItemKeyCallback as hw, InitialValueTemplateItem as hx, WorkspacesContextValue as hy, SchemaError as i, DocumentPreviewStoreOptions as iC, LatencyReportEvent as iS, UpsellDialogUpgradeCtaClicked as i_, createGrantsStore as ia, Loadable as ib, EnhancedObjectDialogContextValue as ic, ErrorActions as id, _isSanityDocumentTypeDefinition as if, isSanityCreateLinked as ig, NumberDiff$1 as ih, PresentUser as ii, DecorationMember as il, FromToProps as im, ObjectInputMembers as in, DocumentRevision as io, DocumentActionComponent as ip, ArrayOfObjectOptionsInput as ir, RenderCustomMarkers as is, Plugin as it, LegacyLayerProvider as iu, LogoProps as iv, isVersionId as iw, useTimeAgo as ix, StudioTheme as iy, Config as j, PerspectiveContextValue as jC, CommentDeleteDialog as jS, useCopyPaste as j_, ListenQueryOptions as ja, Locale as jb, defaultRenderItem as jc, DEFAULT_DECORATORS as jd, buildLegacyTheme as jf, CommentsOnboardingContextValue as jg, UnscheduleDocumentVersionEvent as jh, useRenderingContextStore as ji, TypeAnnotationMismatchError as jl, useAnnotationColor as jm, SlugInput as jn, getPreviewValueWithFallback as jo, isEmptyObject as jp, FormFieldValidation as jr, PrimitiveInputProps as js, defineDocumentInspector as jt, DetailPreview as ju, SearchOperatorParams as jv, ErrorStatus as jw, useReferringDocuments as jx, CommentsIntentProviderProps as jy, BetaFeatures as k, ReleaseAvatarIcon as kC, useClient as kS, StudioWorkspaceManifest as k_, QueryParams$1 as ka, LocaleProviderBase as kb, defaultRenderInlineBlock as kc, RELEASES_INTENT as kd, catchWithCount as kf, useCommentsTelemetry as kg, ScheduleDocumentVersionEvent as kh, usePresenceStore as ki, MissingKeysError as kl, ChangeListProps as km, TagsArrayInputProps as kn, createObservableBufferedDocument as ko, getItemKeySegment as kp, FormInputAbsolutePathArg as kr, PortableTextInputProps as ks, DocumentInspectorProps as kt, MediaPreview as ku, SearchOperatorButtonValue as kv, ConnectionStatusStore as kw, useRelativeTime as kx, CommentsSelectedPathProvider as ky, resolveConfig as l, AvailabilityResponse as lC, PendingMutationsEvent as lS, NavbarContextValue as l_, DocumentPairPermissionsOptions as la, ValidateDocumentOptions as lb, StudioFileInput as lc, formatRelativeLocalePublishDate as ld, resizeObserver as lf, CreateLinkMetadata as lg, StringSegmentChanged$1 as lh, DocumentPreviewPresence as li, ArrayOfObjectsFormNode as ll, DiffTooltipProps as lm, MemberFieldSet as ln, SelectionState as lo, DocumentActionGroup as lp, ArrayOfObjectsFunctions as lr, FieldCommentsProps as ls, SanityFormConfig as lt, TooltipOfDisabled as lu, ToolMenuProps as lv, DocumentVariantType as lw, resolveInitialObjectValue as lx, useActiveWorkspace as ly, definePlugin as m, FieldName as mC, CommitFunction as mS, StudioAnnouncementsDialog as m_, DocumentValuePermission as ma, defaultLocale as mb, UploadProgressEvent as mc, RELEASES_STUDIO_CLIENT_OPTIONS as md, PartialExcept as mf, SanityCreateConfigProvider as mg, useEventsStore as mh, useAgentVersionDisplay as mi, DocumentFormNode as ml, DiffInspectWrapperProps as mm, ArrayOfPrimitivesItem as mn, TimelineOptions as mo, DuplicateDocumentActionComponent as mp, useFieldActions as mr, StringFieldProps as ms, SourceClientOptions as mt, useRovingFocus as mu, useSearchMaxFieldDepth as mv, CommandListGetItemDisabledCallback as mw, prepareTemplates as mx, WorkspacesProviderProps as my, getConfigContextFromSource as n, useDocumentVersions as nC, DocumentStoreExtraOptions as nS, UpsellDialogDismissed as n_, useTemplatePermissionsFromHookFactory as na, CommentsType as nb, ArrayInputMoveItemEvent as nc, useCopyErrorDetails as nd, joinPath as nf, getSanityCreateLinkMetadata as ng, ItemDiff$1 as nh, Location as ni, ArrayOfPrimitivesItemMember as nl, FromToArrowDirection as nm, useFormBuilder as nn, TimelineStore as no, HookCollectionActionHook as np, ArrayOfPrimitiveOptionsInput as nr, RenderBlockActionsCallback as ns, NewDocumentOptionsResolver as nt, UserAvatar as nu, ActiveToolLayoutProps as nv, isSystemBundle as nw, useTools as nx, useColorSchemeValue as ny, CreateWorkspaceFromConfigOptions as o, createDocumentPreviewStore as oC, getPairListener as oS, UpsellDialogViewedInfo as o_, DocumentValuePermissionsOptions as oa, CommentsAuthoringPathProvider as ob, ImageInputProps as oc, DocumentStatusIndicator as od, createSWR as of, isSanityCreateStartCompatibleDoc as og, ReferenceDiff as oh, RegionWithIntersectionDetails as oi, FieldSetMember as ol, FallbackDiff as om, ObjectMembersProps as on, HistoryStoreOptions as oo, DocumentActionCustomDialogComponentProps as op, VirtualizerScrollInstance as or, ArrayOfPrimitivesFieldProps as os, PreparedConfig as ot, ZIndexContextValue as ou, NavbarProps as ov, removeDupes as ow, DEFAULT_MAX_RECURSION_DEPTH as ox, useAddonDataset as oy, createPlugin as p, DraftsModelDocumentAvailability as pC, WelcomeEvent as pS, isValidAnnouncementRole as p_, useDocumentPairPermissionsFromHookFactory as pa, TranslationProps as pb, UploadOptions as pc, isReleaseScheduledOrScheduling as pd, isPausedCardinalityOneRelease as pf, AppIdCache as pg, getValueError as ph, AgentVersionDisplay as pi, ComputeDiff as pl, DiffInspectWrapper as pm, MemberItemError as pn, Timeline as po, DuplicateActionProps as pp, HoveredFieldProvider as pr, PrimitiveFieldProps as ps, Source as pt, StatusButtonProps as pu, PartialIndexSettings as pv, CommandListElementType as pw, defaultTemplatesForSchema as px, WorkspacesProvider as py, DocumentLanguageFilterResolver as q, getDraftId as qC, ConnectorContextValue as qS, FormPatchOrigin as q_, MapDocument as qa, Rule as qb, FormState as qc, LoadingState as qd, getSchemaTypeTitle as qf, WorkspaceLoaderBoundary as qg, useUserColor as qh, Status as qi, insert as ql, Diff$1 as qm, DateTimeInput as qn, isObjectInputProps as qo, DocumentChangeContextInstance as qp, PresenceOverlay as qr, BlockAnnotationProps as qs, AuthProvider as qt, usePreviewCard as qu, Filters as qv, KeyValueStore as qw, useFeatureEnabled as qx, CommentReactionShortNames as qy, useConfigContextFromSource as r, DocumentPreviewStore as rC, InitialSnapshotEvent as rS, UpsellDialogLearnMoreCtaClicked as r_, GrantsStoreOptions as ra, CommentsUIMode as rb, UploadEvent as rc, ErrorWithId as rd, _isCustomDocumentTypeDefinition as rf, isSanityCreateExcludedType as rg, NullDiff$1 as rh, Position as ri, ArrayOfPrimitivesMember as rl, FromTo as rm, useDocumentForm as rn, useTimelineStore as ro, useScheduleAction as rp, ArrayOfOptionsInput as rr, RenderBlockActionsProps as rs, PartialContext as rt, UserAvatarProps as ru, LayoutProps as rv, isSystemBundleName as rw, TimeAgoOpts as rx, StudioColorScheme as ry, createSourceFromConfig as s, ApiConfig as sC, IdPair as sS, StudioProvider as s_, getDocumentValuePermissions as sa, useWorkspaceSchemaId as sb, StudioImageInput as sc, CapabilityGate as sd, SharedResizeObserver as sf, SanityCreateConfigContextValue as sg, StringDiff$1 as sh, ReportedRegionWithRect as si, FieldsetRenderMembersCallback as sl, Event$1 as sm, ObjectInputMember as sn, createHistoryStore as so, DocumentActionDescription as sp, useVirtualizerScrollInstance as sr, BaseFieldProps as ss, ReleaseActionsResolver as st, ImperativeToast as su, StudioComponents as sv, systemBundles as sw, Serializeable as sx, AddonDatasetContextValue as sy, ActiveWorkspaceMatcherContextValue as t, useDocumentVersionTypeSortedList as tC, DocumentPairLoadedEvent as tS, UpsellDescriptionSerializer as t_, useTemplatePermissions as ta, CommentsTextSelectionItem as tb, ArrayInputInsertEvent as tc, serializeError as td, fieldNeedsEscape as tf, isProd as tg, GroupChangeNode as th, FormNodePresence as ti, ArrayOfObjectsMember as tl, FromToArrow as tm, toMutationPatches as tn, TimelineState as to, GetHookCollectionStateProps as tp, ArrayOfPrimitivesFunctions as tr, PortableTextMarker as ts, NewDocumentOptionsContext as tt, AvatarSkeleton as tu, StudioNavbar as tv, isPublishedId as tw, useUnitFormatter as tx, useColorSchemeSetValue as ty, prepareConfig as u, DocumentAvailability as uC, ReconnectEvent as uS, StudioLayout as u_, DocumentPermission as ua, validateDocument as ub, AssetSourcesResolver as uc, getDocumentIsInPerspective as ud, CardinalityOneRelease as uf, CreateLinkedActionsProps as ug, StringSegmentUnchanged$1 as uh, DocumentPreviewPresenceProps as ui, ArrayOfPrimitivesFormNode as ul, DiffTooltipWithAnnotationsProps as um, MemberFieldError as un, TimelineController as uo, DocumentActionModalDialogProps as up, useDidUpdate as ur, FieldProps as us, ScheduledPublishingPluginOptions as ut, TextWithTone as uu, StudioLogo as uv, getDocumentVariantType as uw, resolveInitialValue as ux, MatchWorkspaceOptions as uy, ConfigResolutionError as v, ObserveDocumentTypeFromIdFn as vC, DocumentRemoteMutationEvent as vS, StudioProps as v_, PermissionCheckResult as va, useTranslation as vb, StudioReferenceInput as vc, getReleaseIdFromReleaseDocumentId as vd, isNonNullable as vf, ScrollContainerProps as vg, CreateDocumentVersionEvent as vh, ResourceCacheProviderProps as vi, NumberFormNode as vl, DiffErrorBoundary as vm, ArrayOfObjectsInputMembers as vn, DocumentVersion as vo, useSetPerspective as vp, FieldActionMenu as vr, BaseInputProps as vs, Workspace as vt, RelativeTime as vu, SearchFilterDefinition as vv, CommandListItemContext as vw, TemplateFieldDefinition as vx, validateNames as vy, AppsOptions as w, Selection as wC, useDateTimeFormat as wS, LiveManifestRegisterProvider as w_, useDocumentValues as wa, defineLocale as wb, FormBuilder as wc, useArchivedReleases as wd, EMPTY_ARRAY as wf, CollapseMenu as wg, EditDocumentVersionEvent as wh, useDocumentPreviewStore as wi, ArrayItemError as wl, ChangeTitleSegment as wm, TextInput as wn, checkoutPair as wo, PerspectiveNotWriteableReason as wp, useFormValue as wr, NumberInputProps as ws, ReleaseActionsContext as wt, InlinePreview as wu, I18nSearchOperatorNameKey as wv, CorsOriginErrorOptions as ww, useSyncState as wx, ActiveWorkspaceMatcher as wy, ConfigPropertyErrorOptions as x, PreviewPath as xC, SnapshotEvent as xS, useSource as x_, useInitialValueResolverContext as xa, useGetI18nText as xb, StudioCrossDatasetReferenceInputProps as xc, useReleasesIds as xd, getReferencePaths as xf, CollapseMenuButtonProps as xg, DeleteDocumentVersionEvent as xh, useDocumentPresence as xi, ObjectRenderMembersCallback as xl, DiffCard as xm, ArrayOfObjectsMemberProps as xn, Pair as xo, useExcludedPerspective as xp, useGetFormValue as xr, EditorChange as xs, ReleaseActionComponent as xt, CircularProgress as xu, SearchOperatorType as xv, BetaBadge as xw, TemplateReferenceTarget as xx, getNamelessWorkspaceIdentifier as xy, ConfigResolutionErrorOptions as y, ObservePathsFn as yC, MutationPayload as yS, SourceProvider as y_, useResolveInitialValueForType as ya, useCurrentLocale as yb, StudioReferenceInputProps as yc, LATEST as yd, isArray as yf, useOnScroll as yg, CreateLiveDocumentEvent as yh, useResourceCache as yi, ObjectArrayFormNode as yl, DiffErrorBoundaryProps as ym, ArrayOfObjectsInputMembersProps as yn, DocumentVersionEvent as yo, usePerspective as yp, FieldActionMenuProps as yr, BooleanInputProps as ys, WorkspaceOptions as yt, RelativeTimeProps as yu, defineSearchFilter as yv, CommandListProps as yw, TemplateItem as yx, validateWorkspaces as yy, DocumentActionsVersionType as z, DraftId as zC, TrackerContextStore as zS, FormDecPatch as z_, InitialValueState as za, LocaleSource as zb, FormCallbacksProvider as zc, measureFirstEmission as zd, IsLastPaneProvider as zf, CommentInlineHighlightSpan as zg, isScheduleDocumentVersionEvent as zh, ProjectStore as zi, PatchMsg as zl, AnnotationDetails as zm, UpdateReadOnlyPlugin as zn, SanityDefaultPreviewProps as zo, resolveDiffComponent as zp, FormFieldSet as zr, RenderItemCallback as zs, DocumentFieldActionItem as zt, PortableTextPreviewLayoutKey as zu, SearchFactoryOptions as zv, createMockAuthStore as zw, useListFormat as zx, CommentIntentGetter as zy };