import { it as Plugin } from "./_chunks-dts/ActiveWorkspaceMatcherContext.js";
import { $ as Serializable, $t as GenericListBuilder$1, A as StructureToolFeatures, At as DocumentListItem$1, B as StructureBuilderOptions$1, Bt as ListItemSerializeOptions$1, C as RouterPaneSiblingContext$1, Cn as BaseIntentParams$1, Ct as View$1, D as StructureResolver$1, Dn as IntentJsonParams$1, Dt as ListInput$1, En as IntentChecker$1, Et as ListBuilder$1, Ft as ListItem$1, G as ItemChild$1, Gt as DocumentListBuilder$1, H as ChildObservable$1, Ht as UnserializedListItem$1, It as ListItemBuilder$1, J as Collection$1, Jt as PartialDocumentList$1, K as Builder$1, Kt as DocumentListInput$1, Lt as ListItemChild$1, M as StructureToolPaneActionHandler, Mt as DocumentListItemInput$1, N as UnresolvedPaneNode$1, Nt as PartialDocumentListItem$1, O as StructureResolverContext$1, On as IntentParams$1, Ot as DocumentTypeListBuilder$1, Pt as isDocumentListItem$1, Q as EditorNode$1, Qt as GenericList$1, Rt as ListItemDisplayOptions$1, S as RouterPaneSibling$1, Sn as ComponentViewBuilder$1, St as UserViewComponent$1, T as SerializablePaneNode$1, Tn as Intent$1, Tt as List$1, U as ChildResolver$1, Ut as UnserializedListItemChild$1, V as createStructureBuilder$1, Vt as PartialListItem$1, W as ChildResolverOptions$1, Wt as DocumentList$1, X as Divider$1, Xt as BaseGenericList$1, Y as CollectionBuilder$1, Yt as getTypeNamesFromFilter$1, Z as DocumentNode$1, Zt as BuildableGenericList$1, _ as PaneMenuItem$1, _n as ViewBuilder$1, _t as DefaultDocumentNodeContext$1, a as ParameterizedLinkProps$1, an as maybeSerializeMenuItemGroup$1, at as ComponentBuilder$1, b as PaneNodeResolver$1, bn as FormViewBuilder$1, bt as StructureContext$1, cn as maybeSerializeInitialValueTemplateItem$1, ct as MenuItem$1, d as DocumentFieldMenuActionNode$1, dn as DocumentOptions$1, dt as MenuItemParamsType$1, en as GenericListInput$1, et as SerializeOptions$1, f as DocumentListPaneNode$1, fn as PartialDocumentNode$1, ft as PartialMenuItem$1, g as PaneListItemDivider$1, gn as GenericViewBuilder$1, gt as maybeSerializeMenuItem$1, h as PaneListItem$1, hn as BaseView$1, ht as getOrderingMenuItemsForSchemaType$1, i as PaneRouterContextValue$1, in as MenuItemGroupBuilder$1, it as Component$2, j as StructureToolOptions, jt as DocumentListItemBuilder$1, k as StructureToolContextValue, kt as DocumentTypeListInput$1, l as BaseResolvedPaneNode, ln as menuItemsFromInitialValueTemplateItems$1, lt as MenuItemActionType$1, m as ListPaneNode$1, mn as documentFromEditorWithInitialValue$1, mt as getOrderingMenuItem$1, n as ChildLinkProps$1, nt as StructureNode$1, o as ReferenceChildLinkProps$1, on as InitialValueTemplateItemBuilder$1, ot as ComponentInput$1, p as DocumentPaneNode$1, pn as documentFromEditor$1, pt as SortMenuItem$1, q as Child$1, qt as DocumentListOptions$1, r as EditReferenceOptions$1, rn as MenuItemGroup$1, rt as BuildableComponent$1, sn as defaultInitialValueTemplateItems$1, t as BackLinkProps$1, tn as ListDisplayOptions$1, tt as SerializePath$1, u as CustomComponentPaneNode$1, un as DocumentBuilder$1, ut as MenuItemBuilder$1, v as PaneMenuItemGroup$1, vn as maybeSerializeView$1, vt as DefaultDocumentNodeResolver$1, w as RouterPanes$1, wt as BuildableList$1, x as RouterPaneGroup$1, xn as ComponentView$1, xt as UserComponent$1, y as PaneNode$1, yn as FormView$1, yt as StructureBuilder$1, z as SerializeError$1, zt as ListItemInput$1 } from "./_chunks-dts/types.js";
import { C as PaneLayout$1, D as ConfirmDeleteDialogProps$1, E as ConfirmDeleteDialogContainer, O as BaseStructureToolPaneProps, S as usePaneRouter$1, _ as StructureLocaleResourceKeys$1, c as useDocumentPane$1, d as useDocumentTitle$1, h as DocumentPaneProviderProps$1, i as StructureToolProviderProps, l as DocumentInspectorHeader$1, n as useStructureTool, o as DocumentListPaneProps$1, r as StructureToolProvider } from "./_chunks-dts/index.js";
import * as react from "react";
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type BackLinkProps = BackLinkProps$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type BaseGenericList = BaseGenericList$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type BaseIntentParams = BaseIntentParams$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type BaseView = BaseView$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type BuildableComponent = BuildableComponent$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type BuildableGenericList = BuildableGenericList$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type BuildableList = BuildableList$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type Builder = Builder$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type Child = Child$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ChildLinkProps = ChildLinkProps$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ChildObservable = ChildObservable$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ChildResolver = ChildResolver$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ChildResolverOptions = ChildResolverOptions$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type Collection = Collection$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type CollectionBuilder = CollectionBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type Component = Component$2;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ComponentInput = ComponentInput$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ComponentView = ComponentView$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ConfirmDeleteDialogProps = ConfirmDeleteDialogProps$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type CustomComponentPaneNode = CustomComponentPaneNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DefaultDocumentNodeContext = DefaultDocumentNodeContext$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DefaultDocumentNodeResolver = DefaultDocumentNodeResolver$1;
/**
 * @deprecated Import `StructureToolContextValue` from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DeskToolContextValue = StructureToolContextValue;
/**
 * @deprecated Import `StructureToolFeatures` from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DeskToolFeatures = StructureToolFeatures;
/**
 * @deprecated Import `StructureToolMenuItem` from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DeskToolMenuItem = MenuItem$1;
/**
 * @deprecated Import `StructureToolOptions` from `sanity/structure` instead
 * @hidden
 * @public
 */
type DeskToolOptions = StructureToolOptions;
/**
 * @deprecated Import `StructureToolPaneActionHandler` from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DeskToolPaneActionHandler = StructureToolPaneActionHandler;
/**
 * @deprecated Import `StructureToolProviderProps` from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DeskToolProviderProps = StructureToolProviderProps;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type Divider = Divider$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentFieldMenuActionNode = DocumentFieldMenuActionNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentList = DocumentList$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentListInput = DocumentListInput$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentListItem = DocumentListItem$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentListItemInput = DocumentListItemInput$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentListOptions = DocumentListOptions$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentListPaneNode = DocumentListPaneNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentListPaneProps = DocumentListPaneProps$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentNode = DocumentNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentOptions = DocumentOptions$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentPaneNode = DocumentPaneNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentPaneProviderProps = DocumentPaneProviderProps$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type DocumentTypeListInput = DocumentTypeListInput$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type EditReferenceOptions = EditReferenceOptions$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type EditorNode = EditorNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type FormView = FormView$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type GenericList = GenericList$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type GenericListInput = GenericListInput$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type Intent = Intent$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type IntentChecker = IntentChecker$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type IntentJsonParams = IntentJsonParams$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type IntentParams = IntentParams$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ItemChild = ItemChild$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type List = List$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ListDisplayOptions = ListDisplayOptions$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ListInput = ListInput$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ListItem = ListItem$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ListItemChild = ListItemChild$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ListItemDisplayOptions = ListItemDisplayOptions$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ListItemInput = ListItemInput$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ListItemSerializeOptions = ListItemSerializeOptions$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ListPaneNode = ListPaneNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type MenuItem = MenuItem$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type MenuItemActionType = MenuItemActionType$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type MenuItemGroup = MenuItemGroup$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type MenuItemParamsType = MenuItemParamsType$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PaneListItem = PaneListItem$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PaneListItemDivider = PaneListItemDivider$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PaneMenuItem = PaneMenuItem$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PaneMenuItemGroup = PaneMenuItemGroup$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PaneNode = PaneNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PaneNodeResolver = PaneNodeResolver$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PaneRouterContextValue = PaneRouterContextValue$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ParameterizedLinkProps = ParameterizedLinkProps$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PartialDocumentList = PartialDocumentList$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PartialDocumentListItem = PartialDocumentListItem$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PartialDocumentNode = PartialDocumentNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PartialListItem = PartialListItem$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type PartialMenuItem = PartialMenuItem$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ReferenceChildLinkProps = ReferenceChildLinkProps$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type RouterPaneGroup = RouterPaneGroup$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type RouterPaneSibling = RouterPaneSibling$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type RouterPaneSiblingContext = RouterPaneSiblingContext$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type RouterPanes = RouterPanes$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type SerializablePaneNode = SerializablePaneNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type SerializeOptions = SerializeOptions$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type SerializePath = SerializePath$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type SortMenuItem = SortMenuItem$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type StructureBuilder = StructureBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type StructureBuilderOptions = StructureBuilderOptions$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type StructureContext = StructureContext$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type StructureLocaleResourceKeys = StructureLocaleResourceKeys$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type StructureNode = StructureNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type StructureResolver = StructureResolver$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type StructureResolverContext = StructureResolverContext$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type UnresolvedPaneNode = UnresolvedPaneNode$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type UnserializedListItem = UnserializedListItem$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type UnserializedListItemChild = UnserializedListItemChild$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type UserComponent = UserComponent$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type UserViewComponent = UserViewComponent$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type View = View$1;
/**
 * @deprecated Import from `sanity/structure` instead
 * @hidden
 * @beta
 */
type ViewBuilder = ViewBuilder$1;
/** --------- NON-TYPES FOLLOW --------- */
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const ComponentBuilder: typeof ComponentBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const ComponentViewBuilder: typeof ComponentViewBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const ConfirmDeleteDialog: typeof ConfirmDeleteDialogContainer;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const DEFAULT_INTENT_HANDLER: symbol;
/**
 * @deprecated Import `StructureToolProvider` from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const DeskToolProvider: typeof StructureToolProvider;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const DocumentBuilder: typeof DocumentBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const DocumentInspectorHeader: typeof DocumentInspectorHeader$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const DocumentListBuilder: typeof DocumentListBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const DocumentListItemBuilder: typeof DocumentListItemBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const DocumentListPane: react.NamedExoticComponent<BaseStructureToolPaneProps<"documentList">>;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const DocumentPane: react.NamedExoticComponent<DocumentPaneProviderProps$1>;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const DocumentPaneProvider: react.MemoExoticComponent<(props: DocumentPaneProviderProps$1) => react.JSX.Element>;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const DocumentTypeListBuilder: typeof DocumentTypeListBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const FormViewBuilder: typeof FormViewBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const GenericListBuilder: typeof GenericListBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const GenericViewBuilder: typeof GenericViewBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const HELP_URL: {
  ID_REQUIRED: "structure-node-id-required";
  TITLE_REQUIRED: "structure-title-required";
  FILTER_REQUIRED: "structure-filter-required";
  INVALID_LIST_ITEM: "structure-invalid-list-item";
  COMPONENT_REQUIRED: "structure-view-component-required";
  DOCUMENT_ID_REQUIRED: "structure-document-id-required";
  DOCUMENT_TYPE_REQUIRED: "structure-document-type-required";
  SCHEMA_TYPE_REQUIRED: "structure-schema-type-required";
  SCHEMA_TYPE_NOT_FOUND: "structure-schema-type-not-found";
  LIST_ITEMS_MUST_BE_ARRAY: "structure-list-items-must-be-array";
  QUERY_PROVIDED_FOR_FILTER: "structure-query-provided-for-filter";
  ACTION_OR_INTENT_REQUIRED: "structure-action-or-intent-required";
  LIST_ITEM_IDS_MUST_BE_UNIQUE: "structure-list-item-ids-must-be-unique";
  ACTION_AND_INTENT_MUTUALLY_EXCLUSIVE: "structure-action-and-intent-mutually-exclusive";
  API_VERSION_REQUIRED_FOR_CUSTOM_FILTER: "structure-api-version-required-for-custom-filter";
};
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const InitialValueTemplateItemBuilder: typeof InitialValueTemplateItemBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const ListBuilder: typeof ListBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const ListItemBuilder: typeof ListItemBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const MenuItemBuilder: typeof MenuItemBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const MenuItemGroupBuilder: typeof MenuItemGroupBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const PaneLayout: typeof PaneLayout$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const SerializeError: typeof SerializeError$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const component: (componentOrSpec?: Partial<ComponentView$1<Record<string, any>>> | UserViewComponent$1 | undefined) => ComponentViewBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const createStructureBuilder: typeof createStructureBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const defaultInitialValueTemplateItems: typeof defaultInitialValueTemplateItems$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const defaultIntentChecker: IntentChecker$1;
/**
 * @deprecated Import `structureTool` from `sanity/structure` instead!
 * @hidden
 * @public
 */
declare const deskTool: Plugin<void | StructureToolOptions>;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const documentFromEditor: typeof documentFromEditor$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const documentFromEditorWithInitialValue: typeof documentFromEditorWithInitialValue$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const form: (spec?: Partial<FormView$1> | undefined) => FormViewBuilder$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const getOrderingMenuItem: typeof getOrderingMenuItem$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const getOrderingMenuItemsForSchemaType: typeof getOrderingMenuItemsForSchemaType$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const getTypeNamesFromFilter: typeof getTypeNamesFromFilter$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const isDocumentListItem: typeof isDocumentListItem$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const maybeSerializeInitialValueTemplateItem: typeof maybeSerializeInitialValueTemplateItem$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const maybeSerializeMenuItem: typeof maybeSerializeMenuItem$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const maybeSerializeMenuItemGroup: typeof maybeSerializeMenuItemGroup$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const maybeSerializeView: typeof maybeSerializeView$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const menuItemsFromInitialValueTemplateItems: typeof menuItemsFromInitialValueTemplateItems$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const shallowIntentChecker: IntentChecker$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const structureLocaleNamespace: "structure";
/**
 * @deprecated Import `useStructureTool` from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const useDeskTool: typeof useStructureTool;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const useDocumentPane: typeof useDocumentPane$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const useDocumentTitle: typeof useDocumentTitle$1;
/**
 * @deprecated Import from `sanity/structure` instead!
 * @hidden
 * @beta
 */
declare const usePaneRouter: typeof usePaneRouter$1;
export { BackLinkProps, BaseGenericList, BaseIntentParams, type BaseResolvedPaneNode, BaseView, BuildableComponent, BuildableGenericList, BuildableList, Builder, Child, ChildLinkProps, ChildObservable, ChildResolver, ChildResolverOptions, Collection, CollectionBuilder, Component, ComponentBuilder, ComponentInput, ComponentView, ComponentViewBuilder, ConfirmDeleteDialog, ConfirmDeleteDialogProps, CustomComponentPaneNode, DEFAULT_INTENT_HANDLER, DefaultDocumentNodeContext, DefaultDocumentNodeResolver, DeskToolContextValue, DeskToolFeatures, DeskToolMenuItem, DeskToolOptions, DeskToolPaneActionHandler, DeskToolProvider, DeskToolProviderProps, Divider, DocumentBuilder, DocumentFieldMenuActionNode, DocumentInspectorHeader, DocumentList, DocumentListBuilder, DocumentListInput, DocumentListItem, DocumentListItemBuilder, DocumentListItemInput, DocumentListOptions, DocumentListPane, DocumentListPaneNode, DocumentListPaneProps, DocumentNode, DocumentOptions, DocumentPane, DocumentPaneNode, DocumentPaneProvider, DocumentPaneProviderProps, DocumentTypeListBuilder, DocumentTypeListInput, EditReferenceOptions, EditorNode, FormView, FormViewBuilder, GenericList, GenericListBuilder, GenericListInput, GenericViewBuilder, HELP_URL, InitialValueTemplateItemBuilder, Intent, IntentChecker, IntentJsonParams, IntentParams, ItemChild, List, ListBuilder, ListDisplayOptions, ListInput, ListItem, ListItemBuilder, ListItemChild, ListItemDisplayOptions, ListItemInput, ListItemSerializeOptions, ListPaneNode, MenuItem, MenuItemActionType, MenuItemBuilder, MenuItemGroup, MenuItemGroupBuilder, MenuItemParamsType, PaneLayout, PaneListItem, PaneListItemDivider, PaneMenuItem, PaneMenuItemGroup, PaneNode, PaneNodeResolver, PaneRouterContextValue, ParameterizedLinkProps, PartialDocumentList, PartialDocumentListItem, PartialDocumentNode, PartialListItem, PartialMenuItem, ReferenceChildLinkProps, RouterPaneGroup, RouterPaneSibling, RouterPaneSiblingContext, RouterPanes, type Serializable, SerializablePaneNode, SerializeError, SerializeOptions, SerializePath, SortMenuItem, StructureBuilder, StructureBuilderOptions, StructureContext, StructureLocaleResourceKeys, StructureNode, StructureResolver, StructureResolverContext, UnresolvedPaneNode, UnserializedListItem, UnserializedListItemChild, UserComponent, UserViewComponent, View, ViewBuilder, component, createStructureBuilder, defaultInitialValueTemplateItems, defaultIntentChecker, deskTool, documentFromEditor, documentFromEditorWithInitialValue, form, getOrderingMenuItem, getOrderingMenuItemsForSchemaType, getTypeNamesFromFilter, isDocumentListItem, maybeSerializeInitialValueTemplateItem, maybeSerializeMenuItem, maybeSerializeMenuItemGroup, maybeSerializeView, menuItemsFromInitialValueTemplateItems, shallowIntentChecker, structureLocaleNamespace, useDeskTool, useDocumentPane, useDocumentTitle, usePaneRouter };