import * as _sanity_types0 from "@sanity/types";
import { AssetSource, FieldDefinitionBase, InitialValueProperty, ObjectDefinition, ObjectOptions, ObjectSchemaType, Reference, RuleDef, ValidationBuilder } from "@sanity/types";
/** @public */
interface VideoOptions extends ObjectOptions {
  accept?: string;
  sources?: AssetSource[];
}
/** @public */
interface VideoRule extends RuleDef<VideoRule, VideoValue> {
  /**
   * Require a file field has an asset.
   *
   * @example
   * ```ts
   * defineField({
   *  name: 'video',
   *  title: 'Video',
   *  type: 'sanity.video',
   *  validation: (Rule) => Rule.required().assetRequired(),
   * })
   * ```
   */
  assetRequired(): VideoRule;
}
/** @public */
interface VideoValue {
  asset?: Reference;
  media?: Reference;
  [index: string]: unknown;
}
/** @public */
interface VideoDefinition$1 extends Omit<ObjectDefinition, 'type' | 'fields' | 'options' | 'groups' | 'validation'> {
  type: 'sanity.video';
  fields?: ObjectDefinition['fields'];
  options?: VideoOptions;
  validation?: ValidationBuilder<VideoRule, VideoValue>;
  initialValue?: InitialValueProperty<any, VideoValue>;
}
/**
 * @public
 * @beta
 */
declare const videoTypeName: "sanity.video";
/**
 * @public
 * @beta
 */
interface VideoDefinition extends Omit<ObjectDefinition, 'type' | 'fields' | 'options'> {
  type: typeof videoTypeName;
  options?: VideoOptions;
}
declare module '@sanity/types' {
  interface IntrinsicDefinitions {
    'sanity.video': VideoDefinition;
  }
}
/**
 * Define a video field within a document, object, image or file definition `fields` array.
 *
 * This function will narrow the schema type down to video fields and options based on the provided
 * type-string.
 *
 * Using `defineVideoField` is optional, but should provide improved autocompletion in your IDE, when building your schema.
 * Video field-properties like `validation` and `initialValue` will also be more specific.
 *
 * Note: This video field type is designed to work specifically with the Media Library asset source.
 * Make sure you have the Media Library is enabled in your studio via sanity.config.ts.
 *
 * See {@link defineType} for similar examples.
 *
 * @param definition - should be a valid video field type definition.
 *
 * @see defineField
 * @see defineArrayMember
 * @see typed
 *
 * @beta
 */
declare function defineVideoField(definition: Omit<VideoDefinition$1, 'type'> & FieldDefinitionBase): {
  type: "sanity.video";
  name: string;
} & Omit<VideoDefinition, "preview"> & {
  preview?: _sanity_types0.PreviewConfig<Record<string, string>, Record<string, any>> | undefined;
} & FieldDefinitionBase & _sanity_types0.WidenValidation & _sanity_types0.WidenInitialValue;
export { defineVideoField };