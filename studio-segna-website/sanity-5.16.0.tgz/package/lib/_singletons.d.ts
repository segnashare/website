import { Bc as FormCallbacksValue, Bf as TasksEnabledContextValue, Bg as CommentInputContextValue, Bt as DocumentFieldActionNode$1, Ey as RouterHistory, FS as ChangeIndicatorTrackerContextValue, Fc as ReferenceInputOptions, Ff as TasksUpsellContextValue, Fg as CommentsContextValue, Ft as DocumentFieldAction$1, Gg as CommentsUpsellContextValue, Gu as PreviewCardContextValue, If as TasksContextValue, Kg as UpsellData, Lf as TasksNavigationContextValue, Ng as CommentsEnabledContextValue, Od as MetadataWrapper, Oy as CommentsSelectedPathContextValue, P_ as CopyPasteContextType, Qh as UserColorManager, RS as TrackerContextGetSnapshot, Rf as MentionUserContextValue, Rn as PortableTextMemberItem, Sd as ReleasesUpsellContextValue, Sr as FormValueContextValue, Th as EventsStore, _v as SearchContextValue, ab as CommentsAuthoringPathContextValue, dr as FormBuilderContextValue, ei as FieldPresenceData, fp as DocumentActionProps, gi as ResourceCache, gp as SchedulesContextValue, h_ as StudioAnnouncementsContextValue, hy as WorkspacesContextValue, ic as EnhancedObjectDialogContextValue, jC as PerspectiveContextValue, jb as Locale, jg as CommentsOnboardingContextValue, l_ as NavbarContextValue, ls as FieldCommentsProps, o_ as UpsellDialogViewedInfo, or as VirtualizerScrollInstance, ou as ZIndexContextValue, pg as AppIdCache, pt as Source$1, qS as ConnectorContextValue, qp as DocumentChangeContextInstance, ry as StudioColorScheme, sg as SanityCreateConfigContextValue, sp as DocumentActionDescription, sy as AddonDatasetContextValue, t as ActiveWorkspaceMatcherContextValue, ti as FormNodePresence, ts as PortableTextMarker, vt as Workspace, zS as TrackerContextStore, zy as CommentIntentGetter } from "./_chunks-dts/ActiveWorkspaceMatcherContext.js";
import { F as PaneLayoutContextValue, P as PaneContextValue, c as DocumentPaneInfoContextValue, i as PaneRouterContextValue, k as StructureToolContextValue, s as DocumentPaneContextValue, w as RouterPanes, y as PaneNode } from "./_chunks-dts/types.js";
import { g as PresentationParamsContextValue, h as PresentationNavigateContextValue, m as PresentationContextValue, v as PresentationPluginOptions } from "./_chunks-dts/types2.js";
import { _ as RouterContextValue } from "./_chunks-dts/types3.js";
import * as react from "react";
import { CSSProperties, ComponentType, MutableRefObject, PropsWithChildren, ReactNode, RefObject } from "react";
import { ArraySchemaType, ObjectSchemaType, Path, PortableTextBlock, SanityDocument, ValidationMarker } from "@sanity/types";
import { SanityClient } from "@sanity/client";
import { i18n } from "i18next";
import { BehaviorSubject, Observable } from "rxjs";
import { PubSub } from "nano-pubsub";
import { PortableTextMemberSchemaTypes } from "@portabletext/sanity-bridge";
import { SanityDocument as SanityDocument$2 } from "sanity";
import { SemVer } from "semver";
import { Serializable } from "@sanity/presentation-comlink";
/** @internal */
declare const ActiveWorkspaceMatcherContext: react.Context<ActiveWorkspaceMatcherContextValue | null>;
/**
 * @beta
 * @hidden
 */
declare const AddonDatasetContext: react.Context<AddonDatasetContextValue | null>;
/**
 * @internal
 */
declare const AppIdCacheContext: react.Context<AppIdCache | null>;
/** @internal */
interface ArrayValidationState {
  maxReached: boolean;
  maxReachedReason: string | undefined;
}
/** @internal */
declare const ArrayValidationContext: react.Context<ArrayValidationState | null>;
/**
 * @internal
 */
interface AssetLimitUpsellContextValue {
  upsellDialogOpen: boolean;
  handleOpenDialog: (source: UpsellDialogViewedInfo['source']) => void;
  upsellData: UpsellData | null;
  telemetryLogs: {
    dialogSecondaryClicked: () => void;
    dialogPrimaryClicked: () => void;
  };
}
/**
 * @internal
 */
declare const AssetLimitUpsellContext: react.Context<AssetLimitUpsellContextValue | null>;
interface CalendarContextValue {
  date?: Date;
  endDate?: Date;
  focusedDate: Date;
  selectRange?: boolean;
  selectTime?: boolean;
  /**
   * An integer indicating the first day of the week.
   * Can be either 1 (Monday), 6 (Saturday) or 7 (Sunday).
   */
  firstWeekDay: 1 | 6 | 7;
}
/**
 * @internal
 */
declare const CalendarContext: react.Context<CalendarContextValue | undefined>;
/**
 * @internal
 * @hidden
 */
type ChangeIndicatorTrackerContextStoreType = TrackerContextStore<ChangeIndicatorTrackerContextValue> | null;
/**
 * @internal
 * @hidden
 */
type ChangeIndicatorTrackerGetSnapshotType = TrackerContextGetSnapshot<ChangeIndicatorTrackerContextValue> | null;
/** @internal */
declare const ChangeIndicatorTrackerContextStore: react.Context<ChangeIndicatorTrackerContextStoreType>;
/** @internal */
declare const ChangeIndicatorTrackerContextGetSnapshot: react.Context<ChangeIndicatorTrackerGetSnapshotType>;
/**
 * The setter for ColorSchemeValueContext, in a separate context to avoid unnecessary re-renders
 * If set to false then the UI should adjust to reflect that the Studio can't change the color scheme
 * @internal
 */
declare const ColorSchemeSetValueContext: react.Context<false | ((nextScheme: StudioColorScheme) => void) | null>;
/**
 * Used to keep track of the internal value, which can be "system" in addition to "light" and "dark"
 * @internal
 */
declare const ColorSchemeValueContext: react.Context<StudioColorScheme | null>;
/**
 * @internal
 */
declare const CommentInputContext: react.Context<CommentInputContextValue | null>;
/**
 * @beta
 * @hidden
 */
declare const CommentsAuthoringPathContext: react.Context<CommentsAuthoringPathContextValue | null>;
/**
 * @internal
 */
declare const CommentsContext: react.Context<CommentsContextValue | null>;
/**
 * @internal
 */
declare const CommentsEnabledContext: react.Context<CommentsEnabledContextValue>;
/**
 * @internal
 */
declare const CommentsIntentContext: react.Context<CommentIntentGetter | undefined>;
/**
 * @internal
 */
declare const CommentsOnboardingContext: react.Context<CommentsOnboardingContextValue | null>;
/**
 * @internal
 */
declare const CommentsSelectedPathContext: react.Context<CommentsSelectedPathContextValue | null>;
/**
 * @internal
 */
declare const CommentsUpsellContext: react.Context<CommentsUpsellContextValue | null>;
/**
 * @beta
 * @hidden
 */
declare const CopyPasteContext: react.Context<CopyPasteContextType | null>;
/**
 * Entry in the dialog stack.
 *
 * @beta
 */
interface DialogStackEntry {
  id: string;
  path?: Path;
}
/**
 * Context value for tracking the dialog stack.
 *
 * @beta
 */
interface DialogStackContextValue {
  /** Stack of dialog entries, last one is the top */
  stack: DialogStackEntry[];
  /** Push a dialog onto the stack */
  push: (id: string, path?: Path) => void;
  /** Remove a dialog from the stack */
  remove: (id: string) => void;
  /** Update the path of an existing dialog entry */
  update: (id: string, path?: Path) => void;
  /** Close dialogs. Pass `{ toParent: true }` to close only the top dialog and navigate to the parent. */
  close: (options?: {
    /**
     * When true, closes only the top dialog and navigates to its parent path.
     * When false or omitted, closes all dialogs and resets to the root path.
     */
    toParent?: boolean;
  }) => void;
  /** Navigate to a specific path, updating the form path and cleaning up stack entries that are at or deeper than the target. */
  navigateTo: (path: Path) => void;
}
/**
 * Context for tracking the stack of open dialogs.
 *
 * @beta
 */
declare const DialogStackContext: react.Context<DialogStackContextValue | null>;
/** @internal */
declare const DiffContext: react.Context<{
  path: Path;
}>;
/**
 * @internal
 */
declare const DocumentActionPropsContext: react.Context<DocumentActionProps | undefined>;
/**
 * @internal
 */
declare const DocumentActionsStateContext: react.Context<DocumentActionDescription[] | null>;
/** @internal */
declare const DocumentChangeContext: react.Context<DocumentChangeContextInstance | null>;
/**
 * @internal
 */
interface DocumentFieldActionsContextValue {
  actions: DocumentFieldAction$1[];
}
/**
 * @internal
 */
declare const DocumentFieldActionsContext: react.Context<DocumentFieldActionsContextValue | null>;
/**
 * @internal
 */
interface DocumentIdContextValue {
  id: string;
}
/**
 * @internal
 */
declare const DocumentIdContext: react.Context<DocumentIdContextValue | null>;
/**
 * @internal
 */
interface DocumentLimitUpsellContextValue {
  upsellDialogOpen: boolean;
  handleOpenDialog: (source: UpsellDialogViewedInfo['source']) => void;
  handleClose: () => void;
  upsellData: UpsellData | null;
  telemetryLogs: {
    dialogSecondaryClicked: () => void;
    dialogPrimaryClicked: () => void;
    panelPrimaryClicked: () => void;
    panelSecondaryClicked: () => void;
  };
}
/**
 * @internal
 */
declare const DocumentLimitUpsellContext: react.Context<DocumentLimitUpsellContextValue | null>;
/** @internal */
declare const DocumentPaneContext: react.Context<DocumentPaneContextValue | null>;
/** @internal */
declare const DocumentPaneInfoContext: react.Context<DocumentPaneInfoContextValue | null>;
/** @internal */
interface DocumentSheetListContextValue {
  focusAnchorCell: () => void;
  resetFocusSelection: () => void;
  setSelectedAnchorCell: (colId: string, rowIndex: number) => void;
  getStateByCellId: (colId: string, rowIndex: number) => 'focused' | 'selectedAnchor' | 'selectedRange' | null;
  submitFocusedCell: () => void;
}
/** @internal */
declare const DocumentSheetListContext: react.Context<DocumentSheetListContextValue | undefined>;
/**
 * @internal
 * @deprecated This context is no longer used and will be removed in a future release as we make the enhanced object dialog the default.
 */
declare const EnhancedObjectDialogContext: react.Context<EnhancedObjectDialogContextValue>;
/**
 * @internal
 */
declare const EventsContext: react.Context<EventsStore | null>;
/** @internal */
interface FieldActionsContextValue {
  actions: DocumentFieldActionNode$1[];
  __internal_comments?: FieldCommentsProps;
  __internal_slot?: ReactNode;
  focused?: boolean;
  hovered: boolean;
  onMouseEnter: () => void;
  onMouseLeave: () => void;
}
/** @internal */
declare const FieldActionsContext: react.Context<FieldActionsContextValue>;
/**
 * @internal
 */
declare const FormBuilderContext: react.Context<FormBuilderContextValue | null>;
/**
 * @internal
 */
declare const FormCallbacksContext: react.Context<FormCallbacksValue | null>;
/** @internal */
declare const FormFieldPresenceContext: react.Context<FormNodePresence[]>;
/**
 * @internal
 */
declare const FormValueContext: react.Context<FormValueContextValue | null>;
interface FreeTrialResponse {
  id: string;
  icon: string;
  style: string;
  showOnLoad: FreeTrialDialog | null;
  showOnClick: FreeTrialDialog | null;
  daysLeft: number;
  totalDays: number;
}
interface FreeTrialDialog {
  _id: string;
  _type: 'dialog';
  _createdAt: string;
  ctaButton?: {
    text: string;
    action: 'openNext' | 'closeDialog' | 'openUrl';
    url?: string;
  };
  secondaryButton?: {
    text: string;
  };
  descriptionText: PortableTextBlock[];
  dialogType: 'modal' | 'popover';
  headingText: string;
  id: string;
  image: Image$1 | null;
  tags?: Tag[];
  _rev: string;
  _updatedAt: string;
}
interface Tag {
  _type: 'tag';
  _key: string;
  tag: string;
}
interface Image$1 {
  asset: {
    url: string;
    altText: string | null;
  };
}
/**
 * @internal
 */
interface FreeTrialContextProps {
  data: FreeTrialResponse | null;
  showDialog: boolean;
  showOnLoad: boolean;
  /**
   * If the user is seeing the `showOnLoad` popover or modal, and clicks on the pricing button the `showOnClick` modal should be triggered.
   */
  toggleShowContent: (closeAndReOpen?: boolean) => void;
}
/**
 * @internal
 */
declare const FreeTrialContext: react.Context<FreeTrialContextProps | undefined>;
/**
 * Context for tracking fullscreen state of portable text editors by their path
 * @internal
 */
interface FullscreenPTEContextValue {
  /**
   * Get the fullscreen state for a specific path
   */
  getFullscreenPath: (path: Path) => string | undefined;
  /**
   * Set the fullscreen state for a specific path
   */
  setFullscreenPath: (path: Path, isFullscreen: boolean) => void;
  /**
   * Check if any portable text editor is currently in fullscreen mode
   */
  hasAnyFullscreen: () => boolean;
  /**
   * Get all fullscreen paths
   */
  allFullscreenPaths: string[];
}
/**
 * @internal
 */
declare const FullscreenPTEContext: react.Context<FullscreenPTEContextValue>;
/**
 * @internal
 * @hidden
 */
type GetFormValueContextValue = (path: Path) => unknown;
/**
 * @internal
 */
declare const GetFormValueContext: react.Context<GetFormValueContextValue | null>;
/** @internal */
interface HoveredFieldContextValue {
  store: {
    subscribe: (onStoreCallback: () => void) => () => void;
    getSnapshot: () => string[];
  };
  onMouseEnter: (path: Path) => void;
  onMouseLeave: (path: Path) => void;
}
/** @internal */
declare const HoveredFieldContext: react.Context<HoveredFieldContextValue>;
/**
 * TODO: remove this context when alternate document-specific context are
 * introduced.
 *
 * The following context is used in the structure tool to set the active
 * document if it's the last pane open in the structure tool. This is a
 * temporary context provider that was introduced when the comments and tasks
 * plugins were refactor and decoupled from the structure tool. ideally this
 * should be removed and replaced with a document-specific context that gives
 * plugin authors access to what the `usePane`, `usePaneRouter`, and
 * `useDocumentPane` provides without exposing specifics from the structure tool
 */
/**
 * @internal
 */
declare const IsLastPaneContext: react.Context<boolean>;
/**
 * User application from the API
 * @internal
 */
interface UserApplication {
  id: string;
  type: string;
  projectId?: string;
  organizationId?: string;
  title?: string;
  urlType: 'internal' | 'external';
  appHost: string;
}
/**
 * Cache for user applications fetched from the API.
 * Caches by projectId to avoid duplicate fetches.
 * @internal
 */
interface UserApplicationCache {
  /**
   * Get user applications for a project.
   * Returns cached results if available, otherwise fetches from API.
   */
  get: (client: SanityClient) => Promise<UserApplication[]>;
}
/**
 * @hidden
 * @internal
 */
type LiveUserApplicationContextValue = {
  userApplication: UserApplication | undefined;
  isLoading: boolean;
};
/**
 *
 * @hidden
 * @internal
 */
declare const LiveUserApplicationContext: react.Context<LiveUserApplicationContextValue>;
/**
 * @internal
 * @hidden
 */
interface LocaleContextValue {
  locales: Locale[];
  currentLocale: Locale;
  __internal: {
    i18next: i18n;
  };
  changeLocale: (newLocale: string) => Promise<void>;
}
/**
 * @internal
 * @hidden
 */
declare const LocaleContext: react.Context<LocaleContextValue | undefined>;
/** @internal */
type MediaLibraryIds = {
  libraryId: string;
  organizationId: string;
};
/** @internal */
declare const MediaLibraryIdsContext: react.Context<MediaLibraryIds | null>;
/**
 * @internal
 */
declare const MentionUserContext: react.Context<MentionUserContextValue | null>;
/** @internal */
declare const NavbarContext: react.Context<NavbarContextValue>;
/**
 * @hidden
 * @internal
 */
type PackageVersionInfoContextValue = {
  /**
   * Request a new update check
   */
  checkForUpdates: () => void;
  /**
   * Status of version check (i.e. are we currently checking for updates)
   */
  versionCheckStatus: {
    lastCheckedAt: Date | null;
    checking: boolean;
  };
  /**
   * Whether this Studio is configured to be auto-updating
   */
  isAutoUpdating: boolean;
  /**
   * If an importmap for the sanity module exists in the DOM, includes details
   * will be undefined if no importmap is found
   */
  importMapInfo?: {
    valid: false;
    error: Error;
  } | {
    valid: true;
    minVersion: SemVer;
    appId?: string;
  };
  /**
   * What is the version tagged as latest (periodically checked)
   */
  latestTaggedVersion?: SemVer;
  /**
   * What version is the Studio currently running
   */
  currentVersion: SemVer;
  /**
   * What is the current auto-updating version (as periodically resolved via module server and configured via manage)
   */
  autoUpdatingVersion?: SemVer;
};
/**
 *
 * @hidden
 * @internal
 */
declare const PackageVersionInfoContext: react.Context<PackageVersionInfoContextValue>;
/**
 * @internal
 */
declare const PaneContext: react.Context<PaneContextValue | null>;
/**
 * @internal
 */
declare const PaneLayoutContext: react.Context<PaneLayoutContextValue | null>;
/**
 *
 * @hidden
 * @beta
 */
declare const PaneRouterContext: react.Context<PaneRouterContextValue>;
/**
 *
 * @hidden
 * @beta
 */
declare const PerspectiveContext: react.Context<PerspectiveContextValue | null>;
/**
 * @internal
 */
declare const PortableTextMarkersContext: react.Context<PortableTextMarker[]>;
/** @internal */
type PortableTextEditorElement = HTMLDivElement | HTMLSpanElement;
/**
 * @internal
 */
declare const PortableTextMemberItemElementRefsContext: react.Context<BehaviorSubject<Record<string, PortableTextEditorElement | null | undefined>>>;
/**
 * @internal
 */
declare const PortableTextMemberItemsContext: react.Context<PortableTextMemberItem[]>;
/**
 * Context for Sanity-specific schema types for Portable Text.
 * This provides access to the full Sanity schema types instead of relying on
 * `editor.schemaTypes` from PTE, which will contain minimal PT schema types
 * when PTE removes its Sanity dependencies.
 *
 * @internal
 */
declare const PortableTextMemberSchemaTypesContext: react.Context<PortableTextMemberSchemaTypes | null>;
/**
 * @internal
 */
declare const PresenceContext: react.Context<FormNodePresence[]>;
/**
 * @internal
 * @hidden
 */
type PresenceTrackerContextStoreType = TrackerContextStore<FieldPresenceData> | null;
/**
 * @internal
 * @hidden
 */
type PresenceTrackerGetSnapshotType = TrackerContextGetSnapshot<FieldPresenceData> | null;
/** @internal */
declare const PresenceTrackerContextStore: react.Context<PresenceTrackerContextStoreType>;
/** @internal */
declare const PresenceTrackerContextGetSnapshot: react.Context<PresenceTrackerGetSnapshotType>;
/**
 * @internal
 */
declare const PresentationContext: react.Context<PresentationContextValue | null>;
/** @internal */
type PresentationDisplayedDocumentContextValue = (displayed: Partial<SanityDocument$2> | null | undefined) => void;
/**
 * @internal
 */
declare const PresentationDisplayedDocumentContext: react.Context<PresentationDisplayedDocumentContextValue | null>;
interface PresentationDocumentContextValue {
  options: PresentationPluginOptions[];
  register: (options: PresentationPluginOptions) => () => void;
}
/**
 * @internal
 */
declare const PresentationDocumentContext: react.Context<PresentationDocumentContextValue | null>;
/**
 * @internal
 */
declare const PresentationNavigateContext: react.Context<PresentationNavigateContextValue | null>;
interface PanelElement {
  id: string;
  type: 'panel';
  defaultSize: number | null;
  order: number;
  maxWidth: number | null;
  minWidth: number;
}
interface ResizerElement {
  id: string;
  order: number;
  type: 'resizer';
  el: RefObject<HTMLDivElement | null>;
}
interface PresentationPanelsContextValue {
  activeResizer: string | null;
  drag: (id: string, event: MouseEvent) => void;
  getPanelStyle: (id: string) => React.CSSProperties;
  registerElement: (id: string, panel: PanelElement | ResizerElement) => void;
  startDragging: (id: string, event: MouseEvent) => void;
  stopDragging: () => void;
  unregisterElement: (id: string) => void;
}
/**
 * @internal
 */
declare const PresentationPanelsContext: react.Context<PresentationPanelsContextValue | null>;
/**
 * @internal
 */
declare const PresentationParamsContext: react.Context<PresentationParamsContextValue | null>;
interface PresentationSharedStateContextValue {
  removeValue: (key: string) => void;
  setValue: (key: string, value: Serializable) => void;
}
/**
 * @internal
 */
declare const PresentationSharedStateContext: react.Context<PresentationSharedStateContextValue | null>;
/**
 * @internal
 */
declare const PreviewCardContext: react.Context<PreviewCardContextValue>;
/**
 * @internal
 */
declare const ReferenceInputOptionsContext: react.Context<ReferenceInputOptions>;
/**
 * @internal
 */
interface ReferenceItemRef {
  menuRef: MutableRefObject<HTMLDivElement | null>;
  menuButtonRef: MutableRefObject<HTMLButtonElement | null>;
  containerRef: MutableRefObject<HTMLDivElement | null>;
}
/**
 * This is a way to store ref of the menu as well as the container of the ReferenceItem
 * so it can be used down the tree for clickOutside handling
 * @internal
 */
declare const ReferenceItemRefContext: react.Context<ReferenceItemRef | null>;
/**
 * @internal
 */
interface ReleasesMetadataContextValue {
  state: MetadataWrapper;
  addReleaseIdsToListener: (slugs: string[]) => void;
  removeReleaseIdsFromListener: (slugs: string[]) => void;
}
/**
 * @internal
 * @hidden
 */
declare const ReleasesMetadataContext: react.Context<ReleasesMetadataContextValue | null>;
type SortDirection = 'asc' | 'desc';
interface TableSort {
  column: string;
  direction: SortDirection;
}
/**
 * @internal
 */
interface TableContextValue {
  searchTerm: string | null;
  setSearchTerm: (searchTerm: string) => void;
  sort: TableSort | null;
  setSortColumn: (column: string) => void;
}
/**
 * @internal
 */
declare const TableContext: react.Context<TableContextValue | null>;
/**
 * @beta
 * @hidden
 */
declare const ReleasesUpsellContext: react.Context<ReleasesUpsellContextValue | null>;
declare const LOADING_PANE: unique symbol;
interface PaneData {
  active: boolean;
  childItemId: string | null;
  groupIndex: number;
  index: number;
  itemId: string;
  key: string;
  pane: PaneNode | typeof LOADING_PANE;
  params: Record<string, string | undefined> & {
    perspective?: string;
  };
  path: string;
  payload: unknown;
  selected: boolean;
  siblingIndex: number;
  maximized: boolean;
}
interface Panes {
  paneDataItems: PaneData[];
  routerPanes: RouterPanes;
  resolvedPanes: (PaneNode | typeof LOADING_PANE)[];
  maximizedPane: PaneData | null;
  setMaximizedPane: (pane: PaneData | null) => void;
}
/**
 * @internal
 */
declare const ResolvedPanesContext: react.Context<Panes | null>;
/**
 * @internal
 */
declare function ResolvedPanesProvider({
  children,
  value
}: {
  children: ReactNode;
  value: Panes;
}): react.JSX.Element;
/**
 * @internal
 */
declare const ResourceCacheContext: react.Context<ResourceCache | null>;
/** @internal */
declare const ReviewChangesContext: react.Context<ConnectorContextValue>;
/**
 * @internal
 */
declare const RouterContext: react.Context<RouterContextValue | null>;
/**
 * Internal use only. Userland should leverage the public `useRouter` APIs.
 * @internal
 */
declare const RouterHistoryContext: react.Context<RouterHistory | null>;
/**
 * @internal
 */
declare const SanityCreateConfigContext: react.Context<SanityCreateConfigContextValue>;
interface HasUsedScheduledPublishing {
  used: boolean;
  loading: boolean;
}
/**
 * @internal
 */
type ScheduledPublishingEnabledContextValue = {
  enabled: false;
  mode: null;
  hasUsedScheduledPublishing: HasUsedScheduledPublishing;
} | {
  enabled: true;
  mode: 'default' | 'upsell';
  hasUsedScheduledPublishing: HasUsedScheduledPublishing;
};
/**
 * @internal
 */
declare const ScheduledPublishingEnabledContext: react.Context<ScheduledPublishingEnabledContextValue>;
/**
 * @internal
 */
interface SchedulePublishUpsellContextValue {
  upsellDialogOpen: boolean;
  handleOpenDialog: (source: UpsellDialogViewedInfo['source']) => void;
  handleClose: () => void;
  upsellData: UpsellData | null;
  telemetryLogs: {
    dialogSecondaryClicked: () => void;
    dialogPrimaryClicked: () => void;
    panelViewed: (source: UpsellDialogViewedInfo['source']) => void;
    panelDismissed: () => void;
    panelPrimaryClicked: () => void;
    panelSecondaryClicked: () => void;
  };
}
/**
 * @internal
 */
declare const SchedulePublishUpsellContext: react.Context<SchedulePublishUpsellContextValue>;
/**
 * @deprecated we will be dropping support for scheduled publishing on a future major version
 * @internal
 */
declare const SchedulesContext: react.Context<SchedulesContextValue | undefined>;
/**
 * @internal
 */
declare const ScrollContext: react.Context<PubSub<Event> | null>;
/**
 * @internal
 */
declare const SearchContext: react.Context<SearchContextValue | undefined>;
/**
 * Entry representing a selected annotation for the combined popover
 * @internal
 */
interface AnnotationEntry {
  key: string;
  title: string;
  schemaType: ObjectSchemaType;
  onOpen: () => void;
  onRemove: () => void;
  referenceElement: HTMLElement | null;
}
/**
 * Context value for tracking selected annotations
 * @internal
 */
interface SelectedAnnotationsContextValue {
  register: (entry: AnnotationEntry) => void;
  unregister: (key: string) => void;
  annotations: AnnotationEntry[];
}
/**
 * Context for managing selected annotations in the Portable Text editor.
 * Used by CombinedAnnotationPopover to show all active annotations in a single popover.
 * @internal
 */
declare const SelectedAnnotationsContext: react.Context<SelectedAnnotationsContextValue | null>;
/**
 * @internal
 */
interface SingleDocReleaseContextValue {
  /**
   * Sets the scheduled draft perspective into the local router params.
   */
  onSetScheduledDraftPerspective: (releaseId: string) => void;
}
/**
 * @internal
 */
declare const SingleDocReleaseContext: react.Context<SingleDocReleaseContextValue | null>;
/**
 * @internal
 */
type SingleDocReleaseEnabledContextValue = {
  enabled: false;
  mode: null;
} | {
  enabled: true;
  mode: 'default' | 'upsell';
};
/**
 * @internal
 */
declare const SingleDocReleaseEnabledContext: react.Context<SingleDocReleaseEnabledContextValue>;
/**
 * @internal
 */
interface SingleDocReleaseUpsellContextValue {
  upsellDialogOpen: boolean;
  handleOpenDialog: (source: UpsellDialogViewedInfo['source']) => void;
  handleClose: () => void;
  upsellData: UpsellData | null;
  telemetryLogs: {
    dialogSecondaryClicked: () => void;
    dialogPrimaryClicked: () => void;
    panelViewed: (source: UpsellDialogViewedInfo['source']) => void;
    panelDismissed: () => void;
    panelPrimaryClicked: () => void;
    panelSecondaryClicked: () => void;
  };
}
/**
 * @internal
 */
declare const SingleDocReleaseUpsellContext: react.Context<SingleDocReleaseUpsellContextValue>;
/**
 * @internal
 */
declare const SortableItemIdContext: react.Context<string | null>;
/**
 * @internal
 */
declare const SourceContext: react.Context<Source$1 | null>;
/**
 * @internal
 */
declare const StructureToolContext: react.Context<StructureToolContextValue | null>;
/**
 * @internal
 */
declare const StudioAnnouncementContext: react.Context<StudioAnnouncementsContextValue | undefined>;
/**
 * @internal
 */
declare const TasksContext: react.Context<TasksContextValue | null>;
/**
 * @internal
 */
declare const TasksEnabledContext: react.Context<TasksEnabledContextValue>;
/**
 * @internal
 */
declare const TasksNavigationContext: react.Context<TasksNavigationContextValue | null>;
/**
 * @beta
 * @hidden
 */
declare const TasksUpsellContext: react.Context<TasksUpsellContextValue | null>;
/**
 * @internal
 */
declare const UserApplicationCacheContext: react.Context<UserApplicationCache | null>;
/**
 * @internal
 */
declare const UserColorManagerContext: react.Context<UserColorManager | null>;
/**
 * @internal
 */
declare const ValidationContext: react.Context<ValidationMarker[]>;
/**
 * This is used to store the reference to the scroll element for virtualizer
 * @internal
 */
declare const VirtualizerScrollInstanceContext: react.Context<VirtualizerScrollInstance | null>;
/**
 * @internal
 */
declare const WorkspaceContext: react.Context<Workspace | null>;
/** @internal */
declare const WorkspacesContext: react.Context<WorkspacesContextValue | null>;
/**
 * @internal
 */
declare const zIndexContextDefaults: ZIndexContextValue;
/**
 * TODO: Rename to `ZOffsetsContext`
 *
 * @internal
 */
declare const ZIndexContext: react.Context<ZIndexContextValue>;
export { ActiveWorkspaceMatcherContext, AddonDatasetContext, AnnotationEntry, AppIdCacheContext, ArrayValidationContext, AssetLimitUpsellContext, AssetLimitUpsellContextValue, CalendarContext, ChangeIndicatorTrackerContextGetSnapshot, ChangeIndicatorTrackerContextStore, ColorSchemeSetValueContext, ColorSchemeValueContext, CommentInputContext, CommentsAuthoringPathContext, CommentsContext, CommentsEnabledContext, CommentsIntentContext, CommentsOnboardingContext, CommentsSelectedPathContext, CommentsUpsellContext, CopyPasteContext, DialogStackContext, DialogStackContextValue, DialogStackEntry, DiffContext, DocumentActionPropsContext, DocumentActionsStateContext, DocumentChangeContext, DocumentFieldActionsContext, DocumentFieldActionsContextValue, DocumentIdContext, DocumentIdContextValue, DocumentLimitUpsellContext, DocumentLimitUpsellContextValue, DocumentPaneContext, DocumentPaneInfoContext, DocumentSheetListContext, EnhancedObjectDialogContext, EventsContext, FieldActionsContext, FieldActionsContextValue, FormBuilderContext, FormCallbacksContext, FormFieldPresenceContext, FormValueContext, FreeTrialContext, FullscreenPTEContext, GetFormValueContext, GetFormValueContextValue, HoveredFieldContext, HoveredFieldContextValue, IsLastPaneContext, LiveUserApplicationContext, LiveUserApplicationContextValue, LocaleContext, LocaleContextValue, MediaLibraryIdsContext, MentionUserContext, NavbarContext, PackageVersionInfoContext, PackageVersionInfoContextValue, PaneContext, PaneLayoutContext, PaneRouterContext, PerspectiveContext, PortableTextEditorElement, PortableTextMarkersContext, PortableTextMemberItemElementRefsContext, PortableTextMemberItemsContext, PortableTextMemberSchemaTypesContext, PresenceContext, PresenceTrackerContextGetSnapshot, PresenceTrackerContextStore, PresentationContext, PresentationDisplayedDocumentContext, PresentationDocumentContext, PresentationNavigateContext, PresentationPanelsContext, PresentationParamsContext, PresentationSharedStateContext, PreviewCardContext, ReferenceInputOptionsContext, ReferenceItemRef, ReferenceItemRefContext, ReleasesMetadataContext, ReleasesUpsellContext, ResolvedPanesContext, ResolvedPanesProvider, ResourceCacheContext, ReviewChangesContext, RouterContext, RouterHistoryContext, SanityCreateConfigContext, SchedulePublishUpsellContext, SchedulePublishUpsellContextValue, ScheduledPublishingEnabledContext, ScheduledPublishingEnabledContextValue, SchedulesContext, ScrollContext, SearchContext, SelectedAnnotationsContext, SelectedAnnotationsContextValue, SingleDocReleaseContext, SingleDocReleaseContextValue, SingleDocReleaseEnabledContext, SingleDocReleaseEnabledContextValue, SingleDocReleaseUpsellContext, SingleDocReleaseUpsellContextValue, SortableItemIdContext, SourceContext, StructureToolContext, StudioAnnouncementContext, TableContext, TasksContext, TasksEnabledContext, TasksNavigationContext, TasksUpsellContext, UserApplicationCacheContext, UserColorManagerContext, ValidationContext, VirtualizerScrollInstanceContext, WorkspaceContext, WorkspacesContext, ZIndexContext, zIndexContextDefaults };