import { C as PreviewUrlResolver, D as PreviewProps, E as PreviewHeaderProps, S as PreviewUrlOption, T as StructureDocumentPaneParams, _ as PresentationPerspective, a as DocumentLocationResolver, b as PresentationStateParams, c as DocumentLocationsState, d as HeaderOptions, f as InspectorTab, g as PresentationParamsContextValue, h as PresentationNavigateContextValue, i as DocumentLocation, l as DocumentResolver, n as ConnectionStatus, o as DocumentLocationResolverObject, p as NavigatorOptions, r as ContextFn, s as DocumentLocationResolvers, t as CombinedSearchParams, u as DocumentResolverContext, v as PresentationPluginOptions, w as PreviewUrlResolverOptions, x as PresentationViewport, y as PresentationSearchParams } from "./_chunks-dts/types2.js";
import * as sanity from "sanity";
import { Serializable, Serializable as Serializable$1, SerializableArray, SerializableObject, SerializablePrimitive } from "@sanity/presentation-comlink";
/** @public */
declare const useSharedState: (key: string, value: Serializable$1) => undefined;
/**
 * Define locations for a given document type.
 * This function doesn't do anything itself, it is used to provide type information.
 * @param resolver - resolver that return locations for a document.
 * @public
 */
declare function defineLocations<K extends string>(resolver: DocumentLocationResolverObject<K> | DocumentLocationsState): typeof resolver;
/**
 * Define documents for a given location.
 * This function doesn't do anything itself, it is used to provide type information.
 * @param resolvers - resolvers that return documents.
 * @public
 */
declare function defineDocuments(resolvers: DocumentResolver[]): typeof resolvers;
/** @public */
declare const presentationTool: sanity.Plugin<PresentationPluginOptions>;
/** @public */
declare function usePresentationNavigate(): PresentationNavigateContextValue;
/** @public */
declare function usePresentationParams(throwOnMissingContext?: true): PresentationParamsContextValue;
/** @public */
declare function usePresentationParams(throwOnMissingContext: false): PresentationParamsContextValue | null;
export { type CombinedSearchParams, type ConnectionStatus, type ContextFn, type DocumentLocation, type DocumentLocationResolver, type DocumentLocationResolverObject, type DocumentLocationResolvers, type DocumentLocationsState, type DocumentResolver, type DocumentResolverContext, type HeaderOptions, type InspectorTab, type NavigatorOptions, type PresentationNavigateContextValue, type PresentationParamsContextValue as PresentationParams, type PresentationPerspective, type PresentationPluginOptions, type PresentationSearchParams, type PresentationStateParams, type PresentationViewport, type PreviewHeaderProps, type PreviewProps, type PreviewUrlOption, type PreviewUrlResolver, type PreviewUrlResolverOptions, type Serializable, type SerializableArray, type SerializableObject, type SerializablePrimitive, type StructureDocumentPaneParams, defineDocuments, defineLocations, presentationTool, usePresentationNavigate, usePresentationParams, useSharedState };