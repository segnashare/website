import { ComponentType, ReactNode } from "react";
import { ObjectSchemaType, Path, SanityDocument, SanityDocumentLike, SchemaType, SortOrdering, SortOrderingItem, ValidationMarker } from "@sanity/types";
import { Observable } from "rxjs";
import { SearchParam } from "sanity/router";
import { ConfigContext, DocumentActionComponent, DocumentBadgeComponent, DocumentFieldAction, DocumentFieldActionNode, DocumentFormNode, DocumentInspector, DocumentLanguageFilterComponent, DocumentStore, EditStateFor, GeneralPreviewLayoutKey, I18nTextRecord as I18nTextRecord$1, InitialValueTemplateItem, LocaleSource, NodeChronologyProps, PatchEvent, PermissionCheckResult, PerspectiveStack, PreviewLayoutKey, ReleaseId, Source, StateTree, TimelineStore } from "sanity";
/**
 * Intent parameters (json)
 *
 * @public
 */
type IntentJsonParams = {
  [key: string]: any;
};
/**
 * Base intent parameters
 *
 * @public
 * @todo dedupe with core
 */
interface BaseIntentParams {
  /**
   * Document schema type name to create/edit.
   * Required for `create` intents, optional for `edit` (but encouraged, safer and faster)
   */
  type?: string;
  /**
   * ID of the document to create/edit.
   * Required for `edit` intents, optional for `create`.
   */
  id?: string;
  /**
   * Name (ID) of initial value template to use for `create` intent. Optional.
   */
  template?: string;
  /**
   * Experimental field path
   *
   * @beta
   * @experimental
   * @hidden
   */
  path?: string;
  /**
   * Optional "mode" to use for edit intent.
   * Known modes are `structure` and `presentation`.
   */
  mode?: string;
  /**
   * Arbitrary/custom parameters are generally discouraged - try to keep them to a minimum,
   * or use `payload` (arbitrary JSON-serializable object) instead.
   */
  [key: string]: string | undefined;
}
/** @internal */
declare const DEFAULT_INTENT_HANDLER: unique symbol;
/**
 * Intent parameters
 * See {@link structure.BaseIntentParams} and {@link structure.IntentJsonParams}
 *
 * @public
 */
type IntentParams = BaseIntentParams | [BaseIntentParams, IntentJsonParams];
/**
 * Interface for intents
 * @public */
interface Intent {
  /** Intent type */
  type: string;
  /** Intent parameters. See {@link IntentParams}
   */
  params?: IntentParams;
  searchParams?: SearchParam[];
}
/**
 * Interface for intent checker
 *
 * @public
 */
interface IntentChecker {
  (/** Intent name */intentName: string, /** Intent checker parameter */params: {
    [key: string]: any;
  }, /** Structure context. See {@link StructureNode} */context: {
    pane: StructureNode;
    index: number;
  }): boolean;
  /** intent checker identify */
  identity?: symbol;
}
declare function defaultIntentChecker(intentName: string, params: {
  [key: string]: any;
}, {
  pane
}: {
  pane: StructureNode;
  index: number;
}): boolean;
declare namespace defaultIntentChecker {
  var identity: symbol | undefined;
}
declare class DividerBuilder implements Serializable<Divider> {
  protected spec: Divider;
  constructor(spec?: Divider);
  /** Set the title of the divider
   * @param title - the title of the divider
   * @returns divider builder based on title provided
   */
  title(title: string): DividerBuilder;
  /** Get the title of the divider
   * @returns the title of the divider
   */
  getTitle(): Divider['title'];
  /** Set the i18n key and namespace used to populate the localized title.
   * @param i18n - the key and namespaced used to populate the localized title.
   * @returns divider builder based on i18n key and ns provided
   */
  i18n(i18n: I18nTextRecord$1<'title'>): DividerBuilder;
  /** Get i18n key and namespace used to populate the localized title
   * @returns the i18n key and namespace used to populate the localized title
   */
  getI18n(): I18nTextRecord$1<'title'> | undefined;
  /** Serialize the divider
   * @returns the serialized divider
   */
  serialize(): Divider;
  /** Clone divider builder (allows for options overriding)
   * @param withSpec - divider builder options
   * @returns cloned builder
   */
  clone(withSpec?: Partial<Divider>): DividerBuilder;
}
/**
 * Interface for component views.
 *
 * @public */
interface ComponentView<TOptions = Record<string, any>> extends BaseView {
  type: 'component';
  /** Component view components. See {@link UserViewComponent} */
  component: UserViewComponent;
  /** Component view options */
  options: TOptions;
}
/**
 * Class for building a component view.
 *
 * @public */
declare class ComponentViewBuilder extends GenericViewBuilder<Partial<ComponentView>, ComponentViewBuilder> {
  /** Partial Component view option object. See {@link ComponentView} */
  protected spec: Partial<ComponentView>;
  constructor(
  /**
   * Component view component or spec
   * @param componentOrSpec - user view component or partial component view. See {@link UserViewComponent} and {@link ComponentView}
   */

  componentOrSpec?: UserViewComponent | Partial<ComponentView>);
  /** Set view Component
   * @param component - component view component. See {@link UserViewComponent}
   * @returns component view builder based on component view provided. See {@link ComponentViewBuilder}
   */
  component(component: UserViewComponent): ComponentViewBuilder;
  /** Get view Component
   * @returns Partial component view. See {@link ComponentView}
   */
  getComponent(): Partial<ComponentView>['component'];
  /** Set view Component options
   * @param options - component view options
   * @returns component view builder based on options provided. See {@link ComponentViewBuilder}
   */
  options(options: {
    [key: string]: any;
  }): ComponentViewBuilder;
  /** Get view Component options
   * @returns component view options. See {@link ComponentView}
   */
  getOptions(): ComponentView['options'];
  /** Serialize view Component
   * @param options - serialization options. See {@link SerializeOptions}
   * @returns component view based on path provided in options. See {@link ComponentView}
   *
   */
  serialize(options?: SerializeOptions): ComponentView;
  /** Clone Component view builder (allows for options overriding)
   * @param withSpec - partial for component view option. See {@link ComponentView}
   * @returns component view builder. See {@link ComponentViewBuilder}
   */
  clone(withSpec?: Partial<ComponentView>): ComponentViewBuilder;
}
/**
 * Interface for form views.
 *
 * @public */
interface FormView extends BaseView {
  type: 'form';
}
/**
 * Class for building a form view.
 *
 * @public */
declare class FormViewBuilder extends GenericViewBuilder<Partial<BaseView>, FormViewBuilder> {
  /** Document list options. See {@link FormView} */
  protected spec: Partial<FormView>;
  constructor(spec?: Partial<FormView>);
  /**
   * Serialize Form view builder
   * @param options - Serialize options. See {@link SerializeOptions}
   * @returns form view builder based on path provided in options. See {@link FormView}
   */
  serialize(options?: SerializeOptions): FormView;
  /**
   * Clone Form view builder (allows for options overriding)
   * @param withSpec - Partial form view builder options. See {@link FormView}
   * @returns form view builder. See {@link FormViewBuilder}
   */
  clone(withSpec?: Partial<FormView>): FormViewBuilder;
}
/**
 * Interface for base view
 *
 * @public */
interface BaseView {
  /** View id */
  id: string;
  /** View Title */
  title: string;
  /** View Icon */
  icon?: React.ComponentType | React.ReactNode;
}
/**
 * Class for building generic views.
 *
 * @public
 */
declare abstract class GenericViewBuilder<TView extends Partial<BaseView>, ConcreteImpl> implements Serializable<BaseView> {
  /** Generic view option object */
  protected spec: TView;
  /** Set generic view ID
   * @param id - generic view ID
   * @returns generic view builder based on ID provided.
   */
  id(id: string): ConcreteImpl;
  /** Get generic view ID
   * @returns generic view ID
   */
  getId(): TView['id'];
  /** Set generic view title
   * @param title - generic view title
   * @returns generic view builder based on title provided and (if provided) its ID.
   */
  title(title: string): ConcreteImpl;
  /** Get generic view title
   * @returns generic view title
   */
  getTitle(): TView['title'];
  /** Set generic view icon
   * @param icon - generic view icon
   * @returns generic view builder based on icon provided.
   */
  icon(icon: React.ComponentType | React.ReactNode): ConcreteImpl;
  /** Get generic view icon
   * @returns generic view icon
   */
  getIcon(): TView['icon'];
  /** Serialize generic view
   * @param options - serialization options. See {@link SerializeOptions}
   * @returns generic view object based on path provided in options. See {@link BaseView}
   */
  serialize(options?: SerializeOptions): BaseView;
  /** Clone generic view builder (allows for options overriding)
   * @param withSpec - Partial generic view builder options. See {@link BaseView}
   * @returns Generic view builder.
   */
  abstract clone(withSpec?: Partial<BaseView>): ConcreteImpl;
}
/** @internal */
declare function maybeSerializeView(item: View | Serializable<View>, index: number, path: SerializePath): View;
/**
 * View builder. See {@link ComponentViewBuilder} and {@link FormViewBuilder}
 *
 * @public
 */
type ViewBuilder = ComponentViewBuilder | FormViewBuilder;
/**
 * Interface for options of Partial Documents. See {@link PartialDocumentNode}
 *
 * @public */
interface DocumentOptions {
  /** Document Id */
  id: string;
  /** Document Type */
  type: string;
  /** Document Template */
  template?: string;
  /** Template parameters */
  templateParameters?: Record<string, unknown>;
}
/**
 * Interface for partial document (focused on the document pane)
 *
 * @public */
interface PartialDocumentNode {
  /** Document Id */
  id?: string;
  /** Document title */
  title?: string;
  /** I18n key and namespace used to populate the localized title */
  i18n?: I18nTextRecord$1<'title'>;
  /** Document children of type {@link Child} */
  child?: Child;
  /**
   * Views for the document pane. See {@link ViewBuilder} and {@link View}
   */
  views?: (View | ViewBuilder)[];
  /**
   * Document options. See {@link DocumentOptions}
   */
  options?: Partial<DocumentOptions>;
  /**
   * View IDs to open as split panes by default when the document is opened.
   * Pass an array of view IDs that match the IDs defined in `views`.
   * If specified with 2+ valid view IDs, the document will open in split-pane mode.
   */
  defaultPanes?: string[];
}
/**
 * A `DocumentBuilder` is used to build a document node.
 *
 * @public */
declare class DocumentBuilder implements Serializable<DocumentNode> {
  /** Component builder option object See {@link PartialDocumentNode} */
  protected spec: PartialDocumentNode;
  protected _context: StructureContext;
  constructor(
  /**
   * Structure context. See {@link StructureContext}
   */

  _context: StructureContext, spec?: PartialDocumentNode);
  /** Set Document Builder ID
   * @param id - document builder ID
   * @returns document builder based on ID provided. See {@link DocumentBuilder}
   */
  id(id: string): DocumentBuilder;
  /** Get Document Builder ID
   * @returns document ID. See {@link PartialDocumentNode}
   */
  getId(): PartialDocumentNode['id'];
  /** Set Document title
   * @param title - document title
   * @returns document builder based on title provided (and ID). See {@link DocumentBuilder}
   */
  title(title: string): DocumentBuilder;
  /** Get Document title
   * @returns document title. See {@link PartialDocumentNode}
   */
  getTitle(): PartialDocumentNode['title'];
  /** Set the i18n key and namespace used to populate the localized title.
   * @param i18n - the key and namespaced used to populate the localized title.
   * @returns component builder based on i18n key and ns provided
   */
  i18n(i18n: I18nTextRecord$1<'title'>): DocumentBuilder;
  /** Get i18n key and namespace used to populate the localized title
   * @returns the i18n key and namespace used to populate the localized title
   */
  getI18n(): I18nTextRecord$1<'title'> | undefined;
  /** Set Document child
   * @param child - document child
   * @returns document builder based on child provided. See {@link DocumentBuilder}
   */
  child(child: Child): DocumentBuilder;
  /** Get Document child
   * @returns document child. See {@link PartialDocumentNode}
   */
  getChild(): PartialDocumentNode['child'];
  /** Set Document ID
   * @param documentId - document ID
   * @returns document builder with document based on ID provided. See {@link DocumentBuilder}
   */
  documentId(documentId: string): DocumentBuilder;
  /** Get Document ID
   * @returns document ID. See {@link DocumentOptions}
   */
  getDocumentId(): Partial<DocumentOptions>['id'];
  /** Set Document Type
   * @param documentType - document type
   * @returns document builder with document based on type provided. See {@link DocumentBuilder}
   */
  schemaType(documentType: SchemaType | string): DocumentBuilder;
  /** Get Document Type
   * @returns document type. See {@link DocumentOptions}
   */
  getSchemaType(): Partial<DocumentOptions>['type'];
  /** Set Document Template
   * @param templateId - document template ID
   * @param parameters - document template parameters
   * @returns document builder with document based on template provided. See {@link DocumentBuilder}
   */
  initialValueTemplate(templateId: string, parameters?: Record<string, unknown>): DocumentBuilder;
  /** Get Document Template
   * @returns document template. See {@link DocumentOptions}
   */
  getInitialValueTemplate(): Partial<DocumentOptions>['template'];
  /** Get Document's initial value Template parameters
   * @returns document template parameters. See {@link DocumentOptions}
   */
  getInitialValueTemplateParameters(): Partial<DocumentOptions>['templateParameters'];
  /** Set Document views
   * @param views - document views. See {@link ViewBuilder} and {@link View}
   * @returns document builder with document based on views provided. See {@link DocumentBuilder}
   */
  views(views: (View | ViewBuilder)[]): DocumentBuilder;
  /** Get Document views
   * @returns document views. See {@link ViewBuilder} and {@link View}
   */
  getViews(): (View | ViewBuilder)[];
  /**
   * Set the view IDs to open as split panes by default when the document is opened.
   * Pass an array of view IDs that match the IDs defined in `views()`.
   * If specified with 2+ valid view IDs, the document will open in split-pane mode.
   *
   * @param viewIds - Array of view IDs to open as split panes
   * @returns document builder with defaultPanes config. See {@link DocumentBuilder}
   *
   * @example
   * ```ts
   * S.document()
   *   .schemaType('article')
   *   .views([
   *     S.view.form().id('editor'),
   *     S.view.component(PreviewPane).id('preview').title('Preview')
   *   ])
   *   .defaultPanes(['editor', 'preview'])  // Opens both as split panes
   * ```
   */
  defaultPanes(viewIds: string[]): DocumentBuilder;
  /** Serialize Document builder
   * @param options - serialization options. See {@link SerializeOptions}
   * @returns document node based on path, index and hint provided in options. See {@link DocumentNode}
   */
  serialize({
    path,
    index,
    hint
  }?: SerializeOptions): DocumentNode;
  /** Clone Document builder
   * @param withSpec - partial document node specification used to extend the cloned builder. See {@link PartialDocumentNode}
   * @returns document builder based on context and spec provided. See {@link DocumentBuilder}
   */
  clone(withSpec?: PartialDocumentNode): DocumentBuilder;
}
/** @internal */
declare function documentFromEditor(context: StructureContext, spec?: EditorNode): DocumentBuilder;
/** @internal */
declare function documentFromEditorWithInitialValue({
  resolveDocumentNode,
  templates
}: StructureContext, templateId: string, parameters?: Record<string, unknown>): DocumentBuilder;
/**
 * A `InitialValueTemplateItemBuilder` is used to build a document node with an initial value set.
 *
 * @public
 */
declare class InitialValueTemplateItemBuilder implements Serializable<InitialValueTemplateItem> {
  /** Initial Value template item option object. See {@link InitialValueTemplateItem} */
  protected spec: Partial<InitialValueTemplateItem>;
  protected _context: StructureContext;
  constructor(
  /**
   * Structure context. See {@link StructureContext}
   */

  _context: StructureContext, spec?: Partial<InitialValueTemplateItem>);
  /** Set initial value template item builder ID
   * @param id - initial value template item ID
   * @returns initial value template item based on ID provided. See {@link InitialValueTemplateItemBuilder}
   */
  id(id: string): InitialValueTemplateItemBuilder;
  /** Get initial value template item builder ID
   * @returns initial value template item ID. See {@link InitialValueTemplateItem}
   */
  getId(): Partial<InitialValueTemplateItem>['id'];
  /** Set initial value template item title
   * @param title - initial value template item title
   * @returns initial value template item based on title provided. See {@link InitialValueTemplateItemBuilder}
   */
  title(title: string): InitialValueTemplateItemBuilder;
  /** Get initial value template item title
   * @returns initial value template item title. See {@link InitialValueTemplateItem}
   */
  getTitle(): Partial<InitialValueTemplateItem>['title'];
  /** Set initial value template item description
   * @param description - initial value template item description
   * @returns initial value template item builder based on description provided. See {@link InitialValueTemplateItemBuilder}
   */
  description(description: string): InitialValueTemplateItemBuilder;
  /** Get initial value template item description
   * @returns initial value template item description. See {@link InitialValueTemplateItem}
   */
  getDescription(): Partial<InitialValueTemplateItem>['description'];
  /** Set initial value template ID
   * @param templateId - initial value template item template ID
   * @returns initial value template item based builder on template ID provided. See {@link InitialValueTemplateItemBuilder}
   */
  templateId(templateId: string): InitialValueTemplateItemBuilder;
  /** Get initial value template item template ID
   * @returns initial value template item ID. See {@link InitialValueTemplateItem}
   */
  getTemplateId(): Partial<InitialValueTemplateItem>['templateId'];
  /** Get initial value template item template parameters
   * @param parameters - initial value template item parameters
   * @returns initial value template item builder based on parameters provided. See {@link InitialValueTemplateItemBuilder}
   */
  parameters(parameters: {
    [key: string]: any;
  }): InitialValueTemplateItemBuilder;
  /** Get initial value template item template parameters
   * @returns initial value template item parameters. See {@link InitialValueTemplateItem}
   */
  getParameters(): Partial<InitialValueTemplateItem>['parameters'];
  /** Serialize initial value template item
   * @param options - serialization options. See {@link SerializeOptions}
   * @returns initial value template item object based on the path, index and hint provided in options. See {@link InitialValueTemplateItem}
   */
  serialize({
    path,
    index,
    hint
  }?: SerializeOptions): InitialValueTemplateItem;
  /** Clone generic view builder (allows for options overriding)
   * @param withSpec - initial value template item builder options. See {@link InitialValueTemplateItemBuilder}
   * @returns initial value template item builder based on the context and options provided. See {@link InitialValueTemplateItemBuilder}
   */
  clone(withSpec?: Partial<InitialValueTemplateItem>): InitialValueTemplateItemBuilder;
}
/** @internal */
declare function defaultInitialValueTemplateItems(context: StructureContext): InitialValueTemplateItemBuilder[];
/** @internal */
declare function maybeSerializeInitialValueTemplateItem(item: InitialValueTemplateItem | InitialValueTemplateItemBuilder, index: number, path: SerializePath): InitialValueTemplateItem;
/** @internal */
declare function menuItemsFromInitialValueTemplateItems(context: StructureContext, templateItems: InitialValueTemplateItem[]): MenuItem[];
/** @internal */
declare function maybeSerializeMenuItemGroup(item: MenuItemGroup | MenuItemGroupBuilder, index: number, path: SerializePath): MenuItemGroup;
/**
 * Interface for menu item groups
 * @public
 */
interface MenuItemGroup {
  /** Menu group Id */
  id: string;
  /** Menu group title */
  title: string;
  i18n?: I18nTextRecord$1<'title'>;
}
/**
 * Class for building menu item groups.
 *
 * @public
 */
declare class MenuItemGroupBuilder implements Serializable<MenuItemGroup> {
  /** Menu item group ID */
  protected _id: string;
  /** Menu item group title */
  protected _title: string;
  protected _i18n?: I18nTextRecord$1<'title'>;
  protected _context: StructureContext;
  constructor(
  /**
   * Structure context. See {@link StructureContext}
   */

  _context: StructureContext, spec?: MenuItemGroup);
  /**
   * Set menu item group ID
   * @param id - menu item group ID
   * @returns menu item group builder based on ID provided. See {@link MenuItemGroupBuilder}
   */
  id(id: string): MenuItemGroupBuilder;
  /**
   * Get menu item group ID
   * @returns menu item group ID
   */
  getId(): string;
  /**
   * Set menu item group title
   * @param title - menu item group title
   * @returns menu item group builder based on title provided. See {@link MenuItemGroupBuilder}
   */
  title(title: string): MenuItemGroupBuilder;
  /**
   * Get menu item group title
   * @returns menu item group title
   */
  getTitle(): string;
  /**
   * Set the i18n key and namespace used to populate the localized title.
   * @param i18n - object with i18n key and related namespace
   * @returns menu item group builder based on i18n info provided. See {@link MenuItemGroupBuilder}
   */
  i18n(i18n: I18nTextRecord$1<'title'>): MenuItemGroupBuilder;
  /**
   * Get the i18n key and namespace used to populate the localized title.
   * @returns the i18n key and namespace used to populate the localized title.
   */
  getI18n(): I18nTextRecord$1<'title'> | undefined;
  /**
   * Serialize menu item group builder
   * @param options - serialization options (path). See {@link SerializeOptions}
   * @returns menu item group based on path provided in options. See {@link MenuItemGroup}
   */
  serialize(options?: SerializeOptions): MenuItemGroup;
}
/** @internal */
declare const shallowIntentChecker: IntentChecker;
/**
 * Interface for list display options
 *
 * @public */
interface ListDisplayOptions {
  /** Check if list display should show icons */
  showIcons?: boolean;
}
/**
 * Interface for base generic list
 *
 * @public
 */
interface BaseGenericList extends StructureNode {
  /** List layout key. */
  defaultLayout?: PreviewLayoutKey;
  /** Can handle intent. See {@link IntentChecker} */
  canHandleIntent?: IntentChecker;
  /** List display options. See {@link ListDisplayOptions} */
  displayOptions?: ListDisplayOptions;
  /** List child. See {@link Child} */
  child: Child;
  /** List initial values array. See {@link InitialValueTemplateItem} and {@link InitialValueTemplateItemBuilder} */
  initialValueTemplates?: (InitialValueTemplateItem | InitialValueTemplateItemBuilder)[];
}
/**
 * Interface for generic list
 *
 * @public
 */
interface GenericList extends BaseGenericList {
  /** List type */
  type: string;
  /** List menu items array. See {@link MenuItem} */
  menuItems: MenuItem[];
  /** List menu item groups array. See {@link MenuItemGroup} */
  menuItemGroups: MenuItemGroup[];
}
/**
 * Interface for buildable generic list
 *
 * @public
 */
interface BuildableGenericList extends Partial<BaseGenericList> {
  /** List menu items array. See {@link MenuItem} and {@link MenuItemBuilder} */
  menuItems?: (MenuItem | MenuItemBuilder)[];
  /** List menu items groups array. See {@link MenuItemGroup} and {@link MenuItemGroupBuilder} */
  menuItemGroups?: (MenuItemGroup | MenuItemGroupBuilder)[];
}
/**
 * Interface for generic list input
 * Allows builders and only requires things not inferrable
 *
 * @public */
interface GenericListInput extends StructureNode {
  /** Input id */
  id: string;
  /** Input title */
  title: string;
  /** Input menu items groups. See {@link MenuItem} and {@link MenuItemBuilder} */
  menuItems?: (MenuItem | MenuItemBuilder)[];
  /** Input menu items groups. See {@link MenuItemGroup} and {@link MenuItemGroupBuilder} */
  menuItemGroups?: (MenuItemGroup | MenuItemGroupBuilder)[];
  /** Input initial value array. See {@link InitialValueTemplateItem} and {@link InitialValueTemplateItemBuilder} */
  initialValueTemplates?: (InitialValueTemplateItem | InitialValueTemplateItemBuilder)[];
  /** Input default layout. */
  defaultLayout?: PreviewLayoutKey;
  /** If input can handle intent. See {@link IntentChecker} */
  canHandleIntent?: IntentChecker;
  /** Input child of type {@link Child} */
  child?: Child;
}
/**
 * Class for building generic lists
 *
 * @public
 */
declare abstract class GenericListBuilder<TList extends BuildableGenericList, ConcreteImpl> implements Serializable<GenericList> {
  /** Check if initial value templates are set */
  protected initialValueTemplatesSpecified: boolean;
  /** Generic list option object */
  protected spec: TList;
  /** Set generic list ID
   * @param id - generic list ID
   * @returns generic list builder based on ID provided.
   */
  id(id: string): ConcreteImpl;
  /** Get generic list ID
   * @returns generic list ID
   */
  getId(): TList['id'];
  /** Set generic list title
   * @param title - generic list title
   * @returns generic list builder based on title and ID provided.
   */
  title(title: string): ConcreteImpl;
  /** Get generic list title
   * @returns generic list title
   */
  getTitle(): TList['title'];
  /** Set the i18n key and namespace used to populate the localized title.
   * @param i18n - the key and namespaced used to populate the localized title.
   * @returns component builder based on i18n key and ns provided
   */
  i18n(i18n: I18nTextRecord$1<'title'>): ConcreteImpl;
  /** Get i18n key and namespace used to populate the localized title
   * @returns the i18n key and namespace used to populate the localized title
   */
  getI18n(): TList['i18n'];
  /** Set generic list layout
   * @param defaultLayout - generic list layout key.
   * @returns generic list builder based on layout provided.
   */
  defaultLayout(defaultLayout: PreviewLayoutKey): ConcreteImpl;
  /** Get generic list layout
   * @returns generic list layout
   */
  getDefaultLayout(): TList['defaultLayout'];
  /** Set generic list menu items
   * @param menuItems - generic list menu items. See {@link MenuItem} and {@link MenuItemBuilder}
   * @returns generic list builder based on menu items provided.
   */
  menuItems(menuItems: (MenuItem | MenuItemBuilder)[] | undefined): ConcreteImpl;
  /** Get generic list menu items
   * @returns generic list menu items
   */
  getMenuItems(): TList['menuItems'];
  /** Set generic list menu item groups
   * @param menuItemGroups - generic list menu item groups. See {@link MenuItemGroup} and {@link MenuItemGroupBuilder}
   * @returns generic list builder based on menu item groups provided.
   */
  menuItemGroups(menuItemGroups: (MenuItemGroup | MenuItemGroupBuilder)[]): ConcreteImpl;
  /** Get generic list menu item groups
   * @returns generic list menu item groups
   */
  getMenuItemGroups(): TList['menuItemGroups'];
  /** Set generic list child
   * @param child - generic list child. See {@link Child}
   * @returns generic list builder based on child provided (clone).
   */
  child(child: Child): ConcreteImpl;
  /** Get generic list child
   * @returns generic list child
   */
  getChild(): TList['child'];
  /** Set generic list can handle intent
   * @param canHandleIntent - generic list intent checker. See {@link IntentChecker}
   * @returns generic list builder based on can handle intent provided.
   */
  canHandleIntent(canHandleIntent?: IntentChecker): ConcreteImpl;
  /** Get generic list can handle intent
   * @returns generic list can handle intent
   */
  getCanHandleIntent(): TList['canHandleIntent'];
  /** Set generic list display options
   * @param enabled - allow / disallow for showing icons
   * @returns generic list builder based on display options (showIcons) provided.
   */
  showIcons(enabled?: boolean): ConcreteImpl;
  /** Get generic list display options
   * @returns generic list display options (specifically showIcons)
   */
  getShowIcons(): boolean | undefined;
  /** Set generic list initial value templates
   * @param templates - generic list initial value templates. See {@link InitialValueTemplateItemBuilder}
   * @returns generic list builder based on templates provided.
   */
  initialValueTemplates(templates: InitialValueTemplateItem | InitialValueTemplateItemBuilder | Array<InitialValueTemplateItem | InitialValueTemplateItemBuilder>): ConcreteImpl;
  /** Get generic list initial value templates
   * @returns generic list initial value templates
   */
  getInitialValueTemplates(): TList['initialValueTemplates'];
  /** Serialize generic list
   * @param options - serialization options. See {@link SerializeOptions}
   * @returns generic list object based on path provided in options. See {@link GenericList}
   */
  serialize(options?: SerializeOptions): GenericList;
  /** Clone generic list builder (allows for options overriding)
   * @param _withSpec - generic list options.
   * @returns generic list builder.
   */
  abstract clone(_withSpec?: object): ConcreteImpl;
}
/**
 * Partial document list
 *
 * @public
 */
interface PartialDocumentList extends BuildableGenericList {
  /** Document list options. See {@link DocumentListOptions} */
  options?: DocumentListOptions;
  /** Schema type name */
  schemaTypeName?: string;
}
/**
 * Interface for document list input
 *
 * @public
 */
interface DocumentListInput extends GenericListInput {
  /** Document list options. See {@link DocumentListOptions} */
  options: DocumentListOptions;
}
/**
 * Interface for document list
 *
 * @public
 */
interface DocumentList extends GenericList {
  type: 'documentList';
  /** Document list options. See {@link DocumentListOptions} */
  options: DocumentListOptions;
  /** Document list child. See {@link Child} */
  child: Child;
  /** Document schema type name */
  schemaTypeName?: string;
}
/**
 * Interface for document List options
 *
 * @public
 */
interface DocumentListOptions {
  /** Document list filter */
  filter: string;
  /** Document list parameters */
  params?: Record<string, unknown>;
  /** Document list API version */
  apiVersion?: string;
  /** Document list API default ordering array. */
  defaultOrdering?: SortOrderingItem[];
}
/**
 * Class for building document list
 *
 * @public
 */
declare class DocumentListBuilder extends GenericListBuilder<PartialDocumentList, DocumentListBuilder> {
  /** Document list options. See {@link PartialDocumentList} */
  protected spec: PartialDocumentList;
  protected _context: StructureContext;
  constructor(
  /**
   * Structure context. See {@link StructureContext}
   */

  _context: StructureContext, spec?: DocumentListInput);
  /** Set API version
   * @param apiVersion - API version
   * @returns document list builder based on the options and API version provided. See {@link DocumentListBuilder}
   */
  apiVersion(apiVersion: string): DocumentListBuilder;
  /** Get API version
   * @returns API version
   */
  getApiVersion(): string | undefined;
  /** Set Document list filter
   * @param filter - GROQ-filter used to determine which documents to display. Do not support joins, since they operate on individual documents, and will ignore order-clauses and projections. See {@link https://www.sanity.io/docs/realtime-updates}
   * @returns document list builder based on the options and filter provided. See {@link DocumentListBuilder}
   */
  filter(filter: string): DocumentListBuilder;
  /** Get Document list filter
   * @returns filter
   */
  getFilter(): string | undefined;
  /** Set Document list schema type name
   * @param type - schema type name.
   * @returns document list builder based on the schema type name provided. See {@link DocumentListBuilder}
   */
  schemaType(type: SchemaType | string): DocumentListBuilder;
  /** Get Document list schema type name
   * @returns schema type name
   */
  getSchemaType(): string | undefined;
  /** Set Document list options' parameters
   * @param params - parameters
   * @returns document list builder based on the options provided. See {@link DocumentListBuilder}
   */
  params(params: Record<string, unknown>): DocumentListBuilder;
  /** Get Document list options' parameters
   * @returns options
   */
  getParams(): Record<string, unknown> | undefined;
  /** Set Document list default ordering
   * @param ordering - default sort ordering array. See {@link SortOrderingItem}
   * @returns document list builder based on ordering provided. See {@link DocumentListBuilder}
   */
  defaultOrdering(ordering: SortOrderingItem[]): DocumentListBuilder;
  /** Get Document list default ordering
   * @returns default ordering. See {@link SortOrderingItem}
   */
  getDefaultOrdering(): SortOrderingItem[] | undefined;
  /** Serialize Document list
   * @param options - serialization options. See {@link SerializeOptions}
   * @returns document list object based on path provided in options. See {@link DocumentList}
   */
  serialize(options?: SerializeOptions): DocumentList;
  /** Clone Document list builder (allows for options overriding)
   * @param withSpec - override document list spec. See {@link PartialDocumentList}
   * @returns document list builder. See {@link DocumentListBuilder}
   */
  clone(withSpec?: PartialDocumentList): DocumentListBuilder;
  /** Get Document list spec
   * @returns document list spec. See {@link PartialDocumentList}
   */
  getSpec(): PartialDocumentList;
}
/** @internal */
declare function getTypeNamesFromFilter(filter: string, params?: Record<string, unknown>): string[];
/**
 * Unserialized list item child.
 * See {@link Collection}, {@link CollectionBuilder}, {@link ChildResolver} and {@link ItemChild}
 *
 * @public
 */
type UnserializedListItemChild = Collection | CollectionBuilder | ChildResolver | Observable<ItemChild>;
/**
 * Child of List Item
 * See {@link Collection}, {@link ChildResolver}, {@link ItemChild}
 * @public
 */
type ListItemChild = Collection | ChildResolver | Observable<ItemChild> | undefined;
/**
 * Interface for serialize list item options
 *
 * @public
 */
interface ListItemSerializeOptions extends SerializeOptions {
  /** Check if list item title is optional */
  titleIsOptional?: boolean;
}
/**
 * Interface for ist item display options
 *
 * @public */
interface ListItemDisplayOptions {
  /** Check if list item display should show icon */
  showIcon?: boolean;
}
/**
 * interface for list item input
 *
 * @public */
interface ListItemInput {
  /** List item id */
  id: string;
  /** List item title */
  title?: string;
  /** List item icon */
  icon?: React.ComponentType | React.ReactNode;
  /** List item child. See {@link ListItemChild} */
  child?: ListItemChild;
  /** List item display options. See {@link ListItemDisplayOptions} */
  displayOptions?: ListItemDisplayOptions;
  /** List item schema type. See {@link SchemaType} */
  schemaType?: SchemaType | string;
}
/**
 * Interface for List Item
 *
 * @public */
interface ListItem {
  /** List item id */
  id: string;
  /** List item type */
  type: string;
  /**
   * The i18n key and namespace used to populate the localized title. This is
   * the recommend way to set the title if you are localizing your studio.
   */
  i18n?: I18nTextRecord$1<'title'>;
  /** List item title. Note that the `i18n` key and namespace will take precedence. */
  title?: string;
  /** List item icon */
  icon?: React.ComponentType | React.ReactNode;
  /** List item child. See {@link ListItemChild} */
  child?: ListItemChild;
  /** List item display options. See {@link ListItemDisplayOptions} */
  displayOptions?: ListItemDisplayOptions;
  /** List item schema type. See {@link SchemaType} */
  schemaType?: SchemaType;
}
/**
 * Interface for unserialized list items.
 *
 * @public
 */
interface UnserializedListItem {
  /** List item ID */
  id: string;
  /** List item title */
  title: string;
  /**
   * The i18n key and namespace used to populate the localized title. This is
   * the recommend way to set the title if you are localizing your studio.
   */
  i18n?: I18nTextRecord$1<'title'>;
  /** List item icon */
  icon?: React.ComponentType | React.ReactNode;
  /** List item child. See {@link UnserializedListItemChild} */
  child?: UnserializedListItemChild;
  /** List item display options. See {@link ListItemDisplayOptions} */
  displayOptions?: ListItemDisplayOptions;
  /** List item schema. See {@link SchemaType} */
  schemaType?: SchemaType | string;
}
/**
 * Partial list item. See {@link UnserializedListItem}
 *
 * @public */
type PartialListItem = Partial<UnserializedListItem>;
/**
 * Class for building list items
 *
 * @public */
declare class ListItemBuilder implements Serializable<ListItem> {
  /** List item option object. See {@link PartialListItem} */
  protected spec: PartialListItem;
  protected _context: StructureContext;
  constructor(
  /**
   * Structure context. See {@link StructureContext}
   */

  _context: StructureContext, spec?: ListItemInput);
  /**
   * Set list item ID
   * @returns list item builder based on ID provided. See {@link ListItemBuilder}
   */
  id(id: string): ListItemBuilder;
  /**
   * Get list item ID
   * @returns list item ID. See {@link PartialListItem}
   */
  getId(): PartialListItem['id'];
  /**
   * Set list item title
   * @returns list item builder based on title provided. See {@link ListItemBuilder}
   */
  title(title: string): ListItemBuilder;
  /**
   * Get list item title
   * @returns list item title. See {@link PartialListItem}
   */
  getTitle(): PartialListItem['title'];
  /** Set the i18n key and namespace used to populate the localized title.
   * @param i18n - the key and namespaced used to populate the localized title.
   * @returns component builder based on i18n key and ns provided
   */
  i18n(i18n: I18nTextRecord$1<'title'>): ListItemBuilder;
  /** Get i18n key and namespace used to populate the localized title
   * @returns the i18n key and namespace used to populate the localized title
   */
  getI18n(): I18nTextRecord$1<'title'> | undefined;
  /**
   * Set list item icon
   * @returns list item builder based on icon provided. See {@link ListItemBuilder}
   */
  icon(icon: React.ComponentType | React.ReactNode): ListItemBuilder;
  /**
   * Set if list item should show icon
   * @returns list item builder based on showIcon provided. See {@link ListItemBuilder}
   */
  showIcon(enabled?: boolean): ListItemBuilder;
  /**
   * Check if list item should show icon
   * @returns true if it should show the icon, false if not, undefined if not set
   */
  getShowIcon(): boolean | undefined;
  /**
   *Get list item icon
   * @returns list item icon. See {@link PartialListItem}
   */
  getIcon(): PartialListItem['icon'];
  /**
   * Set list item child
   * @param child - list item child. See {@link UnserializedListItemChild}
   * @returns list item builder based on child provided. See {@link ListItemBuilder}
   */
  child(child: UnserializedListItemChild): ListItemBuilder;
  /**
   * Get list item child
   * @returns list item child. See {@link PartialListItem}
   */
  getChild(): PartialListItem['child'];
  /**
   * Set list item schema type
   * @param schemaType - list item schema type. See {@link SchemaType}
   * @returns list item builder based on schema type provided. See {@link ListItemBuilder}
   */
  schemaType(schemaType: SchemaType | string): ListItemBuilder;
  /**
   * Get list item schema type
   * @returns list item schema type. See {@link PartialListItem}
   */
  getSchemaType(): PartialListItem['schemaType'];
  /** Serialize list item builder
   * @param options - serialization options. See {@link ListItemSerializeOptions}
   * @returns list item node based on path provided in options. See {@link ListItem}
   */
  serialize(options?: ListItemSerializeOptions): ListItem;
  /** Clone list item builder
   * @param withSpec - partial list item options. See {@link PartialListItem}
   * @returns list item builder based on context and spec provided. See {@link ListItemBuilder}
   */
  clone(withSpec?: PartialListItem): ListItemBuilder;
}
/**
 * Interface for document list item input
 *
 * @public
 */
interface DocumentListItemInput extends ListItemInput {
  /** Document list item input schema type. See {@link SchemaType} */
  schemaType: SchemaType | string;
}
/**
 * Interface for document list item
 *
 * @public
 */
interface DocumentListItem extends ListItem {
  /** Document schema type. See {@link SchemaType} */
  schemaType: SchemaType;
  /** Document ID */
  _id: string;
}
/**
 * Partial document list item
 *
 * @public
 */
type PartialDocumentListItem = Partial<UnserializedListItem>;
/**
 * Class for building a document list item
 *
 * @public
 */
declare class DocumentListItemBuilder extends ListItemBuilder {
  /** Document list options. See {@link PartialDocumentListItem} */
  protected spec: PartialDocumentListItem;
  protected _context: StructureContext;
  constructor(
  /**
   * Structure context. See {@link StructureContext}
   */

  _context: StructureContext, spec?: DocumentListItemInput);
  /**
   * Serialize document list item
   * @param options - serialization options. See {@link SerializeOptions}
   * @returns document list item object based on path provided in options. See {@link DocumentListItem}
   */
  serialize(options?: SerializeOptions): DocumentListItem;
  /** Clone Document list item builder (allows for options overriding)
   * @param withSpec - Document list item builder options. See {@link PartialDocumentListItem}
   * @returns document list item builder. See {@link DocumentListItemBuilder}
   */
  clone(withSpec?: PartialDocumentListItem): DocumentListItemBuilder;
}
/** @internal */
declare function isDocumentListItem(item: unknown): item is DocumentListItem;
/**
 * Interface for document type list input
 *
 * @public
 */
interface DocumentTypeListInput extends Partial<GenericListInput> {
  /** Document type list input schema type. See {@link SchemaType} */
  schemaType: SchemaType | string;
}
/**
 * Class for building a document type list
 *
 * @public
 */
declare class DocumentTypeListBuilder extends DocumentListBuilder {
  /** Document list options. See {@link PartialDocumentList} */
  protected spec: PartialDocumentList;
  protected _context: StructureContext;
  constructor(
  /**
   * Structure context. See {@link StructureContext}
   */

  _context: StructureContext, spec?: DocumentListInput);
  /**
   * Set Document type list child
   * @param child - Child component. See {@link Child}
   * @returns document type list builder based on child component provided without default intent handler. See {@link DocumentTypeListBuilder}
   */
  child(child: Child): DocumentTypeListBuilder;
  /** Clone Document type list builder (allows for options overriding)
   * @param withSpec - Document type list builder options. See {@link PartialDocumentList}
   * @returns document type list builder. See {@link DocumentTypeListBuilder}
   */
  clone(withSpec?: PartialDocumentList): DocumentTypeListBuilder;
  /** Clone Document type list builder (allows for options overriding) and remove default intent handler
   * @param withSpec - Document type list builder options. See {@link PartialDocumentList}
   * @returns document type list builder without default intent handler. See {@link DocumentTypeListBuilder}
   */
  cloneWithoutDefaultIntentHandler(withSpec?: PartialDocumentList): DocumentTypeListBuilder;
}
/**
 * Interface for List
 *
 * @public
 */
interface List extends GenericList {
  type: 'list';
  /** List items. See {@link ListItem} and {@link Divider} */
  items: (ListItem | Divider)[];
}
/**
 * Interface for list input
 *
 * @public
 */
interface ListInput extends GenericListInput {
  /** List input items array. See {@link ListItem}, {@link ListItemBuilder} and {@link Divider} */
  items?: (ListItem | ListItemBuilder | Divider | DividerBuilder)[];
}
/**
 * Interface for buildable list
 *
 * @public
 */
interface BuildableList extends BuildableGenericList {
  /** List items. See {@link ListItem}, {@link ListItemBuilder} and {@link Divider} */
  items?: (ListItem | ListItemBuilder | Divider | DividerBuilder)[];
}
/**
 * A `ListBuilder` is used to build a list of items in the structure tool.
 *
 * @public */
declare class ListBuilder extends GenericListBuilder<BuildableList, ListBuilder> {
  /** buildable list option object. See {@link BuildableList} */
  protected spec: BuildableList;
  protected _context: StructureContext;
  constructor(
  /**
   * Structure context. See {@link StructureContext}
   */

  _context: StructureContext, spec?: ListInput);
  /**
   * Set list builder based on items provided
   * @param items - list items. See {@link ListItemBuilder}, {@link ListItem} and {@link Divider}
   * @returns list builder based on items provided. See {@link ListBuilder}
   */
  items(items: (ListItemBuilder | ListItem | Divider | DividerBuilder)[]): ListBuilder;
  /** Get list builder items
   * @returns list items. See {@link BuildableList}
   */
  getItems(): BuildableList['items'];
  /** Serialize list builder
   * @param options - serialization options. See {@link SerializeOptions}
   * @returns list based on path in options. See {@link List}
   */
  serialize(options?: SerializeOptions): List;
  /**
   * Clone list builder and return new list builder based on context and spec provided
   * @param withSpec - list options. See {@link BuildableList}
   * @returns new list builder based on context and spec provided. See {@link ListBuilder}
   */
  clone(withSpec?: BuildableList): ListBuilder;
}
/**
 * View. See {@link FormView} and {@link ComponentView}
 *
 * @public
 */
type View = FormView | ComponentView;
/**
 * User view component
 *
 * @public */
type UserViewComponent<TOptions = Record<string, any>> = React.ComponentType<{
  document: {
    draft: SanityDocument | null;
    displayed: Partial<SanityDocument>;
    historical: Partial<SanityDocument> | null;
    published: SanityDocument | null;
  };
  documentId: string;
  options: TOptions;
  schemaType: SchemaType;
}>;
/**
 * User defined component
 *
 * @public
 */
type UserComponent = React.ComponentType<{
  /** Component child. See {@link ComponentBuilder} */child?: ComponentBuilder; /** Component child item ID */
  childItemId?: string; /** Component ID */
  id: string; /** Is component active */
  isActive?: boolean; /** Is component selected */
  isSelected?: boolean; /** item ID */
  itemId: string; /** Component options */
  options?: Record<string, unknown>; /** Pane key */
  paneKey: string; /** URL parameters */
  urlParams: Record<string, string | undefined> | undefined;
}>;
/**
 * Interface for the structure builder context.
 *
 * @public
 */
interface StructureContext extends Source {
  /** Resolve document method
   * @returns a document node builder, or null/undefined if no document node should be returned.
   * See {@link DocumentBuilder}
   */
  resolveDocumentNode: (/** an object holding the documentId and schemaType for the document node being resolved. */

  options: {
    documentId?: string;
    schemaType: string;
  }) => DocumentBuilder;
  /** Get structure builder
   * @returns a structure builder. See {@link StructureBuilder}
   */
  getStructureBuilder: () => StructureBuilder;
  /**
   * The stacked array of perspective ids ordered chronologically to represent the state of documents at the given point in time.
   * It can be used as the perspective param in the client to get the correct view of the documents.
   * ["published"] | ["drafts"] | ["releaseId2", "releaseId1", "drafts"]
   * See {@link PerspectiveStack}
   */
  perspectiveStack: PerspectiveStack;
}
/**
 * An object holding the documentId and schemaType for the document node being resolved.
 *
 * @public
 */
interface DefaultDocumentNodeContext extends ConfigContext {
  /**
   * The id of the sanity document
   */
  documentId?: string;
  /**
   * the schema of the sanity document
   */
  schemaType: string;
}
/**
 * A resolver function used to return the default document node used when editing documents.
 *
 * @public
 *
 * @returns a document node builder, or null/undefined if no document node should be returned.
 *
 */
type DefaultDocumentNodeResolver = (
/**
 * S - an instance of the structure builder, that can be used to build the lists/items/panes for the structure tool
 * context - an object holding various context that may be used to customize the structure, for instance the current user.
 *  Defaults to
 * ```ts
 * (S) => S.defaults()
 * ```
 * See {@link StructureBuilder}
 */

S: StructureBuilder,
/**
 * An object holding the documentId and schemaType for the document node being resolved.
 * See {@link DefaultDocumentNodeContext}
 */

options: DefaultDocumentNodeContext) => DocumentBuilder | null | undefined;
/**
 * Interface for the structure builder.
 *
 * @public
 */
interface StructureBuilder {
  /**
   * @internal
   */
  component: (spec?: ComponentInput | UserComponent) => ComponentBuilder;
  /** By giving an object of options with documentID and its schema type receive the the respective Document builder
   * @param options - an object holding the documentId and schemaType for the document node being resolved.
   * @returns a Document builder. See {@link DocumentBuilder}
   */
  defaultDocument: (options: {
    documentId?: string;
    schemaType: string;
  }) => DocumentBuilder;
  /** Get an array of Item builders that take Initial Value template into consideration
   * @returns an array of initial value template item builders. See {@link ListItemBuilder}
   */
  defaultInitialValueTemplateItems: () => InitialValueTemplateItemBuilder[];
  /** Get the default List builder
   * @returns a List builder. See {@link ListBuilder}
   */
  defaults: () => ListBuilder;
  /** Get a structure Divider
   * @returns a DividerBuilder. See {@link DividerBuilder}
   */
  divider: (spec?: Divider) => DividerBuilder;
  /** By giving a partial Document Node receive the respective Document Builder
   * @param spec - a partial document node. See {@link PartialDocumentNode}
   * @returns a Document builder. See {@link DocumentBuilder}
   */
  document: (spec?: PartialDocumentNode) => DocumentBuilder;
  /** By giving a Document List Input receive the respective Document List Builder
   * @param spec - a document list input. See {@link DocumentListInput}
   * @returns a Document List builder. See {@link DocumentListBuilder}
   */
  documentList: (spec?: DocumentListInput) => DocumentListBuilder;
  /** By giving a Document List Item Input receive the respective Document List Item builder
   * @param spec - a document list item input. See {@link DocumentListItemInput}
   * @returns a Document List Item builder. See {@link DocumentListItemBuilder}
   */
  documentListItem: (spec?: DocumentListItemInput) => DocumentListItemBuilder;
  /** By giving a type name or Document Type List Input receive the respective Document List Builder
   * @param typeNameOrSpec - a type name or a document type list input. See {@link DocumentTypeListInput}
   * @returns a Document List builder. See {@link DocumentListBuilder}
   */
  documentTypeList: (typeNameOrSpec: string | DocumentTypeListInput) => DocumentListBuilder;
  /** By providing a type name receive a List Item builder
   * @param typeName - a type name
   * @returns a List Item builder. See {@link ListItemBuilder}
   */
  documentTypeListItem: (typeName: string) => ListItemBuilder;
  /** Get an array of List Item builders
   * @returns an array of list item builders. See {@link ListItemBuilder}
   */
  documentTypeListItems: () => ListItemBuilder[];
  /** By giving a templateID and a set of parameters receive a Document builder that takes InitialValueTemplate into account
   * @param templateId - a template ID
   * @param parameters - an object of parameters
   * @returns a Document builder. See {@link DocumentBuilder}
   */
  documentWithInitialValueTemplate: (templateId: string, parameters?: Record<string, unknown>) => DocumentBuilder;
  /** By giving a Editor Node receive the respective Document Builder
   * @param spec - an editor node. See {@link EditorNode}
   * @returns a Document builder. See {@link DocumentBuilder}
   */
  editor: (spec?: EditorNode) => DocumentBuilder;
  /** By giving a templateID and a set of parameters receive an Item Builder that takes InitialValueTemplate into account
   * @param templateId - a template ID
   * @param parameters - an object of parameters
   * @returns an Item builder. See {@link ListItemBuilder}
   */
  initialValueTemplateItem: (templateId: string, parameters?: Record<string, any>) => InitialValueTemplateItemBuilder;
  /** By giving a List Input receive the respective Builder, otherwise return default ListBuilder builder
   * @param spec - a list input. See {@link ListInput}
   * @returns a List builder. See {@link ListBuilder}
   */
  list: (spec?: ListInput) => ListBuilder;
  /** By giving a List Item Input receive the respective Builder, otherwise return default ListItem builder
   * @param spec - a list item input. See {@link ListItemInput}
   * @returns a List Item builder. See {@link ListItemBuilder}
   */
  listItem: (spec?: ListItemInput) => ListItemBuilder;
  /** By giving a Menu Item receive the respective Builder, otherwise return default MenuItem builder
   * @param spec - a menu item. See {@link MenuItem}
   * @returns a Menu Item builder. See {@link MenuItemBuilder}
   */
  menuItem: (spec?: MenuItem) => MenuItemBuilder;
  /** By giving a Menu Item Group receive the respective Builder
   * @param spec - a menu item group. See {@link MenuItemGroup}
   * @returns a Menu Item Group builder. See {@link MenuItemGroupBuilder}
   */
  menuItemGroup: (spec?: MenuItemGroup) => MenuItemGroupBuilder;
  /** By giving an array of initial value template receive an array of Menu Items, otherwise return default MenuItem builder
   * @param templateItems - an array of initial value template items. See {@link InitialValueTemplateItem}
   * @returns an array of Menu Items. See {@link MenuItem}
   */
  menuItemsFromInitialValueTemplateItems: (templateItems: InitialValueTemplateItem[]) => MenuItem[];
  /** By giving a sort ordering object receive a Menu Item Builder
   * @param ordering - a sort ordering object. See {@link SortOrdering}
   * @returns a Menu Item builder. See {@link MenuItemBuilder}
   */
  orderingMenuItem: (ordering: SortOrdering) => MenuItemBuilder;
  /** By giving a type receive a list of Menu Items ordered by it
   * @param type - a type
   * @returns an array of Menu Items. See {@link MenuItem}
   */
  orderingMenuItemsForType: (type: string) => MenuItemBuilder[];
  /** View for structure */
  view: {
    /** form for view
     * @param spec - a partial form view. See {@link FormView}
     * @returns a Form View builder. See {@link FormViewBuilder}
     */
    form: (spec?: Partial<FormView>) => FormViewBuilder;
    /** component for view
     * @param componentOrSpec - a partial component view or a React component. See {@link ComponentView}
     * @returns a Component View builder. See {@link ComponentViewBuilder}
     */
    component: (componentOrSpec?: Partial<ComponentView> | React.ComponentType<any>) => ComponentViewBuilder;
  };
  /** Context for the structure builder. See {@link StructureContext} */
  context: StructureContext;
}
/** @internal */
declare function maybeSerializeMenuItem(item: MenuItem | MenuItemBuilder, index: number, path: SerializePath): MenuItem;
/**
 * Menu item action type
 * @public */
type MenuItemActionType = string | ((params: Record<string, unknown> | undefined, scope?: unknown) => void);
/**
 * Known menu item parameters that control built-in behavior.
 * These properties have specific meanings in the structure builder.
 *
 * @public */
interface KnownMenuItemParams {
  /**
   * When true, hides all visual indicators showing this menu item is selected.
   * This includes both the checkmark icon and the pressed/selected styling.
   * The item can still be selected - this only affects the visual feedback.
   * Useful when you want the menu item to perform an action without showing a selection state.
   */
  hideSelectionIndicator?: boolean;
  /**
   * The value to associate with this menu item for tracking selected state.
   * Used with the 'setMenuItemState' action for custom toggle behavior.
   * When a menu item is clicked, this value is stored against the menu item's `id`.
   * Defaults to `true` if not specified.
   */
  value?: unknown;
  /**
   * Layout key for layout switching menu items.
   * Used with the 'setLayout' action.
   */
  layout?: string;
  /**
   * Sort ordering configuration for sort menu items.
   * Used with the 'setSortOrder' action.
   */
  by?: SortOrderingItem[];
  /**
   * Extended projection string for sort ordering.
   * Used internally for sort menu items.
   */
  extendedProjection?: string;
}
/**
 * Menu items parameters.
 * Includes known parameters that control built-in behavior,
 * plus allows additional custom parameters.
 *
 * @public */
type MenuItemParamsType = KnownMenuItemParams & Record<string, unknown>;
/**
 * Interface for menu items
 *
 * @public */
interface MenuItem {
  /**
   * Unique identifier for the menu item.
   * Used for tracking selected state of custom menu items.
   * Menu items with the same id will share selected state (like radio buttons).
   */
  id?: string;
  /**
   * The i18n key and namespace used to populate the localized title. This is
   * the recommend way to set the title if you are localizing your studio.
   */
  i18n?: I18nTextRecord$1<'title'>;
  /**
   * Menu Item title. Note that the `i18n` configuration will take
   * precedence and this title is left here as a fallback if no i18n key is
   * provided and compatibility with older plugins
   */
  title: string;
  /** Menu Item action */
  action?: MenuItemActionType;
  /** Menu Item intent */
  intent?: Intent;
  /** Menu Item group */
  group?: string;
  /** Menu Item icon */
  icon?: React.ComponentType | React.ReactNode;
  /** Menu Item parameters. See {@link MenuItemParamsType} */
  params?: MenuItemParamsType;
  /** Determine if it will show the MenuItem as action */
  showAsAction?: boolean;
}
/**
 * Partial menu items
 * @public
 */
type PartialMenuItem = Partial<MenuItem>;
/**
 * Class for building menu items.
 *
 * @public */
declare class MenuItemBuilder implements Serializable<MenuItem> {
  /** menu item option object. See {@link PartialMenuItem} */
  protected spec: PartialMenuItem;
  protected _context: StructureContext;
  constructor(
  /**
   * Structure context. See {@link StructureContext}
   */

  _context: StructureContext, spec?: MenuItem);
  /**
   * Set menu item id for tracking selected state.
   * Menu items with the same id will share selected state (like radio buttons).
   * Use with action 'setMenuItemState' to enable automatic selected state tracking.
   * @param id - unique identifier for the menu item
   * @returns menu item builder based on id provided. See {@link MenuItemBuilder}
   */
  id(id: string): MenuItemBuilder;
  /**
   * Get menu item id
   * @returns menu item id. See {@link PartialMenuItem}
   */
  getId(): PartialMenuItem['id'];
  /**
   * Set menu item action
   * @param action - menu item action. See {@link MenuItemActionType}
   * @returns menu item builder based on action provided. See {@link MenuItemBuilder}
   */
  action(action: MenuItemActionType): MenuItemBuilder;
  /**
   * Get menu item action
   * @returns menu item builder action. See {@link PartialMenuItem}
   */
  getAction(): PartialMenuItem['action'];
  /**
   * Set menu item intent
   * @param intent - menu item intent. See {@link Intent}
   * @returns menu item builder based on intent provided. See {@link MenuItemBuilder}
   */
  intent(intent: Intent): MenuItemBuilder;
  /**
   * Get menu item intent
   * @returns menu item intent. See {@link PartialMenuItem}
   */
  getIntent(): PartialMenuItem['intent'];
  /**
   * Set menu item title
   * @param title - menu item title
   * @returns menu item builder based on title provided. See {@link MenuItemBuilder}
   */
  title(title: string): MenuItemBuilder;
  /**
   * Get menu item title. Note that the `i18n` configuration will take
   * precedence and this title is left here for compatibility.
   * @returns menu item title
   */
  getTitle(): string | undefined;
  /**
   * Set the i18n key and namespace used to populate the localized title.
   * @param i18n - object with i18n key and related namespace
   * @returns menu item builder based on i18n config provided. See {@link MenuItemBuilder}
   */
  i18n(i18n: I18nTextRecord$1<'title'>): MenuItemBuilder;
  /**
   * Get the i18n key and namespace used to populate the localized title.
   * @returns the i18n key and namespace used to populate the localized title.
   */
  getI18n(): I18nTextRecord$1<'title'> | undefined;
  /**
   * Set menu item group
   * @param group - menu item group
   * @returns menu item builder based on group provided. See {@link MenuItemBuilder}
   */
  group(group: string): MenuItemBuilder;
  /**
   * Get menu item group
   * @returns menu item group. See {@link PartialMenuItem}
   */
  getGroup(): PartialMenuItem['group'];
  /**
   * Set menu item icon
   * @param icon - menu item icon
   * @returns menu item builder based on icon provided. See {@link MenuItemBuilder}
   */
  icon(icon: React.ComponentType | React.ReactNode): MenuItemBuilder;
  /**
   * Get menu item icon
   * @returns menu item icon. See {@link PartialMenuItem}
   */
  getIcon(): PartialMenuItem['icon'];
  /**
   * Set menu item parameters
   * @param params - menu item parameters. See {@link MenuItemParamsType}
   * @returns menu item builder based on parameters provided. See {@link MenuItemBuilder}
   */
  params(params: MenuItemParamsType): MenuItemBuilder;
  /**
   * Get meny item parameters
   * @returns menu item parameters. See {@link PartialMenuItem}
   */
  getParams(): PartialMenuItem['params'];
  /**
   * Set menu item to show as action
   * @param showAsAction - determine if menu item should show as action
   * @returns menu item builder based on if it should show as action. See {@link MenuItemBuilder}
   */
  showAsAction(showAsAction?: boolean): MenuItemBuilder;
  /**
   * Check if menu item should show as action
   * @returns true if menu item should show as action, false if not. See {@link PartialMenuItem}
   */
  getShowAsAction(): PartialMenuItem['showAsAction'];
  /** Serialize menu item builder
   * @param options - serialization options. See {@link SerializeOptions}
   * @returns menu item node based on path provided in options. See {@link MenuItem}
   */
  serialize(options?: SerializeOptions): MenuItem;
  /** Clone menu item builder
   * @param withSpec - menu item options. See {@link PartialMenuItem}
   * @returns menu item builder based on context and spec provided. See {@link MenuItemBuilder}
   */
  clone(withSpec?: PartialMenuItem): MenuItemBuilder;
}
/** @internal */
interface SortMenuItem extends MenuItem {
  params: {
    by: SortOrderingItem[];
  };
}
/** @internal */
declare function getOrderingMenuItem(context: StructureContext, {
  by,
  title,
  i18n
}: SortOrdering, extendedProjection?: string): MenuItemBuilder;
/** @internal */
declare function getOrderingMenuItemsForSchemaType(context: StructureContext, typeName: SchemaType | string): MenuItemBuilder[];
/**
 * Interface for component
 *
 * @public
 */
interface Component$1 extends StructureNode {
  /** Component of type {@link UserComponent} */
  component: UserComponent;
  /** Component child of type {@link Child} */
  child?: Child;
  /** Component menu items, array of type {@link MenuItem} */
  menuItems: MenuItem[];
  /** Component menu item group, array of type {@link MenuItemGroup} */
  menuItemGroups: MenuItemGroup[];
  /** Component options */
  options: {
    [key: string]: unknown;
  };
  canHandleIntent?: IntentChecker;
}
/**
 * Interface for component input
 *
 * @public
 */
interface ComponentInput extends StructureNode {
  /** Component of type {@link UserComponent} */
  component: UserComponent;
  /** Component child of type {@link Child} */
  child?: Child;
  /** Component options */
  options?: {
    [key: string]: unknown;
  };
  /** Component menu items. See {@link MenuItem} and {@link MenuItemBuilder}  */
  menuItems?: (MenuItem | MenuItemBuilder)[];
  /** Component menu item groups. See {@link MenuItemGroup} and {@link MenuItemGroupBuilder} */
  menuItemGroups?: (MenuItemGroup | MenuItemGroupBuilder)[];
}
/**
 * Interface for buildable component
 *
 * @public
 */
interface BuildableComponent extends Partial<StructureNode> {
  /** Component of type {@link UserComponent} */
  component?: UserComponent;
  /** Component child of type {@link Child} */
  child?: Child;
  /** Component options */
  options?: {
    [key: string]: unknown;
  };
  /** Component menu items. See {@link MenuItem} and {@link MenuItemBuilder}  */
  menuItems?: (MenuItem | MenuItemBuilder)[];
  /** Component menu item groups. See {@link MenuItemGroup} and {@link MenuItemGroupBuilder} */
  menuItemGroups?: (MenuItemGroup | MenuItemGroupBuilder)[];
  canHandleIntent?: IntentChecker;
}
/**
 * Class for building components
 *
 * @public
 */
declare class ComponentBuilder implements Serializable<Component$1> {
  /** component builder option object */
  protected spec: BuildableComponent;
  constructor(spec?: ComponentInput);
  /** Set Component ID
   * @param id - component ID
   * @returns component builder based on ID provided
   */
  id(id: string): ComponentBuilder;
  /** Get ID
   * @returns ID
   */
  getId(): BuildableComponent['id'];
  /** Set Component title
   * @param title - component title
   * @returns component builder based on title provided (and ID)
   */
  title(title: string): ComponentBuilder;
  /** Get Component title
   * @returns title
   */
  getTitle(): BuildableComponent['title'];
  /** Set the i18n key and namespace used to populate the localized title.
   * @param i18n - the key and namespaced used to populate the localized title.
   * @returns component builder based on i18n key and ns provided
   */
  i18n(i18n: I18nTextRecord$1<'title'>): ComponentBuilder;
  /** Get i18n key and namespace used to populate the localized title
   * @returns the i18n key and namespace used to populate the localized title
   */
  getI18n(): I18nTextRecord$1<'title'> | undefined;
  /** Set Component child
   * @param child - child component
   * @returns component builder based on child component provided
   */
  child(child: Child): ComponentBuilder;
  /** Get Component child
   * @returns child component
   */
  getChild(): BuildableComponent['child'];
  /** Set component
   * @param component - user built component
   * @returns component builder based on component provided
   */
  component(component: UserComponent): ComponentBuilder;
  /** Get Component
   * @returns component
   */
  getComponent(): BuildableComponent['component'];
  /** Set Component options
   * @param options - component options
   * @returns component builder based on options provided
   */
  options(options: {
    [key: string]: unknown;
  }): ComponentBuilder;
  /** Get Component options
   * @returns component options
   */
  getOptions(): NonNullable<BuildableComponent['options']>;
  /** Set Component menu items
   * @param menuItems - component menu items
   * @returns component builder based on menuItems provided
   */
  menuItems(menuItems: (MenuItem | MenuItemBuilder)[]): ComponentBuilder;
  /** Get Component menu items
   * @returns menu items
   */
  getMenuItems(): BuildableComponent['menuItems'];
  /** Set Component menu item groups
   * @param menuItemGroups - component menu item groups
   * @returns component builder based on menuItemGroups provided
   */
  menuItemGroups(menuItemGroups: (MenuItemGroup | MenuItemGroupBuilder)[]): ComponentBuilder;
  /** Get Component menu item groups
   * @returns menu item groups
   */
  getMenuItemGroups(): BuildableComponent['menuItemGroups'];
  canHandleIntent(canHandleIntent: IntentChecker): ComponentBuilder;
  /** Serialize component
   * @param options - serialization options
   * @returns component object based on path provided in options
   *
   */
  serialize(options?: SerializeOptions): Component$1;
  /** Clone component builder (allows for options overriding)
   * @param withSpec - component builder options
   * @returns cloned builder
   */
  clone(withSpec?: BuildableComponent): ComponentBuilder;
}
/**
 * Interface for the structure builder node.
 *
 * @public
 */
interface StructureNode {
  /** Node ID */
  id: string;
  /** Node ID */
  title?: string;
  i18n?: I18nTextRecord$1<'title'>;
  /** Node type */
  type?: string;
}
/**
 * Interface for the document list builder (focused on the document pane)
 *
 * @public */
interface DocumentNode extends StructureNode {
  /**
   * Document children. See {@link Child}
   */
  child?: Child;
  /**
   * Options for the document pane
   */
  options: {
    /** Document Id */id: string; /** Document Type */
    type?: string; /** Document Template */
    template?: string; /** Template parameters */
    templateParameters?: {
      [key: string]: any;
    };
  };
  /**
   * View array for the document pane. See {@link View}
   */
  views: View[];
  /**
   * View IDs to open as split panes by default when the document is opened.
   * Only populated if 2+ valid view IDs are configured.
   */
  defaultPanes?: string[];
}
/**
 * Interface for Editor node
 *
 * @public */
interface EditorNode extends StructureNode {
  /** Editor child. See {@link Child} */
  child?: Child;
  /** Editor options */
  options: {
    /** Editor ID */id: string; /** Editor type */
    type?: string; /** Editor template */
    template?: string; /** Template parameters */
    templateParameters?: {
      [key: string]: any;
    };
  };
}
/**
 * A `Divider` is a visual separator in the structure tree.
 *
 * @public
 */
interface Divider {
  /**
   * The divider's ID
   */
  id: string;
  type: 'divider';
  /**
   * The divider's title
   */
  title?: string;
  /**
   * The i18n key and namespace used to populate the localized title
   */
  i18n?: I18nTextRecord$1<'title'>;
}
/**
 * Path of a serialized structure node
 *
 * @public
 */
type SerializePath = (string | number)[];
/**
 * Interface for seraializing a structure node
 * @public */
interface SerializeOptions {
  /** path. See {@link SerializePath} */
  path: SerializePath;
  /** index */
  index?: number;
  /** hint */
  hint?: string;
}
/**
 *  A interface for serializing a structure node to a plain JavaScript object.
 *
 * @public
 */
interface Serializable<T> {
  serialize(options: SerializeOptions): T;
}
/**
 * Collection
 * See {@link List}, {@link DocumentList}, {@link EditorNode}, {@link DocumentNode} and {@link Component}
 *
 * @public
 */
type Collection = List | DocumentList | EditorNode | DocumentNode | Component$1;
/**
 * Collection builder
 * See {@link ListBuilder}, {@link DocumentListBuilder}, {@link DocumentTypeListBuilder}, {@link DocumentBuilder} and {@link ComponentBuilder}
 *
 * @public
 */
type CollectionBuilder = ListBuilder | DocumentListBuilder | DocumentTypeListBuilder | DocumentBuilder | ComponentBuilder;
/**
 * Child of a structure node
 * See {@link Collection}, {@link CollectionBuilder} and {@link ChildResolver}
 *
 * @public
 */
type Child = Collection | CollectionBuilder | ChildResolver;
/** @internal */
type Builder = CollectionBuilder | ComponentBuilder | DocumentBuilder | DocumentListBuilder | DocumentListItemBuilder | ListItemBuilder | MenuItemBuilder | MenuItemGroupBuilder | InitialValueTemplateItemBuilder;
/**
 * Interface for child resolver options
 *
 * @public
 */
interface ChildResolverOptions {
  /** Child parent */
  parent: unknown;
  /** Child index */
  index: number;
  splitIndex: number;
  /** Child path */
  path: string[];
  /** Child parameters */
  params: Record<string, string | undefined>;
  /** Structure context. See {@link StructureContext} */
  structureContext: StructureContext;
  /** Serialize options. See {@link SerializeOptions} */
  serializeOptions?: SerializeOptions;
}
/**
 * Item Child. See {@link CollectionBuilder} and {@link Collection}
 *
 * @public
 */
type ItemChild = CollectionBuilder | Collection | undefined;
/**
 * Interface for child observable
 *
 * @public
 */
interface ChildObservable {
  /** Subscribes to the child observable. See {@link ItemChild} */
  subscribe: (child: ItemChild | Promise<ItemChild>) => Record<string, unknown>;
}
/**
 * Interface for child resolver
 *
 * @public */
interface ChildResolver {
  (itemId: string, options: ChildResolverOptions): ItemChild | Promise<ItemChild> | ChildObservable | Observable<ItemChild> | undefined;
}
/** @internal */
interface StructureBuilderOptions {
  source: Source;
  defaultDocumentNode?: DefaultDocumentNodeResolver;
  perspectiveStack: PerspectiveStack;
}
/** @internal */
declare function createStructureBuilder({
  defaultDocumentNode,
  source,
  perspectiveStack
}: StructureBuilderOptions): StructureBuilder;
/** @internal */
declare class SerializeError extends Error {
  readonly path: SerializePath;
  helpId?: (typeof HELP_URL)[keyof typeof HELP_URL];
  constructor(message: string, parentPath: SerializePath, pathSegment: string | number | undefined, hint?: string);
  withHelpUrl(id: (typeof HELP_URL)[keyof typeof HELP_URL]): SerializeError;
}
/** @internal */
declare const HELP_URL: {
  ID_REQUIRED: "structure-node-id-required";
  TITLE_REQUIRED: "structure-title-required";
  FILTER_REQUIRED: "structure-filter-required";
  INVALID_LIST_ITEM: "structure-invalid-list-item";
  COMPONENT_REQUIRED: "structure-view-component-required";
  DOCUMENT_ID_REQUIRED: "structure-document-id-required";
  DOCUMENT_TYPE_REQUIRED: "structure-document-type-required";
  SCHEMA_TYPE_REQUIRED: "structure-schema-type-required";
  SCHEMA_TYPE_NOT_FOUND: "structure-schema-type-not-found";
  LIST_ITEMS_MUST_BE_ARRAY: "structure-list-items-must-be-array";
  QUERY_PROVIDED_FOR_FILTER: "structure-query-provided-for-filter";
  ACTION_OR_INTENT_REQUIRED: "structure-action-or-intent-required";
  LIST_ITEM_IDS_MUST_BE_UNIQUE: "structure-list-item-ids-must-be-unique";
  ACTION_AND_INTENT_MUTUALLY_EXCLUSIVE: "structure-action-and-intent-mutually-exclusive";
  API_VERSION_REQUIRED_FOR_CUSTOM_FILTER: "structure-api-version-required-for-custom-filter";
};
/** @internal */
declare const form: (spec?: Partial<FormView> | undefined) => FormViewBuilder;
/** @internal */
declare const component: (componentOrSpec?: Partial<ComponentView<Record<string, any>>> | UserViewComponent | undefined) => ComponentViewBuilder;
/**
 * @internal
 */
interface PaneData {
  maximized: boolean;
  element: HTMLElement;
  collapsed: boolean;
  currentMinWidth?: number;
  currentMaxWidth?: number;
  flex: number;
}
/**
 *
 * @hidden
 * @beta
 */
interface PaneContextValue {
  collapse: () => void;
  collapsed: boolean;
  expand: () => void;
  index?: number;
  isLast: boolean;
  rootElement: HTMLDivElement | null;
}
/**
 * @internal
 */
interface PaneConfigOpts {
  currentMinWidth?: number;
  currentMaxWidth?: number;
  flex: number;
  id: string;
  minWidth?: number;
  maxWidth?: number;
}
/**
 *
 * @hidden
 * @beta
 */
interface PaneLayoutContextValue {
  collapse: (element: HTMLElement) => void;
  collapsed?: boolean;
  expand: (element: HTMLElement) => void;
  expandedElement: HTMLElement | null;
  mount: (element: HTMLElement, opts: PaneConfigOpts) => () => void;
  resize: (type: 'start' | 'move' | 'end', element: HTMLElement, deltaX: number) => void;
  resizing: boolean;
  panes: PaneData[];
}
interface _PaneMenuItem {
  type: 'item';
  key: string;
  disabled?: boolean | {
    reason: ReactNode;
  };
  /** When true, hides all icon indicators showing this menu item is selected. */
  hideSelectionIndicator?: boolean;
  hotkey?: string;
  icon: ComponentType | ReactNode;
  iconRight?: ComponentType | ReactNode;
  intent?: Intent;
  onAction: () => void;
  renderAsButton: boolean;
  selected?: boolean;
  title?: string;
  i18n?: I18nTextRecord$1<'title'>;
  tone?: 'primary' | 'critical' | 'caution' | 'positive';
}
/** @internal */
interface StructureToolFeatures {
  /**
   * @hidden
   * @beta
   */
  backButton: boolean;
  resizablePanes: boolean;
  reviewChanges: boolean;
  splitPanes: boolean;
  splitViews: boolean;
}
/** @internal */
interface StructureToolContextValue {
  features: StructureToolFeatures;
  layoutCollapsed: boolean;
  setLayoutCollapsed: (layoutCollapsed: boolean) => void;
  rootPaneNode: UnresolvedPaneNode;
  structureContext: StructureContext;
}
/**
 *  Structure tool context. Extends from {@link ConfigContext}.
 *  @hidden
 *  @public
 */
interface StructureResolverContext extends ConfigContext {
  /**
   * This can be replaced by a different API in the future.
   * It is provided as-is to support common structure patterns found in V2 in V3.
   * @alpha
   * */
  documentStore: DocumentStore;
  /** @alpha */
  i18n: LocaleSource;
  /**
   * The stacked array of perspective ids ordered chronologically to represent the state of documents at the given point in time.
   * It can be used as the perspective param in the client to get the correct view of the documents.
   * ["published"] | ["drafts"] | ["releaseId2", "releaseId1", "drafts"]
   * See {@link PerspectiveStack}
   */
  perspectiveStack: PerspectiveStack;
}
/**
 * Lets you configure how lists, documents, views, menus, and initial value templates are organized in the Sanity Studio’s structure-tool.
 *
 * @public
 *
 * @returns A structure builder, or null/undefined if no structure should be returned. See {@link StructureBuilder}
 * @example Configuring structure
 * ```ts
 * // sanity.config.js
 *
 * import {defineConfig} from 'sanity'
 * import {structureTool} from 'sanity/structure'
 * import {schemaTypes} from './schema'
 *
 * export default defineConfig({
 *  name: 'default',
 *  title: 'My Cool Project',
 *  projectId: 'my-project-id',
 *  dataset: 'production',
 *  plugins: [
 *    structureTool({
 *      structure: (S, context) => {
 *        console.log(context) // returns { currentUser, dataset, projectId, schema, getClient, documentStore }
 *        return S.documentTypeList('post')
 *      },
 *    })
 *  ],
 *  schema: schemaTypes
 * })
 * ```
 *
 */
type StructureResolver = (
/**
 * S - An instance of the structure builder, that can be used to build the lists/items/panes for the structure tool
 * context - an object holding various context that may be used to customize the structure, for instance the current user.
 *  Defaults to
 * ```ts
 * (S) => S.defaults()
 * ```
 * See {@link StructureBuilder}
 */

S: StructureBuilder,
/**
 * An object containing pane and index information for the current structure tool.
 * See {@link StructureResolverContext}
 */

context: StructureResolverContext) => unknown;
/** @internal */
type StructureToolPaneActionHandler = (params: any, scope?: unknown) => void;
/**
 * The params for the `structureTool` api. See {@link structureTool}
 *
 * @public */
interface StructureToolOptions {
  icon?: React.ComponentType;
  name?: string;
  /**
   * A workspace can have different "sources". These sources were meant to allow using multiple datasets within the same workspace, for instance.
   * This is not supported yet, but the API is still here.
   *
    @hidden
    @alpha
  */
  source?: string;
  /**
   * A structure resolver function. See {@link StructureResolver}
   */
  structure?: StructureResolver;
  /**
   * A resolver function used to return the default document node used when editing documents. See {@link DefaultDocumentNodeResolver}
   */
  defaultDocumentNode?: DefaultDocumentNodeResolver;
  /**
   * The title that will be displayed for the tool. Defaults to Structure
   */
  title?: string;
}
/**
 * Represents the state of the `panes` inside the structure-tool router
 *
 * - The structure tool stores the state of the current panes inside of the router.
 * - The panes are stored in groups delimited in the URL by `;`.
 * - In each group, there can be one or more sibling (aka split) panes delimited
 *   by `|`.
 * - Each item pane can contain it's own parameters and payloads
 * - Per item pane in each group, if not specified separately, the ID, params,
 *   and payload will be inherited from the first item pane in the pane group
 *   (unless it's an `exclusiveParam`)
 *
 * E.g. `/structure/books;book-123|,view=preview` will parse to:
 *
 * ```js
 * [
 *   // first pane group
 *   [{id: 'book'}],
 *
 *   // second pane group
 *   [
 *     [
 *       // first pane item
 *       {id: 'book-123'},
 *       // second pane item
 *       {id: 'book-123', params: {view: 'preview'}},
 *     ],
 *   ],
 * ]
 * ```
 *
 * @hidden
 * @beta
 */
type RouterPanes = RouterPaneGroup[];
/**
 * Represents a "pane group" in the router.
 *
 * @see RouterPanes
 *
 *
 * @hidden
 * @beta
 */
type RouterPaneGroup = RouterPaneSibling[];
/**
 * Represents a "sibling pane" or "split pane" in the router.
 *
 * @see RouterPanes
 *
 *
 * @hidden
 * @beta
 */
interface RouterPaneSibling {
  id: string;
  params?: Record<string, string | undefined>;
  payload?: unknown;
}
/**
 * Passed as the second argument to the item of resolving pane children
 *
 * @see RouterPanes
 *
 * @internal
 */
interface RouterPaneSiblingContext {
  id: string;
  parent: PaneNode | null;
  index: number;
  splitIndex: number;
  path: string[];
  params: Record<string, string | undefined>;
  payload: unknown;
  structureContext: StructureContext;
  serializeOptions?: {
    path: (string | number)[];
    index?: number;
    hint?: string;
  };
}
/**
 * Represents what can be passed into `menuItems` inside of structure-tool panes
 *
 * @see BaseResolvedPaneNode
 *
 * @internal
 */
interface PaneMenuItem extends MenuItem {
  disabled?: _PaneMenuItem['disabled'];
  shortcut?: string;
  selected?: boolean;
  tone?: 'primary' | 'positive' | 'caution' | 'critical';
}
/** @internal */
interface PaneMenuItemGroup {
  id: string;
  title?: string;
  i18n?: I18nTextRecord$1<'title'>;
}
/** @internal */
interface BaseResolvedPaneNode<T extends PaneNode['type']> {
  id: string;
  type: T;
  title: string;
  i18n?: I18nTextRecord$1<'title'>;
  menuItems?: PaneMenuItem[];
  menuItemGroups?: PaneMenuItemGroup[];
  canHandleIntent?: (intentName: string, params: Record<string, string | undefined>, options: {
    pane: PaneNode;
    index: number;
  }) => boolean;
  child?: UnresolvedPaneNode;
}
/** @internal */
interface CustomComponentPaneNode extends BaseResolvedPaneNode<'component'> {
  component: UserComponent;
  options?: Record<string, unknown>;
}
/** @internal */
interface DocumentPaneNode extends BaseResolvedPaneNode<'document'> {
  options: {
    id: string;
    type: string;
    template?: string;
    templateParameters?: Record<string, unknown>;
  };
  source?: string;
  views?: View[];
  /**
   * View IDs to open as split panes by default when the document is opened.
   * Only populated if 2+ valid view IDs are configured.
   */
  defaultPanes?: string[];
}
/** @internal */
interface DocumentListPaneNode extends BaseResolvedPaneNode<'documentList'> {
  defaultLayout?: GeneralPreviewLayoutKey;
  displayOptions?: {
    showIcons?: boolean;
  };
  initialValueTemplates?: InitialValueTemplateItem[];
  options: {
    filter: string;
    defaultOrdering?: Array<{
      field: string;
      direction: 'asc' | 'desc';
    }>;
    params?: Record<string, unknown>;
    apiVersion?: string;
  };
  schemaTypeName: string;
  source?: string;
}
/** @internal */
interface PaneListItem<TParams = unknown> {
  type: 'listItem';
  id: string;
  _id?: string;
  schemaType?: SchemaType;
  title: string;
  i18n?: I18nTextRecord$1<'title'>;
  icon?: React.ComponentType | false;
  displayOptions?: {
    showIcon?: boolean;
  };
  action?: (t: TParams) => unknown;
  params?: TParams;
}
/** @internal */
interface PaneListItemDivider {
  type: 'divider';
  /**
   * The title of the divider.
   */
  title?: string;
  /**
   * The i18n key and namespace used to populate the localized title
   */
  i18n?: I18nTextRecord$1<'title'>;
}
/** @internal */
interface ListPaneNode extends BaseResolvedPaneNode<'list'> {
  defaultLayout?: GeneralPreviewLayoutKey;
  displayOptions?: {
    showIcons?: boolean;
  };
  items?: Array<PaneListItem | PaneListItemDivider>;
  source?: string;
}
/** @internal */
type PaneNode = CustomComponentPaneNode | DocumentPaneNode | DocumentListPaneNode | ListPaneNode;
/** @internal */
type SerializablePaneNode = {
  serialize(context: RouterPaneSiblingContext): UnresolvedPaneNode;
};
/** @internal */
type PaneNodeResolver = (id: string, context: RouterPaneSiblingContext) => UnresolvedPaneNode;
/** @internal */
type UnresolvedPaneNode = PaneNodeResolver | SerializablePaneNode | Observable<UnresolvedPaneNode> | PromiseLike<UnresolvedPaneNode> | PaneNode;
/**
 * @hidden
 * @beta */
type DocumentFieldMenuActionNode = DocumentFieldActionNode & {
  intent?: Intent;
};
/**
 * @internal
 */
interface StrictVersionLayeringOptions$1 {
  /**
   * By default, version layering includes all document versions, regardless of their expected
   * publication time—or lack thereof. For example, it includes all ASAP and undecided versions,
   * despite ASAP and undecided versions having no fixed chronology. There is no way to determine
   * which ASAP or undecided version is expected to be published before another.
   *
   * It also includes any existing draft, which has no fixed chronology, either.
   *
   * This functionality is useful for listing all document versions in a deterministic order, but
   * doesn't accurately portray the upstream and downstream versions based on expected publication
   * time.
   *
   * In strict mode, version layering instead only includes versions that have a fixed chronology.
   * **Cross-version layering is only effective for scheduled versions, with all other
   * versions being layered directly onto the published version (if it exists).**
   */
  strict?: boolean;
}
/** @internal */
interface DocumentPaneContextValue extends Pick<NodeChronologyProps, 'hasUpstreamVersion'> {
  actions: DocumentActionComponent[] | null;
  activeViewId: string | null;
  badges: DocumentBadgeComponent[] | null;
  changesOpen: boolean;
  closeInspector: (inspectorName?: string) => void;
  collapsedFieldSets: StateTree<boolean> | undefined;
  collapsedPaths: StateTree<boolean> | undefined;
  compareValue: SanityDocument | null;
  connectionState: 'connecting' | 'reconnecting' | 'connected';
  displayed: Partial<SanityDocument> | null;
  displayInlineChanges?: boolean;
  documentId: string;
  documentIdRaw: string;
  documentType: string;
  editState: EditStateFor | null;
  fieldActions: DocumentFieldAction[];
  focusPath: Path;
  index: number;
  inspectOpen: boolean;
  inspector: DocumentInspector | null;
  inspectors: DocumentInspector[];
  menuItemGroups: PaneMenuItemGroup[];
  onBlur: (blurredPath: Path) => void;
  onChange: (event: PatchEvent) => void;
  onFocus: (pathOrEvent: Path) => void;
  onHistoryClose: () => void;
  onHistoryOpen: () => void;
  onInspectClose: () => void;
  onMenuAction: (item: PaneMenuItem) => void;
  onPaneClose: () => void;
  onPaneSplit?: () => void;
  onPathOpen: (path: Path) => void;
  onSetActiveFieldGroup: (path: Path, groupName: string) => void;
  onSetCollapsedPath: (path: Path, expanded: boolean) => void;
  onSetCollapsedFieldSet: (path: Path, expanded: boolean) => void;
  onSetMaximizedPane?: () => void;
  maximized: boolean;
  openInspector: (inspectorName: string, paneParams?: Record<string, string>) => void;
  openPath: Path;
  paneKey: string;
  previewUrl?: string | null;
  ready: boolean;
  schemaType: ObjectSchemaType;
  /**
   * @deprecated not used anymore
   * */
  setTimelineMode?: undefined;
  /**
   * @deprecated not used anymore
   * */
  timelineMode?: undefined;
  setTimelineRange(since: string | null, rev: string | null): void;
  setIsDeleting: (state: boolean) => void;
  timelineError: Error | null;
  /**
   * Soon to be deprecated with the upcoming `releases` changes.
   */
  timelineStore?: TimelineStore;
  title: string | null;
  validation: ValidationMarker[];
  value: SanityDocumentLike;
  views: View[];
  formState: DocumentFormNode | null;
  /**
   * TODO: COREL - Remove this after updating sanity-assist to use <PerspectiveProvider>
   *
   * @deprecated use `usePerspective()` instead
   */
  selectedReleaseId: ReleaseId | undefined;
  permissions?: PermissionCheckResult | null;
  isDeleting: boolean;
  isDeleted: boolean;
  isPermissionsLoading: boolean;
  isInitialValueLoading?: boolean;
  unstable_languageFilter: DocumentLanguageFilterComponent[];
  revisionId: string | null;
  revisionNotFound: boolean;
  lastNonDeletedRevId: string | null;
  lastRevisionDocument: SanityDocument | null;
}
/** @internal */
type DocumentPaneInfoContextValue = Pick<DocumentPaneContextValue, 'actions' | 'badges' | 'documentId' | 'documentIdRaw' | 'documentType' | 'fieldActions' | 'index' | 'menuItemGroups' | 'maximized' | 'onPaneClose' | 'onPaneSplit' | 'onSetMaximizedPane' | 'paneKey' | 'schemaType' | 'title' | 'views' | 'unstable_languageFilter'>;
/**
 * @hidden
 * @beta */
interface ChildLinkProps {
  childId: string;
  childParameters?: Record<string, string>;
  childPayload?: unknown;
  children?: ReactNode;
}
/**
 * @hidden
 * @beta */
interface BackLinkProps {
  children?: ReactNode;
}
/**
 * @hidden
 * @beta */
interface ReferenceChildLinkProps {
  documentId: string;
  documentType: string;
  parentRefPath: Path;
  template?: {
    id: string;
    params?: Record<string, string | number | boolean>;
  };
  children: ReactNode;
}
/**
 * @hidden
 * @beta */
interface ParameterizedLinkProps {
  params?: Record<string, string>;
  payload?: unknown;
}
/**
 * @hidden
 * @beta */
interface EditReferenceOptions {
  parentRefPath: Path;
  id: string;
  type: string;
  version?: ReleaseId;
  template: {
    id: string;
    params?: Record<string, string | number | boolean>;
  };
}
/**
 * @hidden
 * @beta */
interface PaneRouterContextValue {
  /**
   * Zero-based index (position) of pane, visually
   */
  index: number;
  /**
   * Zero-based index of pane group (within URL structure)
   */
  groupIndex: number;
  /**
   * Zero-based index of pane within sibling group
   */
  siblingIndex: number;
  /**
   * Payload of the current pane
   */
  payload?: unknown;
  /**
   * Params of the current pane
   */
  params?: RouterPaneSibling['params'];
  /**
   * Whether or not the pane has any siblings (within the same group)
   */
  hasGroupSiblings: boolean;
  /**
   * The length of the current group
   */
  groupLength: number;
  /**
   * Current router state for the "panes" property
   */
  routerPanesState: RouterPanes;
  /**
   * Curried StateLink that passes the correct state automatically
   */
  ChildLink: ComponentType<ChildLinkProps>;
  /**
   * Curried StateLink that pops off the last pane group
   */
  BackLink?: ComponentType<BackLinkProps>;
  /**
   * A specialized `ChildLink` that takes in the needed props to open a
   * referenced document to the right
   */
  ReferenceChildLink: ComponentType<ReferenceChildLinkProps>;
  /**
   * Similar to `ReferenceChildLink` expect without the wrapping component
   */
  handleEditReference: (options: EditReferenceOptions) => void;
  /**
   * Curried StateLink that passed the correct state, but merges params/payload
   */
  ParameterizedLink: ComponentType<ParameterizedLinkProps>;
  /**
   * Replaces the current pane with a new one
   */
  replaceCurrent: (pane: {
    id?: string;
    payload?: unknown;
    params?: Record<string, string>;
  }) => void;
  /**
   * Removes the current pane from the group
   */
  closeCurrent: () => void;
  /**
   * Removes all panes to the right including current pane
   */
  closeCurrentAndAfter: (expandLast?: boolean) => void;
  /**
   * Duplicate the current pane, with optional overrides for item ID and parameters
   */
  duplicateCurrent: (pane?: {
    payload?: unknown;
    params?: Record<string, string>;
  }) => void;
  /**
   * Set the current "view" for the pane
   */
  setView: (viewId: string | null) => void;
  /**
   * Set the parameters for the current pane
   */
  setParams: (params: Record<string, string | undefined>, stickyParams?: Record<string, string>) => void;
  /**
   * Set the payload for the current pane
   */
  setPayload: (payload: unknown) => void;
  /**
   * A function that creates a path with the given parameters without navigating to it.
   * Useful for creating links that can be e.g. copied to clipboard and shared.
   */
  createPathWithParams: (params: Record<string, string | undefined>) => string;
  /**
   * Proxied navigation to a given intent. Consider just exposing `router` instead?
   */
  navigateIntent: (intentName: string, params: Record<string, string>, options?: {
    replace?: boolean;
  }) => void;
}
export { Serializable as $, GenericListBuilder as $t, StructureToolFeatures as A, DocumentListItem as At, StructureBuilderOptions as B, ListItemSerializeOptions as Bt, RouterPaneSiblingContext as C, BaseIntentParams as Cn, View as Ct, StructureResolver as D, IntentJsonParams as Dn, ListInput as Dt, StrictVersionLayeringOptions$1 as E, IntentChecker as En, ListBuilder as Et, PaneLayoutContextValue as F, ListItem as Ft, ItemChild as G, DocumentListBuilder as Gt, ChildObservable as H, UnserializedListItem as Ht, component as I, ListItemBuilder as It, Collection as J, PartialDocumentList as Jt, Builder as K, DocumentListInput as Kt, form as L, ListItemChild as Lt, StructureToolPaneActionHandler as M, DocumentListItemInput as Mt, UnresolvedPaneNode as N, PartialDocumentListItem as Nt, StructureResolverContext as O, IntentParams as On, DocumentTypeListBuilder as Ot, PaneContextValue as P, isDocumentListItem as Pt, EditorNode as Q, GenericList as Qt, HELP_URL as R, ListItemDisplayOptions as Rt, RouterPaneSibling as S, ComponentViewBuilder as Sn, UserViewComponent as St, SerializablePaneNode as T, Intent as Tn, List as Tt, ChildResolver as U, UnserializedListItemChild as Ut, createStructureBuilder as V, PartialListItem as Vt, ChildResolverOptions as W, DocumentList as Wt, Divider as X, BaseGenericList as Xt, CollectionBuilder as Y, getTypeNamesFromFilter as Yt, DocumentNode as Z, BuildableGenericList as Zt, PaneMenuItem as _, ViewBuilder as _n, DefaultDocumentNodeContext as _t, ParameterizedLinkProps as a, maybeSerializeMenuItemGroup as an, ComponentBuilder as at, PaneNodeResolver as b, FormViewBuilder as bn, StructureContext as bt, DocumentPaneInfoContextValue as c, maybeSerializeInitialValueTemplateItem as cn, MenuItem as ct, DocumentFieldMenuActionNode as d, DocumentOptions as dn, MenuItemParamsType as dt, GenericListInput as en, SerializeOptions as et, DocumentListPaneNode as f, PartialDocumentNode as fn, PartialMenuItem as ft, PaneListItemDivider as g, GenericViewBuilder as gn, maybeSerializeMenuItem as gt, PaneListItem as h, BaseView as hn, getOrderingMenuItemsForSchemaType as ht, PaneRouterContextValue as i, MenuItemGroupBuilder as in, Component$1 as it, StructureToolOptions as j, DocumentListItemBuilder as jt, StructureToolContextValue as k, defaultIntentChecker as kn, DocumentTypeListInput as kt, BaseResolvedPaneNode as l, menuItemsFromInitialValueTemplateItems as ln, MenuItemActionType as lt, ListPaneNode as m, documentFromEditorWithInitialValue as mn, getOrderingMenuItem as mt, ChildLinkProps as n, shallowIntentChecker as nn, StructureNode as nt, ReferenceChildLinkProps as o, InitialValueTemplateItemBuilder as on, ComponentInput as ot, DocumentPaneNode as p, documentFromEditor as pn, SortMenuItem as pt, Child as q, DocumentListOptions as qt, EditReferenceOptions as r, MenuItemGroup as rn, BuildableComponent as rt, DocumentPaneContextValue as s, defaultInitialValueTemplateItems as sn, KnownMenuItemParams as st, BackLinkProps as t, ListDisplayOptions as tn, SerializePath as tt, CustomComponentPaneNode as u, DocumentBuilder as un, MenuItemBuilder as ut, PaneMenuItemGroup as v, maybeSerializeView as vn, DefaultDocumentNodeResolver as vt, RouterPanes as w, DEFAULT_INTENT_HANDLER as wn, BuildableList as wt, RouterPaneGroup as x, ComponentView as xn, UserComponent as xt, PaneNode as y, FormView as yn, StructureBuilder as yt, SerializeError as z, ListItemInput as zt };